"""KherveAI chat box — the family assistant panel, wired for CAD.

Same design as KherveAI in KherveFitting: multiple AI providers
(Claude / Mistral / Ollama Cloud) behind one chat panel, API keys per
provider (settings dialog or environment variables), and slash
commands that drive the app directly without any network.

The CAD twist: the assistant always sees the current OpenSCAD
program, and when it replies with a fenced ``scad`` code block the
panel offers to apply it — the block is parsed by the .scad importer
straight into the object tree, so the assistant can build and edit
geometry with the full tool set.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import base64
import html
import json
import os
import re
import urllib.error
import urllib.request

from PyQt5.QtCore import (QBuffer, QByteArray, QSettings, Qt, QThread,
                          QUrl, pyqtSignal)
from PyQt5.QtGui import QImage, QKeySequence, QTextDocument
from PyQt5.QtWidgets import (QApplication, QComboBox, QDialog,
                             QDialogButtonBox, QFileDialog, QFormLayout,
                             QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                             QPushButton, QTextBrowser, QToolButton,
                             QVBoxLayout, QWidget)

from . import icons

_SETTINGS = ("Kherve", "KherveCAD")

#: AI provider options and their models — same structure as the
#: KherveAI family modules.
AI_PROVIDERS = {
    "Claude": {
        "api_url": "https://api.anthropic.com/v1/messages",
        "models": [
            "claude-opus-4-5",
            "claude-sonnet-4-5",
            "claude-haiku-4-5",
        ],
        "requires_key": True,
        "key_env": "ANTHROPIC_API_KEY",
        "key_url": "https://console.anthropic.com/settings/keys",
        "header_format": "x-api-key",
    },
    "OpenAI": {
        "api_url": "https://api.openai.com/v1/chat/completions",
        "models": [
            "gpt-5.1", "gpt-5", "gpt-4.1", "gpt-4o", "gpt-4o-mini",
            "o3", "o4-mini",
        ],
        "requires_key": True,
        "key_env": "OPENAI_API_KEY",
        "key_url": "https://platform.openai.com/api-keys",
        "header_format": "Bearer",
    },
    "Mistral": {
        "api_url": "https://api.mistral.ai/v1/chat/completions",
        "models": [
            "mistral-large-latest", "mistral-small-latest",
        ],
        "requires_key": True,
        "key_env": "MISTRAL_API_KEY",
        "key_url": "https://console.mistral.ai/api-keys/",
        "header_format": "Bearer",
    },
    "Ollama (Cloud)": {
        "api_url": "https://ollama.com/api/chat",
        "models": [
            "gpt-oss:120b-cloud", "gpt-oss:20b-cloud",
            "deepseek-v3.1:671b-cloud", "llama3.3:70b-cloud",
        ],
        "requires_key": True,
        "key_env": "OLLAMA_API_KEY",
        "key_url": "https://ollama.com/settings/keys",
        "header_format": "Bearer",
    },
}

#: Upper bound on the reply length we ask the model for. Set high so
#: long programs and explanations are never truncated; providers clamp
#: it to whatever the chosen model actually supports.
#: Room for the reply. A whole part program plus its explanation runs
#: long, and a truncated reply is a broken `scad` block that will not
#: parse — so this is set well above what a normal answer needs, but
#: inside the output ceiling of every model offered above.
MAX_TOKENS = 16000
TEMPERATURE = 0.7

#: Rough English chars-per-token, used only to keep the running
#: conversation inside a model's context window.
_CHARS_PER_TOKEN = 4
#: Keep as much of the conversation as fits in this many tokens of
#: history, so the assistant remembers the whole session — only the
#: oldest turns are dropped, and only once it would overflow a large
#: model's context window. (The true ceiling is whatever context window
#: the chosen model supports — e.g. ~200k tokens for Claude — so this
#: is generous headroom rather than a hard limit you will normally hit.)
HISTORY_TOKEN_BUDGET = 400000

#: The conversation is also saved between runs so the assistant picks up
#: where you left off. Persist at most this many characters (most recent
#: first) to keep the settings store small.
_PERSIST_CHARS = 200000


def _persist_enabled() -> bool:
    """Skip disk persistence under the offscreen test platform so the
    suite never reads or writes the user's real chat history."""
    return os.environ.get("QT_QPA_PLATFORM", "") != "offscreen"

SYSTEM_PROMPT = """\
You are the assistant inside KherveCAD — an easy-to-use CAD GUI with
OpenSCAD as the engine. The document is a tree of objects that maps
1:1 to an OpenSCAD program, editable in the Objects tree, the Code tab,
or by you.

When the user asks you to create or change geometry, reply with a
short explanation and ONE fenced code block tagged `scad` containing
the COMPLETE OpenSCAD program for the whole document (not a diff). The
app parses that block back into the object tree, so stay inside the
supported subset:
- shapes: circle(r/d,$fn,angle), square([w,h],center),
  polygon(points=[...]), text("s",size); cube([x,y,z]/size,center),
  sphere(r/d,$fn), cylinder(h,r1/r2 or d,$fn,center).
- transforms: translate/rotate/scale/mirror([x,y,z]) (rotate/scale
  also take a scalar), linear_extrude(height,twist,scale,center),
  rotate_extrude(angle,$fn), offset(r) / offset(delta,chamfer),
  projection(cut) (a 2D result — renders via OpenSCAD only).
- booleans: union/difference/intersection/hull/minkowski() {}.
- control: for (i = [a:s:b] | [v1,v2,...] | listvar), if (cond) {}
  else {}, name = value; assignments, `*` to disable.
- expressions: numbers, +-*/%^, comparisons, && ||, ternary c ? a : b,
  vectors [a,b,c] with v.x/.y/.z and v[i], ranges [a:s:b], and
  functions sin cos tan asin acos atan atan2 sqrt abs pow exp ln log
  min max floor ceil round sign norm len (trig in degrees).
- user module(){} definitions with parameters ARE supported — the app
  inlines each call; nested modules too. import("file.stl") works.
- KherveCAD helpers: kcad_sweep(path=[[x,y,z],...], smooth=3, twist=0,
  scale=1, wall=0, closed=false) { 2D profile } drives a profile along
  a 3D path (pipes with wall>0, handrails, springs, O-rings with
  closed=true); kcad_loft(sections=[[x,y,z,rx,ry],...]) is a tube
  through elliptical sections; kcad_section_loft(heights=[[z0],[z1],...],
  smooth=0) { one 2D shape per section, in order } lofts through shapes
  WITH CORNERS — a car body, a boat hull (rotate it to lie along X); kcad_pattern(kind="linear"|"polar"|"grid",
  count=6, step=[dx,dy,dz], angle=360, axis="z", rise=0,
  counts=[nx,ny,nz]) { ... } repeats its children (a bolt circle: polar,
  angle 360 spreads count copies evenly, below 360 they span the angle;
  a spiral stair: polar with rise); kcad_shell(thickness=2, open="top")
  { ... } hollows a solid into an even-walled shell (open="none" for a
  closed hollow); kcad_fillet(radius=2, kind="round",
  edges=[[x1,y1,z1,x2,y2,z2],...]) { ... } rounds the edges listed
  (their start and end points). Prefer these to chains of hull().
Avoid: function definitions, children()/$children, use/include,
recursion, and list comprehensions [for ...]. If the user needs those,
tell them to open the file directly (KherveCAD keeps it as a raw
OpenSCAD block that the engine renders).

Name every piece: end EVERY shape line (each cube, sphere, cylinder…)
with a short comment saying which part of the model it is, e.g.
`cube([4, 4, 12]);  // Front-left leg` or `sphere(1.5);  // Left eye`,
and label blocks on their opening line (`for (i = [0:3]) {  // Legs`).
A labelled block is not enough — each shape inside needs its own label.
The tree then reads "Cube [Front-left leg]" instead of rows of bare
"Cube". Plain words, 2-5 of them, one statement per line; no banner
comments like `// ---- Legs ----` and no sizes in the label.

Explain parts and masters: a module() without parameters becomes an
**Object** (a part, edited in the Object tab and placed as instances in
Main); a Master (Masters tab) is reused through Linked copies. Most users
do not know these terms, so whenever your program creates one, say in
one or two plain sentences what you made, why, and where to find it —
e.g. "I built the leg once as an Object and placed it four times, so
editing it in the Object tab changes all four legs."

Sizes are in the document's unit, stated with every message
(millimetres unless it says otherwise). Prefer named variables (and vectors like
size=[x,y,z]) for key dimensions so parts stay parametric. The user's
current program is provided with every message — modify it rather than
starting over, unless asked.

KherveCAD splits **parts from assemblies**, and which one you are
writing is stated with every message:
- **Object mode** (the Object tab is open on one part): your program is
  the CONTENTS of that part. Build it out of ordinary shapes,
  transforms and booleans so every step shows as a row in the Object
  tree — that tree IS how the user reads and edits the part, so keep
  the structure explicit, one step per node, rather than collapsing
  everything into one clever expression. Do not wrap the
  result in a module or place copies of it; the app supplies the
  part's own placement in the assembly.
- **Main mode** (the Main tab): your program is the whole assembly —
  parts and their placements. A part built here lands as one row; to
  work on how a part is MADE, the user must switch to the Object tab
  (Object mode) first. Say so when they ask you to change the inside
  of a part while Main is current.

If the user attaches an image or screenshot, study it and reproduce the
object as faithfully as you can in 3D: identify the primitive shapes,
their proportions and how they combine, estimate sensible millimetre
dimensions, and emit a `scad` program that recreates it. Say briefly
what you saw and note any assumptions you made about size.

App features you can explain if asked: the Objects / Masters /
Variables / Code tabs (Masters holds reusable definitions placed as
Linked copies); the Library menu examples (Learn tutorials, Mechanical parts,
Showcase); the Library menu of parametric parts (CF/KF flanges,
fasteners, chemistry & room items); the Git menu (Commit Ctrl+K, Push,
Pull) for the current .kcad's folder; F5 to render with OpenSCAD;
opening/importing .kcad/.scad and meshes (.stl/.obj/.off/.3mf) via
File > Open or drag-and-drop;
and File > New Window for a second document.
"""


def get_api_key(provider: str) -> str:
    """Provider key from settings, falling back to the environment."""
    settings = QSettings(*_SETTINGS)
    key = settings.value(f"chat/api_keys/{provider}", "") or ""
    if not key:
        env = AI_PROVIDERS.get(provider, {}).get("key_env")
        key = os.environ.get(env, "") if env else ""
    return key


def set_api_key(provider: str, key: str):
    QSettings(*_SETTINGS).setValue(f"chat/api_keys/{provider}", key)


def get_models(provider: str) -> list:
    """The model list for *provider*: a previously refreshed list from
    settings, else the built-in defaults."""
    cached = QSettings(*_SETTINGS).value(f"chat/models/{provider}", None)
    if isinstance(cached, str):                # a lone entry round-trips
        cached = [cached]                      # as a bare string
    if cached:
        return [str(m) for m in cached]
    return list(AI_PROVIDERS.get(provider, {}).get("models", []))


def set_models(provider: str, models: list):
    QSettings(*_SETTINGS).setValue(f"chat/models/{provider}",
                                   list(models))


#: Where each provider lists its available models (GET, same auth as
#: the chat endpoint).
_MODELS_URLS = {
    "Claude": "https://api.anthropic.com/v1/models",
    "OpenAI": "https://api.openai.com/v1/models",
    "Mistral": "https://api.mistral.ai/v1/models",
    "Ollama (Cloud)": "https://ollama.com/api/tags",
}


def _keep_model(provider: str, model_id: str) -> bool:
    """Drop non-chat models the list endpoints also return."""
    lid = model_id.lower()
    if provider == "OpenAI":
        return lid.startswith(("gpt", "o1", "o3", "o4", "chatgpt"))
    if provider == "Mistral":
        return not any(bad in lid for bad in
                       ("embed", "ocr", "moderation"))
    return True


def fetch_models(provider: str, key: str) -> list:
    """Live model ids from the provider's list endpoint."""
    url = _MODELS_URLS.get(provider)
    if not url:
        return []
    config = AI_PROVIDERS[provider]
    headers = {}
    if config["header_format"] == "Bearer":
        headers["Authorization"] = f"Bearer {key}"
    elif config["header_format"] == "x-api-key":
        headers["x-api-key"] = key
        headers["anthropic-version"] = "2023-06-01"
    request = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(request, timeout=30) as reply:
        payload = json.loads(reply.read().decode())
    if provider == "Ollama (Cloud)":
        items = payload.get("models", [])
        ids = [m.get("name") or m.get("model") for m in items]
    else:
        items = payload.get("data", [])
        ids = [m.get("id") for m in items]
    return [i for i in ids if i and _keep_model(provider, i)]


def _attach_images(provider: str, messages, images):
    """Return a copy of *messages* with *images* merged into the most
    recent user turn, in the shape each provider's vision API expects.
    Each image is a dict ``{"media_type", "data"}`` (base64 PNG)."""
    if not images:
        return messages
    msgs = [dict(m) for m in messages]
    idx = next((i for i in range(len(msgs) - 1, -1, -1)
                if msgs[i].get("role") == "user"), None)
    if idx is None:
        return msgs
    text = msgs[idx].get("content", "")
    if provider == "Claude":
        content = [{"type": "image",
                    "source": {"type": "base64",
                               "media_type": im["media_type"],
                               "data": im["data"]}} for im in images]
        content.append({"type": "text", "text": text})
        msgs[idx] = {"role": "user", "content": content}
    elif provider == "Ollama (Cloud)":
        msgs[idx] = {"role": "user", "content": text,
                     "images": [im["data"] for im in images]}
    else:                                   # OpenAI / Mistral vision
        content = [{"type": "text", "text": text}]
        for im in images:
            content.append({"type": "image_url", "image_url": {
                "url": f"data:{im['media_type']};base64,{im['data']}"}})
        msgs[idx] = {"role": "user", "content": content}
    return msgs


def build_request(provider: str, model: str, messages, system: str,
                  images=None):
    """Request body per provider — same formats as KherveAI. When
    *images* are given they are attached to the latest user message."""
    messages = _attach_images(provider, messages, images)
    if provider == "Claude":
        return {"model": model, "messages": messages,
                "max_tokens": MAX_TOKENS, "system": system,
                "stream": False}
    if provider == "Ollama (Cloud)":
        return {"model": model, "stream": False,
                "messages": [{"role": "system", "content": system}]
                + messages,
                "options": {"temperature": TEMPERATURE}}
    # OpenAI / Mistral (OpenAI-style chat/completions)
    body = {"model": model,
            "messages": [{"role": "system", "content": system}]
            + messages}
    # OpenAI reasoning models (o-series, gpt-5) use a different token
    # field and reject a custom temperature
    if provider == "OpenAI" and model.startswith(("o1", "o3", "o4",
                                                  "gpt-5")):
        body["max_completion_tokens"] = MAX_TOKENS
    else:
        body["temperature"] = TEMPERATURE
        body["max_tokens"] = MAX_TOKENS
    return body


def parse_reply(provider: str, payload: dict) -> str:
    if provider == "Claude":
        return "".join(part.get("text", "")
                       for part in payload.get("content", []))
    if provider == "Ollama (Cloud)":
        return payload.get("message", {}).get("content", "")
    choices = payload.get("choices", [])
    return choices[0]["message"]["content"] if choices else ""


class ChatWorker(QThread):
    """One request to the selected provider, off the GUI thread."""

    replied = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, provider, model, key, messages, system,
                 images=None, parent=None):
        super().__init__(parent)
        self.provider, self.model, self.key = provider, model, key
        self.messages, self.system = messages, system
        self.images = images or []

    def run(self):
        config = AI_PROVIDERS[self.provider]
        headers = {"Content-Type": "application/json"}
        if config["header_format"] == "Bearer":
            headers["Authorization"] = f"Bearer {self.key}"
        elif config["header_format"] == "x-api-key":
            headers["x-api-key"] = self.key
            headers["anthropic-version"] = "2023-06-01"
        body = build_request(self.provider, self.model, self.messages,
                             self.system, self.images)
        request = urllib.request.Request(
            config["api_url"], data=json.dumps(body).encode(),
            headers=headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=180) as reply:
                payload = json.loads(reply.read().decode())
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode()[:300]
            except Exception:
                pass
            self.failed.emit(f"HTTP {exc.code}: {detail or exc.reason}")
            return
        except Exception as exc:
            self.failed.emit(str(exc))
            return
        text = parse_reply(self.provider, payload)
        if text:
            self.replied.emit(text)
        else:
            self.failed.emit("empty reply from provider")


class ModelListWorker(QThread):
    """Fetch a provider's model list off the GUI thread."""

    loaded = pyqtSignal(list)
    failed = pyqtSignal(str)

    def __init__(self, provider, key, parent=None):
        super().__init__(parent)
        self.provider, self.key = provider, key

    def run(self):
        try:
            models = fetch_models(self.provider, self.key)
        except urllib.error.HTTPError as exc:
            self.failed.emit(f"HTTP {exc.code}: {exc.reason}")
            return
        except Exception as exc:
            self.failed.emit(str(exc))
            return
        if models:
            self.loaded.emit(models)
        else:
            self.failed.emit("no models returned")


class ChatConfigDialog(QDialog):
    """Provider / model / API key settings (persisted via QSettings)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Assistant settings")
        self._mworker = None
        settings = QSettings(*_SETTINGS)

        self.provider = QComboBox()
        self.provider.addItems(list(AI_PROVIDERS))
        self.provider.setCurrentText(
            settings.value("chat/provider", "Claude"))
        self.provider.currentTextChanged.connect(self._provider_changed)

        self.model = QComboBox()
        self.refresh_btn = QToolButton()
        self.refresh_btn.setIcon(icons.icon("mdi.refresh"))
        self.refresh_btn.setToolTip(
            "Refresh — fetch the latest models from the provider")
        self.refresh_btn.clicked.connect(self._refresh_models)
        model_row = QHBoxLayout()
        model_row.setContentsMargins(0, 0, 0, 0)
        model_row.addWidget(self.model, 1)
        model_row.addWidget(self.refresh_btn)

        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.Password)
        self.key_link = QLabel()
        self.key_link.setOpenExternalLinks(True)
        self.status = QLabel()
        self.status.setStyleSheet("color:#888888")

        form = QFormLayout(self)
        form.addRow("Provider", self.provider)
        form.addRow("Model", model_row)
        form.addRow("API key", self.key)
        form.addRow("", self.key_link)
        form.addRow("", self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok
                                   | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        self._provider_changed(self.provider.currentText())
        saved_model = settings.value("chat/model", "")
        if saved_model:
            index = self.model.findText(saved_model)
            if index >= 0:
                self.model.setCurrentIndex(index)

    def _provider_changed(self, provider):
        config = AI_PROVIDERS[provider]
        self.model.clear()
        self.model.addItems(get_models(provider))
        self.key.setText(get_api_key(provider))
        self.key.setPlaceholderText(
            f"or set {config['key_env']} in the environment")
        self.key_link.setText(
            f'<a href="{config["key_url"]}">Get a key</a>')
        self.status.clear()

    def _refresh_models(self):
        provider = self.provider.currentText()
        key = self.key.text().strip() or get_api_key(provider)
        if AI_PROVIDERS[provider]["requires_key"] and not key:
            self.status.setText("Enter the API key first, then refresh.")
            return
        self.refresh_btn.setEnabled(False)
        self.status.setText(f"Fetching {provider} models…")
        self._mworker = ModelListWorker(provider, key, self)
        self._mworker.loaded.connect(self._models_loaded)
        self._mworker.failed.connect(self._models_failed)
        self._mworker.finished.connect(
            lambda: self.refresh_btn.setEnabled(True))
        self._mworker.start()

    def _models_loaded(self, models):
        provider = self.provider.currentText()
        set_models(provider, models)
        current = self.model.currentText()
        self.model.clear()
        self.model.addItems(models)
        index = self.model.findText(current)
        if index >= 0:
            self.model.setCurrentIndex(index)
        self.status.setText(f"{len(models)} models loaded.")

    def _models_failed(self, message):
        self.status.setText("Couldn't fetch models: " + message)

    def _save(self):
        settings = QSettings(*_SETTINGS)
        provider = self.provider.currentText()
        settings.setValue("chat/provider", provider)
        settings.setValue("chat/model", self.model.currentText())
        set_api_key(provider, self.key.text().strip())
        self.accept()


_SCAD_BLOCK_RE = re.compile(r"```(?:scad|openscad)\s*\n(.*?)```",
                            re.DOTALL)

_IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp")


def _qimage_to_png_b64(image: QImage) -> str:
    """Base64-encode a QImage as PNG (the wire format for every vision
    API we support)."""
    store = QByteArray()                  # must outlive the QBuffer that
    buffer = QBuffer(store)               # only holds a pointer to it
    buffer.open(QBuffer.WriteOnly)
    image.save(buffer, "PNG")
    buffer.close()
    return base64.b64encode(bytes(store)).decode("ascii")


def _images_from_mime(mime) -> list:
    """Every image a drop/paste carries: a raw bitmap and/or image
    files referenced by URL."""
    out = []
    if mime.hasImage():
        image = QImage(mime.imageData())
        if not image.isNull():
            out.append(image)
    if mime.hasUrls():
        for url in mime.urls():
            path = url.toLocalFile()
            if path.lower().endswith(_IMAGE_EXTS):
                image = QImage(path)
                if not image.isNull():
                    out.append(image)
    return out


class ChatInput(QLineEdit):
    """Message box that recalls previously sent lines with Up/Down,
    shell-style — the same feel as KherveAI elsewhere in the family.
    Pasting (Ctrl+V) or dropping an image attaches it to the next
    message via :attr:`image_added`."""

    image_added = pyqtSignal(object)          # a QImage

    def __init__(self, parent=None):
        super().__init__(parent)
        self._history = []
        self._index = 0                       # len == "composing new"
        self._draft = ""                      # text held while browsing
        self.setAcceptDrops(True)

    def remember(self, text):
        """Record a just-sent line and reset the browse cursor."""
        if text and (not self._history or self._history[-1] != text):
            self._history.append(text)
        self._index = len(self._history)
        self._draft = ""

    def load_history(self, lines):
        """Seed the Up/Down history from a previous run."""
        self._history = list(lines)
        self._index = len(self._history)
        self._draft = ""

    def recent_history(self, limit):
        """The most recent typed lines, for persistence."""
        return self._history[-limit:]

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Paste):
            image = QApplication.clipboard().image()
            if not image.isNull():            # a bitmap on the clipboard
                self.image_added.emit(image)
                return
        if event.key() == Qt.Key_Up:
            self._browse(-1)
        elif event.key() == Qt.Key_Down:
            self._browse(1)
        else:
            super().keyPressEvent(event)

    def dragEnterEvent(self, event):
        if _images_from_mime(event.mimeData()):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if _images_from_mime(event.mimeData()):
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        images = _images_from_mime(event.mimeData())
        if images:
            for image in images:
                self.image_added.emit(image)
            event.acceptProposedAction()
        else:
            super().dropEvent(event)

    def _browse(self, step):
        if not self._history:
            return
        if self._index == len(self._history) and step < 0:
            self._draft = self.text()         # keep the unsent draft
        new = max(0, min(self._index + step, len(self._history)))
        self._index = new
        self.setText(self._draft if new == len(self._history)
                     else self._history[new])
        self.end(False)                       # cursor to end of line


class ChatPanel(QWidget):
    """The KherveAI chat box, docked in the main window."""

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.window = window                  # MainWindow
        self.history = []                     # [{"role", "content"}]
        self._blocks = []                     # scad blocks by index
        self._worker = None
        self._pending_images = []             # {"media_type","data","thumb"}
        self._thumb_seq = 0                   # unique transcript image keys

        header = QHBoxLayout()
        title = QLabel("<b>Assistant</b> — CAD helper")
        settings_btn = QToolButton()
        settings_btn.setIcon(icons.icon("mdi.cog-outline"))
        settings_btn.setToolTip("Provider, model and API key")
        settings_btn.clicked.connect(self.open_settings)
        header.addWidget(QLabel())
        header.itemAt(0).widget().setPixmap(
            icons.icon("mdi.robot-outline").pixmap(20, 20))
        header.addWidget(title)
        header.addStretch()
        header.addWidget(settings_btn)

        self.transcript = QTextBrowser()
        self.transcript.setOpenLinks(False)
        self.transcript.anchorClicked.connect(self._anchor_clicked)

        self.input = ChatInput()
        self.input.setPlaceholderText(
            "Ask, paste an image to reproduce, or /help for commands")
        self.input.returnPressed.connect(self.send)
        self.input.image_added.connect(self._attach_image)
        self.attach_btn = QToolButton()
        self.attach_btn.setIcon(icons.icon("mdi.image-plus"))
        self.attach_btn.setToolTip(
            "Attach an image for the assistant to reproduce "
            "(you can also paste or drop one)")
        self.attach_btn.clicked.connect(self._attach_from_file)
        self.send_btn = QPushButton(icons.icon("mdi.send-outline"), "")
        self.send_btn.setToolTip("Send")
        self.send_btn.clicked.connect(self.send)

        self.attach_info = QLabel()
        self.attach_info.setStyleSheet("color:#2176c7")
        self.attach_info.setVisible(False)
        self.attach_info.linkActivated.connect(self._clear_attachments)

        input_row = QHBoxLayout()
        input_row.addWidget(self.attach_btn)
        input_row.addWidget(self.input)
        input_row.addWidget(self.send_btn)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.addLayout(header)
        layout.addWidget(self.transcript, 1)
        layout.addWidget(self.attach_info)
        layout.addLayout(input_row)

        if _persist_enabled():
            self._load_state()
        else:
            self._welcome()

    # -------------------------------------------------------- persistence
    def _welcome(self):
        self._append_note(
            "Hi! I can answer questions and build geometry — when I "
            "design a part it is applied straight to the document "
            "(Ctrl+Z to undo). Type <b>/help</b> for app commands.")

    def _load_state(self):
        """Restore the previous conversation and the Up/Down input
        history saved on the last run."""
        settings = QSettings(*_SETTINGS)
        try:
            saved = json.loads(settings.value("chat/history", "") or "[]")
        except Exception:
            saved = []
        try:
            typed = json.loads(
                settings.value("chat/input_history", "") or "[]")
        except Exception:
            typed = []
        self.input.load_history([str(t) for t in typed if t])
        self.history = [m for m in saved if isinstance(m, dict)
                        and m.get("role") and "content" in m]
        if self.history:
            self._replay_transcript()
            self._append_note(
                "↺ Restored your previous conversation — I still "
                "remember it. Type <b>/clear</b> to start fresh.")
        else:
            self._welcome()

    def _save_state(self):
        if not _persist_enabled():
            return
        # keep the most recent messages within the persistence budget
        kept, total = [], 0
        for message in reversed(self.history):
            total += len(message.get("content", ""))
            if total > _PERSIST_CHARS and kept:
                break
            kept.insert(0, message)
        settings = QSettings(*_SETTINGS)
        settings.setValue("chat/history", json.dumps(kept))
        settings.setValue("chat/input_history",
                          json.dumps(self.input.recent_history(200)))

    def _replay_transcript(self):
        """Redraw the restored conversation in the transcript."""
        for message in self.history:
            if message["role"] == "user":
                self._append("user", html.escape(message["content"]))
            elif message["role"] == "assistant":
                prose = _SCAD_BLOCK_RE.sub("", message["content"]).strip()
                self._append("assistant", html.escape(
                    prose or message["content"]).replace("\n", "<br>"))

    # ------------------------------------------------------- transcript
    def _append(self, role, html_text):
        colors = {"user": "#2176c7", "assistant": "#2e7d4f",
                  "note": "#888888"}
        who = {"user": "You", "assistant": "Assistant",
               "note": "•"}[role]
        self.transcript.append(
            f'<p><b style="color:{colors[role]}">{who}:</b> '
            f'{html_text}</p>')
        bar = self.transcript.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _append_note(self, html_text):
        self._append("note", html_text)

    def _render_markdownish(self, text):
        """Escape + render fenced code blocks, adding Apply links for
        scad blocks."""
        parts = []
        last = 0
        for match in re.finditer(r"```(\w*)\s*\n(.*?)```", text,
                                 re.DOTALL):
            parts.append(html.escape(text[last:match.start()])
                         .replace("\n", "<br>"))
            lang, code = match.group(1), match.group(2)
            escaped = html.escape(code)
            parts.append(f"<pre style='background:rgba(127,127,127"
                         f",0.15); padding:6px'>{escaped}</pre>")
            if lang.lower() in ("scad", "openscad"):
                self._blocks.append(code)
                index = len(self._blocks) - 1
                parts.append(f'<a href="apply:{index}">&#9654; Apply '
                             f'this program to the document</a><br>')
            last = match.end()
        parts.append(html.escape(text[last:]).replace("\n", "<br>"))
        return "".join(parts)

    def _anchor_clicked(self, url):
        target = url.toString()
        if not target.startswith("apply:"):
            return
        try:
            code = self._blocks[int(target.split(":", 1)[1])]
        except (ValueError, IndexError):
            return
        self.apply_scad(code)

    # ------------------------------------------------------- attachments
    def _attach_from_file(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Attach image(s)", "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp)")
        for path in paths:
            image = QImage(path)
            if not image.isNull():
                self._attach_image(image)

    def _attach_image(self, image):
        """Queue a QImage to ride along with the next message."""
        self._pending_images.append({
            "media_type": "image/png",
            "data": _qimage_to_png_b64(image),
            "thumb": image})
        self._update_attach_info()

    def _clear_attachments(self, *_):
        self._pending_images = []
        self._update_attach_info()

    def _update_attach_info(self):
        count = len(self._pending_images)
        if count:
            plural = "s" if count != 1 else ""
            self.attach_info.setText(
                f"📎 {count} image{plural} attached — "
                f'<a href="clear">remove</a>')
            self.attach_info.setVisible(True)
        else:
            self.attach_info.clear()
            self.attach_info.setVisible(False)

    def _embed_thumb(self, image) -> str:
        """Register a scaled copy of *image* as a transcript resource and
        return the URL to reference it from an <img> tag."""
        thumb = image.scaled(240, 240, Qt.KeepAspectRatio,
                             Qt.SmoothTransformation)
        self._thumb_seq += 1
        url = QUrl(f"attached://{self._thumb_seq}")
        self.transcript.document().addResource(
            QTextDocument.ImageResource, url, thumb)
        return url.toString()

    # ---------------------------------------------------------- applying
    def apply_scad(self, code):
        from .scadparse import parse_scad
        try:
            root, warnings = parse_scad(code)
        except Exception as exc:
            self._append_note(f"Could not parse that program: "
                              f"{html.escape(str(exc))}")
            return
        model = self.window.model
        comp = self.active_object()
        if comp is not None:
            self._apply_into_object(comp, root, warnings)
            return
        answer = QMessageBox.question(
            self, "Apply program",
            "Replace the current document with this program?\n"
            "(No = add it alongside the existing objects.)",
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
        if answer == QMessageBox.Cancel:
            return
        if answer == QMessageBox.Yes:
            model.root = root
        else:
            for child in list(root.children):
                root.remove(child)
                model.root.add(child)
        model.group_variables()
        model.structure_changed.emit()
        self.window.view3d.fit()
        note = ("Program applied to the assembly. To build *inside* a "
                "part — so the Object tree shows how it is made — open "
                "it in the Object tab and ask again.")
        if warnings:
            note += " Skipped: " + "; ".join(warnings[:5])
        self._append_note(html.escape(note))

    @staticmethod
    def _object_contents(root):
        """The nodes to put inside an Object. A program that is one
        module plus its call (what `subtree_scad` emits, so what the
        assistant is shown and usually mirrors) re-imports as a single
        Object — unwrap it, or applying it would nest a part inside
        itself every time."""
        children = list(root.children)
        solid = [n for n in children if n.type != "assign"]
        if len(solid) == 1 and solid[0].type == "component":
            return [n for n in children if n.type == "assign"] \
                + list(solid[0].children)
        return children

    def _apply_into_object(self, comp, root, warnings):
        """Apply the program inside the Object being edited, so its
        construction shows in the Object tree."""
        model = self.window.model
        answer = QMessageBox.question(
            self, "Apply program",
            f"Replace the contents of '{comp.name}' with this "
            f"program?\n(No = add it alongside what is already "
            f"inside.)",
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
        if answer == QMessageBox.Cancel:
            return
        nodes = self._object_contents(root)
        for node in list(nodes):
            node.parent.remove(node)
        if answer == QMessageBox.Yes:
            for child in list(comp.children):
                comp.remove(child)
        for node in nodes:
            comp.add(node)
        model.structure_changed.emit()
        self.window.builder.open_component(comp)   # keep it in view
        note = f"Applied inside '{comp.name}' — see the Object tree."
        if warnings:
            note += " Skipped: " + "; ".join(warnings[:5])
        self._append_note(html.escape(note))

    # ------------------------------------------------------------ sending
    def send(self):
        text = self.input.text().strip()
        images = self._pending_images
        if not text and not images:
            return
        if not text:                          # image-only: give it a task
            text = "Reproduce this image as 3D geometry."
        self.input.remember(text)             # recall with Up/Down later
        self.input.clear()
        self._pending_images = []
        self._update_attach_info()
        self._append_user(text, images)
        if text.startswith("/"):
            self.handle_command(text)         # commands ignore images
        else:
            self._ask(text, images)
        self._save_state()                    # remember across restarts

    def _append_user(self, text, images):
        """Show a user turn, with any attached images as inline thumbs."""
        parts = [f'<img src="{self._embed_thumb(im["thumb"])}"><br>'
                 for im in images]
        parts.append(html.escape(text).replace("\n", "<br>"))
        self._append("user", "".join(parts))

    def active_object(self):
        """The Object the user is editing, or None when Main is
        current. Everything the assistant makes lands in this scope, so
        a part it builds is built *inside* the Object and the Object
        tree shows how it is made."""
        return self.window.builder.isolated_component()

    def _scope_context(self):
        """The program the assistant works on, plus which mode it is:
        one Object's contents in Object mode, the whole assembly in
        Main."""
        from .units import name, symbol
        model = self.window.model
        comp = self.active_object()
        unit_line = (f"\nUNITS: {name(model.unit)} — write every size so "
                     f"1 means 1 {symbol(model.unit)}.")
        if comp is not None:
            return (unit_line + f"\n\nMODE: Object — the user is editing the part "
                    f"'{comp.name}'. Your program is the CONTENTS of "
                    f"that part; it is applied inside it, and each step "
                    f"becomes a row in the Object tree.\n"
                    f"Current Object program:\n```scad\n"
                    + model.subtree_scad(comp) + "\n```")
        return (unit_line + "\n\nMODE: Main — the user is in the assembly. Your "
                "program is the whole document. To change how one part "
                "is MADE, they must open it in the Object tab first "
                "(Object mode) — say so rather than rebuilding the "
                "part from the assembly.\n"
                "Current document program:\n```scad\n"
                + model.to_scad() + "\n```")

    def _ask(self, text, images=()):
        settings = QSettings(*_SETTINGS)
        provider = settings.value("chat/provider", "Claude")
        if provider not in AI_PROVIDERS:
            provider = "Claude"
        config = AI_PROVIDERS[provider]
        models = get_models(provider)
        model = settings.value("chat/model", models[0])
        if model not in models:
            model = models[0]
        key = get_api_key(provider)
        if config["requires_key"] and not key:
            self._append_note(
                f"No API key for {provider}. Open settings (gear "
                f"icon) or set {config['key_env']}.")
            return
        self.history.append({"role": "user", "content": text})
        self._trim_history()
        system = SYSTEM_PROMPT + self._scope_context()
        self.send_btn.setEnabled(False)
        note = f"asking {provider} ({model})…"
        if images:
            note = (f"asking {provider} ({model}) to reproduce "
                    f"{len(images)} image(s)…")
        self._append_note(note)
        payload = [{"media_type": im["media_type"], "data": im["data"]}
                   for im in images]
        self._worker = ChatWorker(provider, model, key,
                                  list(self.history), system,
                                  payload, self)
        self._worker.replied.connect(self._replied)
        self._worker.failed.connect(self._failed)
        self._worker.finished.connect(
            lambda: self.send_btn.setEnabled(True))
        self._worker.start()

    def _trim_history(self):
        """Keep the whole conversation, dropping only the oldest turns
        once it would overflow the context budget — so the assistant
        remembers as much of the session as safely fits."""
        budget = HISTORY_TOKEN_BUDGET * _CHARS_PER_TOKEN     # in chars
        total = sum(len(m["content"]) for m in self.history)
        while len(self.history) > 2 and total > budget:
            total -= len(self.history.pop(0)["content"])

    def _replied(self, text):
        self.history.append({"role": "assistant", "content": text})
        self._trim_history()
        self._save_state()                    # remember across restarts
        blocks = _SCAD_BLOCK_RE.findall(text)
        # show only the explanation, never the raw program — the code
        # is applied to the document automatically
        prose = _SCAD_BLOCK_RE.sub("", text).strip()
        if prose:
            self._append("assistant",
                         html.escape(prose).replace("\n", "<br>"))
        elif not blocks:
            self._append("assistant",
                         html.escape(text).replace("\n", "<br>"))
        if blocks:
            self._auto_apply(blocks[-1])

    def _auto_apply(self, code):
        """Parse the assistant's program straight into the object tree
        (undoable with Ctrl+Z) instead of printing it in the chat.

        It lands in whatever the user is working in: **inside the
        Object** while the Object tab is open — so the part's
        construction shows step by step in the Object tree — else the
        document."""
        from .scadparse import parse_scad
        try:
            root, warnings = parse_scad(code)
        except Exception as exc:
            self._append_note("Couldn't apply that program: "
                              + html.escape(str(exc)))
            return
        count = sum(1 for n in root.walk() if n.type != "root")
        comp = self.active_object()
        if comp is not None:
            nodes = self._object_contents(root)
            for node in list(nodes):
                node.parent.remove(node)
            for child in list(comp.children):
                comp.remove(child)
            for node in nodes:
                comp.add(node)
            self.window.model.structure_changed.emit()
            self.window.builder.open_component(comp)
            where = f"inside '{comp.name}' — open the Object tree to " \
                    f"see how it is built"
        else:
            self.window.model.root = root
            self.window.model.group_variables()
            self.window.model.structure_changed.emit()
            where = ("in the document (Main). To build *inside* a "
                     "part, open it in the Object tab first")
        self.window.view3d.fit()
        note = (f"✓ Built {where} — {count} object"
                f"{'s' if count != 1 else ''}. Press Ctrl+Z to undo.")
        if warnings:
            note += " Skipped: " + "; ".join(warnings[:4])
        self._append_note(html.escape(note))

    def _failed(self, message):
        self._append_note("Request failed: " + html.escape(message))

    def open_settings(self):
        ChatConfigDialog(self).exec_()

    # ------------------------------------------------------ slash commands
    def handle_command(self, text):
        parts = text[1:].split()
        command, args = (parts[0].lower() if parts else "help"), parts[1:]
        window = self.window
        model = window.model

        if command == "help":
            self._append_note(
                "Commands: <b>/code</b> show the OpenSCAD program · "
                "<b>/list</b> object tree · <b>/render</b> OpenSCAD "
                "render · <b>/fit</b> fit 3D view · <b>/part</b> "
                "&lt;cf16|cf40|cf63|cf100|cf160&gt; "
                "&lt;flange|nipple|tee|cross&gt; · /part turbo · "
                "<b>/hide</b>|<b>/show</b> &lt;name&gt; · "
                "<b>/settings</b> · <b>/clear</b> chat history")
        elif command == "code":
            self._append_note("<pre>" + html.escape(model.to_scad())
                              + "</pre>")
        elif command == "list":
            lines = []
            for node in model.root.walk():
                if node.type == "root":
                    continue
                depth = 0
                probe = node
                while probe.parent is not None:
                    depth += 1
                    probe = probe.parent
                eye = "" if node.visible else " (hidden)"
                lines.append("&nbsp;" * (depth - 1) * 3
                             + html.escape(f"{node.name} [{node.type}]"
                                           + eye))
            self._append_note("<br>".join(lines) or "empty document")
        elif command == "render":
            window._render_now()
            self._append_note("render requested")
        elif command == "fit":
            window.view3d.fit()
            self._append_note("3D view fitted")
        elif command == "clear":
            self.history = []
            self.transcript.clear()
            self._append_note("chat history cleared")
        elif command == "settings":
            self.open_settings()
        elif command == "part":
            self._cmd_part(args)
        elif command in ("hide", "show"):
            name = " ".join(args).lower()
            hits = [n for n in model.root.walk()
                    if name and name in n.name.lower()]
            for node in hits:
                model.set_visible(node, command == "show")
            self._append_note(f"{command}: {len(hits)} object(s)")
        else:
            self._append_note(f"unknown command /{command} — try /help")

    def _cmd_part(self, args):
        from . import library
        model = self.window.model
        if not args:
            self._append_note("usage: /part cf40 tee|gate|angle · "
                              "/part m6 bolt · /part turbo dn100")
            return
        if args[0].lower() == "turbo":
            wanted = args[1].lower() if len(args) > 1 else "dn100"
            size = next((k for k in library.TURBO_SIZES
                         if k.lower().startswith(wanted)),
                        "DN100 CF (~300 l/s)")
            node = library.build_part("turbo", {"_size": size})
            node.name = f"Turbo {size.split(' ')[0]}"
        elif args[0].upper() in library.BOLT_SIZES:
            dims = dict(library.BOLT_SIZES[args[0].upper()])
            kind = args[1].lower() if len(args) > 1 else "bolt"
            part_id = {"bolt": "bolt_hex", "screw": "bolt_socket",
                       "nut": "nut_hex"}.get(kind)
            if part_id is None:
                self._append_note("kinds: bolt, screw, nut")
                return
            node = library.build_part(part_id, dims)
            node.name = f"{args[0].upper()} {node.name}"
        else:
            size_key = next((k for k in library.CF_SIZES
                             if k.lower().startswith(args[0].lower())),
                            None)
            if size_key is None:
                self._append_note("sizes: " + ", ".join(
                    k.split()[0] for k in library.CF_SIZES))
                return
            kind = args[1].lower() if len(args) > 1 else "flange"
            part_id = {"flange": "cf_flange", "blank": "cf_blank",
                       "nipple": "cf_nipple", "tee": "cf_tee",
                       "cross": "cf_cross", "gate": "valve_gate",
                       "angle": "valve_angle",
                       "valve": "valve_angle"}.get(kind)
            if part_id is None:
                self._append_note(
                    "kinds: flange, blank, nipple, tee, cross, "
                    "gate, angle")
                return
            dims = dict(library.CF_SIZES[size_key])
            dims["port_length"] = 60.0
            node = library.build_part(part_id, dims)
            node.name = f"{size_key.split()[0]} {node.name}"
        model.root.add(node)
        model.structure_changed.emit()
        self.window.builder.tree.select_nodes([node])
        self.window.view3d.fit()
        self._append_note(html.escape(f"inserted {node.name}"))
