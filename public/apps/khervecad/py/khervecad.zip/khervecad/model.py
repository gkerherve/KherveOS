"""Object tree model — the single source of truth.

A KherveCAD document is a tree of ``CadNode`` objects. Every GUI tool
(shape tools, extrusions, booleans, the properties panel, dragging in
the 2D view) only ever creates or edits nodes; the OpenSCAD program
shown in the Code tab is generated from the tree by ``to_scad()``, so
the tree and the code can never disagree. OpenSCAD is the engine —
each node type maps to exactly one OpenSCAD statement.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import itertools
import json
import re
import time

from PyQt5.QtCore import QObject, QTimer, pyqtSignal
from PyQt5.QtWidgets import QUndoCommand, QUndoStack

from . import expr

# --------------------------------------------------------------- registry

SHAPE_2D = "2d"
SHAPE_3D = "3d"
OPERATION = "op"
BOOLEAN = "bool"
CONTROL = "ctl"          # loops / conditionals / assignments

#: hard cap when unrolling while loops into an OpenSCAD value list.
MAX_WHILE_ITERATIONS = 1000

#: surface materials a color node can carry. The built-in preview
#: shades each face with its own (view3d.MATERIAL_STYLES); OpenSCAD has
#: no materials, so codegen records it as a kcad_material() prefix that
#: renders as nothing but brings the material back on import.
MATERIALS = ["Default", "Plastic", "Metal", "Matte", "Clay", "Glass",
             "Rubber", "Skin", "Gold", "Copper", "Emissive",
             "Brick", "Concrete", "Render", "Roof tiles", "Slate", "Stone",
             "Bark", "Leaves",
             # house finishes, also drawn by the shader (glrender.SURFACES)
             "Wall tiles", "Metro tiles", "Mosaic", "Hex tiles", "Marble",
             "Floor tiles", "Checker tiles", "Terrazzo", "Zellige",
             "Floorboards", "Parquet", "Carpet", "Plaster", "Cladding",
             "Shingles", "Thatch", "Standing seam", "Solar panels",
             "Panelling", "Fabric", "Velvet", "Leather", "Bouclé",
             "Wood", "Grass",
             # creature skins (glrender.creature)
             "Scales", "Reptile", "Fur", "Feathers", "Chitin", "Slime"]

#: OpenSCAD's debug modifiers a node may carry as params["modifier"]
#: (written before its statement, read back by scadparse). Unlike the
#: selection highlight, which imitates `#` without emitting it, these
#: are the author's own and belong to the program.
MODIFIERS = {"#": "highlight", "%": "background", "!": "show only"}

#: OpenSCAD text() options
TEXT_HALIGN = ("left", "center", "right")
TEXT_VALIGN = ("baseline", "bottom", "center", "top")
TEXT_DIRECTIONS = ("ltr", "rtl", "ttb", "btt")

#: param schema entry: (key, label, kind, minimum, maximum)
#: kinds: "float", "int", "bool", "str", "points" (list of [x, y]).
NODE_TYPES = {
    # ----- 2D shapes ------------------------------------------------
    "line": dict(
        label="Line", category=SHAPE_2D, icon="mdi.vector-line",
        params=dict(x1=0.0, y1=0.0, x2=40.0, y2=0.0, width=2.0),
        schema=[("x1", "X1", "float", -1e6, 1e6),
                ("y1", "Y1", "float", -1e6, 1e6),
                ("x2", "X2", "float", -1e6, 1e6),
                ("y2", "Y2", "float", -1e6, 1e6),
                ("width", "Width", "float", 0.01, 1e4)]),
    "rect": dict(
        label="Rectangle", category=SHAPE_2D, icon="mdi.rectangle-outline",
        params=dict(x=0.0, y=0.0, width=40.0, height=25.0),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("width", "Width", "float", 0.01, 1e6),
                ("height", "Height", "float", 0.01, 1e6)]),
    "circle": dict(
        label="Circle", category=SHAPE_2D, icon="mdi.circle-outline",
        params=dict(x=0.0, y=0.0, radius=15.0, angle=360.0,
                    start_angle=0.0, segments=64),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("radius", "Radius", "float", 0.01, 1e6),
                ("angle", "Angle (90=quarter)", "float", 1.0, 360.0),
                ("start_angle", "Start angle", "float", -360.0, 360.0),
                ("segments", "Segments ($fn)", "int", 3, 512)]),
    "polygon": dict(
        label="Polygon", category=SHAPE_2D, icon="mdi.vector-polygon",
        params=dict(x=0.0, y=0.0,
                    points=[[0.0, 0.0], [40.0, 0.0], [20.0, 30.0]]),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("points", "Points", "points", None, None),
                # OpenSCAD's paths: one outline per row of point indices;
                # an outline inside another is a hole
                ("paths", "Paths (point indices; empty = all, in order)",
                 "rows", None, None)]),
    "text": dict(
        label="Text", category=SHAPE_2D, icon="mdi.format-text",
        # font, halign, valign, spacing and direction are optional
        # (schema only): a node without them is OpenSCAD's defaults, and
        # documents saved before them stay byte-identical
        params=dict(x=0.0, y=0.0, text="Kherve", size=10.0),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("text", "Text", "str", None, None),
                ("size", "Size", "float", 0.1, 1e4),
                ("font", "Font (e.g. Liberation Sans:style=Bold)", "str",
                 None, None),
                ("halign", "Horizontal align", "choice",
                 list(TEXT_HALIGN), None),
                ("valign", "Vertical align", "choice",
                 list(TEXT_VALIGN), None),
                ("spacing", "Letter spacing", "float", 0.1, 10.0),
                ("direction", "Direction", "choice",
                 list(TEXT_DIRECTIONS), None)]),
    # ----- 3D primitives --------------------------------------------
    "cube": dict(
        label="Cube", category=SHAPE_3D, icon="mdi.cube-outline",
        params=dict(x=0.0, y=0.0, z=0.0,
                    width=20.0, depth=20.0, height=20.0, center=False),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("z", "Z", "float", -1e6, 1e6),
                ("width", "Width (X)", "float", 0.01, 1e6),
                ("depth", "Depth (Y)", "float", 0.01, 1e6),
                ("height", "Height (Z)", "float", 0.01, 1e6),
                ("center", "Center", "bool", None, None)]),
    "sphere": dict(
        label="Sphere", category=SHAPE_3D, icon="mdi.circle-slice-8",
        params=dict(x=0.0, y=0.0, z=0.0, radius=12.0, segments=48),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("z", "Z", "float", -1e6, 1e6),
                ("radius", "Radius", "float", 0.01, 1e6),
                ("segments", "Segments ($fn)", "int", 4, 512)]),
    "cylinder": dict(
        label="Cylinder", category=SHAPE_3D, icon="mdi.database-outline",
        params=dict(x=0.0, y=0.0, z=0.0, height=25.0,
                    radius_bottom=10.0, radius_top=10.0,
                    segments=64, center=False),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("z", "Z", "float", -1e6, 1e6),
                ("height", "Height", "float", 0.01, 1e6),
                ("radius_bottom", "Radius bottom", "float", 0.0, 1e6),
                ("radius_top", "Radius top", "float", 0.0, 1e6),
                ("segments", "Segments ($fn)", "int", 3, 512),
                ("center", "Center", "bool", None, None)]),
    # ----- operations (wrap children) --------------------------------
    "linear_extrude": dict(
        label="Linear extrude", category=OPERATION,
        icon="mdi.arrow-expand-up",
        params=dict(height=10.0, twist=0.0, scale=1.0, center=False,
                    segments=0),
        schema=[("height", "Height", "float", 0.01, 1e6),
                ("twist", "Twist (deg)", "float", -1e5, 1e5),
                ("scale", "Scale", "float", 0.0, 1e4),
                ("center", "Center", "bool", None, None),
                ("segments", "Slices (0=auto)", "int", 0, 512)]),
    "rotate_extrude": dict(
        label="Rotate extrude", category=OPERATION,
        icon="mdi.rotate-3d-variant",
        params=dict(angle=360.0, segments=96),
        schema=[("angle", "Angle (deg)", "float", 0.01, 360.0),
                ("segments", "Segments ($fn)", "int", 3, 512)]),
    "translate": dict(
        label="Translate", category=OPERATION, icon="mdi.cursor-move",
        params=dict(x=0.0, y=0.0, z=0.0),
        schema=[("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("z", "Z", "float", -1e6, 1e6)]),
    "rotate": dict(
        label="Rotate", category=OPERATION, icon="mdi.rotate-right",
        params=dict(x=0.0, y=0.0, z=0.0),
        schema=[("x", "X (deg)", "float", -360.0, 360.0),
                ("y", "Y (deg)", "float", -360.0, 360.0),
                ("z", "Z (deg)", "float", -360.0, 360.0)]),
    "scale": dict(
        label="Scale", category=OPERATION, icon="mdi.resize",
        params=dict(x=1.0, y=1.0, z=1.0),
        schema=[("x", "X", "float", 0.001, 1e4),
                ("y", "Y", "float", 0.001, 1e4),
                ("z", "Z", "float", 0.001, 1e4)]),
    "mirror": dict(
        label="Mirror", category=OPERATION, icon="mdi.flip-horizontal",
        params=dict(x=1.0, y=0.0, z=0.0),
        schema=[("x", "X", "float", -1.0, 1.0),
                ("y", "Y", "float", -1.0, 1.0),
                ("z", "Z", "float", -1.0, 1.0)]),
    "offset": dict(
        label="Offset (round corners)", category=OPERATION,
        icon="mdi.rounded-corner",
        params=dict(radius=2.0, chamfer=False),
        schema=[("radius", "Radius (+out/-in)", "float", -1e4, 1e4),
                ("chamfer", "Chamfer (no rounding)", "bool", None, None)]),
    "projection": dict(
        # flattens 3D children to a 2D outline (cut = a section slice).
        # A 2D result the built-in preview can't show — the OpenSCAD
        # engine renders it (mainly for 2D/DXF templates).
        label="Projection (3D→2D)", category=OPERATION,
        icon="mdi.image-filter-center-focus-weak",
        params=dict(cut=False),
        schema=[("cut", "Cut (section slice)", "bool", None, None)]),
    "color": dict(
        label="Color", category=OPERATION, icon="mdi.palette-outline",
        params=dict(color="#4a90d9", alpha=1.0, material="Default"),
        schema=[("color", "Color", "color", None, None),
                ("alpha", "Opacity (0-1)", "float", 0.0, 1.0),
                ("material", "Material", "choice", MATERIALS, None)]),
    # ----- booleans / grouping ---------------------------------------
    "union": dict(
        label="Group (union)", category=BOOLEAN, icon="mdi.group",
        # a group is a part: it can be moved, rotated and coloured
        params=dict(x=0.0, y=0.0, z=0.0, rx=0.0, ry=0.0, rz=0.0,
                    color="", alpha=1.0),
        schema=[("x", "Move X", "float", -1e6, 1e6),
                ("y", "Move Y", "float", -1e6, 1e6),
                ("z", "Move Z", "float", -1e6, 1e6),
                ("rx", "Rotate X°", "float", -360.0, 360.0),
                ("ry", "Rotate Y°", "float", -360.0, 360.0),
                ("rz", "Rotate Z°", "float", -360.0, 360.0),
                ("color", "Color", "color", None, None),
                ("alpha", "Opacity (0-1)", "float", 0.0, 1.0)]),
    "component": dict(
        # an Object: a self-contained part that compiles to its own
        # OpenSCAD module (one definition + one placed call), so the
        # program reads as an assembly of named parts. Carries the
        # same placement/colour params as a Group.
        label="Object", category=BOOLEAN,
        icon="mdi.package-variant-closed",
        params=dict(x=0.0, y=0.0, z=0.0, rx=0.0, ry=0.0, rz=0.0,
                    color="", alpha=1.0),
        schema=[("x", "Move X", "float", -1e6, 1e6),
                ("y", "Move Y", "float", -1e6, 1e6),
                ("z", "Move Z", "float", -1e6, 1e6),
                ("rx", "Rotate X°", "float", -360.0, 360.0),
                ("ry", "Rotate Y°", "float", -360.0, 360.0),
                ("rz", "Rotate Z°", "float", -360.0, 360.0),
                ("color", "Color", "color", None, None),
                ("alpha", "Opacity (0-1)", "float", 0.0, 1.0)]),
    "difference": dict(
        label="Difference", category=BOOLEAN, icon="mdi.set-left",
        params=dict(), schema=[]),
    "intersection": dict(
        label="Intersection", category=BOOLEAN, icon="mdi.set-center",
        params=dict(), schema=[]),
    "hull": dict(
        label="Hull", category=BOOLEAN, icon="mdi.vector-combine",
        params=dict(), schema=[]),
    "minkowski": dict(
        label="Minkowski (round edges)", category=BOOLEAN,
        icon="mdi.blur",
        params=dict(), schema=[]),
    # ----- control flow ----------------------------------------------
    "for_loop": dict(
        label="For loop", category=CONTROL, icon="mdi.repeat",
        params=dict(variable="i", start=0.0, end=4.0, step=1.0,
                    values=""),
        schema=[("variable", "Variable", "str", None, None),
                ("start", "From", "float", -1e6, 1e6),
                ("end", "To", "float", -1e6, 1e6),
                ("step", "Step", "float", -1e6, 1e6),
                ("values", "Values (overrides range)", "str",
                 None, None)]),
    "while_loop": dict(
        label="While loop", category=CONTROL, icon="mdi.sync",
        params=dict(variable="x", start=1.0, condition="x < 100",
                    update="x * 2"),
        schema=[("variable", "Variable", "str", None, None),
                ("start", "Initial value", "float", -1e6, 1e6),
                ("condition", "While condition", "str", None, None),
                ("update", "Update expression", "str", None, None)]),
    "if_else": dict(
        label="If / else", category=CONTROL, icon="mdi.call-split",
        params=dict(condition="true"),
        schema=[("condition", "Condition", "str", None, None)]),
    "assign": dict(
        label="Variable", category=CONTROL, icon="mdi.variable",
        params=dict(variable="size", value="10"),
        # + OpenSCAD Customizer annotations (options, description, group),
        # optional: see customizer.py
        schema=[("variable", "Name", "str", None, None),
                ("value", "Value / expression", "str", None, None),
                ("options", "Customizer: [range] or [choices]", "str",
                 None, None),
                ("description", "Customizer: description", "str", None,
                 None),
                ("group", "Customizer: tab / group", "str", None, None)]),
    "variables": dict(
        label="Variables", category=CONTROL, icon="mdi.table",
        params=dict(), schema=[]),
    "masters": dict(
        # a definitions store: the masters it holds render only through
        # Linked copies, so the group itself adds no scene geometry. It
        # is shown in its own Masters tab, away from the Objects tree.
        label="Masters", category=CONTROL, icon="mdi.folder-star-outline",
        params=dict(), schema=[]),
    "reference": dict(
        # a linked instance of another object ("master"): it renders
        # whatever the master contains, so editing the master updates
        # every reference. Carries its own position/rotation.
        label="Linked copy", category=CONTROL, icon="mdi.link-variant",
        # an instance is a part like any other: it can be moved,
        # rotated and **coloured** on its own, so two copies of one
        # Object can wear different colours in the assembly
        params=dict(ref="", x=0.0, y=0.0, z=0.0, rx=0.0, ry=0.0,
                    rz=0.0, color="", alpha=1.0),
        schema=[("ref", "Master (object name)", "str", None, None),
                ("x", "Move X", "float", -1e6, 1e6),
                ("y", "Move Y", "float", -1e6, 1e6),
                ("z", "Move Z", "float", -1e6, 1e6),
                ("rx", "Rotate X°", "float", -360.0, 360.0),
                ("ry", "Rotate Y°", "float", -360.0, 360.0),
                ("rz", "Rotate Z°", "float", -360.0, 360.0),
                ("color", "Color", "color", None, None),
                ("alpha", "Opacity (0-1)", "float", 0.0, 1.0)]),
    # ----- external geometry ------------------------------------------
    "stl_import": dict(
        label="Import STL", category=SHAPE_3D,
        icon="mdi.file-import-outline",
        # translate([x,y,z]) rotate([rx,ry,rz]) scale(scale) import(path)
        # — right-click ▸ Imported mesh centres it and fixes its units
        params=dict(path="", x=0.0, y=0.0, z=0.0, rx=0.0, ry=0.0, rz=0.0,
                    scale=1.0),
        schema=[("path", "STL file", "str", None, None),
                ("x", "X", "float", -1e6, 1e6),
                ("y", "Y", "float", -1e6, 1e6),
                ("z", "Z", "float", -1e6, 1e6),
                ("rx", "Rotate X°", "float", -360.0, 360.0),
                ("ry", "Rotate Y°", "float", -360.0, 360.0),
                ("rz", "Rotate Z°", "float", -360.0, 360.0),
                ("scale", "Scale", "float", 1e-4, 1e4)]),
    "scad_raw": dict(
        # verbatim OpenSCAD, emitted straight into the program — for
        # library calls (BOSL2, ...) the built-in tessellator can't
        # model. It renders only through the OpenSCAD engine, so the
        # built-in preview shows nothing for it.
        label="OpenSCAD code", category=CONTROL, icon="mdi.code-tags",
        params=dict(code="// Raw OpenSCAD — rendered by the engine\n"
                         "cube([10, 10, 10], center = true);"),
        schema=[("code", "OpenSCAD code", "text", None, None)]),
}

#: types that accept children (assignments, Linked copies and raw code
#: are leaves).
CONTAINER_TYPES = {t for t, d in NODE_TYPES.items()
                   if d["category"] in (OPERATION, BOOLEAN, CONTROL)} \
    - {"assign", "reference", "scad_raw"}


def fmt(value) -> str:
    """Format a number the OpenSCAD way: no trailing zeros. Strings
    pass through raw — they are expressions like ``i * 10``."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        text = f"{value:.4f}".rstrip("0").rstrip(".")
        return text if text not in ("", "-", "-0") else "0"
    return str(value)


def split_values(text: str) -> list:
    """*text* split at its top-level commas: a loop's value list
    ``[7, 7], [30, 7]`` is two vectors, not four numbers."""
    chunks, depth, quote, start = [], 0, False, 0
    for i, ch in enumerate(text):
        if ch == '"' and (i == 0 or text[i - 1] != "\\"):
            quote = not quote
        elif quote:
            continue
        elif ch in "[(":
            depth += 1
        elif ch in "])":
            depth -= 1
        elif ch == "," and depth == 0:
            chunks.append(text[start:i])
            start = i + 1
    chunks.append(text[start:])
    return [c for c in chunks if c.strip()]


def scad_str(text: str) -> str:
    """Quote *text* as an OpenSCAD string literal."""
    return '"' + str(text).replace("\\", "\\\\").replace('"', '\\"') + '"'


#: document-wide segment count applied to every round object while set
#: (None = each object keeps its own $fn). Set around codegen by
#: DocumentModel.to_scad_map(); the mesh module has its own copy.
_FN_OVERRIDE = None

#: {str(node id): node} for resolving Linked-copy references, plus the
#: set of references currently expanding (cycle guard). Set around
#: codegen by DocumentModel.to_scad_map().
_REF_INDEX = None
_REF_STACK = set()

#: {node id: OpenSCAD module name} for Objects (components), assigned
#: per-document by DocumentModel.to_scad_map() so every module name is
#: unique; None when emitting a loose subtree (sanitised name only).
_MODULE_NAMES = None

#: {node id} of Objects whose ``module`` is emitted at the top of the
#: program instead of where the node sits, because OpenSCAD forbids a
#: module definition inside an instantiation's child block.
_HOISTED = None

#: identifiers a component's module must not shadow: OpenSCAD keywords
#: and built-in calls.
_SCAD_RESERVED = {
    "module", "function", "if", "else", "for", "let", "each", "true",
    "false", "undef", "include", "use", "circle", "square", "polygon",
    "text", "cube", "sphere", "cylinder", "polyhedron", "translate",
    "rotate", "scale", "mirror", "resize", "multmatrix", "color",
    "offset", "hull", "minkowski", "union", "difference",
    "intersection", "render", "surface", "projection",
    "linear_extrude", "rotate_extrude", "import", "children", "echo",
    "assert",
}


def module_name(name: str) -> str:
    """*name* as a valid, non-reserved OpenSCAD module identifier
    (``Object 2`` -> ``Object_2``)."""
    import re
    ident = re.sub(r"\W", "_", str(name).strip()) or "part"
    if ident[0].isdigit():
        ident = "_" + ident
    if ident in _SCAD_RESERVED:
        ident += "_"
    return ident


def _nested_components(node, nested=False, out=None):
    """Objects that sit inside an operation's child block. OpenSCAD
    accepts a ``module`` definition at file level or inside a module
    body, but *not* as a child of an instantiation: emitting one there
    (an Object used as the cutter of a `difference()`, say) is a parser
    error, and export died on it. Those definitions are hoisted to the
    top of the program instead, leaving only the placed call behind.
    Masters are skipped — that store emits nothing."""
    out = [] if out is None else out
    for child in node.children:
        if child.type == "masters":
            continue
        if child.type == "component":
            if nested:
                out.append(child)
            # a module body may legally hold further definitions
            _nested_components(child, False, out)
        else:
            _nested_components(
                child,
                nested or child.type not in ("root", "variables"),
                out)
    return out


def _referenced_modules(only):
    """The Objects whose ``module`` an isolated program for *only* must
    still define: the Objects *only* instances (a Linked copy of an
    Object emits a bare ``Part();`` call), transitively through masters
    and nested instances, minus the ones defined inside the subtree
    itself. Order is definition-before-use for readability."""
    inside = {n.id for n in only.walk()}
    out, queue, seen = [], [only], set()
    while queue:
        for node in queue.pop().walk():
            if node.type != "reference":
                continue
            target = (_REF_INDEX or {}).get(
                str(node.params.get("ref", "")).strip())
            if target is None or target.id in seen:
                continue
            seen.add(target.id)
            queue.append(target)
            if target.type == "component" and target.id not in inside:
                out.append(target)
    return out


#: a segment count this low is a polygon on purpose (a hex head, a hex
#: socket, an octagonal pot), not a coarse circle: the document-wide
#: $fn leaves it alone. It used to turn every hex socket round, so no
#: key could turn a library bolt or the butt hinge's.
POLYGON_SEGMENTS = 8


def keeps_segments(segments) -> bool:
    """True when *segments* is an intended polygon the common $fn must
    not replace."""
    return isinstance(segments, (int, float)) and \
        not isinstance(segments, bool) and 0 < segments <= POLYGON_SEGMENTS


def _fn(p) -> object:
    """Effective $fn for a round object: the document-wide common
    segment count when one is active, else the object's own value —
    except an intended polygon (`keeps_segments`), which keeps its
    sides."""
    if _FN_OVERRIDE is None or keeps_segments(p["segments"]):
        return p["segments"]
    return _FN_OVERRIDE


def _nonzero(p, keys) -> bool:
    """True if any of *keys* holds a non-zero number or an expression."""
    for key in keys:
        value = p.get(key, 0)
        if isinstance(value, str):
            if value.strip() not in ("", "0", "0.0"):
                return True
        elif value:
            return True
    return False


def _group_prefix(p) -> str:
    """Transform / colour wrappers a Group carries as a part: emitted
    only when set, so a plain group stays ``union()``."""
    prefix = ""
    col = str(p.get("color", "")).strip()
    if col:
        alpha = p.get("alpha", 1.0)
        prefix += (f"color({scad_str(col)}) "
                   if isinstance(alpha, float) and alpha >= 1.0
                   else f"color({scad_str(col)}, {fmt(alpha)}) ")
    if _nonzero(p, ("x", "y", "z")):
        prefix += (f"translate([{fmt(p['x'])}, {fmt(p['y'])}, "
                   f"{fmt(p['z'])}]) ")
    if _nonzero(p, ("rx", "ry", "rz")):
        prefix += (f"rotate([{fmt(p['rx'])}, {fmt(p['ry'])}, "
                   f"{fmt(p['rz'])}]) ")
    return prefix


def _definitions_index(root) -> int:
    """Where a new top-level definition goes: after the leading
    variables / assignments."""
    index = 0
    for child in root.children:
        if child.type not in ("variables", "assign", "scad_use"):
            break
        index += 1
    return index


def _definition(node, taken) -> "CadNode":
    """*node* (detached) as a hidden Object definition named after it.
    A plain Group simply becomes the Object; anything else — or a Group
    with its own move / turn / colour, which an Object's module would
    drop (a component's placement goes on its CALL) — is wrapped, and
    the wrapped node renamed "<name> body" so the name stays unique."""
    if node.type == "component":
        comp = node
    elif node.type == "union" and not _group_prefix(node.params):
        node.type = "component"
        comp = node
    else:
        comp = CadNode("component", node.name)
        base = candidate = f"{node.name} body"
        for i in itertools.count(2):
            if candidate not in taken:
                break
            candidate = f"{base} {i}"
        node.name = candidate
        comp.add(node)
    comp.visible = False
    return comp


def retire_masters(root) -> int:
    """Masters were folded into Objects (2026-09-19): an Object is the
    same "define once, place many" and also takes a colour, anchors,
    mates, the exploded view and its own module. Every master of an old
    document's Masters store becomes a hidden Object where the store
    stood; its Linked copies then call that Object's module
    (`CadNode._emit_reference`), so the scene is unchanged. Returns how
    many masters were converted."""
    moved = 0
    for store in [c for c in root.children if c.type == "masters"]:
        index = store.index()
        root.remove(store)
        taken = {n.name for n in root.walk()} | \
            {n.name for n in store.walk()}
        for master in list(store.children):
            store.remove(master)
            root.add(_definition(master, taken), index)
            index += 1
            moved += 1
    return moved


# ------------------------------------------------------------------ node

#: "Cube [Body]" — a node's generic name plus the label that says what
#: it IS. The label travels through the program as a trailing comment
#: (`cube(...);  // Body`), which scadparse reads back, so an assistant
#: that comments its code names every row of the tree.
_TAG_RE = re.compile(r"^(.*?\S)\s+\[([^\[\]\n]+)\]$")

#: types whose name is structural (module name, variable, reference
#: target) or that never emit a statement line of their own
UNTAGGED_TYPES = frozenset({"root", "variables", "masters", "component",
                            "reference", "assign", "if_else",
                            "scad_raw"})


def name_tag(name) -> str:
    """The bracketed label of "Cube [Body]" -> "Body", else ""."""
    match = _TAG_RE.match(str(name or ""))
    return match.group(2).strip() if match else ""


def with_tag(name, tag) -> str:
    """*name* labelled *tag* — an existing label is replaced."""
    match = _TAG_RE.match(str(name or ""))
    base = match.group(1) if match else str(name or "").strip()
    tag = str(tag).replace("[", "(").replace("]", ")").strip()
    return f"{base} [{tag}]" if tag else base


class CadNode:
    """One object in the tree: a shape, an operation or a boolean."""

    _ids = itertools.count(1)

    def __init__(self, type: str, name: str = "", params: dict = None):
        if type not in NODE_TYPES and type != "root":
            raise ValueError(f"unknown node type: {type}")
        self.id = next(CadNode._ids)
        self.type = type
        self.name = name or (NODE_TYPES[type]["label"]
                             if type != "root" else "root")
        self.visible = True
        base = {} if type == "root" else NODE_TYPES[type]["params"]
        self.params = {k: (list(map(list, v)) if isinstance(v, list) else v)
                       for k, v in base.items()}
        if params:
            self.params.update(params)
        self.children = []
        self.parent = None

    # ------------------------------------------------------- structure
    def add(self, child: "CadNode", index: int = None) -> "CadNode":
        child.parent = self
        if index is None:
            self.children.append(child)
        else:
            self.children.insert(index, child)
        return child

    def remove(self, child: "CadNode"):
        self.children.remove(child)
        child.parent = None

    def index(self) -> int:
        return self.parent.children.index(self) if self.parent else 0

    def walk(self):
        """Yield self and all descendants, depth first."""
        yield self
        for child in self.children:
            yield from child.walk()

    def is_container(self) -> bool:
        return self.type == "root" or self.type in CONTAINER_TYPES

    @property
    def category(self) -> str:
        return "root" if self.type == "root" \
            else NODE_TYPES[self.type]["category"]

    def has_2d_content(self) -> bool:
        """True if the subtree bottoms out in 2D shapes (extrudable)."""
        if self.category == SHAPE_2D:
            return True
        if self.category == SHAPE_3D:
            return False
        return any(c.has_2d_content() for c in self.children)

    def arc_points(self, env: dict = None):
        """Arc vertices of a (possibly partial) circle, local coords."""
        import math
        p = self.params
        radius = expr.resolve(p["radius"], env, 1.0)
        angle = min(max(expr.resolve(p.get("angle", 360.0), env, 360.0),
                        1.0), 360.0)
        start = expr.resolve(p.get("start_angle", 0.0), env, 0.0)
        segments = max(int(expr.resolve(p["segments"], env, 64)), 3)
        steps = max(int(segments * angle / 360.0), 2)
        return [(radius * math.cos(math.radians(start + angle * i / steps)),
                 radius * math.sin(math.radians(start + angle * i / steps)))
                for i in range(steps + 1)]

    def loop_values(self, env: dict = None):
        """Concrete values a for/while loop iterates over (unrolled
        with the expression evaluator; used by codegen for `while` and
        by the preview tessellator for both)."""
        p = self.params
        if self.type == "for_loop":
            if str(p.get("values", "")).strip():
                chunks = split_values(str(p["values"]))
                out = []
                for chunk in chunks:
                    try:
                        value = expr.evaluate(chunk, env)
                    except expr.ExprError:
                        value = 0.0
                    # a lone value may be a whole list/range (a
                    # `for (x = x_values)` over a vector variable, or the
                    # list itself in brackets) — iterate its elements.
                    # Several values are the elements: [7, 7], [30, 7]
                    # is two points, each one vector
                    if len(chunks) == 1 and isinstance(value, (list, tuple)):
                        out.extend(value)
                    else:
                        out.append(value)
                return out
            start = expr.resolve(p["start"], env, 0.0)
            end = expr.resolve(p["end"], env, 0.0)
            step = expr.resolve(p["step"], env, 1.0) or 1.0
            values, v = [], start
            while (step > 0 and v <= end + 1e-9) or \
                    (step < 0 and v >= end - 1e-9):
                values.append(v)
                v += step
                if len(values) >= MAX_WHILE_ITERATIONS:
                    break
            return values
        if self.type == "while_loop":
            var = str(p.get("variable", "x")) or "x"
            value = expr.resolve(p["start"], env, 0.0)
            values = []
            scope = dict(env or {})
            for _ in range(MAX_WHILE_ITERATIONS):
                scope[var] = value
                try:
                    if not expr.evaluate(p["condition"], scope):
                        break
                    values.append(value)
                    value = expr.evaluate(p["update"], scope)
                except expr.ExprError:
                    break
            return values
        return []

    # --------------------------------------------------------- codegen
    def to_scad(self, indent: int = 0) -> str:
        lines = []
        self.emit(lines, indent)
        return "\n".join(text for text, _node in lines)

    def modifier_prefix(self) -> str:
        """What goes before this node's statement: ``*`` when hidden,
        else its OpenSCAD debug modifier (``#`` highlight, ``%``
        background, ``!`` show only) — see MODIFIERS."""
        if not self.visible:
            return "*"
        mod = self.params.get("modifier")
        return mod if mod in MODIFIERS else ""

    def emit(self, lines, indent: int = 0, spans: dict = None):
        """Append (text, node) pairs for this subtree to *lines*.
        When *spans* is given, record ``spans[node.id] = (first_line,
        last_line_exclusive)`` so the GUI can map code lines back to
        nodes (selection highlight, OpenSCAD error marking)."""
        start = len(lines)
        pad = "    " * indent
        star = self.modifier_prefix()

        if self.type == "masters":
            # A definitions store: its masters render only through Linked
            # copies, so the group contributes no scene geometry. It is
            # still walked to index masters as reference targets.
            pass
        elif self.type in ("root", "variables"):
            # "variables" is a purely organisational group: its children
            # (assignments) are emitted at the same level, so the code
            # and OpenSCAD scope are exactly as if they were loose.
            for child in self.children:
                child.emit(lines, indent, spans)
        elif self.type == "scad_raw":
            # verbatim OpenSCAD, one (text, node) pair per line so the
            # code tab maps back to this node; hidden => nothing emitted
            if self.visible:
                code = str(self.params.get("code", ""))
                for ln in (code.split("\n") if code else [""]):
                    lines.append((pad + ln, self))
        elif self.type == "reference":
            self._emit_reference(lines, indent, spans)
        elif self.type == "component":
            self._emit_component(lines, indent, spans)
        elif self.type == "if_else":
            self._emit_if_else(lines, indent, spans)
        else:
            # a statement may span lines (a baked mesh's arrays): every
            # physical line is its own entry, or the line spans that map
            # code back to nodes would drift for everything after it
            if self.type == "assign":
                from . import customizer
                lines.extend((pad + text, self)
                             for text in customizer.lines_before(self))
            head, *more = (pad + star + self._statement()).split("\n")
            if more:
                lines.append((head, self))
                lines.extend((pad + ln, self) for ln in more[:-1])
                head = pad + more[-1]
            tag = "" if self.type in UNTAGGED_TYPES \
                else name_tag(self.name)
            note = f"  // {tag}" if tag else ""
            if self.type == "assign":
                note = customizer.trailing(self)
            if not self.is_container():
                lines.append((head + ";" + note, self))
            elif not self.children:
                lines.append((head + " { }" + note, self))
            else:
                lines.append((head + " {" + note, self))
                for child in self.children:
                    child.emit(lines, indent + 1, spans)
                lines.append((pad + "}", self))
        if spans is not None:
            spans[self.id] = (start, len(lines))

    def _emit_reference(self, lines, indent: int, spans):
        """A Linked copy of an **Object** is an assembly *instance*: it
        emits one placed call of the Object's module, so the program
        reads `translate(...) Part();` — one definition, many placed
        calls. A copy of anything else inlines its master's geometry
        (moved/rotated by its own transform) as before."""
        pad = "    " * indent
        star = self.modifier_prefix()
        prefix = _group_prefix(self.params)             # move/rotate
        target = (_REF_INDEX or {}).get(
            str(self.params.get("ref", "")).strip())
        if target is None or self.id in _REF_STACK:
            lines.append((pad + star + prefix + "union() { }", self))
            return
        if target.type == "component":
            name = (_MODULE_NAMES or {}).get(target.id) \
                or module_name(target.name)
            lines.append((pad + star + prefix + f"{name}();", self))
            return
        lines.append((pad + star + prefix + "union() {", self))
        _REF_STACK.add(self.id)
        try:
            target.emit(lines, indent + 1, spans)
        finally:
            _REF_STACK.discard(self.id)
        lines.append((pad + "}", self))

    def _emit_component(self, lines, indent: int, spans):
        """An Object compiles to its own zero-argument module plus one
        placed call, so the generated program reads as an assembly of
        named parts and each part is reusable OpenSCAD."""
        pad = "    " * indent
        star = self.modifier_prefix()
        name = (_MODULE_NAMES or {}).get(self.id) \
            or module_name(self.name)
        if self.id not in (_HOISTED or ()):
            self.emit_module(lines, indent, spans)
        # a name the identifier cannot carry ("Throat and belly",
        # "Wheel" deduped to Wheel_2) rides the call as its label, which
        # the importer reads back as the Object's name
        shown = str(self.name or "").strip()
        note = f"  // {shown}" if shown and shown != name else ""
        lines.append((pad + star + _group_prefix(self.params)
                      + f"{name}();" + note, self))

    def emit_module(self, lines, indent: int = 0, spans: dict = None):
        """Just the Object's ``module X() { ... }`` definition, without
        the placed call that puts it in the scene. An isolated Object's
        program needs the modules of every Object it instances — the
        instance emits a bare ``Part();`` call, and OpenSCAD silently
        renders nothing for a module it cannot find, so those parts
        went missing from the exact render while the built-in preview
        (which resolves references from the document root) showed
        them."""
        pad = "    " * indent
        name = (_MODULE_NAMES or {}).get(self.id) \
            or module_name(self.name)
        lines.append((pad + f"module {name}() {{", self))
        for child in self.children:
            child.emit(lines, indent + 1, spans)
        lines.append((pad + "}", self))

    def _emit_if_else(self, lines, indent: int, spans):
        """`if (cond) { then } else { else }` — the else branch is a
        child union node named "Else"; everything else is the then
        branch."""
        pad = "    " * indent
        star = self.modifier_prefix()
        else_node = next((c for c in self.children
                          if c.type == "union"
                          and c.name.lower().startswith("else")), None)
        then_nodes = [c for c in self.children if c is not else_node]
        head = f"{pad}{star}if ({fmt(self.params['condition'])})"
        has_else = else_node is not None and else_node.children
        if then_nodes:
            lines.append((head + " {", self))
            for child in then_nodes:
                child.emit(lines, indent + 1, spans)
            lines.append((pad + ("} else {" if has_else else "}"),
                          self))
        else:
            lines.append((head + " { }" + (" else {" if has_else
                                           else ""), self))
        if has_else:
            for child in else_node.children:
                child.emit(lines, indent + 1, spans)
            lines.append((pad + "}", self))

    def _statement(self) -> str:
        p = self.params
        t = self.type
        if t == "line":
            # A stroked segment: the hull of two circles gives a line
            # with round caps — a real 2D solid OpenSCAD can extrude.
            d = fmt(p["width"])
            return (f"hull() {{ "
                    f"translate([{fmt(p['x1'])}, {fmt(p['y1'])}]) "
                    f"circle(d={d}, $fn=32); "
                    f"translate([{fmt(p['x2'])}, {fmt(p['y2'])}]) "
                    f"circle(d={d}, $fn=32); }}")
        if t == "rect":
            return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}]) "
                    f"square([{fmt(p['width'])}, {fmt(p['height'])}])")
        if t == "circle":
            angle = p.get("angle", 360.0)
            partial = isinstance(angle, str) or angle < 360.0
            if not partial:
                return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}]) "
                        f"circle(r={fmt(p['radius'])}, "
                        f"$fn={fmt(_fn(p))})")
            # Quarter / semi / any pie slice: a polygon fan of arc
            # points (centre first) — a real 2D solid.
            pts = ", ".join(f"[{fmt(x)}, {fmt(y)}]"
                            for x, y in self.arc_points())
            return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}]) "
                    f"polygon(points=[[0, 0], {pts}])")
        if t == "polygon":
            pts = ", ".join(f"[{fmt(x)}, {fmt(y)}]"
                            for x, y in p["points"])
            paths = [r for r in (p.get("paths") or [])
                     if isinstance(r, list) and r]
            extra = ""
            if paths:
                extra = ", paths=[" + ", ".join(
                    "[" + ", ".join(fmt(int(i)) if isinstance(i, (int, float))
                                    else str(i) for i in r) + "]"
                    for r in paths) + "]"
            return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}]) "
                    f"polygon(points=[{pts}]{extra})")
        if t == "text":
            extra = ""
            if str(p.get("font") or "").strip():
                extra += f", font={scad_str(str(p['font']).strip())}"
            for key, default in (("halign", "left"), ("valign", "baseline"),
                                 ("direction", "ltr")):
                value = str(p.get(key) or default)
                if value != default:
                    extra += f", {key}={scad_str(value)}"
            spacing = p.get("spacing", 1.0)
            if spacing not in (1, 1.0, None, ""):
                extra += f", spacing={fmt(spacing)}"
            return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}]) "
                    f"text({scad_str(p['text'])}, size={fmt(p['size'])}"
                    f"{extra})")
        if t == "cube":
            return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}, "
                    f"{fmt(p['z'])}]) "
                    f"cube([{fmt(p['width'])}, {fmt(p['depth'])}, "
                    f"{fmt(p['height'])}], center={fmt(p['center'])})")
        if t == "sphere":
            return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}, "
                    f"{fmt(p['z'])}]) "
                    f"sphere(r={fmt(p['radius'])}, "
                    f"$fn={fmt(_fn(p))})")
        if t == "cylinder":
            return (f"translate([{fmt(p['x'])}, {fmt(p['y'])}, "
                    f"{fmt(p['z'])}]) "
                    f"cylinder(h={fmt(p['height'])}, "
                    f"r1={fmt(p['radius_bottom'])}, "
                    f"r2={fmt(p['radius_top'])}, "
                    f"$fn={fmt(_fn(p))}, "
                    f"center={fmt(p['center'])})")
        if t == "linear_extrude":
            args = [f"height={fmt(p['height'])}"]
            if p["twist"]:
                args.append(f"twist={fmt(p['twist'])}")
            if p["scale"] != 1.0:
                args.append(f"scale={fmt(p['scale'])}")
            if p["center"]:
                args.append("center=true")
            if p["segments"]:
                args.append(f"slices={fmt(p['segments'])}")
            return f"linear_extrude({', '.join(args)})"
        if t == "rotate_extrude":
            args = []
            if p["angle"] != 360.0:
                args.append(f"angle={fmt(p['angle'])}")
            args.append(f"$fn={fmt(_fn(p))}")
            return f"rotate_extrude({', '.join(args)})"
        if t in ("translate", "rotate", "scale", "mirror"):
            return (f"{t}([{fmt(p['x'])}, {fmt(p['y'])}, "
                    f"{fmt(p['z'])}])")
        if t == "union":
            return _group_prefix(p) + "union()"
        if t in ("difference", "intersection", "hull", "minkowski"):
            return f"{t}()"
        if t == "offset":
            if p["chamfer"]:
                return (f"offset(delta={fmt(p['radius'])}, "
                        f"chamfer=true)")
            return f"offset(r={fmt(p['radius'])})"
        if t == "projection":
            return f"projection(cut = {fmt(bool(p.get('cut', False)))})"
        if t == "color":
            alpha = p.get("alpha", 1.0)
            material = str(p.get("material") or "Default")
            prefix = (f"kcad_material({scad_str(material)}) "
                      if material != "Default" else "")
            if isinstance(alpha, float) and alpha >= 1.0:
                return prefix + f"color({scad_str(p['color'])})"
            return prefix + f"color({scad_str(p['color'])}, {fmt(alpha)})"
        if t == "for_loop":
            var = str(p.get("variable", "i")) or "i"
            values = str(p.get("values", "")).strip()
            if values:
                # a bare variable holds a list/range already — iterate it
                # directly; a literal value list gets wrapped in [ ... ]
                if values.isidentifier():
                    return f"for ({var} = {values})"
                chunks = split_values(values)
                if len(chunks) == 1 and chunks[0].strip().startswith("["):
                    # the value is the list itself: [[7, 7]] is one point
                    return f"for ({var} = {chunks[0].strip()})"
                return f"for ({var} = [{values}])"
            return (f"for ({var} = [{fmt(p['start'])} : "
                    f"{fmt(p['step'])} : {fmt(p['end'])}])")
        if t == "while_loop":
            # OpenSCAD has no while statement, but its list comprehension
            # has a C-style for: OpenSCAD itself computes the values, per
            # iteration, so a condition may read document variables and
            # enclosing loop variables. Unrolling here (no environment)
            # turned any such loop into `for (x = [0])`. `_w` caps it at
            # MAX_WHILE_ITERATIONS, as the preview does.
            var = str(p.get("variable", "x")) or "x"
            return (f"for ({var} = [for ({var} = {fmt(p['start'])}, "
                    f"_w = 0; ({fmt(p['condition'])}) && "
                    f"_w < {MAX_WHILE_ITERATIONS}; "
                    f"{var} = {fmt(p['update'])}, _w = _w + 1) {var}])")
        if t == "assign":
            return f"{p['variable']} = {fmt(p['value'])}"
        if t == "stl_import":
            out = (f"translate([{fmt(p['x'])}, {fmt(p['y'])}, "
                   f"{fmt(p['z'])}]) ")
            turn = [p.get(k, 0.0) for k in ("rx", "ry", "rz")]
            if any(v != 0 for v in turn):       # an expression counts
                out += f"rotate([{', '.join(fmt(v) for v in turn)}]) "
            if p.get("scale", 1.0) != 1:
                out += f"scale({fmt(p['scale'])}) "
            return out + f"import({scad_str(p['path'])}, convexity=10)"
        if t in _organic.TYPES:
            return _organic.statement(self, fmt, _fn)
        raise ValueError(f"no codegen for type: {t}")   # pragma: no cover


# -------------------------------------------------------------- document

class DocumentModel(QObject):
    """The open document: a root node plus change signals.

    Panels connect to the signals; anything that edits the tree calls
    the methods here so every view stays in sync.
    """

    #: tree shape changed (nodes added / removed / moved / grouped).
    structure_changed = pyqtSignal()
    #: a single node's params / name / visibility changed.
    node_changed = pyqtSignal(object)
    #: the drawing's dimension annotations were added/removed.
    dimensions_changed = pyqtSignal()
    #: the reference images (refimage.py) were added/removed/changed.
    references_changed = pyqtSignal()
    #: the Blueprint sheet (blueprint.py) was edited or replaced.
    drawing_changed = pyqtSignal()
    #: a mate was dropped because its placement was edited by hand.
    mate_released = pyqtSignal(object)
    #: the document's display unit (units.py) was changed.
    unit_changed = pyqtSignal(str)
    #: the document's scale against the real thing changed (the N of 1 : N)
    scale_changed = pyqtSignal(float)

    #: the placement params a mate drives — typing into one of these
    #: releases the mate (see set_param).
    PLACEMENT_KEYS = ("x", "y", "z", "rx", "ry", "rz")

    #: consecutive edits inside this window merge into one undo step
    #: (a 2D drag or spinbox scrub stays a single Ctrl+Z).
    UNDO_MERGE_S = 0.4

    def __init__(self):
        super().__init__()
        self.root = CadNode("root")
        # document-wide segment count for round objects, applied
        # at 45 when switched on (off by default: each object keeps its own)
        self.global_fn = 45
        self.global_fn_on = False
        #: engineering-drawing dimension annotations, each a dict
        #: {"a": [x, y], "b": [x, y], "plane": <2D view plane>}.
        self.dimensions = []
        #: pictures to model against, each {"path", "plane", "x", "y",
        #: "width", "height", "offset", "opacity", "visible"}
        self.reference_images = []
        #: the Blueprint sheet (blueprint.py): views, annotations and
        #: title block as a plain dict, or None before one is made. Kept
        #: out of the undo snapshots — the Blueprint window has its own
        #: undo, and a Ctrl+Z in the model must not rewind the drawing.
        self.drawing = None
        #: the House Builder design (house.house_to_spec + "objects", the
        #: names of the Objects it built) or None — saved in the .kcad
        #: and IN the undo snapshots, so the builder reopens on the
        #: house the document holds and a Ctrl+Z of a Build rewinds both
        self.house = None
        #: the City Builder design (city.resolve + "objects") or None —
        #: saved and in the undo snapshots, like the house
        self.city = None
        #: what one model unit means ("nm", "um", "mm", "cm", "m",
        #: "in") — a label for every readout, never a rescale of the
        #: geometry (see units.py)
        self.unit = "mm"
        #: the N of 1 : N — how many times smaller than life the model
        #: is (a 60 mm Earth is 1 : 212 600 000; 1 = life size, below 1
        #: an enlargement). A label like the unit: the scale bar reads
        #: lengths of the real thing, nothing is rescaled
        self.real_scale = 1.0
        #: Blender-style collections (part_collections.py): [{name, visible,
        #: locked}], membership in each part's params["collection"] —
        #: saved and in the undo snapshots
        self.collections = []
        self.undo_stack = QUndoStack(self)
        self._restoring = False
        self._last_state = self._serialize()
        self._capture_timer = QTimer(self)
        self._capture_timer.setSingleShot(True)
        self._capture_timer.setInterval(0)
        self._capture_timer.timeout.connect(self._capture)
        self.structure_changed.connect(self._schedule_capture)
        self.node_changed.connect(lambda _n: self._schedule_capture())
        self.dimensions_changed.connect(self._schedule_capture)
        self.references_changed.connect(self._schedule_capture)
        self.unit_changed.connect(lambda _u: self._schedule_capture())

    # ------------------------------------------------------ undo/redo
    def _serialize(self) -> str:
        from .document import node_to_dict
        return json.dumps({"tree": node_to_dict(self.root),
                           "dimensions": self.dimensions,
                           "references": self.reference_images,
                           "unit": self.unit,
                           "real_scale": self.real_scale,
                           "house": self.house,
                           "city": self.city,
                           "collections": self.collections})

    def _schedule_capture(self):
        """Capture one undo snapshot per event-loop cycle, so a
        multi-step operation (wrap + rename + ...) is one undo step."""
        if not self._restoring and not self._capture_timer.isActive():
            self._capture_timer.start()

    def _capture(self):
        if self._restoring:
            return
        state = self._serialize()
        if state == self._last_state:
            return
        self.undo_stack.push(
            _SnapshotCommand(self, self._last_state, state))
        self._last_state = state

    def restore_state(self, state: str):
        from .document import node_from_dict
        self._restoring = True
        try:
            data = json.loads(state)
            self.root = node_from_dict(data["tree"])
            retire_masters(self.root)
            self.dimensions = [dict(d) for d in data.get("dimensions", [])]
            self.reference_images = [dict(r) for r in
                                     data.get("references", [])]
            self.house = data.get("house")
            self.city = data.get("city")
            self.collections = [dict(c) for c in
                                data.get("collections") or []]
            unit = data.get("unit", "mm")
            unit_moved = unit != self.unit
            self.unit = unit
            scale = float(data.get("real_scale", 1.0) or 1.0)
            scale_moved = scale != self.real_scale
            self.real_scale = scale
            self._last_state = state
            self.structure_changed.emit()
            if unit_moved:
                self.unit_changed.emit(unit)
            if scale_moved:
                self.scale_changed.emit(scale)
        finally:
            self._restoring = False

    # ---------------------------------------------------------- units
    def set_unit(self, unit) -> str:
        """Set the display unit (any spelling `units.normalise` takes);
        the geometry is untouched. One undo step. Returns the code."""
        from .units import normalise
        code = normalise(unit)
        if code != self.unit:
            self.unit = code
            self.unit_changed.emit(code)
        return code

    def set_real_scale(self, n) -> float:
        """Say the model is 1 : *n* of the real thing (a number, or text
        like "1:250000000" / "25:1"); the geometry is untouched. One undo
        step. Returns n."""
        from .units import parse_ratio
        value = float(n) if isinstance(n, (int, float)) else parse_ratio(n)
        if not value > 0:
            raise ValueError(f"not a scale: {n!r}")
        if value != self.real_scale:
            self.real_scale = value
            self.scale_changed.emit(value)
            self._schedule_capture()
        return value

    # ---------------------------------------------------- dimensions
    def add_dimension(self, a, b, plane: str):
        """Add a persistent dimension between two plane points (mm)."""
        self.dimensions.append({"a": [float(a[0]), float(a[1])],
                                "b": [float(b[0]), float(b[1])],
                                "plane": plane})
        self.dimensions_changed.emit()

    def remove_dimension(self, index: int):
        if 0 <= index < len(self.dimensions):
            del self.dimensions[index]
            self.dimensions_changed.emit()

    # ------------------------------------------------ reference images
    def add_reference_image(self, ref: dict) -> int:
        """Add a picture to model against (see refimage.py); returns
        its index."""
        self.reference_images.append(dict(ref))
        self.references_changed.emit()
        return len(self.reference_images) - 1

    def remove_reference_image(self, index: int):
        if 0 <= index < len(self.reference_images):
            del self.reference_images[index]
            self.references_changed.emit()

    def clear_reference_images(self):
        if self.reference_images:
            self.reference_images = []
            self.references_changed.emit()

    def clear_dimensions(self):
        if self.dimensions:
            self.dimensions = []
            self.dimensions_changed.emit()

    # -------------------------------------------------------- queries
    def find(self, node_id: int):
        for node in self.root.walk():
            if node.id == node_id:
                return node
        return None

    def unique_name(self, type: str) -> str:
        base = NODE_TYPES[type]["label"]
        taken = {n.name for n in self.root.walk()}
        for i in itertools.count(1):
            name = f"{base} {i}"
            if name not in taken:
                return name

    def effective_fn(self):
        """The document-wide segment count in force, or None when each
        object keeps its own $fn."""
        return int(self.global_fn) if self.global_fn_on else None

    def set_global_fn(self, on: bool, value: int = None):
        """Enable/disable the common segment count (and optionally set
        it), then refresh every view."""
        self.global_fn_on = bool(on)
        if value is not None:
            self.global_fn = max(int(value), 3)
        self.structure_changed.emit()

    def to_scad(self) -> str:
        return self.to_scad_map()[0]

    def subtree_scad(self, node: CadNode) -> str:
        """A standalone program for one Object/subtree: the document's
        top-level variables first (so expressions still resolve), then
        *node* in its **own local frame** — what the isolated Object
        view renders. The node's Main-assembly placement (`x/y/z/rx/
        ry/rz`, set by a mate) and its hidden-in-Main flag are ignored:
        an Object is edited at its own origin, unaffected by where it
        happens to sit in the assembly."""
        placement = ("x", "y", "z", "rx", "ry", "rz")
        saved = {k: node.params.get(k, 0.0) for k in placement
                 if k in node.params}
        saved_visible = node.visible
        node.visible = True
        for k in saved:
            node.params[k] = 0.0
        try:
            return self.to_scad_map(only=node)[0]
        finally:
            node.params.update(saved)
            node.visible = saved_visible

    def global_assigns(self):
        """Document variables that live outside every Object — the
        "Global" scope of the Variables sheet."""
        out = []

        def walk(n):
            for child in n.children:
                if child.type == "component":
                    continue
                if child.type == "assign":
                    out.append(child)
                else:
                    walk(child)
        walk(self.root)
        return out

    def to_scad_map(self, only: CadNode = None):
        """The full program plus ``{node_id: (first, last_exclusive)}``
        line spans into it — the basis for code-line highlighting and
        for mapping OpenSCAD error line numbers back to nodes. With
        *only*, the program is the document's top-level variables plus
        that subtree alone (the isolated-Object view)."""
        from . import APP_NAME, __version__
        header = (f"// Generated by {APP_NAME} v{__version__}\n"
                  f"// Edit objects in the GUI — this program is\n"
                  f"// regenerated from the object tree.\n")
        offset = header.count("\n") + 1          # + the blank line
        lines, spans = [], {}
        global _FN_OVERRIDE, _REF_INDEX, _MODULE_NAMES, _HOISTED
        _FN_OVERRIDE = self.effective_fn()
        _REF_INDEX = {}                          # by name: masters persist
        _MODULE_NAMES = {}                       # unique per document
        taken = set()
        for n in self.root.walk():
            _REF_INDEX.setdefault(n.name, n)
            if n.type == "component":
                base = candidate = module_name(n.name)
                for k in itertools.count(2):
                    if candidate not in taken:
                        break
                    candidate = f"{base}_{k}"
                taken.add(candidate)
                _MODULE_NAMES[n.id] = candidate
        scope = self.root if only is None else only
        hoisted = _nested_components(scope)
        _HOISTED = {n.id for n in hoisted}
        _REF_STACK.clear()
        try:
            # helper modules for organic nodes, defined once up top
            for text in _organic.preamble(self.root):
                lines.append((text, None))
            for definition in hoisted:
                definition.emit_module(lines, 0, spans)
            if only is None:
                self.root.emit(lines, 0, spans)
            else:
                # the libraries the document uses, wherever their
                # directive sits, so a part's own program still finds
                # the modules its OpenSCAD code calls
                inside = {n.id for n in only.walk()}
                for n in self.root.walk():
                    if n.type == "scad_use" and n.id not in inside:
                        n.emit(lines, 0, spans)
                for child in self.root.children:
                    if child.type in ("variables", "assign"):
                        child.emit(lines, 0, spans)
                for definition in _referenced_modules(only):
                    definition.emit_module(lines, 0, spans)
                only.emit(lines, 0, spans)
        finally:
            _FN_OVERRIDE = None
            _REF_INDEX = None
            _MODULE_NAMES = None
            _HOISTED = None
            _REF_STACK.clear()
        body = "\n".join(text for text, _n in lines)
        code = header + "\n" + body + ("\n" if body else "")
        shifted = {nid: (s + offset, e + offset)
                   for nid, (s, e) in spans.items()}
        return code, shifted

    def node_at_line(self, line: int):
        """Deepest node whose code span contains 0-based *line*."""
        _code, spans = self.to_scad_map()
        best, best_size = None, None
        for nid, (s, e) in spans.items():
            if s <= line < e:
                size = e - s
                if best_size is None or size < best_size:
                    best, best_size = nid, size
        return self.find(best) if best is not None else None

    def group_variables(self):
        """Collect the leading run of top-level variable assignments into
        a single "Variables" container so they read as one item at the
        top of the tree. Transparent in the code, and idempotent."""
        kids = self.root.children
        if any(c.type == "variables" for c in kids):
            return
        lead = []
        for child in kids:
            if child.type == "assign":
                lead.append(child)
            else:
                break
        if len(lead) < 2:
            return
        group = CadNode("variables", "Variables")
        for node in lead:
            self.root.remove(node)
        for node in lead:
            group.add(node)
        self.root.add(group, 0)

    # -------------------------------------------------------- editing
    def add_node(self, type: str, params: dict = None,
                 parent: CadNode = None, name: str = "") -> CadNode:
        node = CadNode(type, name or self.unique_name(type), params)
        (parent or self.root).add(node)
        if type == "if_else":
            node.add(CadNode("union", "Else"))
        self.structure_changed.emit()
        return node

    def remove_node(self, node: CadNode):
        if node.parent is None:
            return
        node.parent.remove(node)
        self.structure_changed.emit()

    def set_param(self, node: CadNode, key: str, value):
        if key in self.PLACEMENT_KEYS:
            # A mate re-solves the placement on every change, so a value
            # typed here was overwritten before it ever reached the
            # screen. Editing it by hand is the user taking control
            # back — the same rule as dragging a mated part in the 2D
            # view, which detaches it too.
            from .mates import mate_of
            if mate_of(node) is not None:
                node.params.pop("mate", None)
                self.mate_released.emit(node)
        node.params[key] = value
        self.node_changed.emit(node)

    def set_modifier(self, node: CadNode, modifier: str):
        """Give *node* an OpenSCAD debug modifier (``#``, ``%``, ``!``) or
        none (``""``)."""
        if modifier in MODIFIERS:
            node.params["modifier"] = modifier
        else:
            node.params.pop("modifier", None)
        self.node_changed.emit(node)

    def set_visible(self, node: CadNode, visible: bool):
        node.visible = visible
        self.node_changed.emit(node)

    def rename(self, node: CadNode, name: str):
        old = node.name
        node.name = name
        # keep Linked copies and mates pointing at a renamed target
        if old and old != name:
            for other in self.root.walk():
                if other.type == "reference" \
                        and other.params.get("ref") == old:
                    other.params["ref"] = name
                elif other.type == "component":
                    mate = other.params.get("mate")
                    if isinstance(mate, dict) \
                            and mate.get("parent") == old:
                        mate["parent"] = name
        self.node_changed.emit(node)

    def shift_node(self, node: CadNode, delta: int):
        """Move *node* up/down within its parent (Ctrl+Up/Down)."""
        parent = node.parent
        if parent is None:
            return
        i = node.index()
        j = max(0, min(len(parent.children) - 1, i + delta))
        if i != j:
            parent.children.insert(j, parent.children.pop(i))
            self.structure_changed.emit()

    def move_node(self, node: CadNode, new_parent: CadNode,
                  index: int = None):
        if new_parent is node or any(n is node for n in
                                     self._ancestors(new_parent)):
            return                       # refuse to reparent into itself
        node.parent.remove(node)
        new_parent.add(node, index)
        self.structure_changed.emit()

    @staticmethod
    def _ancestors(node: CadNode):
        while node is not None:
            yield node
            node = node.parent

    def wrap_nodes(self, nodes, op_type: str) -> CadNode:
        """Wrap *nodes* (same parent expected) in a new container node
        — this is how extrusions, transforms and booleans are applied."""
        nodes = [n for n in nodes if n.parent is not None]
        if not nodes:
            return None
        parent = nodes[0].parent
        nodes = [n for n in nodes if n.parent is parent]
        index = min(n.index() for n in nodes)
        wrapper = CadNode(op_type, self.unique_name(op_type))
        for n in nodes:
            parent.remove(n)
            wrapper.add(n)
        if op_type == "if_else":
            wrapper.add(CadNode("union", "Else"))
        parent.add(wrapper, index)
        self.structure_changed.emit()
        return wrapper

    def set_color(self, nodes, color: str, alpha: float = 1.0,
                  material: str = None):
        """Colour *nodes*: reuse an existing color wrapper (the node
        itself or its parent) or wrap in a new one. *material* (one of
        MATERIALS) is set too when given."""
        wrappers = []
        for node in nodes:
            if node.type == "color":
                wrapper = node
            elif node.parent is not None and \
                    node.parent.type == "color":
                wrapper = node.parent
            else:
                wrapper = self.wrap_nodes([node], "color")
            if wrapper is not None:
                wrapper.params["color"] = color
                wrapper.params["alpha"] = alpha
                if material is not None:
                    wrapper.params["material"] = material
                wrappers.append(wrapper)
                self.node_changed.emit(wrapper)
        return wrappers

    def round_edges(self, nodes, radius: float = 1.0) -> CadNode:
        """Round the edges of *nodes* after extrusion: wrap them in
        minkowski() with a small sphere — the OpenSCAD idiom."""
        wrapper = self.wrap_nodes(nodes, "minkowski")
        if wrapper is not None:
            sphere = CadNode("sphere", self.unique_name("sphere"),
                             dict(radius=radius, segments=24))
            wrapper.add(sphere)
            self.structure_changed.emit()
        return wrapper

    def group_nodes(self, nodes) -> CadNode:
        return self.wrap_nodes(nodes, "union")

    def ungroup(self, node: CadNode):
        """Replace a container node by its children (any container)."""
        if not node.is_container() or node.parent is None:
            return
        parent, index = node.parent, node.index()
        parent.remove(node)
        for child in list(node.children):
            node.remove(child)
            parent.add(child, index)
            index += 1
        self.structure_changed.emit()

    def duplicate(self, node: CadNode) -> CadNode:
        clone = self._clone(node)
        clone.name = self.unique_name(node.type)
        node.parent.add(clone, node.index() + 1)
        self.structure_changed.emit()
        return clone

    def add_linked_copy(self, master: CadNode) -> CadNode:
        """Insert a Linked copy that renders *master* — editing the
        master then updates the copy. The master needs a unique name so
        the link resolves reliably."""
        names = [n.name for n in self.root.walk()]
        if names.count(master.name) > 1:
            master.name = self.unique_name(master.type)
        ref = CadNode("reference", f"Copy of {master.name}",
                      dict(ref=master.name))
        parent = master.parent or self.root
        parent.add(ref, master.index() + 1)
        self.structure_changed.emit()
        return ref

    # -------------------------------------------------------- masters
    def masters_group(self, create: bool = False) -> CadNode:
        """The retired Masters store, if an unconverted tree still has
        one (``retire_masters`` removes it on load). Never created."""
        for child in self.root.children:
            if child.type == "masters":
                return child
        return None

    def make_master(self, node: CadNode) -> CadNode:
        """Define *node* once and place it by reference: it becomes a
        hidden Object at the top level (listed in the Object tab) and a
        Linked copy — an instance of it — takes its place, even inside a
        loop. What the retired Masters store did, now with an Object, so
        the copies can be coloured, mated and exploded. Returns the
        Linked copy."""
        if node.parent is None or \
                node.type in ("masters", "variables", "root", "assign"):
            return None
        names = [n.name for n in self.root.walk()]
        if not node.name or names.count(node.name) > 1:
            node.name = self.unique_name(node.type)
        parent, index = node.parent, node.index()
        parent.remove(node)
        comp = _definition(node, {n.name for n in self.root.walk()})
        ref = CadNode("reference", f"Copy of {comp.name}",
                      dict(ref=comp.name))
        parent.add(ref, index)
        self.root.add(comp, _definitions_index(self.root))
        self.structure_changed.emit()
        return ref

    def instance_master(self, master: CadNode) -> CadNode:
        """Add a Linked copy of *master* (any named node) to the top of
        the document."""
        if master.name and \
                [n.name for n in self.root.walk()].count(master.name) > 1:
            master.name = self.unique_name(master.type)
        ref = CadNode("reference", f"Copy of {master.name}",
                      dict(ref=master.name))
        self.root.add(ref)
        self.structure_changed.emit()
        return ref

    # ----------------------------------------------------- components
    def components(self):
        """Top-level Objects (components) in document order — the
        assembly the Main tab lists."""
        return [c for c in self.root.children if c.type == "component"]

    def all_components(self):
        """Every Object in the document, nested ones included — an
        imported program often places its modules inside a colour or a
        group (``color(...) Pot();``), and those are Objects too. In
        document order; the Masters store is not searched."""
        found = []

        def walk(node):
            for child in node.children:
                if child.type == "masters":
                    continue
                if child.type == "component":
                    found.append(child)
                walk(child)
        walk(self.root)
        return found

    def delete_component(self, comp: CadNode) -> int:
        """Remove an Object definition and every instance / Linked copy
        that places it, wherever it sits — one change, so one Ctrl+Z
        brings them all back. Returns how many instances went."""
        inside = {id(n) for n in comp.walk()}
        refs = [n for n in self.root.walk()
                if n.type == "reference" and id(n) not in inside
                and n.params.get("ref") == comp.name]
        for node in refs + [comp]:
            if node.parent is not None:
                node.parent.remove(node)
        self.structure_changed.emit()
        return len(refs)

    def new_component(self, name: str = "",
                      visible: bool = True) -> CadNode:
        """Create an empty Object at the top level. The UI creates new
        Objects hidden (visible=False): they are built in the Object
        tab first and shown in the Main assembly when ready — the
        isolated Object view ignores this flag, so the two stay
        independent."""
        node = CadNode("component",
                       name or self.unique_name("component"))
        node.visible = bool(visible)
        self.root.add(node)
        self.structure_changed.emit()
        return node

    def add_instance(self, comp: CadNode) -> CadNode:
        """Place an *instance* of an Object into the Main assembly: a
        Linked copy that compiles to one placed call of the Object's
        module. The same Object can be instanced many times, each
        placed and mated on its own."""
        if comp.name and \
                [n.name for n in self.root.walk()].count(comp.name) > 1:
            comp.name = self.unique_name(comp.type)
        taken = {n.name for n in self.root.walk()}
        for i in itertools.count(1):
            name = f"{comp.name} {i}"
            if name not in taken:
                break
        ref = CadNode("reference", name, dict(ref=comp.name))
        self.root.add(ref)
        self.structure_changed.emit()
        return ref

    def instances_of(self, comp: CadNode):
        """Top-level instances (Linked copies) of *comp*."""
        return [c for c in self.root.children
                if c.type == "reference"
                and c.params.get("ref") == comp.name]

    def make_component(self, node: CadNode) -> CadNode:
        """Promote *node* into an Object: a Group converts in place
        (it carries the same placement params), anything else is
        wrapped. Returns the component node."""
        if node.type == "component":
            return node
        if node.parent is None or \
                node.type in ("masters", "variables", "root"):
            return None
        if node.type == "union":
            node.type = "component"
            if node.name.startswith("Group"):
                node.name = self.unique_name("component")
            self.structure_changed.emit()
            return node
        parent, index = node.parent, node.index()
        comp = CadNode("component", self.unique_name("component"))
        parent.remove(node)
        comp.add(node)
        parent.add(comp, index)
        self.structure_changed.emit()
        return comp

    def enclose_as_part(self, node: CadNode, name: str = "") -> CadNode:
        """Wrap *node* into a **visible** Object so the Main assembly
        lists it as a single opaque row (its construction is edited in
        the Object tab). The part keeps *name* (default: the node's own
        name), made unique against everything outside its subtree."""
        base = (name or node.name or "").strip()
        comp = self.make_component(node)
        if comp is None:
            return node
        comp.visible = True
        if base and comp.name != base:
            inside = {n.id for n in comp.walk()}
            taken = {n.name for n in self.root.walk()
                     if n.id not in inside}
            candidate = base
            for i in itertools.count(2):
                if candidate not in taken:
                    break
                candidate = f"{base} {i}"
            comp.name = candidate
            self.node_changed.emit(comp)
        return comp

    def enclose_import_as_part(self, name: str) -> CadNode:
        """Gather every loose top-level geometry node (an import's
        content) into ONE visible Object named *name* — module-defined
        Objects, instances and the variables/masters stores stay as
        they are. Returns the part, or None when nothing was loose."""
        loose = [c for c in self.root.children
                 if c.type not in ("component", "reference", "masters",
                                   "variables", "assign", "scad_use")]
        if not loose:
            return None
        if len(loose) == 1:
            return self.enclose_as_part(loose[0], name=name)
        group = self.group_nodes(loose)
        return self.enclose_as_part(group, name=name)

    def _clone(self, node: CadNode) -> CadNode:
        copy = CadNode(node.type, node.name, None)
        copy.params = {k: (list(map(list, v)) if isinstance(v, list)
                           else v) for k, v in node.params.items()}
        copy.visible = node.visible
        for child in node.children:
            copy.add(self._clone(child))
        return copy

    def clear(self):
        self.reference_images = []
        self.drawing = None
        self.house = None
        self.city = None
        self.collections = []
        self.root = CadNode("root")
        self.structure_changed.emit()
        self.drawing_changed.emit()
        self.set_unit("mm")
        self.set_real_scale(1.0)


class _SnapshotCommand(QUndoCommand):
    """Whole-document snapshot: simple, correct for every operation,
    and cheap at .kcad document sizes. Commands pushed in rapid
    succession merge, so drags stay one undo step."""

    def __init__(self, model, old_state, new_state):
        super().__init__("edit")
        self.model = model
        self.old_state = old_state
        self.new_state = new_state
        self.stamp = time.monotonic()
        self._first_redo = True

    def id(self):
        return 1

    def mergeWith(self, other):
        if time.monotonic() - self.stamp > self.model.UNDO_MERGE_S:
            return False
        self.new_state = other.new_state
        self.stamp = other.stamp
        return True

    def redo(self):
        if self._first_redo:                 # push() applies nothing:
            self._first_redo = False         # the state is already live
            return
        self.model.restore_state(self.new_state)

    def undo(self):
        self.model.restore_state(self.old_state)


# ------------------------------------------------------------ validation

def validate(root: CadNode) -> dict:
    """Static checks over the tree: ``{node_id: error message}`` for
    every node that would break (or silently ruin) the OpenSCAD
    program. The tree panel paints these nodes red."""
    errors = {}

    def check(node, env):
        message = _check_node(node, env, errors)
        if message:
            errors[node.id] = message
        scoped = dict(env)
        if node.type in ("for_loop", "while_loop"):
            values = node.loop_values(env)
            var = str(node.params.get("variable", "i")) or "i"
            scoped[var] = values[0] if values else 0.0
        bound = _organic.child_scope(node, env)
        if bound is not None:                 # let, intersection_for
            scoped = bound

        def define(assign):
            var = str(assign.params.get("variable", "")).strip()
            if var:
                try:
                    scoped[var] = expr.evaluate(
                        assign.params.get("value", 0), scoped)
                except expr.ExprError:
                    pass

        for child in node.children:
            check(child, scoped)
            if child.type == "assign" and child.visible:
                define(child)
            elif child.type == "variables" and child.visible:
                # transparent group: its variables belong to this scope
                for grandchild in child.children:
                    if grandchild.type == "assign" and grandchild.visible:
                        define(grandchild)
    check(root, {})
    return errors


def _check_node(node, env, errors):
    import re
    p = node.params
    t = node.type
    if t == "root":
        return None

    # --- expression params (numeric schema fields holding strings)
    for key, _label, kind, _mn, _mx in NODE_TYPES[t]["schema"]:
        value = p.get(key)
        if kind in ("float", "int") and isinstance(value, str):
            try:
                expr.evaluate(value, env)
            except expr.ExprError as exc:
                return f"{key}: {exc}"

    if t in ("for_loop", "while_loop", "assign"):
        var = str(p.get("variable", "")).strip()
        if not re.fullmatch(r"\$?[A-Za-z_]\w*", var or ""):
            return f"invalid variable name: {var!r}"
    if t == "assign":
        try:
            expr.evaluate(p.get("value", 0), env)
        except expr.ExprError as exc:
            return f"value: {exc}"
    if t in ("while_loop", "if_else"):
        scope = dict(env)
        if t == "while_loop":
            scope[str(p.get("variable", "x")) or "x"] = 0.0
            for key in ("condition", "update"):
                try:
                    expr.evaluate(p[key], scope)
                except expr.ExprError as exc:
                    return f"{key}: {exc}"
            if len(node.loop_values(env)) >= MAX_WHILE_ITERATIONS:
                return ("while loop does not terminate "
                        f"(capped at {MAX_WHILE_ITERATIONS})")
        else:
            try:
                expr.evaluate(p["condition"], scope)
            except expr.ExprError as exc:
                return f"condition: {exc}"
    if t == "for_loop" and str(p.get("values", "")).strip():
        for chunk in split_values(str(p["values"])):
            try:
                expr.evaluate(chunk, env)
            except expr.ExprError as exc:
                return f"values: {exc}"

    if t in _organic.TYPES:
        message = _organic.check(node, env)
        if message:
            return message
    if t == "polygon" and len(p.get("points", [])) < 3:
        return "polygon needs at least 3 points"
    if t == "stl_import":
        from pathlib import Path
        path = str(p.get("path", "")).strip()
        if not path:
            return "no STL file selected"
        if not Path(path).exists():
            return f"file not found: {path}"
        scale = p.get("scale", 1.0)
        if isinstance(scale, (int, float)) and scale <= 0:
            return "scale must be above 0"

    if t in ("linear_extrude", "rotate_extrude"):
        if _contains_3d(node):
            return "extrusions need 2D shapes, but this contains 3D"
        if not node.has_2d_content():
            return "empty extrusion — put 2D shapes inside"
        if t == "rotate_extrude":
            from . import mesh
            for outline in mesh.collect_outlines(node, env):
                xs = [x for x, _y in outline]
                if xs and min(xs) < -1e-6 and max(xs) > 1e-6:
                    return ("profile crosses the Z axis — keep it on "
                            "one side of x = 0")
    elif node.is_container() and t not in ("if_else", "variables"):
        # an Object may say it starts empty on purpose (a Lego build
        # before its first piece): OpenSCAD takes an empty module
        if not any(c.type != "assign" for c in node.children) \
                and not (t == "component" and node.params.get("keep_empty")):
            return "empty — add child objects"
    elif t == "if_else":
        else_node = next((c for c in node.children
                          if c.type == "union"
                          and c.name.lower().startswith("else")), None)
        then_nodes = [c for c in node.children if c is not else_node]
        if not then_nodes and not (else_node and else_node.children):
            return "empty — add objects to the branches"
    return None


def _contains_3d(node) -> bool:
    """True if the subtree produces 3D geometry (illegal inside an
    extrusion)."""
    for n in node.walk():
        if n is node:
            continue
        if n.category == SHAPE_3D or \
                n.type in ("linear_extrude", "rotate_extrude", "sweep",
                           "section_loft"):
            return True
    return False


# Organic node types (capsule, ellipsoid, rounded box, symmetry, joint)
# live in organic.py. Registered last, so that module needs nothing
# from this one at import time.
from . import organic as _organic  # noqa: E402

_organic.register(NODE_TYPES, CONTAINER_TYPES)
