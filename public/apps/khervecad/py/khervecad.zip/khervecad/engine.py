"""OpenSCAD engine integration.

OpenSCAD is the engine behind KherveCAD: the GUI generates an OpenSCAD
program and, when the ``openscad`` binary is installed, this module
runs it headless to produce the exact mesh (booleans included) shown
in the 3D view and exported to STL. Rendering runs in a background
QProcess with debouncing so dragging in the 2D view stays smooth.
Without the binary the app still works — the built-in tessellator
(mesh.py) supplies the preview.

Every run uses OpenSCAD's Manifold backend when the installed binary has
it (`backend_args`): the same exact geometry as the old CGAL backend,
one to two orders of magnitude faster.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import shutil
import struct
import sys
import tempfile
import weakref
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from PyQt5.QtCore import QObject, QProcess, QSettings, QTimer, pyqtSignal

_SETTINGS = ("Kherve", "KherveCAD")

#: name of the binary inside a bundled ``openscad/`` folder.
_OPENSCAD_EXE = "openscad.exe" if os.name == "nt" else "openscad"

#: places to look for the binary besides PATH.
_CANDIDATES = [
    r"C:\Program Files\OpenSCAD\openscad.exe",
    r"C:\Program Files (x86)\OpenSCAD\openscad.exe",
    "/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD",
    "/usr/bin/openscad",
    "/usr/local/bin/openscad",
    "/snap/bin/openscad",
]


#: layouts of a bundled ``openscad/`` folder, relative to a root. Windows
#: and Linux get the portable tree (the binary sits at the top); macOS
#: ships the official ``OpenSCAD.app``, whose binary is buried inside it.
_BUNDLE_LAYOUTS = [
    ("openscad", _OPENSCAD_EXE),
    ("openscad", "OpenSCAD.app", "Contents", "MacOS", "OpenSCAD"),
]


#: OpenSCAD gimbal camera rotations for every standard still, named as
#: the 3D view names the same viewpoint (plus the back-left isometric,
#: which has no preset there).  Paired with ``--viewall --autocenter``
#: these are all a still needs: the distance is computed from the
#: model.  `view_angles` turns each into the 3D view's own camera, so
#: the built-in renderer and OpenSCAD see the same side of the part.
CAMERA_ROTATIONS = {
    "Isometric": (55, 0, 25),          # OpenSCAD's default: front-right
    "Isometric front-left": (55, 0, 335),
    "Isometric back-right": (55, 0, 115),
    "Isometric back": (55, 0, 205),    # the opposite corner: back-left
    # the product-shot angles: mostly the front, a little from the right;
    # steeply from above; nearly level, the way the part stands on a
    # table; and from below, so a listing shows the underside too
    "Three-quarter front": (70, 0, 10),
    "Bird's-eye": (30, 0, 30),
    "Low angle": (80, 0, 40),
    "Underside": (125, 0, 335),
    "Top": (0, 0, 0),
    "Bottom": (180, 0, 0),
    "Front": (90, 0, 0),
    "Back": (90, 0, 180),
    "Right": (90, 0, 90),
    "Left": (90, 0, 270),
}


def wait_until_idle(engine, timeout_s: float) -> bool:
    """Pump the event loop until *engine* has nothing rendering or
    queued, so the 3D view holds OpenSCAD's exact meshes rather than the
    built-in approximation. True when it settled within *timeout_s*
    (always, without OpenSCAD: the preview is then the final word).
    Anything with ``available`` and ``is_idle()`` will do."""
    import time

    from PyQt5.QtCore import QCoreApplication, QEventLoop, QThread
    if not engine.available:
        return True
    deadline = time.monotonic() + timeout_s
    calm = 0
    while True:
        QCoreApplication.processEvents(QEventLoop.AllEvents, 50)
        # idle on two passes in a row: a finished part that queues the
        # next render has had its chance to do so
        calm = calm + 1 if engine.is_idle() else 0
        if calm >= 2:
            return True
        if time.monotonic() >= deadline:
            return False
        QThread.msleep(15)


def view_angles(rotation) -> tuple:
    """The 3D view's (yaw, pitch) for an OpenSCAD gimbal *rotation*.

    OpenSCAD's eye sits at (sin rx sin rz, -sin rx cos rz, cos rx) from
    the target — Front (90,0,0) looks from -Y, Right (90,0,90) from +X
    — and View3D's at (cos p cos y, cos p sin y, sin p).  Equating the
    two gives yaw = rz - 90 and pitch = 90 - rx.  The pitch stops a
    degree short of the poles, as View3D.VIEWS does, where the yaw
    would stop meaning anything.
    """
    rx, _ry, rz = (float(v) for v in rotation)
    yaw = (rz - 90.0 + 180.0) % 360.0 - 180.0
    pitch = min(max(90.0 - rx, -89.0), 89.0)
    return yaw, pitch


def bundled_openscad() -> str:
    """Path of the OpenSCAD shipped beside the app, or '' if there is none.

    The Windows installer drops the official portable build into an
    ``openscad/`` subfolder of the application directory, so the engine
    is guaranteed present; the macOS DMG does the same with the official
    ``OpenSCAD.app`` inside the bundle's ``Contents/Resources/``. Looks
    next to the executable when frozen (PyInstaller one-folder:
    ``sys.executable``'s directory, and ``sys._MEIPASS`` for a one-file
    build) and next to the project root when running from a checkout, so
    a manually-dropped copy works there too.
    """
    roots = []
    if getattr(sys, "frozen", False):
        exe_dir = Path(sys.executable).resolve().parent
        roots.append(exe_dir)
        # In a .app the executable lives in Contents/MacOS/; everything
        # that is not code belongs one level over in Contents/Resources/.
        if exe_dir.name == "MacOS" and exe_dir.parent.name == "Contents":
            roots.append(exe_dir.parent / "Resources")
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            roots.append(Path(meipass))
    roots.append(Path(__file__).resolve().parent.parent)
    for root in roots:
        for layout in _BUNDLE_LAYOUTS:
            exe = root.joinpath(*layout)
            if exe.exists():
                return str(exe)
    return ""


def find_openscad() -> str:
    """Path of the OpenSCAD binary, or '' when not installed.

    A custom location can be stored in QSettings key ``openscad_path``
    (Edit > Locate OpenSCAD in the GUI). Setting the environment
    variable ``KHERVECAD_DISABLE_ENGINE`` forces the built-in preview
    (used by the test suite so no background renders are spawned).

    Order: the user's explicit choice, then the copy bundled beside the
    app, then PATH and the usual install locations. The bundle beats
    discovery — it is the one copy we know is there and know works — but
    not a path the user deliberately pointed us at, or Locate OpenSCAD
    would silently do nothing in an installed build.
    """
    if os.environ.get("KHERVECAD_DISABLE_ENGINE"):
        return ""
    custom = QSettings(*_SETTINGS).value("openscad_path", "")
    if custom and Path(custom).exists():
        return str(custom)
    bundled = bundled_openscad()
    if bundled:
        return bundled
    path = shutil.which("openscad")
    if path:
        return path
    for candidate in _CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return ""


def set_openscad_path(path: str):
    QSettings(*_SETTINGS).setValue("openscad_path", path)


# -------------------------------------------------------------- backend

#: ``KHERVECAD_OPENSCAD_BACKEND=cgal`` forces OpenSCAD's old CGAL backend
#: (for troubleshooting); otherwise `backend_args` picks Manifold.
_BACKEND_ENV = "KHERVECAD_OPENSCAD_BACKEND"

#: {binary path: its backend switch}, asked once per binary
_backend_cache = {}


def _help_text(binary: str) -> str:
    """``binary --help``, stdout and stderr together ('' on failure)."""
    import subprocess
    try:
        out = subprocess.run(
            [binary, "--help"], capture_output=True, text=True,
            errors="replace", timeout=5,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.SubprocessError, ValueError):
        return ""
    return (out.stdout or "") + (out.stderr or "")


def backend_args(binary: str) -> list:
    """The switch that puts OpenSCAD on its Manifold backend, or [].

    Manifold computes the same exact geometry as the old CGAL backend,
    one to two orders of magnitude faster: a car body took 2 min 43 s
    under CGAL and 0.8 s under Manifold — the difference between an
    exact preview and one that never arrives. Recent builds take
    ``--backend=Manifold``; earlier development snapshots offered it as
    the experimental feature ``--enable=manifold``; the 2021.01 release
    has neither and gets no switch (an unknown flag fails every render).
    Read off the binary's --help, once per binary."""
    if not binary or \
            os.environ.get(_BACKEND_ENV, "").strip().lower() == "cgal":
        return []
    if binary not in _backend_cache:
        text = _help_text(binary).lower()
        if "--backend" in text and "manifold" in text:
            _backend_cache[binary] = ["--backend=Manifold"]
        elif "manifold" in text:                 # a feature of --enable
            _backend_cache[binary] = ["--enable=manifold"]
        else:
            _backend_cache[binary] = []
    return list(_backend_cache[binary])


_JOBS_ENV = "KHERVECAD_RENDER_JOBS"


def default_jobs() -> int:
    """OpenSCAD processes rendering parts at once: one per core bar one
    (the app's own), at most 6 — OpenSCAD's Manifold backend is already
    multi-threaded, so more only fights over memory. Overridden by
    ``KHERVECAD_RENDER_JOBS``."""
    try:
        forced = int(os.environ.get(_JOBS_ENV, "0"))
    except ValueError:
        forced = 0
    if forced > 0:
        return forced
    return max(1, min(6, (os.cpu_count() or 2) - 1))


_binstl_cache = {}


def binary_stl_args(binary: str) -> list:
    """``--export-format binstl`` when the binary knows it, else [].

    OpenSCAD writes ASCII STL by default: about five times the bytes of
    a binary one, and far slower to parse — every exact part of the
    preview goes through that file. Probed off --help once per binary,
    and not at all when the backend is forced (a stand-in binary)."""
    if not binary or os.environ.get(_BACKEND_ENV, "").strip():
        return []
    if binary not in _binstl_cache:
        _binstl_cache[binary] = (["--export-format", "binstl"]
                                 if "binstl" in _help_text(binary) else [])
    return list(_binstl_cache[binary])


def backend_name(binary: str) -> str:
    """'Manifold' or 'CGAL': the backend a run of *binary* uses."""
    return "Manifold" if backend_args(binary) else "CGAL"


def _process(parent=None) -> QProcess:
    """A QProcess for one OpenSCAD run. Renders run from a temporary
    folder, so OPENSCADPATH carries the document's folder and the
    library folders `use <...>` / `include <...>` resolve against."""
    process = QProcess(parent) if parent is not None else QProcess()
    try:
        from . import scadlib
        process.setProcessEnvironment(scadlib.process_environment())
    except Exception:                         # never block a render
        pass
    return process


#: variables set on every OpenSCAD run (``-D name=value``) — the
#: animation time $t while View ▸ Animate shows one (animate.py)
DEFINES = {}


def openscad_args(binary: str, out_path, scad_path, extra=()) -> list:
    """The arguments of one OpenSCAD run: output, backend, extras, input.
    Every render and export goes through here, so none of them falls
    back to the slow backend."""
    defines = [arg for name, value in DEFINES.items()
               for arg in ("-D", f"{name}={value}")]
    return ["-o", str(out_path), *backend_args(binary), *defines, *extra,
            str(scad_path)]


# ----------------------------------------------------------------- STL

def parse_stl(path: str):
    """Parse a binary or ASCII STL file into a triangle list."""
    data = Path(path).read_bytes()
    if len(data) >= 84:
        count = struct.unpack_from("<I", data, 80)[0]
        if len(data) == 84 + count * 50:
            return _parse_binary(data, count)
    return _parse_ascii(data.decode("ascii", errors="replace"))


def _parse_binary(data: bytes, count: int):
    # one iter_unpack over the records instead of an unpack per triangle
    return [((v[3], v[4], v[5]), (v[6], v[7], v[8]), (v[9], v[10], v[11]))
            for v in struct.iter_unpack("<12f2x",
                                        data[84:84 + count * 50])]


def _parse_ascii(text: str):
    mesh = []
    vertices = []
    for line in text.splitlines():
        parts = line.split()
        if parts[:1] == ["vertex"]:
            vertices.append(tuple(float(v) for v in parts[1:4]))
            if len(vertices) == 3:
                mesh.append(tuple(vertices))
                vertices = []
    return mesh


def _parse_obj(text):
    """Wavefront OBJ -> triangle list (v vertices + f faces, triangulated
    by fan; vt/vn slashes and negative indices handled)."""
    verts, mesh = [], []
    for line in text.splitlines():
        parts = line.split()
        if not parts:
            continue
        if parts[0] == "v" and len(parts) >= 4:
            verts.append((float(parts[1]), float(parts[2]),
                          float(parts[3])))
        elif parts[0] == "f" and len(parts) >= 4:
            idx = []
            for tok in parts[1:]:
                n = int(tok.split("/")[0])
                idx.append(n - 1 if n > 0 else len(verts) + n)
            for j in range(1, len(idx) - 1):
                try:
                    mesh.append((verts[idx[0]], verts[idx[j]],
                                 verts[idx[j + 1]]))
                except IndexError:
                    pass
    return mesh


def _parse_off(text):
    """Object File Format (OFF) -> triangle list. Faces of any vertex
    count are fan-triangulated; a leading OFF/COFF/NOFF header and #
    comments are tolerated."""
    tokens = []
    for line in text.splitlines():
        tokens.extend(line.split("#", 1)[0].split())
    if not tokens:
        return []
    i = 1 if tokens[0].upper().endswith("OFF") else 0
    mesh = []
    try:
        nv, nf = int(tokens[i]), int(tokens[i + 1])
        i += 3                                    # skip the edge count
        verts = []
        for _ in range(nv):
            verts.append((float(tokens[i]), float(tokens[i + 1]),
                          float(tokens[i + 2])))
            i += 3
        for _ in range(nf):
            cnt = int(tokens[i])
            i += 1
            face = [int(tokens[i + j]) for j in range(cnt)]
            i += cnt
            for j in range(1, cnt - 1):
                mesh.append((verts[face[0]], verts[face[j]],
                             verts[face[j + 1]]))
    except (IndexError, ValueError):
        pass
    return mesh


def _parse_3mf(path: str):
    """3MF (a zip of XML) -> triangle list. Reads every mesh's vertices
    and triangles; build-item transforms are ignored (the OpenSCAD engine
    applies them for the exact render)."""
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        model = "3D/3dmodel.model"
        if model not in names:
            model = next((n for n in names
                          if n.lower().endswith(".model")), None)
            if model is None:
                return []
        root = ET.fromstring(archive.read(model))
    for element in root.iter():                   # drop XML namespaces
        element.tag = element.tag.split("}")[-1]
    mesh = []
    for block in root.iter("mesh"):
        verts = [(float(v.get("x")), float(v.get("y")), float(v.get("z")))
                 for v in block.iter("vertex")]
        for tri in block.iter("triangle"):
            try:
                mesh.append((verts[int(tri.get("v1"))],
                             verts[int(tri.get("v2"))],
                             verts[int(tri.get("v3"))]))
            except (IndexError, TypeError, ValueError):
                pass
    return mesh


#: Mesh formats KherveCAD can preview in the built-in viewer (the
#: OpenSCAD engine's import() renders them all for the exact mesh).
MESH_EXTS = (".stl", ".obj", ".off", ".3mf", ".amf", ".glb")


def parse_mesh(path: str):
    """Parse any supported mesh file into a triangle list, by extension."""
    ext = Path(path).suffix.lower()
    if ext == ".obj":
        return _parse_obj(Path(path).read_text(errors="replace"))
    if ext == ".off":
        return _parse_off(Path(path).read_text(errors="replace"))
    if ext == ".3mf":
        return _parse_3mf(path)
    if ext == ".amf":
        return _parse_amf(path)
    if ext == ".glb":
        # glTF is Y-up: turned Z-up here, so the preview, the STL the
        # import writes and the exact render all agree
        from .photo3d import parse_glb
        return [tuple((v[0], -v[2], v[1]) for v in t) for t in parse_glb(path)]
    return parse_stl(path)


def _parse_amf(path: str):
    """AMF (plain or zipped XML): every object's vertices and the
    triangles of all its volumes, in millimetres (``unit`` honoured)."""
    import xml.etree.ElementTree as ET
    import zipfile
    data = Path(path).read_bytes()
    if data[:2] == b"PK":
        with zipfile.ZipFile(path) as archive:
            data = archive.read(archive.namelist()[0])
    root = ET.fromstring(data)
    scale = {"inch": 25.4, "millimeter": 1.0, "meter": 1000.0,
             "feet": 304.8, "micron": 0.001}.get(
        (root.get("unit") or "millimeter").lower(), 1.0)

    def local(el):
        return el.tag.rsplit("}", 1)[-1]
    tris = []
    for obj in root.iter():
        if local(obj) != "object":
            continue
        verts = []
        for el in obj.iter():
            if local(el) == "coordinates":
                xyz = {local(c): float(c.text or 0) for c in el}
                verts.append((xyz.get("x", 0.0) * scale,
                              xyz.get("y", 0.0) * scale,
                              xyz.get("z", 0.0) * scale))
        for el in obj.iter():
            if local(el) == "triangle":
                idx = {local(c): int(c.text or 0) for c in el}
                try:
                    tris.append((verts[idx["v1"]], verts[idx["v2"]],
                                 verts[idx["v3"]]))
                except (KeyError, IndexError):
                    continue
    return tris


def write_stl(mesh, path: str, name: str = "khervecad"):
    """Write a binary STL (used for export when OpenSCAD is absent)."""
    with open(path, "wb") as fh:
        header = f"{name} (KherveCAD)".encode()[:80]
        fh.write(header.ljust(80, b"\0"))
        fh.write(struct.pack("<I", len(mesh)))
        for a, b, c in mesh:
            ux, uy, uz = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
            vx, vy, vz = (c[0] - a[0], c[1] - a[1], c[2] - a[2])
            nx, ny, nz = (uy * vz - uz * vy, uz * vx - ux * vz,
                          ux * vy - uy * vx)
            length = (nx * nx + ny * ny + nz * nz) ** 0.5 or 1.0
            fh.write(struct.pack("<3f", nx / length, ny / length,
                                 nz / length))
            for v in (a, b, c):
                fh.write(struct.pack("<3f", *v))
            fh.write(b"\0\0")


# --------------------------------------------------------------- engine

class ScadEngine(QObject):
    """Debounced background renders through the OpenSCAD binary."""

    mesh_ready = pyqtSignal(list)      # exact mesh from OpenSCAD
    part_ready = pyqtSignal(str, list)  # (content key, exact part mesh)
    render_failed = pyqtSignal(str)    # compiler message
    busy_changed = pyqtSignal(bool)

    DEBOUNCE_MS = 500

    def __init__(self, parent=None):
        super().__init__(parent)
        self.binary = find_openscad()
        self._dir = Path(tempfile.mkdtemp(prefix="khervecad_"))
        self._process = None
        self._pending_code = None
        #: bumped whenever what is on screen stops matching the render
        #: in flight; _finished then drops that render's result.
        self._generation = 0
        self._running_generation = 0
        #: {content key: program} for per-part exact renders, and the
        #: key of the one running (so it is never queued twice)
        self._part_queue = {}
        self._running_part = None
        #: extra part renders running beside the main one:
        #: {lane number: (QProcess, content key)}
        self._lanes = {}
        #: how many OpenSCAD processes may render parts at once
        self.max_jobs = default_jobs()
        #: folder of finished part meshes kept between sessions, keyed
        #: by content (None: no disk cache — the tests' engines)
        self.cache_dir = None
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(self.DEBOUNCE_MS)
        self._timer.timeout.connect(self._start)

    @property
    def available(self) -> bool:
        return bool(self.binary)

    @property
    def backend(self) -> str:
        """'Manifold' or 'CGAL' ('' without OpenSCAD); see backend_args."""
        return backend_name(self.binary) if self.binary else ""

    def refresh_binary(self):
        _backend_cache.clear()            # a new binary may know new flags
        _binstl_cache.clear()
        self.binary = find_openscad()
        return self.binary

    # ------------------------------------------------------- rendering
    def request_render(self, scad_code: str):
        """Schedule a render of *scad_code* (debounced). A render still
        running is disowned: its code is already superseded, so letting
        it land would paint the previous model over the current one."""
        if not self.available:
            return
        self._pending_code = scad_code
        self._generation += 1
        self._timer.start()

    def request_part_render(self, key: str, scad_code: str):
        """Queue an exact render of ONE part, identified by its content
        *key*. Parts are rendered one at a time in the background and
        the result is emitted as `part_ready(key, mesh)`.

        This is what makes an exact preview affordable: a whole-document
        render redoes the CSG of every part on every change (a minute on
        a real assembly), while a part is re-rendered only when its own
        contents change — never when it is moved, snapped or coloured.
        A stale result cannot mislead: the key IS the content."""
        if not self.available or not key:
            return
        if key in self._part_queue or key == self._running_part or \
                any(k == key for _p, k in self._lanes.values()):
            return
        cached = self._load_cached_part(key)
        if cached:
            # rendered in an earlier session: no OpenSCAD run at all
            QTimer.singleShot(0, lambda k=key, m=cached:
                              self.part_ready.emit(k, m))
            return
        self._part_queue[key] = scad_code
        self._timer.start()

    # ------------------------------------------------ part disk cache
    def _cache_path(self, key: str):
        if not self.cache_dir:
            return None
        import hashlib
        digest = hashlib.sha256(
            f"{self.backend}\0{key}".encode("utf-8", "replace")).hexdigest()
        return Path(self.cache_dir) / f"{digest[:40]}.stl"

    def _load_cached_part(self, key: str):
        path = self._cache_path(key)
        if path is None or not path.exists():
            return None
        try:
            os.utime(path)                     # recently used: keep it
            return parse_stl(str(path))
        except Exception:
            return None

    def _store_cached_part(self, key: str, stl_path: str):
        path = self._cache_path(key)
        if path is None:
            return
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(".tmp")
            shutil.copyfile(stl_path, tmp)
            os.replace(tmp, path)
        except OSError:
            pass                               # a cache, never an error

    def prune_cache(self, max_bytes: int = 1 << 30):
        """Keep the disk cache under *max_bytes*, dropping the least
        recently used meshes first."""
        if not self.cache_dir or not Path(self.cache_dir).is_dir():
            return
        files = sorted(Path(self.cache_dir).glob("*.stl"),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        total = 0
        for path in files:
            total += path.stat().st_size
            if total > max_bytes:
                try:
                    path.unlink()
                except OSError:
                    pass

    def is_idle(self) -> bool:
        """Nothing rendering and nothing waiting: what the 3D view shows
        is final until the model changes again."""
        return (self._process is None and self._pending_code is None
                and not self._part_queue and not self._lanes
                and not self._timer.isActive())

    def _busy(self) -> bool:
        return self._process is not None or bool(self._lanes)

    def wait_idle(self, timeout_s: float) -> bool:
        """See `wait_until_idle`."""
        return wait_until_idle(self, timeout_s)

    def cancel_parts(self):
        """Drop queued part renders (the document changed wholesale)."""
        self._part_queue.clear()

    def cancel(self):
        """Drop the pending render and disown one in flight — the
        built-in preview is authoritative from here (the document is
        multi-coloured, say, which a single STL cannot carry). Without
        this, a render requested before the change lands afterwards and
        silently replaces what is on screen."""
        self._timer.stop()
        self._pending_code = None
        self._generation += 1
        if self._part_queue:            # per-part renders still stand
            self._timer.start()

    def _watch(self, process, done):
        """Call *done(engine)* when *process* finishes — without the
        signal holding the engine.

        A slot that captures ``self`` makes a cycle (engine -> process
        -> connection -> slot -> engine). When its window is dropped
        with a render still running, the garbage collector clears the
        slot's ``self`` and destroys the engine; Qt then kills the
        QProcess and fires ``finished`` into the cleared slot — a
        NameError inside a Qt slot, which PyQt5 answers with abort().
        A weak reference is cleared *before* the collector breaks the
        cycle, so the late signal finds no engine and does nothing."""
        ref = weakref.ref(self)

        def finished(_code, _status):
            engine = ref()
            if engine is not None:
                done(engine)
        process.finished.connect(finished)

    def shutdown(self):
        """Stop rendering for good: drop everything queued and kill the
        render in flight, so no OpenSCAD process outlives the window
        that asked for it."""
        self._timer.stop()
        self._pending_code = None
        self._part_queue.clear()
        self._generation += 1
        process, self._process = self._process, None
        self._running_part = None
        lanes, self._lanes = [p for p, _k in self._lanes.values()], {}
        for process in [process, *lanes]:
            if process is None:
                continue
            try:
                process.finished.disconnect()
            except TypeError:                 # nothing connected
                pass
            process.kill()
            process.waitForFinished(2000)

    def _start(self):
        if self._process is not None:
            # A render is running: keep the code pending; _finished
            # restarts the timer so the newest code wins. Parts may
            # still use the spare lanes meanwhile.
            if self._pending_code is None:
                self._fill_lanes()
            return
        if self._pending_code is None:
            self._start_part()
            self._fill_lanes()
            return
        code = self._pending_code
        self._pending_code = None
        self._running_generation = self._generation
        scad_path = self._dir / "model.scad"
        stl_path = self._dir / "model.stl"
        scad_path.write_text(code, encoding="utf-8")
        self._process = _process(self)
        path = str(stl_path)
        self._watch(self._process, lambda eng: eng._finished(path))
        self._process.start(self.binary,
                            openscad_args(self.binary, stl_path, scad_path,
                                          binary_stl_args(self.binary)))
        self.busy_changed.emit(True)

    def _start_part(self):
        """Run the next queued part render (only when no whole-document
        render is waiting — that one is what the user is looking at)."""
        if not self._part_queue:
            return
        key, code = next(iter(self._part_queue.items()))
        del self._part_queue[key]
        self._running_part = key
        scad_path = self._dir / "part.scad"
        stl_path = self._dir / "part.stl"
        scad_path.write_text(code, encoding="utf-8")
        self._process = _process(self)
        self._watch(self._process,
                    lambda eng, k=key, p=str(stl_path):
                    eng._part_finished(k, p))
        self._process.start(self.binary,
                            openscad_args(self.binary, stl_path, scad_path,
                                          binary_stl_args(self.binary)))
        self.busy_changed.emit(True)

    def _fill_lanes(self):
        """Start queued parts on the spare lanes: parts are independent,
        so several OpenSCAD processes render them side by side (one per
        core, bar one for the app) instead of strictly one after
        another. Each lane has its own files, so none overwrites
        another's program or mesh."""
        while self._part_queue and len(self._lanes) < self.max_jobs - 1:
            lane = next(n for n in range(1, self.max_jobs)
                        if n not in self._lanes)
            key, code = next(iter(self._part_queue.items()))
            del self._part_queue[key]
            scad_path = self._dir / f"part{lane}.scad"
            stl_path = self._dir / f"part{lane}.stl"
            scad_path.write_text(code, encoding="utf-8")
            process = _process(self)
            self._lanes[lane] = (process, key)
            self._watch(process,
                        lambda eng, n=lane, k=key, p=str(stl_path):
                        eng._lane_finished(n, k, p))
            process.start(self.binary,
                          openscad_args(self.binary, stl_path, scad_path,
                                        binary_stl_args(self.binary)))
            self.busy_changed.emit(True)

    def _deliver_part(self, process, key: str, stl_path: str):
        exit_ok = (process.exitStatus() == QProcess.NormalExit
                   and process.exitCode() == 0)
        if exit_ok and Path(stl_path).exists():
            try:
                mesh = parse_stl(stl_path)
            except Exception:
                mesh = None
            if mesh:
                self._store_cached_part(key, stl_path)
                # keyed by content, so a late result is never wrong —
                # it just lands under a key nothing is asking for
                self.part_ready.emit(key, mesh)
        if self._pending_code is not None or self._part_queue:
            self._timer.start()

    def _lane_finished(self, lane: int, key: str, stl_path: str):
        entry = self._lanes.pop(lane, None)
        if entry is None:                     # shut down meanwhile
            return
        self.busy_changed.emit(self._busy())
        self._deliver_part(entry[0], key, stl_path)

    def _part_finished(self, key: str, stl_path: str):
        process = self._process
        self._process = None
        self._running_part = None
        self.busy_changed.emit(self._busy())
        self._deliver_part(process, key, stl_path)

    def _finished(self, stl_path: str):
        process = self._process
        self._process = None
        self.busy_changed.emit(self._busy())
        if self._running_generation != self._generation:
            # superseded or cancelled while it ran: its mesh is of the
            # old model, so it must not reach the view
            if self._pending_code is not None or self._part_queue:
                self._timer.start()
            return
        exit_ok = (process.exitStatus() == QProcess.NormalExit
                   and process.exitCode() == 0)
        if exit_ok and Path(stl_path).exists():
            try:
                mesh = parse_stl(stl_path)
            except Exception as exc:
                self.render_failed.emit(f"STL parse error: {exc}")
            else:
                self.mesh_ready.emit(mesh)
        else:
            stderr = bytes(process.readAllStandardError()) \
                .decode(errors="replace").strip()
            self.render_failed.emit(stderr or "render failed")
        if self._pending_code is not None or self._part_queue:
            self._timer.start()

    # ---------------------------------------------------------- export
    def _run_export(self, scad_code: str, out_path: str,
                    extra=(), timeout_ms: int = 120000) -> str:
        """Run the binary once with ``-o out_path``. '' on success."""
        scad_path = self._dir / "export.scad"
        scad_path.write_text(scad_code, encoding="utf-8")
        process = _process()
        process.start(self.binary,
                      openscad_args(self.binary, out_path, scad_path, extra))
        process.waitForFinished(timeout_ms)
        if process.exitStatus() == QProcess.NormalExit and \
                process.exitCode() == 0:
            return ""
        stderr = bytes(process.readAllStandardError()) \
            .decode(errors="replace").strip()
        return stderr or "OpenSCAD export failed"

    def export_mesh(self, scad_code: str, out_path: str) -> str:
        """Export to whatever format the extension asks for.

        OpenSCAD picks the writer from the suffix, so .stl, .3mf, .off
        and .amf all go down this one path.
        """
        return self._run_export(scad_code, out_path)

    def export_stl(self, scad_code: str, out_path: str) -> str:
        """Export *scad_code* to *out_path* synchronously via the
        binary. Returns '' on success, an error message otherwise."""
        return self.export_mesh(scad_code, out_path)

    def export_png(self, scad_code: str, out_path: str,
                   rotation=CAMERA_ROTATIONS["Isometric"],
                   size=(1600, 1200),
                   colorscheme: str = "Tomorrow") -> str:
        """Render a still to *out_path*.

        The camera is given as a gimbal rotation; ``--viewall
        --autocenter`` then frames the model, so the same rotation
        works for a 2 mm part and a 2 m one.  ``--camera`` must carry
        all seven gimbal values — six is a different form entirely
        (eye + centre), and reading a rotation as a look-at point
        points the camera at nothing.
        """
        extra = [
            "--render",
            "--viewall", "--autocenter",
            "--imgsize=%d,%d" % (int(size[0]), int(size[1])),
            "--camera=0,0,0,%g,%g,%g,0" % tuple(rotation),
            "--colorscheme=%s" % colorscheme,
        ]
        return self._run_export(scad_code, out_path, extra)
