"""SolidWorks' **Trim Entities** (2026-11-11, the user, with SolidWorks'
Trim window: Power trim, Corner, Trim away inside, Trim away outside,
Trim to closest).

The Trim tool keeps one option, chosen in its window (`tool_panel`,
beside the 2D sketch or the 3D view, whichever the sketch is drawn in):

- **Power trim** — drag across lines: every line the cursor crosses
  loses the piece it crossed (to the nearest crossings either side);
- **Corner** — click two lines: each is extended or cut back to where
  they meet, keeping the side you clicked;
- **Trim away inside** — click two boundary entities (lines or circles),
  then the lines to trim: the part between the boundaries goes;
- **Trim away outside** — the same, the part BETWEEN them is kept;
- **Trim to closest** — click a piece: it goes, up to the nearest
  crossings (what Trim always did).

The geometry is Qt-free (`corner`, `away`, `power`), on sketch `line`
nodes in their own coordinates; `sketch_modify.trim` does the closest.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import math

POWER, CORNER, INSIDE, OUTSIDE, CLOSEST = (
    "power", "corner", "inside", "outside", "closest")
MODES = [(POWER, "Power trim"), (CORNER, "Corner"),
         (INSIDE, "Trim away inside"), (OUTSIDE, "Trim away outside"),
         (CLOSEST, "Trim to closest")]
MESSAGES = {
    POWER: "Drag across the lines to trim: each loses the piece the "
           "cursor crosses.",
    CORNER: "Click two lines: each is extended or cut back to where they "
            "meet, keeping the side you click.",
    INSIDE: "Click two boundary entities (lines or circles), then each "
            "line to trim: the part between the boundaries goes.",
    OUTSIDE: "Click two boundary entities (lines or circles), then each "
             "line to trim: only the part between them is kept.",
    CLOSEST: "Click the piece of a line to remove, up to the nearest "
             "crossings.",
}
SETTING = "sketch/trim_mode"
EPS = 1e-9


def mode():
    try:
        from PyQt5.QtCore import QSettings
        v = str(QSettings("Kherve", "KherveCAD").value(SETTING, CLOSEST))
    except Exception:
        v = CLOSEST
    return v if v in dict(MODES) else CLOSEST


def set_mode(value):
    from PyQt5.QtCore import QSettings
    QSettings("Kherve", "KherveCAD").setValue(SETTING, value)


# ------------------------------------------------------------ geometry
def _sm():
    from . import sketch_modify
    return sketch_modify


def line_meet(l1, l2):
    """Where the two lines (run on for ever) meet, or None."""
    sm = _sm()
    a, b = sm._ends(l1)
    c, d = sm._ends(l2)
    r = (b[0] - a[0], b[1] - a[1])
    s = (d[0] - c[0], d[1] - c[1])
    den = r[0] * s[1] - r[1] * s[0]
    if abs(den) < EPS:
        return None
    q = (c[0] - a[0], c[1] - a[1])
    t = (q[0] * s[1] - q[1] * s[0]) / den
    return (a[0] + r[0] * t, a[1] + r[1] * t)


def _end_to(model, line, click, point):
    """Move the end of *line* on the far side of *point* from *click*
    (or the nearer end) onto *point*: the clicked side is kept."""
    sm = _sm()
    tx = sm._t_of(line, point)
    tc = sm._t_of(line, click)
    p = line.params
    x, y = round(point[0], 4), round(point[1], 4)
    if tc <= tx:
        p["x2"], p["y2"] = x, y
    else:
        p["x1"], p["y1"] = x, y
    model.node_changed.emit(line)


def corner(model, l1, click1, l2, click2):
    """Both lines run to where they meet, the clicked sides kept."""
    x = line_meet(l1, l2)
    if x is None:
        raise ValueError("those lines are parallel: they never meet")
    _end_to(model, l1, click1, x)
    _end_to(model, l2, click2, x)
    return x


def _hits(line, bound):
    """Parameters on *line* (0..1) where *bound* crosses it."""
    sm = _sm()
    a, b = sm._ends(line)
    if bound.type == "line":
        c, d = sm._ends(bound)
        t = sm._seg_hit(a, b, c, d)
        return [] if t is None else [t]
    if bound.type == "circle":
        ts = sm._circle_hits(a, b, (sm._num(bound.params.get("x")),
                                    sm._num(bound.params.get("y"))),
                             sm._num(bound.params.get("radius"), 1.0))
        return [t for t in ts if -EPS <= t <= 1 + EPS]
    return []


def away(model, line, bounds, inside=True):
    """Trim *line* between (inside) or outside the two *bounds*.
    Returns 'deleted', 'split', 'shortened' or 'kept'."""
    sm = _sm()
    ts = sorted(t for b in bounds for t in _hits(line, b))
    if len(ts) < 2:
        raise ValueError("%s does not cross both boundaries" % line.name)
    t1, t2 = ts[0], ts[-1]
    a, b = sm._ends(line)
    p = line.params
    lo, hi = sm._at(line, t1), sm._at(line, t2)
    if not inside:
        p["x1"], p["y1"] = lo
        p["x2"], p["y2"] = hi
        model.node_changed.emit(line)
        return "shortened"
    left, right = t1 > EPS, t2 < 1 - EPS
    if not left and not right:
        model.remove_node(line)
        return "deleted"
    if left and right:
        p["x2"], p["y2"] = lo
        twin = sm._insert(model, "line", dict(p), line)
        twin.params.update(x1=hi[0], y1=hi[1], x2=b[0], y2=b[1])
        model.node_changed.emit(line)
        return "split"
    if left:
        p["x2"], p["y2"] = lo
    else:
        p["x1"], p["y1"] = hi
    model.node_changed.emit(line)
    return "shortened"


def power(model, lines, p, q):
    """Each of *lines* crossed by the stroke p -> q (in the lines' own
    coordinates) loses the piece it was crossed on. Returns how many."""
    n = 0
    stroke = ("seg", tuple(p), tuple(q))
    for line in list(lines):
        if line.parent is None:
            continue
        cv = curve_of(line)
        if cv is None:
            continue
        hit = None
        for x in meet_points(cv, stroke):
            if _on(stroke, x) is not None and _on(cv, x) is not None:
                hit = x
                break
        if hit is None:
            continue
        trim_piece(model, line, hit)
        n += 1
    return n


# ------------------------------------------------------- the window
def start(win):
    """The Trim Entities button: the tool and its window, beside the view
    the sketch is drawn in."""
    state.clear()
    from . import sketch_modify
    win._set_tool(sketch_modify.TRIM)
    tool = getattr(win.view3d, "edit_tool", None)
    in_3d = getattr(tool, "tool", None) == sketch_modify.TRIM
    close_panel(win.view2d if in_3d else win.view3d)
    open_panel(win.view3d if in_3d else win.view2d)


def _panel(view, create=True):
    panel = getattr(view, "_trim_panel", None)
    if panel is None and create:
        panel = view._trim_panel = _make_panel(view)
    return panel


def open_panel(view):
    panel = _panel(view)
    if panel is not None:
        panel.refresh()
        panel.open()
    return panel


def close_panel(view):
    panel = _panel(view, create=False)
    if panel is not None:
        panel.hide()


def _make_panel(view):
    from .tool_panel import ToolPanel

    def done():
        close_panel(view)
        try:                              # back to Select
            win = view.window()
            from . import stop_tool
            stop_tool.stop(win)
        except Exception:
            pass

    class TrimPanel(ToolPanel):
        def __init__(self):
            super().__init__(view, "Trim Entities", on_ok=done,
                             on_cancel=done)
            self.message = self.hint(MESSAGES[mode()])
            self.section("Options")
            self.choice("mode", "Option", MODES, mode(), self._mode)
            self.finish()

        def _mode(self, value):
            set_mode(value)
            state.clear()
            self.refresh()

        def refresh(self):
            self.set_value("mode", mode())
            self.message.setText(MESSAGES[mode()] + (
                "  (%d boundary picked)" % len(state.get("bounds", []))
                if mode() in (INSIDE, OUTSIDE) and state.get("bounds")
                else ""))
            self.adjustSize()

    return TrimPanel()


#: picks waiting for their partner (corner's first line, the boundaries)
state = {}


def pick(model, node, click):
    """One click of the Trim tool on *node* at *click* (its own coords),
    in the current option. Returns a sentence for the status bar."""
    m = mode()
    if m == CLOSEST:
        if curve_of(node) is None:
            return "Trim works on lines, arcs and circles."
        return "Trim: %s." % trim_piece(model, node, click)
    if m == CORNER:
        if node.type != "line":
            return "Corner: click two lines."
        first = state.get("first")
        if first is None or first[0] is node or first[0].parent is None:
            state["first"] = (node, click)
            return "Corner: now the other line."
        state.pop("first", None)
        corner(model, first[0], first[1], node, click)
        return "Corner: both lines meet."
    if m in (INSIDE, OUTSIDE):
        bounds = state.setdefault("bounds", [])
        bounds[:] = [b for b in bounds if b.parent is not None]
        if len(bounds) < 2:
            if node.type not in ("line", "circle") or node in bounds:
                return MESSAGES[m]
            bounds.append(node)
            return ("Boundary %d: %s. %s" % (
                len(bounds), node.name, "Now the second boundary."
                if len(bounds) < 2 else "Now click the lines to trim."))
        if node.type != "line" or node in bounds:
            return "Click a line that crosses both boundaries."
        return "Trim: %s." % away(model, node, bounds, inside=m == INSIDE)
    return MESSAGES[m]


# ------------------------------------------- lines, arcs and circles
# (2026-11-11, the user, with SolidWorks' flange: "trim some parts of
# those circles which are inside another circle" — a circle's piece
# between two crossings goes and the rest stays as an open arc; and
# "hovering … that quarter circle should be highlighted")
TWO_PI = 2 * math.pi
#: how near two curves must come to count as touching (relative)
TANGENT_TOL = 1e-6
TANGENT_DIST = 1e-4        # of the radius: "touching" for a solved sketch


def curve_of(node):
    """The node as a curve: ("seg", a, b) or ("arc", cx, cy, r, a0,
    sweep) — a full circle is an arc of 2π from angle 0 — else None."""
    from . import sketch_arc
    p = node.params
    try:
        if node.type == "line":
            a = (float(p["x1"]), float(p["y1"]))
            b = (float(p["x2"]), float(p["y2"]))
            g = sketch_arc.geometry(a[0], a[1], b[0], b[1],
                                    sketch_arc.bulge_of(p))
            return ("seg", a, b) if g is None else ("arc",) + tuple(g)
        if node.type == "circle":
            sweep = math.radians(float(p.get("angle", 360) or 360))
            start = math.radians(float(p.get("start_angle", 0) or 0))
            return ("arc", float(p.get("x", 0)), float(p.get("y", 0)),
                    float(p.get("radius", 1)),
                    start if sweep < TWO_PI - 1e-9 else 0.0,
                    min(sweep, TWO_PI))
    except (KeyError, TypeError, ValueError):
        return None
    return None


def _closed(cv):
    return cv[0] == "arc" and abs(abs(cv[5]) - TWO_PI) < 1e-9


def point_at(cv, t):
    if cv[0] == "seg":
        a, b = cv[1], cv[2]
        return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
    _k, cx, cy, r, a0, sweep = cv
    ang = a0 + sweep * t
    return (cx + r * math.cos(ang), cy + r * math.sin(ang))


def t_of(cv, p, clamp=True):
    """Parameter of the point of *cv* nearest *p* (None off an arc's
    range when not clamped)."""
    if cv[0] == "seg":
        a, b = cv[1], cv[2]
        d = (b[0] - a[0], b[1] - a[1])
        L = d[0] ** 2 + d[1] ** 2 or 1e-12
        t = ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1]) / L
        return min(max(t, 0.0), 1.0) if clamp else t
    _k, cx, cy, r, a0, sweep = cv
    ang = math.atan2(p[1] - cy, p[0] - cx)
    s = 1.0 if sweep >= 0 else -1.0
    u = ((ang - a0) * s) % TWO_PI
    if u > TWO_PI - 1e-7:             # the start, read a hair below 2π
        u = 0.0
    t = u / abs(sweep)
    if t <= 1.0 + 1e-6:               # the end, read a hair past it
        return min(t, 1.0)
    if not clamp:
        return None
    # past the arc's end: the nearer end
    return 1.0 if (u - abs(sweep)) < (TWO_PI - u) else 0.0


def _on(cv, p, tol=1e-6):
    """Parameter of point *p* (on cv's carrier) within cv, else None."""
    t = t_of(cv, p, clamp=False)
    if t is None or t < -tol or t > 1 + tol:
        return None
    q = point_at(cv, min(max(t, 0.0), 1.0))
    return t if math.hypot(q[0] - p[0], q[1] - p[1]) < 1e-5 * max(
        1.0, abs(p[0]) + abs(p[1])) + 1e-6 else None


def meet_points(c1, c2):
    """Points where the carriers of two curves cross (no range check)."""
    if c1[0] == "seg" and c2[0] == "seg":
        a, b = c1[1], c1[2]
        c, d = c2[1], c2[2]
        r = (b[0] - a[0], b[1] - a[1])
        s = (d[0] - c[0], d[1] - c[1])
        den = r[0] * s[1] - r[1] * s[0]
        if abs(den) < 1e-12:
            return []
        q = (c[0] - a[0], c[1] - a[1])
        t = (q[0] * s[1] - q[1] * s[0]) / den
        return [(a[0] + r[0] * t, a[1] + r[1] * t)]
    if c1[0] == "arc" and c2[0] == "seg":
        c1, c2 = c2, c1
    if c1[0] == "seg":
        a, b = c1[1], c1[2]
        _k, cx, cy, rad, _a0, _sw = c2
        d = (b[0] - a[0], b[1] - a[1])
        f = (a[0] - cx, a[1] - cy)
        A = d[0] ** 2 + d[1] ** 2
        B = 2 * (f[0] * d[0] + f[1] * d[1])
        C = f[0] ** 2 + f[1] ** 2 - rad ** 2
        disc = B * B - 4 * A * C
        if A < 1e-18:
            return []
        # a line the solver left a hair off the exact tangent (outside, or
        # a hair inside: two crossings 1e-5 apart) touches the circle ONCE,
        # at the foot of the perpendicular from the centre (2026-11-15,
        # Exercise 58: the Ø28 circle between its two tangent lines was
        # deleted whole)
        t_f = -(f[0] * d[0] + f[1] * d[1]) / A
        foot = (a[0] + d[0] * t_f, a[1] + d[1] * t_f)
        if abs(math.hypot(foot[0] - cx, foot[1] - cy) - rad) < \
                TANGENT_DIST * max(rad, 1.0):
            return [foot]
        if disc < 0:
            # a line TANGENT to the circle touches it once; rounding made
            # it miss by a hair (2026-11-11, the user's trim ran past)
            if disc > -TANGENT_TOL * B * B - 1e-12:
                disc = 0.0
            else:
                return []
        sq = math.sqrt(disc)
        return [(a[0] + d[0] * t, a[1] + d[1] * t)
                for t in ((-B - sq) / (2 * A), (-B + sq) / (2 * A))]
    _k, x0, y0, r0, _a, _s = c1
    _k, x1, y1, r1, _a, _s = c2
    dx, dy = x1 - x0, y1 - y0
    d = math.hypot(dx, dy)
    # circles that only TOUCH (tangent, outside or inside) meet at one
    # point: rounding put them a hair apart and the trim ran past it
    tol = TANGENT_TOL * max(r0, r1, 1.0)
    if d < 1e-12 or d > r0 + r1 + tol or d < abs(r0 - r1) - tol:
        return []
    a = (r0 * r0 - r1 * r1 + d * d) / (2 * d)
    h = math.sqrt(max(r0 * r0 - a * a, 0.0))
    mx, my = x0 + a * dx / d, y0 + a * dy / d
    return [(mx - h * dy / d, my + h * dx / d),
            (mx + h * dy / d, my - h * dx / d)]


def explode(model, node):
    """A rectangle or polygon replaced by its sides as lines, where it
    stood, joined corner to corner (Coincident), a rectangle's sides kept
    Horizontal / Vertical, its own relations moved onto the lines (side
    k -> line k, corner k -> line k's start; the centre's go). The lines,
    side 0 first, or None. SolidWorks trims a rectangle's side the same
    way (2026-11-12, the user: nothing of the rectangle could be picked).
    """
    from . import sketch_constraints as sc
    from .model import CadNode
    parent = node.parent
    if parent is None or node.type not in ("rect", "polygon"):
        return None
    n = 4 if node.type == "rect" else len(node.params.get("points") or [])
    sides = []
    for i in range(n):
        try:
            sides.append(sc._line(node, "e%d" % i, {}))
        except (KeyError, ValueError, IndexError, TypeError):
            return None
    if len(sides) < 3:
        return None
    at = parent.children.index(node)
    shift = len(sides) - 1

    def remap(ref):
        idx, _, ent = ref.partition(".")
        i = int(idx)
        if i > at:
            return "%d.%s" % (i + shift, ent)
        if i < at:
            return ref
        if ent.startswith("e") and ent[1:].isdigit():
            return "%d.l" % (at + int(ent[1:]))
        if ent.startswith("v") and ent[1:].isdigit():
            return "%d.p1" % (at + int(ent[1:]))
        return None                      # the centre: no line has it
    rows = []
    for row in sc.rows(parent):
        refs = [remap(r) for r in row["refs"]]
        if all(r is not None for r in refs):
            rows.append(dict(row, refs=refs))
    keep = {k: v for k, v in node.params.items()
            if k in ("modifier",)}
    parent.remove(node)
    lines = []
    for i, (a, b) in enumerate(sides):
        ln = CadNode("line", "%s side %d" % (node.name, i + 1), dict(
            x1=round(a[0], 6), y1=round(a[1], 6), x2=round(b[0], 6),
            y2=round(b[1], 6), width=0.2, **keep))
        parent.add(ln, at + i)
        lines.append(ln)
    m = len(lines)
    for i in range(m):
        rows.append({"kind": "coincident",
                     "refs": ["%d.p2" % (at + i),
                              "%d.p1" % (at + (i + 1) % m)]})
        if node.type == "rect":
            rows.append({"kind": "horizontal" if i % 2 == 0
                         else "vertical", "refs": ["%d.l" % (at + i)]})
    parent.params[sc.KEY] = rows
    model.structure_changed.emit()
    return lines


def _cutters(node):
    """The curves of the OTHER shapes of the sketch: lines, arcs,
    circles, rectangle and polygon sides (construction ones too, as
    SolidWorks trims to a centerline)."""
    from . import sketch_constraints as sc
    out = []
    parent = node.parent
    for o in (parent.children if parent is not None else []):
        if o is node:
            continue
        cv = curve_of(o)
        if cv is not None:
            if not (o.type == "circle" and _is_point(o)):
                out.append(cv)
            continue
        if o.type in ("rect", "polygon"):
            n = 4 if o.type == "rect" else len(o.params.get("points") or [])
            for i in range(n):
                try:
                    a, b = sc._line(o, "e%d" % i, {})
                except (KeyError, ValueError, IndexError, TypeError):
                    continue
                out.append(("seg", a, b))
    return out + _other_sketches(node)


def _same(m1, m2, eps=1e-6):
    return all(abs(m1[i][j] - m2[i][j]) < eps
               for i in range(4) for j in range(4))


def _other_sketches(node):
    """The curves of the shapes of OTHER sketches of the same Object that
    lie on the same plane — a feature's sketch, hidden inside it, counts
    (2026-11-12, the user: the rectangle should stop at circles another
    extrude had used)."""
    from . import mesh, sketch_constraints as sc
    from .model import SHAPE_2D
    parent = node.parent
    comp = parent
    while comp is not None and comp.type != "component":
        comp = comp.parent
    if comp is None or parent is None:
        return []
    try:
        here = mesh.mat_mul(mesh.ancestor_matrix(parent, {}, stop=comp),
                            mesh.node_matrix(parent, {}))
    except Exception:
        return []
    out, frames = [], {}
    for o in comp.walk():
        if o.category != SHAPE_2D or o is node or o.parent is parent \
                or o.parent is None:
            continue
        if o.params.get("modifier") == "%" and o.type == "circle" and \
                _is_point(o):
            continue
        key = id(o.parent)
        if key not in frames:
            try:
                frames[key] = _same(here, mesh.mat_mul(
                    mesh.ancestor_matrix(o.parent, {}, stop=comp),
                    mesh.node_matrix(o.parent, {})))
            except Exception:
                frames[key] = False
        if not frames[key]:
            continue
        cv = curve_of(o)
        if cv is not None:
            out.append(cv)
            continue
        if o.type in ("rect", "polygon"):
            n = 4 if o.type == "rect" else len(o.params.get("points") or [])
            for i in range(n):
                try:
                    a, b = sc._line(o, "e%d" % i, {})
                except (KeyError, ValueError, IndexError, TypeError):
                    continue
                out.append(("seg", a, b))
    return out


def _is_point(node):
    from .view2d import is_sketch_point
    try:
        return is_sketch_point(node)
    except Exception:
        return False


def cuts(node):
    """Sorted parameters (0..1) where the other shapes cross *node*."""
    cv = curve_of(node)
    if cv is None:
        return []
    ts = []
    for other in _cutters(node):
        for p in meet_points(cv, other):
            if _on(other, p) is None:
                continue
            t = _on(cv, p)
            if t is not None:
                ts.append(min(max(t, 0.0), 1.0))
    ts.sort()
    out = []
    for t in ts:
        if not out or t - out[-1] > 1e-7:
            out.append(t)
    return out


def piece(node, click):
    """(lo, hi) — the parameter range of the piece of *node* under
    *click* between the nearest crossings. For a full circle hi may be
    past 1 (it wraps); None when nothing crosses a circle."""
    cv = curve_of(node)
    if cv is None:
        return None
    t = t_of(cv, click)
    ts = cuts(node)
    if _closed(cv):
        if not ts:
            return (0.0, 1.0)
        ts = [x % 1.0 for x in ts]
        ts = sorted(set(round(x, 9) for x in ts))
        for lo, hi in zip(ts, ts[1:] + [ts[0] + 1.0]):
            tt = t if t >= lo else t + 1.0
            if lo <= tt <= hi:
                return (lo, hi)
        return (ts[-1], ts[0] + 1.0)
    edges = [0.0] + [x for x in ts if 1e-7 < x < 1 - 1e-7] + [1.0]
    for lo, hi in zip(edges, edges[1:]):
        if lo <= t <= hi:
            return (lo, hi)
    return (0.0, 1.0)


def piece_points(node, click, steps=48):
    """The piece trimming *node* at *click* would remove, as a polyline
    in the node's own coordinates (for the highlight)."""
    cv = curve_of(node)
    got = piece(node, click)
    if cv is None or got is None:
        return []
    lo, hi = got
    if cv[0] == "seg":
        return [point_at(cv, lo), point_at(cv, hi)]
    n = max(2, int(steps * (hi - lo)) + 1)
    return [point_at(cv, (lo + (hi - lo) * i / n) % 1.0
                     if _closed(cv) else lo + (hi - lo) * i / n)
            for i in range(n + 1)]


def _set_arc(params, a, b, sweep):
    from . import sketch_arc
    params.update(x1=round(a[0], 6), y1=round(a[1], 6),
                  x2=round(b[0], 6), y2=round(b[1], 6))
    params["bulge"] = round(math.tan(sweep / 4.0), 12)


def trim_piece(model, node, click):
    """Remove the piece of *node* (line, arc, circle) under *click*.
    A circle keeps the rest as an open ARC (a line with a bulge, whose
    centre and size the relations and dimensions still reach). Returns
    'deleted', 'shortened', 'split' or 'opened'."""
    from . import sketch_modify as sm
    cv = curve_of(node)
    got = piece(node, click)
    if cv is None or got is None:
        return "nothing to trim"
    remember(node)
    lo, hi = got
    if _closed(cv):
        span = hi - lo
        if span >= 1.0 - 1e-9:
            model.remove_node(node)
            return "deleted"
        # what stays runs from hi round to lo (+1), counter-clockwise
        keep = 1.0 - span
        a, b = point_at(cv, hi % 1.0), point_at(cv, lo)
        old = node.params
        params = {k: v for k, v in old.items()
                  if k in ("modifier", "origin_point", "collection", KEY)}
        params["width"] = 0.2
        _set_arc(params, a, b, TWO_PI * keep)
        node.type = "line"
        node.params = params
        model.structure_changed.emit()
        model.node_changed.emit(node)
        return "opened"
    if lo <= 1e-9 and hi >= 1 - 1e-9:
        model.remove_node(node)
        return "deleted"
    p = node.params
    a, b = point_at(cv, 0.0), point_at(cv, 1.0)
    sweep = cv[5] if cv[0] == "arc" else 0.0

    def part(t0, t1):
        return point_at(cv, t0), point_at(cv, t1), sweep * (t1 - t0)
    # the end(s) that move let go of what held them there (a corner's
    # Coincident dragged the user's whole rectangle along), and a size
    # set on the line no longer holds
    _release(node, start=lo <= 1e-9, end=hi >= 1 - 1e-9 or
             (lo > 1e-9 and hi < 1 - 1e-9))
    if lo <= 1e-9:
        s, e, sw = part(hi, 1.0)
    elif hi >= 1 - 1e-9:
        s, e, sw = part(0.0, lo)
    else:
        s, e, sw = part(0.0, lo)
        s2, e2, sw2 = part(hi, 1.0)
        twin = sm._insert(model, "line", dict(p), node)
        if cv[0] == "arc":
            _set_arc(twin.params, s2, e2, sw2)
        else:
            twin.params.update(x1=round(s2[0], 6), y1=round(s2[1], 6),
                               x2=round(e2[0], 6), y2=round(e2[1], 6))
        _apply(p, s, e, sw, cv)
        model.node_changed.emit(node)
        model.node_changed.emit(twin)
        return "split"
    _apply(p, s, e, sw, cv)
    model.node_changed.emit(node)
    return "shortened"


#: dimensions a trimmed line no longer keeps (its length changed)
_SIZED = ("length", "distance", "hdistance", "vdistance", "equal",
          "arc_length", "radius", "diameter")


def _release(node, start, end):
    """Drop *node*'s relations on an end trim moves, and its sizes."""
    from . import sketch_constraints as sc
    parent = node.parent
    if parent is None:
        return
    rows = sc.rows(parent)
    if not rows:
        return
    i = str(parent.children.index(node))
    gone = set()
    if start:
        gone.add(i + ".p1")
    if end:
        gone.add(i + ".p2")
    keep = []
    for row in rows:
        refs = row.get("refs") or []
        if any(r in gone for r in refs):
            continue
        if row.get("kind") in _SIZED and any(
                r.partition(".")[0] == i for r in refs):
            continue
        keep.append(row)
    if len(keep) != len(rows):
        if keep:
            parent.params[sc.KEY] = keep
        else:
            parent.params.pop(sc.KEY, None)


def _apply(params, s, e, sweep, cv):
    if cv[0] == "arc":
        _set_arc(params, s, e, sweep)
    else:
        params.update(x1=round(s[0], 6), y1=round(s[1], 6),
                      x2=round(e[0], 6), y2=round(e[1], 6))


# ------------------------------------------------ the hover highlight
#: the piece a click would remove, as SolidWorks shows it
HOVER_INK = "#ff8c00"


def _side_as_line(node, entity):
    """A stand-in line for side *entity* of a rectangle / polygon, in its
    sketch (not added): what Trim will cut once the shape is lines."""
    from . import sketch_constraints as sc
    from .model import CadNode
    try:
        a, b = sc._line(node, entity, {})
    except (KeyError, ValueError, IndexError, TypeError):
        return None
    line = CadNode("line", "side", dict(x1=a[0], y1=a[1], x2=b[0],
                                        y2=b[1], width=0.2))
    line.parent = node.parent            # its sketch, for the cutters
    return line


def _hover_piece(node, click):
    m = mode()
    if m == CLOSEST:
        return piece_points(node, click)
    return []


def hover_2d(scene, pos):
    """The piece under the cursor (Trim to closest), kept in scene
    coordinates for paint_2d."""
    from PyQt5.QtCore import QPointF
    from . import sketch_constrain_ui as scu
    from .view2d_edit import Frame, in_frame_coords
    old = getattr(scene, "_trim_hover", None)
    pts = []
    hit = scu.pick(scene, pos, "curve") if mode() == CLOSEST else None
    if hit is not None:
        node = hit[0]
        item = next((it for it in scu._shape_items(scene)
                     if it.node is node), None)
        q = in_frame_coords(item, pos) if item is not None else pos
        target = node
        if node.type in ("rect", "polygon") and \
                str(hit[1]).startswith("e"):
            # a rectangle's side lights up as the line it will become
            target = _side_as_line(node, str(hit[1])) or node
        local = _hover_piece(target, (q.x(), q.y()))
        frame = item.parentItem() if item is not None else None
        to_s = frame.mapToScene if isinstance(frame, Frame) else \
            (lambda p: QPointF(p))
        pts = [to_s(QPointF(x, y)) for x, y in local]
    scene._trim_hover = pts
    if pts or old:
        scene.update()


def paint_2d(view, painter):
    from PyQt5.QtGui import QColor, QPen, QPolygonF
    scene = view.scene()
    pts = getattr(scene, "_trim_hover", None)
    if not pts or getattr(scene, "tool", None) != "sk_trim":
        return
    k = abs(view.transform().m11()) or 1.0
    painter.save()
    pen = QPen(QColor(HOVER_INK), 3.0 / k)
    painter.setPen(pen)
    painter.drawPolyline(QPolygonF(pts))
    painter.restore()


def paint_3d(painter, project, group, local):
    """The piece in 3D: sketch points -> world -> screen."""
    from PyQt5.QtCore import QPointF
    from PyQt5.QtGui import QColor, QPen, QPolygonF
    from .face_sketch import to_world
    scr = []
    for x, y in local:
        s = project(to_world(group, x, y))
        if s is None or s[2] <= 0:
            continue
        scr.append(QPointF(s[0], s[1]))
    if len(scr) >= 2:
        painter.save()
        painter.setPen(QPen(QColor(HOVER_INK), 3.0))
        painter.drawPolyline(QPolygonF(scr))
        painter.restore()


# ---------------------------------------- what a trim did, undoable
# (2026-11-11, the user: "can't see where the trimming has happened … I
# can't see it in the history … something so that we can remove it")
KEY = "untrimmed"


def remember(node):
    """Before the first trim: what the shape was (its type and params),
    under a key its split pieces share. Later trims keep the first."""
    if isinstance(node.params.get(KEY), dict):
        return
    import uuid
    node.params[KEY] = {
        "key": uuid.uuid4().hex[:12], "type": node.type,
        "params": {k: v for k, v in node.params.items() if k != KEY}}


def trimmed(node) -> bool:
    return isinstance(node.params.get(KEY), dict)


def restore(model, node):
    """The shape as it was before its trims: the whole circle or line
    back, its other pieces (from a split) removed. Returns the node."""
    rec = node.params.get(KEY)
    if not isinstance(rec, dict):
        return None
    parent = node.parent
    if parent is not None:
        for other in list(parent.children):
            if other is not node and isinstance(other.params.get(KEY),
                                                dict) and \
                    other.params[KEY].get("key") == rec.get("key"):
                model.remove_node(other)
    node.type = rec.get("type", node.type)
    node.params = dict(rec.get("params") or {})
    model.structure_changed.emit()
    model.node_changed.emit(node)
    return node
