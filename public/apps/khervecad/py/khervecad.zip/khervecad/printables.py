"""Publish to Printables: build a complete upload bundle from the model.

Printables has no public upload API — Prusa has never shipped one, and
says so partly to keep automated uploads out — so this does not pretend
to push a model over the wire.  It does everything up to that point:
exports the geometry in the formats Printables accepts, renders the
preview stills, drafts the description, then hands the folder and the
upload page to the user, who is already signed in to Printables in
their own browser and makes the final call.

That split is deliberate.  Everything an assistant can honestly
automate is automated — `mcp_tools.publish_to_printables` builds the
whole bundle unattended, description included — and the one act that
publishes something in the user's name stays a human click.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
import zipfile
import zlib
from pathlib import Path

from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox,
                             QFileDialog, QFormLayout, QGroupBox, QHBoxLayout,
                             QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
                             QPushButton, QVBoxLayout)

from . import document, mesh, pngexport, units
from .engine import write_stl
from .mcp_schema import (CATEGORIES, DEFAULT_CATEGORY,
                         DEFAULT_LICENSE, DEFAULT_ORIGIN,
                         DEFAULT_VIEWS, FORMATS, LICENSES, ORIGINS,
                         STILL_VIEWS, SUMMARY_LIMIT)

#: The page the user finishes on.  Printables' own "add a model" form.
UPLOAD_URL = "https://www.printables.com/model/add"

#: Where the tools live, for the credit line.
TOOLS_URL = "https://khervetools.com"

#: The choices are defined in `mcp_schema` — the MCP tool advertises
#: them and that module has to stay Qt-free, so it owns them and the
#: dialog follows.  A licence default of share-alike matches shipping
#: the parametric source, which is the point of publishing from a CAD
#: tool rather than a mesh.

#: The blocks are single long lines on purpose: Printables re-wraps
#: the description box to its own width, and text hard-wrapped at 70
#: columns comes out ragged there.
#: Each fixed sentence comes in several phrasings, picked per model
#: (`variant_for`): someone who publishes a lot would otherwise post the
#: same paragraph under every model. The heading and the tools URL never
#: vary — `build_bundle` looks for them to avoid appending the block twice.
CREDIT_HEADING = "MADE WITH"

_CREDIT_LINES = (
    "Vibe designed in KherveCAD ({tools}) - a free, open-source "
    "parametric CAD app with OpenSCAD as its engine - and described with "
    "the help of Claude (Anthropic).",
    "Vibe designed in KherveCAD ({tools}), the free and open-source CAD "
    "app that runs on OpenSCAD. The write-up was drafted with Claude "
    "(Anthropic).",
    "This one was vibe designed: built in KherveCAD ({tools}), a free, "
    "open-source parametric CAD app powered by OpenSCAD, and written up "
    "with a hand from Claude (Anthropic).",
    "Vibe designed from start to finish in KherveCAD ({tools}) - free, "
    "open source, OpenSCAD under the hood - with Claude (Anthropic) "
    "helping with the words.",
    "Made the vibe designed way in KherveCAD ({tools}), a free, "
    "open-source CAD app on top of OpenSCAD, and described together "
    "with Claude (Anthropic).",
)
_SOURCE_LINES = (
    "The {files} in the download {verb} the real, editable source, not "
    "an export of a mesh: open it, change a dimension, re-export.",
    "The {files} in the download {verb} the living source rather than a "
    "frozen mesh - change a number and export your own version.",
    "Want it bigger, smaller or thicker? The {files} in the download "
    "{verb} the editable source: open it, tweak a dimension, export "
    "again.",
    "Included: the {files} - the actual editable source, not a mesh "
    "export. Adjust any dimension and re-export.",
)
_TAIL_LINES = (
    "KherveCAD and the rest of the Kherve tools are at {tools}",
    "More Kherve tools, KherveCAD included: {tools}",
    "Get KherveCAD and the other Kherve tools at {tools}",
)


def variant_for(title: str) -> int:
    """A stable number for *title*: the same model always gets the same
    wording (a rebuilt bundle does not change under the user), a
    different model usually gets different wording. crc32, because
    Python's own hash() changes from one run to the next."""
    return zlib.crc32((title or "").strip().lower().encode("utf-8"))


def _pick(options, variant, salt=0):
    """One phrasing. Variant 0 is the original wording everywhere; any
    other variant is hashed with the section's *salt*, so each section
    picks on its own and two models rarely share every sentence (with a
    plain offset, two titles that matched in one list of four matched in
    all of them)."""
    if not variant:
        return options[0]
    return options[zlib.crc32(f"{variant}/{salt}".encode()) % len(options)]


def credit(formats=FORMATS, variant=0) -> str:
    """The attribution block, naming only the files actually shipped."""
    source = [f".{f}" for f in ("scad", "kcad") if f in formats]
    text = (f"{CREDIT_HEADING}\n\n"
            + _pick(_CREDIT_LINES, variant).format(tools=TOOLS_URL) + "\n")
    if source:
        text += "\n" + _pick(_SOURCE_LINES, variant, 1).format(
            files=" and ".join(source),
            verb="is" if len(source) == 1 else "are") + "\n"
    return text + "\n" + _pick(_TAIL_LINES, variant, 2).format(
        tools=TOOLS_URL) + "\n"


def slug(text: str) -> str:
    """A filename stem: words, dashes, nothing surprising."""
    out = re.sub(r"[^\w\s-]", "", str(text)).strip()
    out = re.sub(r"[\s_-]+", "-", out)
    return out.strip("-") or "model"


def _variables(model) -> list:
    """The document's variables, as (name, value) — the parameters a
    downloader would actually change."""
    out = []
    for node in model.root.walk():
        if node.type == "assign":
            name = str(node.params.get("variable", "")).strip()
            if name:
                out.append((name, str(node.params.get("value", ""))))
    return out


def _bounds(model, fn=None):
    try:
        tris = mesh.tessellate(model.root, fn=fn)
    except Exception:
        return None
    from . import anchors
    box = anchors.bbox(tris)
    if box is None:
        return None
    lo, hi = box
    return [round(hi[i] - lo[i], 2) for i in range(3)]


_SUMMARIES = (
    "{name} - parametric model vibe designed in KherveCAD",
    "{name}, vibe designed in KherveCAD and fully parametric",
    "{name} - a vibe designed, parametric print from KherveCAD",
    "{name}: vibe designed in KherveCAD, every dimension adjustable",
)


def default_summary(window, title: str = "", variant=None) -> str:
    """The one-line summary Printables makes required, under its cap.

    Read off the model rather than invented: what it is, that it was
    drawn parametrically, and its footprint if that still fits.
    """
    name = (title or "This model").strip()
    if variant is None:
        variant = variant_for(title)
    text = _pick(_SUMMARIES, variant, 3).format(name=name)
    size = _bounds(window.model, fn=(window.model.global_fn
                                     if window.model.global_fn_on
                                     else None))
    if size:
        with_size = text + ", " + _size_text(window.model, size)
        if len(with_size) <= SUMMARY_LIMIT:
            text = with_size
    if len(text) > SUMMARY_LIMIT:
        text = text[:SUMMARY_LIMIT - 1].rstrip(" ,-") + "…"
    return text


#: What the form's print-settings block says when the caller does not
#: say otherwise.  Declarative, because the field is answered here: a
#: note reading "adjust to what you actually printed" is an instruction
#: to the author sitting in a field the reader sees.
PRINT_SETTINGS = {
    "Rafts": "no",
    "Supports": "no",
    "Resolution": "0.2 mm layer height",
    "Infill": "20%",
    "Filament": "PLA",
    "Notes": "a starting point rather than a tested profile",
}


def form_answers(window, *, title, summary="", tags=(),
                 category=DEFAULT_CATEGORY, license=DEFAULT_LICENSE,
                 origin=DEFAULT_ORIGIN, formats=FORMATS,
                 print_settings=None) -> str:
    """The upload form, field by field, already filled in.

    Printables' "add a model" page asks the same questions every time
    and none of the answers are in the STL, so the bundle carries them
    as copy-and-paste text: the user reads down the page and pastes,
    rather than inventing a category and a summary at upload time.
    """
    model = window.model
    size = _bounds(model, fn=(model.global_fn if model.global_fn_on
                              else None))
    lines = [
        "PRINTABLES UPLOAD FORM - answers to copy across",
        "=" * 46,
        "",
        "Model name (required)",
        f"  {title}",
        "",
        "Summary (required, max %d characters)" % SUMMARY_LIMIT,
        f"  {summary or default_summary(window, title)}",
        "",
        "Main category (required)",
        f"  {category}",
        "",
        "Additional tags (space separated on the form)",
        "  " + (" ".join(tags) if tags else
                "parametric openscad cad 3dprint"),
        "",
        "Model origin - this is a...",
        f"  {origin}",
        "",
        "Licence",
        f"  {license}",
        "",
        "Description",
        "  Paste description.txt (plain text, no Markdown).",
        "",
        "Print settings",
    ]
    settings = dict(PRINT_SETTINGS)
    settings.update(print_settings or {})
    lines += [f"  {key}: {value}" for key, value in settings.items()]
    lines += [
        "",
        "Files to upload",
        "  " + ", ".join(f".{f}" for f in formats) +
        " plus every .png in this folder, in numbered order (the "
        "front-right isometric is first, so it becomes the cover "
        "image).",
    ]
    if size:
        lines += ["", "Bounding box (for your own check against the "
                  "bed)", "  " + _size_text(model, size)]
        if units.coerce(model.unit) != "mm":
            lines.append("  (the files are 1:1, so a slicer reads it as "
                         "%g x %g x %g mm)" % tuple(size))
    return "\n".join(lines) + "\n"


def _size_text(model, size) -> str:
    """"40 x 20 x 10 mm" in the document's unit."""
    return "%g x %g x %g %s" % (*size, units.symbol(model.unit))


def units_note(model) -> str:
    """What the bundle's files mean for a document not in mm — they are
    written 1:1, the way a scale model is printed — or ""."""
    if units.coerce(model.unit) == "mm":
        return ""
    return (f"Modelled in {units.name(model.unit)}. The STL and 3MF "
            f"files are exported 1:1, so a slicer reads each "
            f"{units.symbol(model.unit)} as 1 mm - scale it in the slicer "
            "to taste.")


def _shape_of(model) -> tuple:
    """How the model is built, as (objects, booleans, extrusions).

    Not a classification — nothing here guesses what a part is *for*.
    It is the arithmetic a reader would otherwise do by opening the
    file, and it is the honest half of an opening paragraph.
    """
    objects = booleans = extrusions = 0
    for node in model.root.walk():
        if node.type in ("root", "variables", "masters", "assign"):
            continue
        objects += 1
        if node.type in ("difference", "intersection", "hull",
                         "minkowski"):
            booleans += 1
        elif node.type in ("linear_extrude", "rotate_extrude"):
            extrusions += 1
    return objects, booleans, extrusions


_FIRST = (
    "{name} is {sized} vibe designed in KherveCAD and exported straight "
    "from the object tree that defines it.",
    "{name} is {sized}, vibe designed in KherveCAD and exported directly "
    "from the objects that build it.",
    "Meet {name}: {sized}, vibe designed in KherveCAD and exported "
    "straight from its object tree.",
    "{name} was vibe designed in KherveCAD - {sized} exported straight "
    "from the tree of objects that makes it.",
)
_SECOND = ("It is built from {what}.", "Under the hood: {what}.",
           "The model is made of {what}.")
_THIRD = (
    "{n} dimension{s} {verb} named rather than baked in, so it can be "
    "resized without redrawing it.",
    "{n} dimension{s} {verb} exposed as named parameters - resize it "
    "without redrawing a thing.",
    "Change any of its {n} named dimension{s} and it rebuilds itself.",
)


def opening(window, title: str = "", variant=None) -> str:
    """The paragraph the description opens with.

    This used to be the line "one or two sentences on what this is for
    and why you made it", which is a note to the author sitting where
    the reader's first sentence belongs — and it went out unedited more
    often than not.  So it is written instead, from what the model
    actually says about itself: its size, how it is built, and how many
    dimensions are named rather than baked in.  Everything in it is
    true of any model; the *why* is the one thing only the author can
    add, and a real paragraph is far easier to add a sentence to than a
    placeholder is to replace.
    """
    model = window.model
    if variant is None:
        variant = variant_for(title)
    name = (title or "This").strip()
    size = _bounds(model, fn=(model.global_fn if model.global_fn_on
                              else None))
    sized = f"a {_size_text(model, size)} part" if size else "a part"
    first = _pick(_FIRST, variant, 4).format(name=name, sized=sized)

    objects, booleans, extrusions = _shape_of(model)
    built = []
    if extrusions:
        built.append("%d extrusion%s" % (extrusions,
                                         "" if extrusions == 1 else "s"))
    if booleans:
        built.append("%d boolean%s" % (booleans,
                                       "" if booleans == 1 else "s"))
    second = ""
    if objects:
        what = "%d object%s" % (objects, "" if objects == 1 else "s")
        if built:
            what += " (" + " and ".join(built) + ")"
        second = _pick(_SECOND, variant, 5).format(what=what)

    variables = _variables(model)
    third = ""
    if variables:
        third = _pick(_THIRD, variant, 6).format(
            n=len(variables), s="" if len(variables) == 1 else "s",
            verb="is" if len(variables) == 1 else "are")

    return " ".join(part for part in (first, second, third) if part)


_PARAM_INTROS = (
    "The model is parametric - these are the values to change in the "
    ".scad or .kcad file:",
    "Everything below can be changed in the .scad or .kcad file:",
    "Open the .scad or .kcad file and adjust any of these:",
)
_PRINT_NOTES = (
    "A starting point rather than a tested profile - if you printed it "
    "differently, say so in a comment and I will update this.",
    "These are a sensible starting point, not a tuned profile. If other "
    "settings worked better for you, leave a comment.",
    "Treat these as a starting point. Printed it another way? Share your "
    "settings in the comments.",
)


def default_description(window, title: str = "",
                        formats=FORMATS, variant=None) -> str:
    """A description worth editing rather than one worth deleting.

    Plain text, because that is what Printables' description box shows
    back: Markdown pasted in reads as literal hashes and backticks.
    Everything here is read off the model, so it is right by
    construction: the size someone needs to check against their bed,
    the parameters they can change, and where the thing came from.
    """
    model = window.model
    size = _bounds(model, fn=(model.global_fn if model.global_fn_on
                              else None))
    if variant is None:
        variant = variant_for(title)
    lines = []
    if title:
        lines += [title.upper(), ""]
    lines += [opening(window, title, variant), ""]

    if size:
        lines += [
            "SIZE",
            "",
            _size_text(model, size) + " as modelled (X x Y x Z).",
            "",
        ]
        if units_note(model):
            lines[-1:-1] = [units_note(model)]

    variables = _variables(model)
    if variables:
        lines += ["PARAMETERS", "", _pick(_PARAM_INTROS, variant, 7), ""]
        lines += [f"  {name} = {value}" for name, value in variables]
        lines.append("")

    lines += [
        "PRINT SETTINGS",
        "",
        "Layer height: 0.2 mm",
        "Infill: 20%",
        "Supports: none",
        "Material: PLA",
        "",
        _pick(_PRINT_NOTES, variant, 8),
        "",
        credit(formats, variant),
    ]
    return "\n".join(lines)


def build_bundle(window, folder, *, title, description="", tags=(),
                 license=DEFAULT_LICENSE, formats=FORMATS,
                 views=DEFAULT_VIEWS, image_size=(2000, 1500),
                 summary="", category=DEFAULT_CATEGORY,
                 origin=DEFAULT_ORIGIN, print_settings=None,
                 exploded=None) -> dict:
    """Write the upload folder. Returns what was written and what wasn't.

    Never raises for a missing engine or a format OpenSCAD declined —
    those come back in ``warnings`` so a partial bundle is still
    usable, and the caller can say what is missing.
    """
    folder = Path(str(folder)).expanduser()
    folder.mkdir(parents=True, exist_ok=True)
    stem = slug(title)
    model, engine = window.model, window.engine
    code = model.to_scad()
    files, warnings = [], []

    def wrote(path):
        files.append(str(path))

    if units_note(model) and ({"stl", "3mf"} & set(formats)):
        warnings.append(units_note(model))

    if "scad" in formats:
        path = folder / f"{stem}.scad"
        document.export_scad(model, str(path))
        wrote(path)

    if "kcad" in formats:
        path = folder / f"{stem}.kcad"
        flush = getattr(window, "_flush_blueprint", None)
        if flush is not None:
            flush()                 # the drawing ships as the user left it
        document.save_kcad(model, str(path))
        wrote(path)

    if "stl" in formats:
        path = folder / f"{stem}.stl"
        if engine.available:
            error = engine.export_mesh(code, str(path))
            if error:
                warnings.append(f"STL export failed: {error}")
            else:
                wrote(path)
        else:
            fn = model.global_fn if model.global_fn_on else None
            write_stl(mesh.tessellate(model.root, fn=fn), str(path))
            wrote(path)
            warnings.append(
                "OpenSCAD was not found, so the STL came from the "
                "built-in tessellator." + (
                    " This model uses booleans and they are only "
                    "APPROXIMATED — holes are not cut. Do not upload "
                    "it: install OpenSCAD and build the bundle again."
                    if mesh.approximates(model.root) else
                    " This model uses no booleans, so the geometry is "
                    "faithful."))

    if "stl" in formats:
        # an assembly prints part by part: each Object it shows as its
        # own STL at its own origin, the way a part file comes out
        parts = print_parts(model)
        if len(parts) > 1:
            from . import anchors
            env = anchors.doc_env(model)
            taken = set()
            for comp in parts:
                name, n = slug(comp.name), 2
                while name.lower() in taken:
                    name, n = f"{slug(comp.name)}-{n}", n + 1
                taken.add(name.lower())
                path = folder / f"{stem}-{name}.stl"
                if engine.available:
                    error = engine.export_mesh(model.subtree_scad(comp),
                                               str(path))
                    if error:
                        warnings.append(f"{comp.name}: STL export failed: "
                                        f"{error}")
                        continue
                else:
                    fn = model.global_fn if model.global_fn_on else None
                    write_stl(anchors.local_tris(comp, env=env, fn=fn),
                              str(path), comp.name)
                wrote(path)

    if "3mf" in formats:
        path = folder / f"{stem}.3mf"
        if not engine.available:
            warnings.append(
                "No 3MF: OpenSCAD writes that format and it was not "
                "found.")
        else:
            error = engine.export_mesh(code, str(path))
            if error:
                warnings.append(f"3MF export failed: {error}")
            else:
                wrote(path)

    # the source in one download: Printables lists every file on its
    # own, and whoever wants to remix needs the .scad, .kcad and .3mf
    # together
    source = [Path(f) for f in files
              if Path(f).suffix in (".scad", ".kcad", ".3mf")]
    if source:
        path = folder / f"{stem}-source.zip"
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as bundle:
            for member in source:
                bundle.write(member, member.name)
        wrote(path)

    images = _render_previews(window, folder, stem, views, image_size,
                              warnings)
    if exploded is None:                 # an assembly shows how it goes
        exploded = _assembly_parts(window) >= 2
    if exploded and images:
        images += _render_exploded(window, folder, stem, image_size,
                                   warnings, len(images) + 1)
    files += [str(p) for p in images]

    body = description or default_description(window, title,
                                              formats)
    if TOOLS_URL not in body:
        # the credit is the point of publishing from here, and a
        # description written elsewhere (the MCP tool, the user) has no
        # reason to have carried it.
        body = body.rstrip() + "\n\n" + credit(formats,
                                               variant_for(title))
    notes = folder / "description.txt"
    notes.write_text(body, encoding="utf-8")
    wrote(notes)

    summary = (summary or default_summary(window, title)).strip()
    if len(summary) > SUMMARY_LIMIT:
        summary = summary[:SUMMARY_LIMIT - 1].rstrip() + "…"
        warnings.append("The summary was trimmed to Printables' %d "
                        "character limit." % SUMMARY_LIMIT)
    form = folder / "upload-form.txt"
    form.write_text(form_answers(window, title=title, summary=summary,
                                 tags=tags, category=category,
                                 license=license, origin=origin,
                                 formats=formats,
                                 print_settings=print_settings),
                    encoding="utf-8")
    wrote(form)

    meta = folder / "printables.json"
    meta.write_text(json.dumps({
        "title": title,
        "summary": summary,
        "category": category,
        "origin": origin,
        "tags": list(tags),
        "license": license,
        "description_format": "plain text",
        "print_settings": dict(PRINT_SETTINGS,
                               **(print_settings or {})),
        "upload_url": UPLOAD_URL,
        "made_with": {"app": "KherveCAD", "url": TOOLS_URL,
                      "engine": "OpenSCAD",
                      "description_by": "Claude (Anthropic)"},
        "files": [Path(f).name for f in files],
    }, indent=2), encoding="utf-8")
    wrote(meta)

    return {"folder": str(folder), "files": files,
            "images": [str(p) for p in images],
            "description": body, "summary": summary,
            "category": category, "form": str(form),
            "warnings": warnings}


#: How long the stills wait for OpenSCAD's exact per-part meshes before
#: taking the preview as it stands (a threaded assembly can take a
#: minute the first time; after that every part is cached).
RENDER_WAIT_S = 120.0


def _render_previews(window, folder, stem, views, size, warnings) -> list:
    """Preview stills, painted by the 3D view's own renderer.

    They used to come from OpenSCAD's ``--render`` whenever it was
    installed: its one flat colour scheme, no materials, no platform
    or shadow — nothing like the model the user had been looking at.
    Now every still goes through `pngexport.render`, an offscreen twin
    of the 3D view with the user's colours, materials, style, lighting,
    cavity shading and edge lines, at the screen's proportions.  The
    geometry is still OpenSCAD's: the 3D view shows each part's EXACT
    mesh once it has rendered, so this first waits for the engine to go
    idle (holes cut, threads real) and says so when it could not.

    The three-quarter set by default (`DEFAULT_VIEWS`): every corner
    from above, the product angles and the underside — pictures of a
    solid, where a face seen square-on reads as a flat drawing.
    Printables makes the FIRST image the cover, so the front-right
    isometric leads and is rendered larger than the rest.  The names are
    numbered because the upload page keeps the order the files arrive
    in, which is the order the file dialog lists them.
    """
    ordered, unknown = pngexport.ordered_views(views)
    for name in unknown:
        warnings.append(f"Skipped unknown view {name!r}.")
    if not ordered:
        return []
    if window.engine.available:
        if not window.engine.wait_idle(RENDER_WAIT_S):
            warnings.append(
                "OpenSCAD was still rendering after %d s, so some parts "
                "in the pictures are the built-in preview's (holes may "
                "not be cut). Build the bundle again once the 3D view's "
                "badge says every part is exact." % RENDER_WAIT_S)
    else:
        warnings.append(
            "The preview images come from the built-in renderer without "
            "OpenSCAD's exact meshes, because OpenSCAD was not found." + (
                " This model uses booleans, which it only approximates "
                "— holes are not cut in the pictures."
                if mesh.approximates(window.model.root) else ""))
    builder = getattr(window, "builder", None)
    part = builder.isolated_component() if builder is not None else None
    if part is not None:
        warnings.append(f"The Object tab is open, so the pictures show "
                        f"only {part.name}. Switch to Main to picture the "
                        f"whole model.")

    out = []
    for index, name in enumerate(ordered, 1):
        path = folder / pngexport.file_name(stem, index, name)
        shot = (int(size[0] * 1.3), int(size[1] * 1.3)) if index == 1 \
            else size
        try:
            image = pngexport.render(window.view3d, shot[0], shot[1], name,
                                     uncut=True)
            pngexport._save(image, path)
        except (ValueError, OSError) as exc:
            warnings.append(f"{name} preview failed: {exc}")
            continue
        out.append(path)
    return out


def print_parts(model) -> list:
    """The Objects the assembly shows, each once, in document order —
    what gets its own STL. An Object counts wherever it sits (an
    imported ``color(...) Pot();`` puts it inside a colour), and an
    instance counts as the Object it places (a definition is hidden,
    its instances are what Main shows). The outermost Object is the
    part: the Objects a part is built from are not printed apart.
    Hidden nodes, empty Objects and the Masters store are skipped."""
    from . import mates
    found, seen = [], set()

    def take(comp):
        if comp is not None and comp.children and id(comp) not in seen:
            seen.add(id(comp))
            found.append(comp)

    def walk(node):
        for child in node.children:
            if not child.visible or child.type == "masters":
                continue
            if child.type == "component":
                take(child)
            elif child.type == "reference":
                definition = mates.definition_of(model, child)
                if definition is not None and definition.type == "component":
                    take(definition)
            else:
                walk(child)
    walk(model.root)
    return found


def _assembly_parts(window) -> int:
    """How many parts the pictured scope has (an exploded view of one
    part would show nothing new)."""
    from . import anchors, explode
    builder = getattr(window, "builder", None)
    root = builder.isolated_component() if builder is not None else None
    return explode.part_count(root or window.model.root,
                              anchors.doc_env(window.model),
                              window.model.effective_fn())


def _render_exploded(window, folder, stem, size, warnings, first) -> list:
    """Exploded-view stills, numbered after the others: the front-right
    isometric and the front, every part pulled away from the centre."""
    from . import explode
    out = []
    state = window.explode_state()
    with explode.showing(window, state["amount"] or 1.0, state["mode"]):
        for index, name in enumerate(("Isometric", "Front"), first):
            if name not in pngexport.CAMERA_ROTATIONS:
                continue
            path = folder / pngexport.file_name(stem, index,
                                                f"{name} exploded")
            try:
                image = pngexport.render(window.view3d, size[0], size[1],
                                         name, uncut=True)
                pngexport._save(image, path)
            except (ValueError, OSError) as exc:
                warnings.append(f"Exploded {name} still failed: {exc}")
                continue
            out.append(path)
    return out


def open_upload_page():
    QDesktopServices.openUrl(QUrl(UPLOAD_URL))


def reveal(path):
    """Show *path* in the OS file manager."""
    path = Path(str(path))
    try:
        if sys.platform == "win32":
            subprocess.Popen(["explorer", str(path)])
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


class PublishDialog(QDialog):
    """File ▸ Publish to Printables — assemble the bundle, then hand
    the folder and the upload page over."""

    def __init__(self, window):
        super().__init__(window)
        self._w = window
        self.setWindowTitle("Publish to Printables")
        self.setMinimumWidth(640)
        self.result_bundle = None

        stem = Path(window._path).stem if window._path else ""
        layout = QVBoxLayout(self)

        form = QFormLayout()
        self.title_edit = QLineEdit(stem or "Untitled model")
        form.addRow("Model name", self.title_edit)
        self.summary_edit = QLineEdit(
            default_summary(window, self.title_edit.text()))
        self.summary_edit.setMaxLength(SUMMARY_LIMIT)
        self.summary_edit.setToolTip(
            "Printables' required one-liner, max %d characters."
            % SUMMARY_LIMIT)
        form.addRow("Summary", self.summary_edit)
        self.category_combo = QComboBox()
        self.category_combo.addItems(CATEGORIES)
        self.category_combo.setCurrentText(DEFAULT_CATEGORY)
        form.addRow("Main category", self.category_combo)
        self.origin_combo = QComboBox()
        self.origin_combo.addItems(ORIGINS)
        form.addRow("Model origin", self.origin_combo)
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText(
            "comma separated — printed, functional, parametric, openscad")
        form.addRow("Tags", self.tags_edit)
        self.license_combo = QComboBox()
        self.license_combo.addItems(LICENSES)
        self.license_combo.setCurrentText(DEFAULT_LICENSE)
        form.addRow("Licence", self.license_combo)
        layout.addLayout(form)

        files_box = QGroupBox("Files")
        files_row = QHBoxLayout(files_box)
        self._format_boxes = {}
        for key, label in (("stl", "STL"), ("3mf", "3MF"),
                           ("scad", "OpenSCAD source"),
                           ("kcad", "KherveCAD project")):
            box = QCheckBox(label)
            box.setChecked(True)
            files_row.addWidget(box)
            self._format_boxes[key] = box
        if not window.engine.available:
            self._format_boxes["3mf"].setChecked(False)
            self._format_boxes["3mf"].setEnabled(False)
            self._format_boxes["3mf"].setToolTip(
                "OpenSCAD writes 3MF and it was not found.")
        layout.addWidget(files_box)

        from PyQt5.QtWidgets import QGridLayout
        views_box = QGroupBox("Preview images — painted like the 3D "
                              "view; the front-right Isometric is always "
                              "first, as the cover")
        views_grid = QGridLayout(views_box)
        self._view_boxes = {}
        for index, name in enumerate(STILL_VIEWS):
            box = QCheckBox(name)
            box.setChecked(name in DEFAULT_VIEWS)
            views_grid.addWidget(box, index // 4, index % 4)
            self._view_boxes[name] = box
        self.exploded_box = QCheckBox(
            "Exploded-view pictures too — every part pulled apart, to "
            "show how it goes together")
        self.exploded_box.setChecked(_assembly_parts(window) >= 2)
        views_grid.addWidget(self.exploded_box,
                             (len(STILL_VIEWS) + 3) // 4, 0, 1, 4)
        layout.addWidget(views_box)

        layout.addWidget(QLabel(
            "Description — plain text, so it pastes into Printables' "
            "box exactly as written:"))
        self.description_edit = QPlainTextEdit(
            default_description(window, self.title_edit.text(),
                                self._selected(self._format_boxes)))
        self.description_edit.setMinimumHeight(240)
        layout.addWidget(self.description_edit)

        regen = QPushButton("Regenerate from the model")
        regen.setToolTip("Rebuild the draft in different words — press "
                         "again for another. This discards your edits.")
        regen.clicked.connect(self._regenerate)
        layout.addWidget(regen)

        folder_row = QHBoxLayout()
        self.folder_edit = QLineEdit(self._default_folder())
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        folder_row.addWidget(QLabel("Folder"))
        folder_row.addWidget(self.folder_edit, 1)
        folder_row.addWidget(browse)
        layout.addLayout(folder_row)

        self.open_box = QCheckBox(
            "Open the Printables upload page and show the folder when "
            "it is built")
        self.open_box.setChecked(True)
        layout.addWidget(self.open_box)

        buttons = QDialogButtonBox(QDialogButtonBox.Cancel)
        build = buttons.addButton("Build bundle",
                                  QDialogButtonBox.AcceptRole)
        build.clicked.connect(self._build)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    # ------------------------------------------------------------ bits
    def _default_folder(self) -> str:
        base = (Path(self._w._path).parent if self._w._path
                else Path.home() / "Documents")
        return str(base / f"{slug(self.title_edit.text())}-printables")

    def _browse(self):
        path = QFileDialog.getExistingDirectory(
            self, "Bundle folder", self.folder_edit.text())
        if path:
            self.folder_edit.setText(path)

    def _regenerate(self):
        """A fresh draft in the next set of phrasings — press again for
        another."""
        title = self.title_edit.text()
        if getattr(self, "_variant", None) is None:
            self._variant = variant_for(title)
        self._variant += 1
        self.description_edit.setPlainText(
            default_description(self._w, title,
                                self._selected(self._format_boxes),
                                self._variant))
        self.summary_edit.setText(
            default_summary(self._w, title, self._variant))

    def _selected(self, boxes) -> tuple:
        return tuple(k for k, b in boxes.items() if b.isChecked())

    # ----------------------------------------------------------- build
    def _build(self):
        title = self.title_edit.text().strip() or "Untitled model"
        formats = self._selected(self._format_boxes)
        views = self._selected(self._view_boxes)
        if not formats:
            QMessageBox.warning(self, "Publish to Printables",
                                "Printables needs at least one model "
                                "file.")
            return
        tags = [t.strip() for t in self.tags_edit.text().split(",")
                if t.strip()]
        try:
            bundle = build_bundle(
                self._w, self.folder_edit.text(), title=title,
                description=self.description_edit.toPlainText(),
                tags=tags, license=self.license_combo.currentText(),
                formats=formats, views=views,
                summary=self.summary_edit.text(),
                category=self.category_combo.currentText(),
                origin=self.origin_combo.currentText(),
                exploded=self.exploded_box.isChecked())
        except Exception as exc:
            QMessageBox.warning(self, "Publish to Printables",
                                f"Could not build the bundle:\n{exc}")
            return

        self.result_bundle = bundle
        from PyQt5.QtWidgets import QApplication
        QApplication.clipboard().setText(bundle["description"])

        text = ["Bundle ready in:", bundle["folder"], "",
                "%d file(s), %d preview image(s)."
                % (len(bundle["files"]), len(bundle["images"])),
                "The description is on your clipboard, and "
                "upload-form.txt answers every field on the upload "
                "page."]
        if bundle["warnings"]:
            text += ["", "Warnings:"] + ["• " + w
                                         for w in bundle["warnings"]]
        if self.open_box.isChecked():
            text += ["", "Sign in to Printables in the browser tab "
                     "that just opened, drag the files in, paste the "
                     "description, and copy the rest of the fields "
                     "from upload-form.txt."]
            reveal(bundle["folder"])
            open_upload_page()
        QMessageBox.information(self, "Publish to Printables",
                                "\n".join(text))
        self.accept()
