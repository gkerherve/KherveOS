"""Trim, extend, sketch fillet and chamfer (Qt-free geometry + the 2D
view's click tools), 2026-10-21 — Fusion / SolidWorks sketch MODIFY
tools from the user's "do them all".

KherveCAD's sketch lines are strokes (`line`: two ends and a width) and
its profiles are `polygon` / `rect` areas, so:

- **Trim** (a line): cut it where the other lines of its group cross
  it; the piece under the click goes — the line shortens, or splits in
  two when the piece is in the middle, or is deleted when nothing
  crosses it.
- **Extend** (a line): the end nearest the click runs on to the first
  line or circle it meets.
- **Fillet / Chamfer**: a corner of a polygon or rectangle (a rectangle
  becomes a polygon) is rounded with an arc of `radius` or cut by
  `distance`; where two LINES meet at an end, both are trimmed back to
  the tangent points and an arc stroke (a thin polygon band) joins them.

Every edit is ordinary node params, so the program stays OpenSCAD.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import math

TRIM, EXTEND, FILLET, CHAMFER = ("sk_trim", "sk_extend", "sk_fillet",
                                 "sk_chamfer")
#: (tool, mdi glyph, label)
TOOLS = [(TRIM, "mdi.content-cut", "Trim"),
         (EXTEND, "mdi.arrow-expand-right", "Extend"),
         (FILLET, "mdi.vector-curve", "Sketch fillet"),
         (CHAMFER, "mdi.vector-polyline", "Sketch chamfer"),
         ("sk_mirror", "mdi.flip-horizontal", "Mirror Entities"),
         ("sk_convert", "mdi.vector-square-plus", "Convert Entities"),
         ("sk_offset", "mdi.vector-polyline-plus", "Offset Entities"),
         ("sk_lpattern", "mdi.dots-grid", "Linear Sketch Pattern"),
         ("sk_cpattern", "mdi.rotate-3d-variant", "Circular Sketch Pattern"),
         # (no Extrude regions button: Extruded Boss/Base on overlapping
         # shapes picks the regions itself — the user, 2026-10-25)
         ("make_region", "mdi.vector-union", "Create region"),
         # the Object's 0, 0, 0 moved to a clicked point (origin_tool)
         ("sk_origin", "mdi.crosshairs-gps", "Set Origin Here")]
EPS = 1e-6
ARC_STEPS = 12


def _num(v, default=0.0):
    return float(v) if isinstance(v, (int, float)) and \
        not isinstance(v, bool) else default


def _ends(line):
    p = line.params
    return ((_num(p.get("x1")), _num(p.get("y1"))),
            (_num(p.get("x2")), _num(p.get("y2"))))


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _seg_hit(a, b, c, d, ray=False):
    """Parameter t on a->b where it meets segment c->d (t may run past
    1 when *ray*), or None."""
    r = (b[0] - a[0], b[1] - a[1])
    s = (d[0] - c[0], d[1] - c[1])
    den = _cross(r, s)
    if abs(den) < EPS:
        return None
    q = (c[0] - a[0], c[1] - a[1])
    t = _cross(q, s) / den
    u = _cross(q, r) / den
    if -EPS <= u <= 1 + EPS and (ray or -EPS <= t <= 1 + EPS):
        return t
    return None


def _circle_hits(a, b, centre, radius):
    d = (b[0] - a[0], b[1] - a[1])
    f = (a[0] - centre[0], a[1] - centre[1])
    A = d[0] ** 2 + d[1] ** 2
    B = 2 * (f[0] * d[0] + f[1] * d[1])
    C = f[0] ** 2 + f[1] ** 2 - radius ** 2
    disc = B * B - 4 * A * C
    if A < EPS or disc < 0:
        return []
    s = math.sqrt(disc)
    return [(-B - s) / (2 * A), (-B + s) / (2 * A)]


def _others(line):
    parent = line.parent
    return [n for n in (parent.children if parent else [])
            if n is not line and n.type in ("line", "circle")]


def cuts(line):
    """Parameters 0 < t < 1 where the group's other lines and circles
    cross *line*, sorted."""
    a, b = _ends(line)
    ts = []
    for o in _others(line):
        if o.type == "line":
            c, d = _ends(o)
            t = _seg_hit(a, b, c, d)
            if t is not None:
                ts.append(t)
        else:
            ts += _circle_hits(a, b, (_num(o.params.get("x")),
                                      _num(o.params.get("y"))),
                               _num(o.params.get("radius"), 1.0))
    return sorted(t for t in ts if EPS < t < 1 - EPS)


def _t_of(line, p):
    a, b = _ends(line)
    d = (b[0] - a[0], b[1] - a[1])
    L = d[0] ** 2 + d[1] ** 2 or EPS
    return ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1]) / L


def _at(line, t):
    a, b = _ends(line)
    return (round(a[0] + (b[0] - a[0]) * t, 4),
            round(a[1] + (b[1] - a[1]) * t, 4))


def trim(model, line, click):
    """Remove the piece of *line* (a line, an arc or a circle) under
    *click*, between the nearest crossings of the sketch's other shapes.
    Returns 'deleted', 'shortened', 'split' or 'opened' (a circle left as
    an arc) — sketch_trim.trim_piece."""
    from . import sketch_trim
    return sketch_trim.trim_piece(model, line, click)


def extend(model, line, click):
    """Run the end of *line* nearest *click* on to the first line or
    circle it meets. Returns the new end, or None when nothing is hit."""
    a, b = _ends(line)
    far_end = _t_of(line, click) > 0.5
    if not far_end:
        a, b = b, a                 # always extend past b
    best = None
    for o in _others(line):
        if o.type == "line":
            c, d = _ends(o)
            hits = [_seg_hit(a, b, c, d, ray=True)]
        else:
            hits = _circle_hits(a, b, (_num(o.params.get("x")),
                                       _num(o.params.get("y"))),
                                _num(o.params.get("radius"), 1.0))
        for t in hits:
            if t is not None and t > 1 + EPS and (best is None or t < best):
                best = t
    if best is None:
        return None
    end = (round(a[0] + (b[0] - a[0]) * best, 4),
           round(a[1] + (b[1] - a[1]) * best, 4))
    p = line.params
    if far_end:
        p["x2"], p["y2"] = end
    else:
        p["x1"], p["y1"] = end
    model.node_changed.emit(line)
    return end


# ------------------------------------------------------ fillet / chamfer
def _corner_cut(prev, v, nxt, size, round_):
    """Points replacing corner v between prev and nxt."""
    u1 = (prev[0] - v[0], prev[1] - v[1])
    u2 = (nxt[0] - v[0], nxt[1] - v[1])
    l1, l2 = math.hypot(*u1), math.hypot(*u2)
    if l1 < EPS or l2 < EPS:
        raise ValueError("A corner needs two sides.")
    u1 = (u1[0] / l1, u1[1] / l1)
    u2 = (u2[0] / l2, u2[1] / l2)
    cosang = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
    ang = math.acos(cosang)
    if ang < 1e-3 or ang > math.pi - 1e-3:
        raise ValueError("That corner is straight: nothing to round.")
    setback = size / math.tan(ang / 2) if round_ else size
    if setback >= min(l1, l2) - EPS:
        raise ValueError("Too big for that corner: the sides are %.3g "
                         "and %.3g long." % (l1, l2))
    p1 = (v[0] + u1[0] * setback, v[1] + u1[1] * setback)
    p2 = (v[0] + u2[0] * setback, v[1] + u2[1] * setback)
    if not round_:
        return [p1, p2]
    bis = (u1[0] + u2[0], u1[1] + u2[1])
    bl = math.hypot(*bis)
    dist = size / math.sin(ang / 2)
    c = (v[0] + bis[0] / bl * dist, v[1] + bis[1] / bl * dist)
    a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
    a2 = math.atan2(p2[1] - c[1], p2[0] - c[0])
    sweep = math.remainder(a2 - a1, 2 * math.pi)
    return [(c[0] + size * math.cos(a1 + sweep * k / ARC_STEPS),
             c[1] + size * math.sin(a1 + sweep * k / ARC_STEPS))
            for k in range(ARC_STEPS + 1)]


def _polygon_points(node):
    p = node.params
    if node.type == "rect":
        x, y = _num(p.get("x")), _num(p.get("y"))
        w, h = _num(p.get("width")), _num(p.get("height"))
        return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)], (0.0, 0.0)
    ox, oy = _num(p.get("x")), _num(p.get("y"))
    return [(_num(q[0]) + ox, _num(q[1]) + oy)
            for q in p.get("points") or []], (ox, oy)


def corner(model, node, index, size, round_=True):
    """Fillet (round_) or chamfer vertex *index* of a polygon or
    rectangle. The polygon keeps its SHARP corner point and gains a row
    in ``params["corners"]`` ([index, size, 0 round / 1 chamfer]); the
    arc is worked out from the corner whenever the shape is drawn
    (`expand`), so constraints and drags act on the corner and the arc
    follows — baked arc points were left behind by the solver. A
    rectangle becomes a polygon. Returns the node."""
    if node.type not in ("polygon", "rect"):
        raise ValueError("Fillet a polygon or rectangle corner, or where "
                         "two lines meet.")
    if node.type == "polygon" and node.params.get("paths"):
        raise ValueError("This polygon has holes (paths): edit its "
                         "points instead.")
    pts, origin = _polygon_points(node)
    n = len(pts)
    index %= n
    # checks the size fits (raises ValueError when it does not)
    _corner_cut(pts[index - 1], pts[index], pts[(index + 1) % n],
                float(size), round_)
    if node.type == "rect":
        rel = [[round(x - origin[0], 4), round(y - origin[1], 4)]
               for x, y in pts]
        node.type = "polygon"
        for k in ("width", "height", "center"):
            node.params.pop(k, None)
        node.params.update(x=0.0, y=0.0, points=rel)
        if node.name.startswith("Rectangle"):
            node.name = "Polygon" + node.name[len("Rectangle"):]
    rows = [list(r) for r in node.params.get("corners") or []
            if int(r[0]) != index]
    rows.append([index, round(float(size), 4), 0 if round_ else 1])
    node.params["corners"] = sorted(rows)
    model.structure_changed.emit()
    return node


def expand(points, corners):
    """*points* with each corner row [index, size, kind] replaced by its
    arc (kind 0) or chamfer (1). A corner that no longer fits (its sides
    got shorter than the setback) stays sharp."""
    if not corners:
        return [tuple(map(float, q)) for q in points]
    pts = [(float(q[0]), float(q[1])) for q in points]
    n = len(pts)
    by_index = {}
    for row in corners:
        try:
            by_index[int(row[0]) % n] = (float(row[1]),
                                         int(row[2]) if len(row) > 2
                                         else 0)
        except (TypeError, ValueError, IndexError):
            continue
    out = []
    for i, v in enumerate(pts):
        spec = by_index.get(i)
        if spec is None or spec[0] <= 0:
            out.append(v)
            continue
        try:
            out.extend(_corner_cut(pts[i - 1], v, pts[(i + 1) % n],
                                   spec[0], spec[1] == 0))
        except ValueError:
            out.append(v)
    return out


def line_corner(model, a, b, size, round_=True):
    """Fillet / chamfer where lines *a* and *b* share an end: both are
    trimmed back and the corner piece added as its own node. Returns
    the new node."""
    ea, eb = _ends(a), _ends(b)
    best = min(((i, j) for i in (0, 1) for j in (0, 1)),
               key=lambda ij: math.dist(ea[ij[0]], eb[ij[1]]))
    i, j = best
    if math.dist(ea[i], eb[j]) > 0.5:
        raise ValueError("The two lines do not meet at an end.")
    v = ea[i]
    new = _corner_cut(ea[1 - i], v, eb[1 - j], float(size), round_)
    # the ends no longer meet: a coincident there would pull them back
    from . import sketch_constraints
    sketch_constraints.drop_between(a.parent, a, b)
    for line, k, p in ((a, i, new[0]), (b, j, new[-1])):
        line.params["x%d" % (k + 1)] = round(p[0], 4)
        line.params["y%d" % (k + 1)] = round(p[1], 4)
        model.node_changed.emit(line)
    width = _num(a.params.get("width"), 2.0)
    if round_:
        # the arc as a thin band polygon, as wide as the line
        band = _band(new, width)
        node = _insert(model, "polygon", dict(x=0.0, y=0.0, points=band),
                       a, "Polygon [Fillet]")
    else:
        node = _insert(model, "line", dict(x1=round(new[0][0], 4),
                                           y1=round(new[0][1], 4),
                                           x2=round(new[1][0], 4),
                                           y2=round(new[1][1], 4),
                                           width=width),
                       a, "Line [Chamfer]")
    return node


def _insert(model, type_, params, after, name=""):
    """A new node right after *after* among its siblings."""
    from .model import CadNode
    node = CadNode(type_, name or model.unique_name(type_), params)
    parent = after.parent
    at = parent.children.index(after) + 1
    from . import sketch_constraints
    sketch_constraints.child_inserted(parent, at)
    parent.add(node, at)
    model.structure_changed.emit()
    return node


def _band(pts, width):
    h = width / 2
    left, right = [], []
    for k, p in enumerate(pts):
        q0 = pts[max(k - 1, 0)]
        q1 = pts[min(k + 1, len(pts) - 1)]
        d = (q1[0] - q0[0], q1[1] - q0[1])
        L = math.hypot(*d) or 1.0
        nrm = (-d[1] / L * h, d[0] / L * h)
        left.append([round(p[0] + nrm[0], 4), round(p[1] + nrm[1], 4)])
        right.append([round(p[0] - nrm[0], 4), round(p[1] - nrm[1], 4)])
    return left + right[::-1]


# ------------------------------------------------------- the 2D view
def handles(tool):
    return tool in (TRIM, EXTEND, FILLET, CHAMFER, "regions", "make_region",
                    "sk_construction", "sk_mirror", "sk_lpattern",
                    "sk_cpattern", "sk_convert", "sk_origin", "sk_offset")


PROMPTS = {TRIM: "Trim: click the piece of a line to remove.",
           EXTEND: "Extend: click near the end of a line to run on.",
           FILLET: "Sketch fillet: click a corner (polygon, rectangle, "
                   "or where lines / arcs meet), or the two lines / arcs.",
           CHAMFER: "Sketch chamfer: click a corner (polygon, rectangle, "
                    "or where lines / arcs meet), or the two lines / arcs.",
    "regions": "Extrude regions: click inside the regions to keep, then "
               "Enter or right-click.",
    "make_region": "Create region: click inside the regions to keep, then "
                   "Enter or right-click.",
    "sk_origin": "Set Origin Here: click the point that becomes 0, 0, 0 — "
                 "a corner, centre or middle snaps."}


def press(scene, event):
    from PyQt5.QtCore import Qt
    from . import sketch_constrain_ui as scu
    event.accept()
    if scene.tool == "sk_mirror":
        from . import sketch_mirror
        sketch_mirror.press(scene, event)
        return
    if scene.tool in ("sk_lpattern", "sk_cpattern"):
        from . import sketch_pattern
        sketch_pattern.press(scene, event)
        return
    if scene.tool == "sk_origin":
        from . import origin_tool
        origin_tool.press(scene, event)
        return
    if scene.tool in ("regions", "make_region") and \
            event.button() == Qt.RightButton:
        from . import sketch_regions
        sketch_regions.finish(scene)
        return
    if event.button() != Qt.LeftButton:
        scene._sk_first = None
        return
    pos = event.scenePos()
    tool = scene.tool
    if tool == "sk_construction":
        from . import sketch_tools2
        sketch_tools2.construction_press(scene, event)
        return
    if tool in ("regions", "make_region"):
        from . import sketch_regions
        sketch_regions.press(scene, event)
        return
    if tool == "sk_offset":
        from . import sketch_offset
        from .polygon_draw import px_to_scene
        sketch_offset.press_2d(scene, pos, px_to_scene(scene, 8))
        return
    if tool == "sk_convert":
        from . import sketch_convert
        from .polygon_draw import px_to_scene
        outline = getattr(scene, "face_outline", None) or {}
        made = sketch_convert.click(
            scene.model, None, outline.get("segments") or [],
            (pos.x(), pos.y()), px_to_scene(scene, 8),
            create=scene._create)
        scene.status.emit(
            "Converted %d entit%s." % (len(made), "y" if len(made) == 1
                                       else "ies") if made else
            "Convert Entities: click an edge of the part, or inside the "
            "face for its whole outline.")
        return
    if tool == TRIM:
        # Trim Entities: the option in its window (sketch_trim)
        from . import sketch_trim as tr
        if tr.mode() == tr.POWER:
            scene._power_last = pos       # the stroke starts here
            return
        # lines, arcs AND circles (a circle's piece between two
        # crossings goes, the rest stays an arc)
        want = "curve" if tr.mode() in (tr.INSIDE, tr.OUTSIDE,
                                        tr.CLOSEST) else "line"
        hit = scu.pick(scene, pos, want)
        if hit is None:
            scene.status.emit(tr.MESSAGES[tr.mode()])
            return
        node = hit[0]
        click = _frame_point(scene, node, pos)    # before any rebuild
        if node.type in ("rect", "polygon") and \
                str(hit[1]).startswith("e"):
            # a rectangle / polygon side: the shape becomes its lines,
            # then that side is trimmed
            lines = tr.explode(scene.model, node)
            if lines:
                node = lines[int(str(hit[1])[1:]) % len(lines)]
        try:
            scene.status.emit(tr.pick(scene.model, node, click))
        except ValueError as exc:
            scene.status.emit("Trim: %s." % exc)
        scene._trim_hover = []            # that piece is gone
        scene.update()
        panel = tr._panel(scene.views()[0], create=False) \
            if scene.views() else None
        if panel is not None:
            panel.refresh()
        return
    if tool in (TRIM, EXTEND):
        hit = scu.pick(scene, pos, "line")
        if hit is None or hit[0].type != "line":
            scene.status.emit(PROMPTS[tool])
            return
        node = hit[0]
        p = _frame_point(scene, node, pos)
        if tool == TRIM:
            scene.status.emit("Trim: %s." % trim(scene.model, node, p))
        else:
            end = extend(scene.model, node, p)
            scene.status.emit("Extend: nothing ahead to meet." if end is
                              None else "Extended to (%g, %g)." % end)
        return
    round_ = tool == FILLET
    hit = scu.pick(scene, pos, "point")
    first = getattr(scene, "_sk_first", None)
    if hit is not None and hit[0].type in ("polygon", "rect") and \
            hit[1].startswith("v"):
        size = _ask(scene, tool)
        if size is None:
            return
        try:
            corner(scene.model, hit[0], int(hit[1][1:]), size, round_)
        except ValueError as exc:
            scene.status.emit(str(exc))
        return
    from . import sketch_corner, sketch_arc
    # a click ON a corner where two lines / arcs meet: that corner
    # (SolidWorks: "select a sketch vertex", 2026-11-11, the user)
    if hit is not None and hit[0].type == "line" and \
            hit[1] in ("p1", "p2"):
        other = sketch_corner.partner(hit[0], hit[1])
        if other is not None:
            size = _ask(scene, tool)
            if size is None:
                return
            try:
                sketch_corner.corner(scene.model, hit[0], other, size,
                                     round_)
            except ValueError as exc:
                scene.status.emit(str(exc))
            return
    line = scu.pick(scene, pos, "curve")
    if line is None or line[0].type != "line":
        scene.status.emit(PROMPTS[tool])
        return
    if first is None or first is line[0]:
        scene._sk_first = line[0]
        scene.status.emit("Now click the other line or arc.")
        return
    scene._sk_first = None
    size = _ask(scene, tool)
    if size is None:
        return
    try:
        sketch_corner.between(scene.model, first, line[0], size, round_)
    except ValueError as exc:
        scene.status.emit(str(exc))


def _frame_point(scene, node, pos):
    from .view2d_edit import in_frame_coords
    for it in scene.items():
        if getattr(it, "node", None) is node:
            q = in_frame_coords(it, pos)
            return (q.x(), q.y())
    return (pos.x(), pos.y())


def _ask(scene, tool):
    hook = getattr(scene, "ask_value", None)
    label = "radius" if tool == FILLET else "distance"
    if hook is not None:
        text = hook(tool, 2.0)
    else:
        from . import value_popup
        views = scene.views()
        text = value_popup.ask(views[0] if views else None,
                               "Sketch " + label,
                               "Corner %s (mm):" % label, "2")
        if text is None:
            return None
    from .sketch_constrain_ui import _value
    v = _value(text)                  # "36 / 2" works too
    if not isinstance(v, (int, float)):
        scene.status.emit("A %s is a number of mm." % label)
        return None
    return v if v > 0 else None


def power_move(scene, event):
    """Power trim: the stroke so far crosses lines — trim them."""
    from . import sketch_trim as tr, sketch_constrain_ui as scu
    last = getattr(scene, "_power_last", None)
    if last is None or not (event.buttons() & 1):
        return False
    pos = event.scenePos()
    # a rectangle / polygon the stroke crosses becomes its lines first
    # (power trim skipped them: the user's rectangle could not be cut)
    from . import sketch_constraints as sc
    made = []
    for it in list(scu._shape_items(scene)):
        shape = it.node
        if shape.type not in ("rect", "polygon") or shape.parent is None:
            continue
        a = _frame_point(scene, shape, last)
        b = _frame_point(scene, shape, pos)
        n_sides = 4 if shape.type == "rect" else \
            len(shape.params.get("points") or [])
        for i in range(n_sides):
            try:
                c, d = sc._line(shape, "e%d" % i, {})
            except (KeyError, ValueError, IndexError, TypeError):
                continue
            if _seg_hit(a, b, c, d) is not None:
                made += tr.explode(scene.model, shape) or []
                break
    lines = [it.node for it in scu._shape_items(scene)
             if it.node.type in ("line", "circle")]
    # (the new lines may have no scene item yet: this stroke cuts them)
    lines += [ln for ln in made if ln not in lines]
    n = 0
    for line in lines:
        a = _frame_point(scene, line, last)
        b = _frame_point(scene, line, pos)
        n += tr.power(scene.model, [line], a, b)
    scene._power_last = pos
    if n:
        scene.status.emit("Power trim: %d piece(s) trimmed." % n)
    return True


def drop(scene):
    scene._sk_first = None
    scene._power_last = None
    from . import sketch_trim
    sketch_trim.state.clear()
    for v in scene.views():
        sketch_trim.close_panel(v)
    if getattr(scene, "_mirror", None) is not None:
        from . import sketch_mirror
        sketch_mirror.drop(scene)
    if getattr(scene, "_regions", None) is not None:
        from . import sketch_regions
        sketch_regions.drop(scene)
    if getattr(scene, "_pattern", None) is not None:
        from . import sketch_pattern
        sketch_pattern.drop(scene)


TIPS = {
    TRIM: ("Trim", "Removes the piece of a line between the lines or "
           "circles that cross it.",
           ["Click the piece to remove.", "Nothing crosses it: the whole "
            "line goes. A middle piece splits the line in two."], None),
    EXTEND: ("Extend", "Runs a line on until it meets another line or a "
             "circle.", ["Click near the end to extend."], None),
    FILLET: ("Sketch fillet", "Rounds a corner of a polygon or rectangle, "
             "or where two lines meet.",
             ["Click the corner (or one line, then the other).",
              "Type the radius."], "A rectangle becomes a polygon."),
    CHAMFER: ("Sketch chamfer", "Cuts a corner off at 45° by a distance.",
              ["Click the corner (or one line, then the other).",
               "Type the distance."], None),
    "regions": ("Extrude regions",
                "Overlapping sketch shapes split into regions; the ones "
                "you click are extruded as one solid (SolidWorks' "
                "selected contours).",
                ["Draw overlapping shapes — a rectangle and a perimeter "
                 "circle at one end make three regions.",
                 "Click inside each region to keep (click again to drop "
                 "it); they turn blue.",
                 "Press Enter or right-click: one Linear extrude of "
                 "those regions is made and the sketch shapes are "
                 "hidden."],
                "Set the height in Properties, or drag the arrow in 3D."),
    "make_region": ("Create region — group the 2D, extrude later",
                    "Makes a Regions node from overlapping sketch shapes: "
                    "the regions you click, the shapes inside it with "
                    "their Smart Dimensions — extrude or revolve it later.",
                    ["Draw overlapping shapes (a rectangle and a circle "
                     "on it).",
                     "Click inside each region to keep; they turn blue.",
                     "Enter or right-click makes the Regions node."],
                    "Change a Smart Dimension and the region follows."),
}


def panel_actions(win):
    acts = getattr(win, "_sketch_modify_actions", None)
    if acts is not None:
        return acts
    from PyQt5.QtWidgets import QAction
    from . import icons, language, toolbars, tooltips
    tooltips.TIPS.update(TIPS)
    from . import sketch_mirror
    tooltips.TIPS.update(sketch_mirror.TIPS)
    from . import sketch_pattern
    tooltips.TIPS.update(sketch_pattern.TIPS)
    from . import sketch_convert
    tooltips.TIPS.update(sketch_convert.TIPS)
    from . import origin_tool
    tooltips.TIPS.update(origin_tool.TIPS)
    from . import sketch_offset
    tooltips.TIPS.update(sketch_offset.TIPS)
    acts = []
    for tool, glyph, label in TOOLS:
        act = QAction(icons.icon(glyph, icons.family_color("draw")),
                      language.tr(label), win)
        act.setData(tool)
        act.setCheckable(True)
        toolbars.remember_glyph(act, glyph, "draw")
        tooltips.apply(act, tool)
        if tool in ("regions", "make_region"):
            act.triggered.connect(lambda _=False, t=tool: _regions(win, t))
        elif tool == "sk_mirror":
            act.triggered.connect(
                lambda _=False: sketch_mirror.start(win))
        elif tool == "sk_offset":
            act.setCheckable(False)
            act.triggered.connect(
                lambda _=False: sketch_offset.start(win))
        elif tool == TRIM:
            from . import sketch_trim
            act.triggered.connect(lambda _=False: sketch_trim.start(win))
        elif tool in sketch_pattern.TOOLS:
            act.triggered.connect(
                lambda _=False, t=tool: sketch_pattern.start(win, t))
        else:
            act.triggered.connect(lambda _=False, t=tool: win._set_tool(t))
        win._tool_group.addAction(act)
        acts.append(act)
    win._sketch_modify_actions = acts
    return acts


def _regions(win, tool="regions"):
    """Extrude regions: in the sketch (Fusion / SolidWorks sketch mode)
    the 2D tool; otherwise straight on the 3D view, where the user sees
    the part (2026-10-25)."""
    from . import sketch_mode, sketch_regions
    if tool == "make_region" and sketch_regions.from_selection(win):
        return                           # the selected shapes, at once
    if sketch_mode.sketching(win):
        win._set_tool(tool)
    elif not sketch_regions.start_3d(win,
                                     make_only=tool == "make_region"):
        win._set_tool(tool)


# ---------------------------------------- the OpenSCAD program, both ways
HELPER = """\
module kcad_corners(points = [], corners = []) {
    children();
}"""


def uses(root):
    return any(n.type == "polygon" and n.params.get("corners")
               for n in root.walk())


def _b_corners(parser, positional, named):
    from .model import CadNode
    node = CadNode("union", "Group", {})
    node._kcad_corners = (named.get("points"), named.get("corners"))
    return node


BUILDERS = {"kcad_corners": _b_corners}


def fold(node):
    """kcad_corners(points, corners) polygon(rounded): the polygon back
    with its sharp corners and its corner rows."""
    info = getattr(node, "_kcad_corners", None)
    if info is None:
        return None
    if len(node.children) != 1 or node.children[0].type != "polygon":
        return None
    poly = node.children[0]
    pts, rows = info
    try:
        poly.params["points"] = [[float(x), float(y)] for x, y in pts]
        poly.params["corners"] = [[int(r[0]), float(r[1]),
                                   int(r[2]) if len(r) > 2 else 0]
                                  for r in rows]
    except (TypeError, ValueError):
        return None
    node.remove(poly)
    poly.visible = node.visible and poly.visible
    return poly


# ------------------------------------------------------------------ MCP
def _seg_dist(p, q):
    """Distance from point *q* to the segment of line params *p*."""
    ax, ay, bx, by = p["x1"], p["y1"], p["x2"], p["y2"]
    dx, dy = bx - ax, by - ay
    ln = dx * dx + dy * dy or 1e-12
    t = max(0.0, min(1.0, ((q[0] - ax) * dx + (q[1] - ay) * dy) / ln))
    return math.hypot(ax + t * dx - q[0], ay + t * dy - q[1])


def run_mcp(window, params):
    """The `sketch_modify` MCP tool: trim / extend a line at a point,
    fillet / chamfer a polygon or rectangle corner or where two lines
    meet. Points are in the shapes' own sketch coordinates."""
    model = window.model
    action = params.get("action")

    def node(nid):
        n = model.find(int(nid))
        if n is None:
            raise ValueError("No node with id %r." % nid)
        return n

    def point():
        p = params.get("point")
        if not (isinstance(p, (list, tuple)) and len(p) >= 2):
            raise ValueError("Give point [x, y] on the line.")
        return (float(p[0]), float(p[1]))
    if action == "construction" or (
            action == "trim" and node(params["node_id"]).type in (
                "circle", "rect", "polygon")):
        # (2026-11-14, the pattern exercise's lug: a circle's half trimmed
        # away, a rectangle's side made construction — as the Trim tool
        # and the Construction switch do with the mouse)
        from . import sketch_trim
        shape = node(params["node_id"])
        if shape.type in ("rect", "polygon"):
            p = point()
            sides = sketch_trim.explode(model, shape)
            if not sides:
                raise ValueError("%s has no sides to pick." % shape.name)
            shape = min(sides, key=lambda ln: _seg_dist(ln.params, p))
        if action == "construction":
            on = shape.params.get("modifier") != "%"
            model.set_modifier(shape, "%" if on else "")
            return {"result": "construction" if on else "normal",
                    "node_id": shape.id}
        done = sketch_trim.trim_piece(model, shape, point())
        return {"result": done, "node_id": shape.id,
                "line": None if done == "deleted" else dict(shape.params)}
    if action in ("trim", "extend"):
        line = node(params["node_id"])
        if line.type != "line":
            raise ValueError("%s works on a line; %s is a %s."
                             % (action, line.name, line.type))
        if action == "trim":
            done = trim(model, line, point())
            return {"result": done,
                    "line": None if done == "deleted"
                    else dict(line.params)}
        end = extend(model, line, point())
        if end is None:
            raise ValueError("Nothing for that end to reach.")
        return {"result": "extended", "line": dict(line.params)}
    if action in ("fillet", "chamfer"):
        size = float(params.get("size", 0) or 0)
        if size <= 0:
            raise ValueError("Give size > 0 (radius or chamfer distance).")
        round_ = action == "fillet"
        ids = params.get("node_ids") or []
        if len(ids) == 2:
            # the window's Sketch Fillet / Chamfer (sketch_corner): a real
            # arc tangent to both, with its relations and radius — the old
            # line_corner drew a band polygon nothing could offset
            from . import sketch_corner
            new = sketch_corner.corner(model, node(ids[0]), node(ids[1]),
                                       size, round_)
            return {"result": action, "node_id": getattr(new, "id", None)}
        shape = node(params["node_id"])
        if shape.type not in ("polygon", "rect"):
            raise ValueError("Fillet a polygon / rectangle corner (node_id "
                             "+ vertex), or two lines (node_ids).")
        out = corner(model, shape, int(params.get("vertex", 0)), size,
                     round_)
        shape = out if hasattr(out, "params") else shape
        return {"result": action, "node_id": shape.id,
                "corners": shape.params.get("corners", [])}
    if action == "mirror":
        from . import sketch_mirror
        ids = params.get("node_ids") or []
        if not ids or params.get("mirror_line") is None:
            raise ValueError("Give node_ids (the shapes) and mirror_line "
                             "(the line to mirror about).")
        line = node(params["mirror_line"])
        if line.type != "line":
            raise ValueError("mirror_line must be a line; %s is a %s."
                             % (line.name, line.type))
        copies, skipped = sketch_mirror.mirror(
            model, [node(i) for i in ids], line,
            relate=params.get("relate", True))
        return {"result": "mirrored", "node_ids": [c.id for c in copies],
                "skipped": skipped}
    if action == "offset":
        from . import sketch_offset
        ids = params.get("node_ids") or []
        size = float(params.get("size", 0) or 0)
        pts = params.get("points") or (
            [params["point"]] if params.get("point") is not None else [])
        if not ids and pts and params.get("node_id") is not None \
                and size > 0:
            # the PART's edges at the points (SolidWorks offsets model
            # edges straight away, Select chain on: Exercise 54's wall)
            from . import section_outline
            group = node(params["node_id"])
            segs = section_outline.for_group(window, group)
            if not segs:
                raise ValueError("The sketch's plane meets no part.")
            xs = [c for s_ in segs for p_ in s_ for c in p_[:2]]
            tol = max(0.5, 0.01 * (max(xs) - min(xs)))
            made = sketch_offset.offset_edges(
                model, segs, [tuple(map(float, q[:2])) for q in pts], size,
                -1 if params.get("reverse") else 1, bool(params.get("cap")),
                chain=params.get("chain", True), tol=tol, parent=group)
            return {"result": "offset", "node_ids": [n.id for n in made]}
        if not ids or size <= 0:
            raise ValueError("Give node_ids (lines / arcs that join end "
                             "to end) and size > 0 (the distance).")
        made = sketch_offset.offset(
            model, [node(i) for i in ids], size,
            -1 if params.get("reverse") else 1, bool(params.get("cap")))
        return {"result": "offset", "node_ids": [n.id for n in made]}
    if action == "convert":
        # Convert Entities (Exercise 50): the part's edge at `point` (the
        # sketch's own x, y) where the sketch's plane cuts the part
        from . import section_outline, sketch_convert
        group = node(params["node_id"])
        segs = section_outline.for_group(window, group)
        if not segs:
            raise ValueError("The sketch's plane meets no part to convert.")
        xs = [c for s in segs for p in s for c in p]
        tol = max(0.5, 0.01 * (max(xs) - min(xs)))
        made = sketch_convert.click(model, group, segs, point(), tol)
        if not made:
            raise ValueError("No edge of the part near %r, and the point "
                             "is not inside it." % (list(point()),))
        return {"result": "converted", "node_ids": [n.id for n in made],
                "shapes": [dict(type=n.type, params=dict(n.params))
                           for n in made]}
    raise ValueError("action is trim, extend, fillet, chamfer, mirror, "
                     "offset or convert.")
