"""Runs an MCP tool against the live KherveCAD window.

`mcp_schema.py` is the contract; this is the implementation.  Every
method here touches the real `DocumentModel` and the real viewers, so
it MUST run on the GUI thread — `mcp_bridge.McpBridge` is what
guarantees that, and it also wraps each mutating call in one undo macro
so the user gets their model back with a single Ctrl+Z.

Nodes are addressed by ``CadNode.id``, which the app already keeps, so
there is no parallel identity scheme here.  Ids do not survive undo or
an open: both rebuild the tree from a snapshot, and the tool
descriptions say so.

Nothing here re-implements an editing operation.  Everything goes
through `DocumentModel` (which owns the change signals, the undo
snapshots and the mate bookkeeping), `scadparse` for code, `library`
for parts and `mates` for assemblies — so an MCP edit and a mouse edit
are the same edit.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from __future__ import annotations

import base64
import math
import re
from pathlib import Path

from PyQt5.QtCore import QBuffer, QByteArray, Qt

from . import anchors, document, mates, mesh, units
from .mcp_schema import (CATEGORIES, DEFAULT_CATEGORY,
                         DEFAULT_LICENSE, DEFAULT_ORIGIN,
                         DEFAULT_VIEWS, FORMATS, ORIENTATIONS,
                         ORIGINS, PROJECTIONS, STILL_VIEWS,
                         WRAP_TYPES)
from .mcp_server import IMAGE_KEY
from .model import CONTAINER_TYPES, NODE_TYPES, validate

#: Cap on a rendered preview, so one look at the model stays cheap.
_DEFAULT_RENDER_WIDTH = 900

#: How long render_view waits for OpenSCAD by default, and at most.
_DEFAULT_WAIT_S = 30.0
_MAX_WAIT_S = 300.0

#: render_view parameters that call for the offscreen camera, which
#: leaves the user's own view where it is.
_CAMERA_KEYS = ("azimuth", "elevation", "distance", "zoom", "target",
                "target_node", "projection", "region", "orientations",
                "overlay_reference")

#: the square-on preset for each reference-image plane
_PLANE_VIEWS = {"Top (XY)": "Top", "Front (XZ)": "Front",
                "Side (YZ)": "Right"}

#: The largest side an offscreen render paints — a region crop renders
#: the whole picture bigger, then cuts the detail out of it.
_MAX_RENDER_SIDE = 4096


class ToolError(Exception):
    """A tool failed for a reason the client should read and act on."""


class McpToolExecutor:
    """Executes one named tool against a `MainWindow`."""

    def __init__(self, window):
        self._w = window

    # ── Plumbing ────────────────────────────────────────────────

    @property
    def _model(self):
        return self._w.model

    def execute(self, name: str, tool_input: dict) -> dict:
        """Run *name*; never raises — a failure comes back as {"error"}."""
        handler = getattr(self, f"_t_{name}", None)
        if handler is None:
            return {"error": f"Unknown tool: {name}"}
        try:
            return handler(tool_input or {})
        except ToolError as exc:
            return {"error": str(exc)}
        except Exception as exc:              # pragma: no cover - defensive
            return {"error": f"{type(exc).__name__}: {exc}"}

    # ── Node lookup ─────────────────────────────────────────────

    def _node(self, node_id):
        try:
            node = self._model.find(int(node_id))
        except (TypeError, ValueError):
            raise ToolError(f"{node_id!r} is not a node id.")
        if node is None:
            raise ToolError(
                f"No node with id {node_id} in the document. Ids are "
                "rebuilt by undo and by opening a file — call list_tree "
                "again.")
        return node

    def _nodes(self, ids):
        if not isinstance(ids, (list, tuple)) or not ids:
            raise ToolError("Pass a non-empty list of node ids.")
        return [self._node(i) for i in ids]

    def _scope(self):
        """The container new geometry belongs in: the Object the user
        has open in the Object tab, else the assembly root."""
        comp = self._w.builder.isolated_component()
        return comp if comp is not None else self._model.root

    def _env(self):
        return anchors.doc_env(self._model)

    def _fn(self):
        return self._model.effective_fn()

    def _errors(self):
        try:
            return validate(self._model.root)
        except Exception:
            return {}

    @staticmethod
    def _check_params(type_name: str, params) -> dict:
        """Reject a misspelt parameter rather than silently storing it.

        A stray key would sit in the node forever, do nothing, and give
        the client no hint that its edit was ignored.
        """
        if params is None:
            return {}
        if not isinstance(params, dict):
            raise ToolError("'params' must be an object.")
        known = set(NODE_TYPES[type_name]["params"])
        # optional params live in the schema only (text's halign, a
        # polygon's paths, a variable's Customizer options)
        known |= {row[0] for row in NODE_TYPES[type_name]["schema"]}
        # OpenSCAD's debug modifier any node may carry: "#", "%", "!"
        known.add("modifier")
        if type_name in ("component", "reference"):
            known |= {"mate", "anchors"}
        unknown = [k for k in params if k not in known]
        if unknown:
            raise ToolError(
                f"{type_name} has no parameter "
                f"{', '.join(repr(k) for k in unknown)}. It takes: "
                f"{', '.join(sorted(known))}.")
        return dict(params)

    def _bbox(self):
        try:
            tris = mesh.tessellate(self._model.root, fn=self._fn())
        except Exception:
            return None
        box = anchors.bbox(tris)
        if box is None:
            return None
        lo, hi = box
        return {"min": [round(v, 3) for v in lo],
                "max": [round(v, 3) for v in hi],
                "size": [round(hi[i] - lo[i], 3) for i in range(3)]}

    # ── Units ───────────────────────────────────────────────────
    # Coordinates and sizes are in the document's unit, like every node
    # param. A key ending _mm / _mm2 / _mm3 is always TRUE millimetres:
    # the same number in a mm document, converted (to significant
    # figures, so 1e-13 survives) in any other.

    def _unit(self) -> str:
        return units.coerce(self._model.unit)

    def _in_mm(self, value, power=1, digits=3):
        if value is None:
            return None
        if self._unit() == "mm":
            return round(value, digits)
        return units.significant(units.mm(value, self._unit(), power))

    def _box_in_mm(self, box):
        if box is None:
            return None
        return {k: [self._in_mm(v) for v in vals] for k, vals in box.items()}

    # ── Inspection ──────────────────────────────────────────────

    def _t_get_document_info(self, _params) -> dict:
        model, win = self._model, self._w
        errors = self._errors()
        comp = win.builder.isolated_component()
        objects = [{"id": c.id, "name": c.name, "visible": c.visible,
                    "instances": len(model.instances_of(c))}
                   for c in model.components()]
        unit = self._unit()
        bounds = self._bbox()
        return {
            "path": win._path,
            "unsaved_changes": bool(win._dirty),
            "units": units.name(unit),
            "unit": unit,
            "unit_symbol": units.symbol(unit),
            "mm_per_unit": units.to_mm(unit),
            "real_scale": model.real_scale,
            "scale": units.ratio_text(model.real_scale),
            "units_note": (
                "Every size and coordinate is in the document's unit — "
                "a label only, the geometry is never rescaled. Keys "
                "ending _mm are true millimetres."),
            "node_count": sum(1 for _ in model.root.walk()) - 1,
            "top_level": [n.name for n in model.root.children],
            "objects": objects,
            "collections": [
                {"name": c["name"],
                 "visible": bool(c.get("visible", True)),
                 "locked": bool(c.get("locked", False))}
                for c in model.collections],
            "editing_object": ({"id": comp.id, "name": comp.name}
                               if comp is not None else None),
            "global_segments": int(model.global_fn),
            "global_segments_on": bool(model.global_fn_on),
            "openscad": {
                "available": bool(win.engine.available),
                "path": win.engine.binary or None,
                "backend": win.engine.backend or None,
                "note": ("Exact geometry: booleans really cut."
                         + ("" if win.engine.backend != "CGAL" else
                            " This OpenSCAD only has the old CGAL backend: "
                            "heavy booleans can take minutes, and until "
                            "they land the view is the approximate "
                            "preview — a newer OpenSCAD (Manifold) renders "
                            "them in seconds.")
                         if win.engine.available else
                         "Not found — the preview approximates a "
                         "difference() by showing its first operand, so "
                         "holes look uncut. Edit > Locate OpenSCAD."),
            },
            "exact_preview_booleans": self._csg_info(),
            "blender": self._blender_info(),
            "edit_mode": self._edit_mode_info(),
            "bounds": bounds,
            "bounds_mm": self._box_in_mm(bounds),
            "reference_images": self._references(),
            "errors": [{"id": nid, "message": msg}
                       for nid, msg in errors.items()],
        }

    def _edit_mode_info(self):
        """The user's open Edit Mode (Tab over the 3D view), if any: the
        polyhedron and the vertices they have selected — so "move these
        up a bit" means something to edit_mesh."""
        session = getattr(self._w, "_edit_session", None)
        if session is None:
            return None
        return {"node_id": session.node.id, "name": session.node.name,
                "vertex_count": len(session.points),
                "selected_vertices": sorted(session.selection)}

    def _t_list_node_types(self, params) -> dict:
        want = params.get("category")
        out = []
        for name, spec in NODE_TYPES.items():
            if want and spec["category"] != want:
                continue
            out.append({
                "type": name,
                "label": spec["label"],
                "category": spec["category"],
                "container": name in CONTAINER_TYPES,
                "params": [
                    {"name": key, "label": label, "kind": kind,
                     "min": lo, "max": hi,
                     "default": spec["params"].get(key)}
                    for key, label, kind, lo, hi in spec["schema"]],
            })
        return {"count": len(out), "types": out,
                "note": ("A numeric parameter also accepts an "
                         "expression string, e.g. \"wall * 2\".")}

    def _describe(self, node, depth: int, params: bool, errors: dict):
        info = {"id": node.id, "type": node.type, "name": node.name,
                "children": len(node.children)}
        if not node.visible:
            info["visible"] = False
        if params and node.params:
            info["params"] = {k: v for k, v in node.params.items()
                              if k not in ("anchors",)}
        if node.id in errors:
            info["error"] = errors[node.id]
        if isinstance(node.params.get("mate"), dict):
            info["mate"] = dict(node.params["mate"])
        if node.children and depth != 0:
            info["nodes"] = [
                self._describe(c, depth - 1, params, errors)
                for c in node.children]
        return info

    def _t_list_tree(self, params) -> dict:
        root = (self._node(params["node_id"]) if params.get("node_id")
                else self._model.root)
        depth = params.get("depth")
        depth = 4 if depth is None else int(depth)
        show = params.get("params", True)
        errors = self._errors()
        return {
            "root": {"id": root.id, "type": root.type, "name": root.name},
            "editing_object": getattr(
                self._w.builder.isolated_component(), "name", None),
            "nodes": [self._describe(c, depth - 1, show, errors)
                      for c in root.children],
        }

    def _t_get_node(self, params) -> dict:
        node = self._node(params.get("node_id"))
        errors = self._errors()
        spec = NODE_TYPES.get(node.type, {})
        path, walker = [], node
        while walker is not None:
            path.append(walker.name)
            walker = walker.parent
        info = self._describe(node, 1, True, errors)
        info["path"] = " / ".join(reversed(path))
        info["parent_id"] = node.parent.id if node.parent else None
        info["label"] = spec.get("label", node.type)
        info["schema"] = [
            {"name": key, "label": label, "kind": kind,
             "min": lo, "max": hi}
            for key, label, kind, lo, hi in spec.get("schema", [])]
        return info

    def _t_get_code(self, params) -> dict:
        from . import bake
        model = self._model
        # a baked mesh (a blend) is thousands of rows of numbers nobody
        # reads: summarise them unless asked, so the program fits in a
        # client's context. Import ignores those rows, so the summarised
        # program still round-trips through apply_code.
        bake.ELIDE = not params.get("full")
        try:
            if params.get("node_id"):
                node = self._node(params["node_id"])
                code = model.subtree_scad(node)
                scope = node.name
            else:
                code = model.to_scad()
                scope = "whole document"
        finally:
            bake.ELIDE = False
        return {"scope": scope, "lines": len(code.splitlines()),
                "code": code}

    def _t_render_view(self, params) -> dict:
        win = self._w
        which = str(params.get("view", "3d")).lower()
        try:
            timeout = float(params.get("timeout", _DEFAULT_WAIT_S))
        except (TypeError, ValueError):
            raise ToolError("'timeout' must be a number of seconds.")
        timeout = min(max(timeout, 0.0), _MAX_WAIT_S)
        if which == "3d" and params.get("wait_for_exact", True):
            complete = self._wait_for_render(timeout)
        else:
            complete = self._render_settled()
        offscreen = which == "3d" and any(
            params.get(k) is not None for k in _CAMERA_KEYS)
        limit = max(int(params.get("max_width")
                        or _DEFAULT_RENDER_WIDTH), 16)
        if offscreen:
            image, extra = self._offscreen(params, limit)
        else:
            if params.get("orientation"):
                name = params["orientation"]
                if name not in ORIENTATIONS:
                    raise ToolError(
                        f"Unknown orientation {name!r}. Choose one of: "
                        f"{', '.join(ORIENTATIONS)}.")
                win.view3d.set_view(name)
            elif params.get("fit"):
                win.view3d.fit()
            widget = win.view2d if which == "2d" else win.view3d
            image = widget.grab()
            if image.isNull() or image.width() < 2:
                raise ToolError(
                    "The view has no size to render — the window may "
                    "be minimised.")
            if image.width() > limit:
                image = image.scaledToWidth(limit,
                                            Qt.SmoothTransformation)
            extra = ({"camera": win.view3d.camera_state()}
                     if which == "3d" else {})
        result = {IMAGE_KEY: self._png(image), "view": which,
                  "showing": (win.view3d.source if which == "3d" else
                              "sketch / assembly view"),
                  "width": image.width(), "height": image.height(),
                  "render_complete": complete}
        result.update(extra)
        if not complete:
            result["note"] = (
                "OpenSCAD was still rendering when the timeout ran out, "
                "so this is (partly) the built-in preview, where "
                "booleans are approximated. Call again, or raise "
                "timeout, for the exact render.")
        return result

    # ── render_view helpers ─────────────────────────────────────

    @staticmethod
    def _png(image) -> str:
        """A QImage/QPixmap as base64 PNG."""
        data = QByteArray()
        buffer = QBuffer(data)
        buffer.open(QBuffer.WriteOnly)
        image.save(buffer, "PNG")
        buffer.close()
        return base64.b64encode(bytes(data)).decode("ascii")

    def _render_settled(self) -> bool:
        engine = self._w.engine
        return not engine.available or engine.is_idle()

    def _wait_for_render(self, timeout_s: float) -> bool:
        """Pump the event loop until OpenSCAD is idle with nothing
        queued, so the picture shows the exact render and not the
        built-in approximation of it. True when it settled in time.

        Re-entry is safe: the bridge refuses a second tool call while
        this one runs — the guard an STL export already relies on."""
        from .engine import wait_until_idle
        return wait_until_idle(self._w.engine, timeout_s)

    def _world_tris(self, node) -> list:
        """World-space triangles of *node* as the 3D view draws it (in
        the Object tab, in that Object's own frame) — the built-in
        tessellation, so booleans are approximated."""
        win = self._w
        root = win._render_scope()[0]
        iso = root if root is not self._model.root else None
        with win._isolated_frame(iso):
            return mesh.selected_world_tris(root, {node.id},
                                            env=self._env(), fn=self._fn())

    def _world_points(self, node) -> list:
        return [v for tri in self._world_tris(node) for v in tri]

    @staticmethod
    def _number(params, key, positive=False):
        value = params.get(key)
        if value is None:
            return None
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ToolError(f"'{key}' must be a number.")
        if positive and value <= 0:
            raise ToolError(f"'{key}' must be greater than 0.")
        return value

    def _aim(self, params):
        """(yaw, pitch) for the offscreen camera: a preset, then any
        explicit azimuth/elevation on top."""
        view = self._w.view3d
        yaw, pitch = view.yaw, view.pitch
        name = params.get("orientation")
        if name:
            if name not in ORIENTATIONS:
                raise ToolError(
                    f"Unknown orientation {name!r}. Choose one of: "
                    f"{', '.join(ORIENTATIONS)}.")
            yaw, pitch = view.VIEWS[name]
        az = self._number(params, "azimuth")
        el = self._number(params, "elevation")
        return (yaw if az is None else az, pitch if el is None else el)

    def _model_frame(self):
        """What an offscreen fit frames: the model's own vertices. The
        on-screen fit takes the platform in too (View3D.fit), which is
        the look the user wants — but in a picture an assistant asks
        for it left the model small in the middle of a big disc."""
        return [v for tri in self._w.view3d.mesh for v in tri] or True

    def _offscreen(self, params, limit):
        """render_view from a camera of its own (View3D.snapshot)."""
        from PyQt5.QtCore import QRect
        view = self._w.view3d
        projection = params.get("projection")
        if projection is not None and projection not in PROJECTIONS:
            raise ToolError(f"Unknown projection {projection!r}. Choose "
                            f"one of: {', '.join(PROJECTIONS)}.")
        frame = None
        overlay = None
        if params.get("overlay_reference"):
            # compare to the photo: square on to its plane, orthographic,
            # the picture and the model both in frame, drawn over it
            from . import refimage
            refs = [r for r in self._model.reference_images
                    if r.get("visible", True)]
            if not refs:
                raise ToolError("There is no reference image to compare "
                                "with — set_reference_image first.")
            overlay = True
            params = dict(params)
            if not any(params.get(k) is not None for k in
                       ("azimuth", "elevation", "orientation")):
                params["orientation"] = _PLANE_VIEWS.get(
                    refs[0].get("plane"), "Front")
            if projection is None:
                projection = "Orthographic"
            frame = self._model_frame()
            frame = ([] if frame is True else list(frame)) + [
                c for r in refs for c in refimage.corners(r)]
        if params.get("target_node") is not None:
            node = self._node(params["target_node"])
            frame = self._world_points(node)
            if not frame:
                raise ToolError(
                    f"{node.name} has no geometry in the 3D view to "
                    "frame — it is hidden, empty, or 2D-only.")
        elif params.get("fit"):
            frame = self._model_frame()
        target = params.get("target")
        if target is not None:
            try:
                target = [float(v) for v in target]
            except (TypeError, ValueError):
                target = None
            if target is None or len(target) != 3:
                raise ToolError("'target' must be [x, y, z] in mm.")
        common = dict(distance=self._number(params, "distance", True),
                      target=target, projection=projection,
                      zoom=self._number(params, "zoom", True) or 1.0,
                      overlay=overlay)
        if params.get("orientations"):
            return self._contact_sheet(params["orientations"], limit,
                                       frame, common)
        yaw, pitch = self._aim(params)
        vw, vh = view.width(), view.height()
        aspect = vh / vw if vw > 1 and vh > 1 else 0.75
        w, h = limit, max(int(round(limit * aspect)), 16)
        region = params.get("region")
        if region is None:
            image, cam = view.snapshot(w, h, yaw=yaw, pitch=pitch,
                                       frame=frame, **common)
            return image, {"camera": cam}
        try:
            x0, y0, x1, y1 = (float(v) for v in region)
        except (TypeError, ValueError):
            raise ToolError("'region' must be [x0, y0, x1, y1].")
        if not (0.0 <= x0 < x1 <= 1.0 and 0.0 <= y0 < y1 <= 1.0):
            raise ToolError("'region' is [x0, y0, x1, y1] as fractions "
                            "of the picture: 0 <= x0 < x1 <= 1 and "
                            "0 <= y0 < y1 <= 1.")
        # Same aspect as the whole picture, only bigger, so the framing
        # is the one the caller would see without a region.
        k = min(1.0 / (x1 - x0), 1.0 / (y1 - y0),
                _MAX_RENDER_SIDE / max(w, h))
        bw, bh = int(round(w * k)), int(round(h * k))
        image, cam = view.snapshot(bw, bh, yaw=yaw, pitch=pitch,
                                   frame=frame, **common)
        crop = image.copy(QRect(int(x0 * bw), int(y0 * bh),
                                max(int((x1 - x0) * bw), 1),
                                max(int((y1 - y0) * bh), 1)))
        if crop.width() > limit:
            crop = crop.scaledToWidth(limit, Qt.SmoothTransformation)
        return crop, {"camera": cam, "region": [x0, y0, x1, y1]}

    def _contact_sheet(self, names, limit, frame, common):
        """Several presets tiled into one labelled picture, each view
        framed on its own."""
        from PyQt5.QtCore import QRectF
        from PyQt5.QtGui import QColor, QImage, QPainter
        if not isinstance(names, (list, tuple)):
            raise ToolError("'orientations' must be a list of presets.")
        bad = [n for n in names if n not in ORIENTATIONS]
        if bad:
            raise ToolError(f"Unknown orientation {bad[0]!r}. Choose "
                            f"from: {', '.join(ORIENTATIONS)}.")
        names = list(dict.fromkeys(names))
        view = self._w.view3d
        cols = 1 if len(names) == 1 else 2 if len(names) <= 4 else 3
        rows = (len(names) + cols - 1) // cols
        tw = max(limit // cols, 64)
        th = max(int(tw * 0.75), 48)
        sheet = QImage(tw * cols, th * rows, QImage.Format_ARGB32)
        sheet.fill(QColor("#1e2226"))
        painter = QPainter(sheet)
        font = painter.font()
        font.setBold(True)
        painter.setFont(font)
        tiles = []
        for i, name in enumerate(names):
            yaw, pitch = view.VIEWS[name]
            image, cam = view.snapshot(
                tw, th, yaw=yaw, pitch=pitch,
                frame=self._model_frame() if frame is None else frame,
                **common)
            x, y = (i % cols) * tw, (i // cols) * th
            painter.drawImage(x, y, image)
            painter.setPen(QColor("#1e2226"))
            painter.drawRect(x, y, tw - 1, th - 1)
            box = QRectF(x + 6, y + 6,
                         painter.fontMetrics().width(name) + 12, 20)
            painter.fillRect(box, QColor(0, 0, 0, 150))
            painter.setPen(QColor("#ffffff"))
            painter.drawText(box, Qt.AlignCenter, name)
            tiles.append({"orientation": name, "camera": cam})
        painter.end()
        return sheet, {"tiles": tiles}

    def _t_list_parts(self, params) -> dict:
        from . import library
        part_id = params.get("part_id")
        if part_id:
            spec = library.PARTS.get(part_id)
            if spec is None:
                raise ToolError(f"No library part {part_id!r}.")
            sizes = spec.get("sizes") or {}
            return {
                "part_id": part_id, "label": spec["label"],
                "category": spec["category"],
                "sizes": {name: dict(dims) for name, dims in
                          sizes.items()},
                "dimensions": [{"name": k, "label": lbl}
                               for k, lbl in spec.get("fields", [])],
                "colors": list(spec.get("colors") or []),
                "unit": spec.get("unit", "mm"),
                **({"description": spec["description"],
                    "tags": list(spec.get("tags") or [])}
                   if spec.get("description") else {}),
            }
        from . import user_library
        user_library.refresh(library.PARTS)   # saved since start-up
        want = params.get("category")
        words = str(params.get("search") or "").lower().split()
        groups = {}
        for pid, spec in library.PARTS.items():
            if want and spec["category"] != want:
                continue
            if words and not user_library.matches(spec, pid, words):
                continue
            entry = {"part_id": pid, "label": spec["label"],
                     "sizes": list(spec.get("sizes") or {})}
            if spec.get("description"):
                entry["description"] = spec["description"]
            groups.setdefault(spec["category"], []).append(entry)
        return {"categories": [{"category": c, "parts": p}
                               for c, p in groups.items()],
                "my_library_areas": user_library.existing_sections()}

    def _t_save_to_library(self, params) -> dict:
        from . import library, user_library
        node = self._node(params.get("node_id"))
        tags = params.get("tags") or []
        if isinstance(tags, str):
            tags = [t for t in re.split(r"[,;]", tags)]
        try:
            saved = user_library.save(
                node, params.get("title", ""), params.get("description", ""),
                str(params.get("section") or ""), tags, root=self._model.root,
                unit=self._model.unit, source="assistant",
                global_fn=self._model.global_fn)
        except (ValueError, OSError) as exc:
            raise ToolError(str(exc))
        if node.type == "component":
            user_library.unignore(saved["uid"])
            user_library.remember(node, saved, params.get("description", ""),
                                  tags)
        user_library.refresh(library.PARTS)
        if not str(params.get("description") or "").strip():
            saved["note"] = ("Saved without a description: add one — it "
                             "is what a later search reads.")
        return saved

    def _t_split_part(self, params) -> dict:
        from . import split
        node = self._node(params.get("node_id"))
        try:
            first, second, pin, points = split.split_part(
                self._model, node, str(params.get("axis", "z")),
                params.get("position"), int(params.get("dowels", 2)),
                float(params.get("dowel_diameter", 5.0)),
                float(params.get("dowel_depth", 10.0)),
                float(params.get("clearance", 0.15)),
                float(params.get("gap", 10.0)))
        except ValueError as exc:
            raise ToolError(str(exc))
        return {"halves": [first.id, second.id],
                "pin": pin.id if pin is not None else None,
                "dowels": [[round(u, 3), round(v, 3)] for u, v in points],
                "hidden": node.id}

    def _t_list_scad_libraries(self, _params) -> dict:
        from . import scadlib_dialog
        return scadlib_dialog.describe()

    def _t_install_scad_library(self, params) -> dict:
        from . import scadlib, scadlib_dialog
        key = str(params.get("key", "")).strip()
        lib = next((lib for lib in scadlib.KNOWN
                    if lib.key.lower() == key.lower()), None)
        if lib is None:
            raise ToolError(f"No library {key!r}; list_scad_libraries "
                            f"names them.")
        try:
            folder = scadlib_dialog.run_install(lib)
        except Exception as exc:
            raise ToolError(f"Could not install {lib.title}: {exc}")
        return {"installed": lib.key, "folder": folder,
                "include": lib.include}

    def _t_list_examples(self, _params) -> dict:
        from . import examples
        return {"examples": [{"name": name, "category": category}
                             for name, category, _b in examples.EXAMPLES]}

    def _t_list_anchors(self, params) -> dict:
        model = self._model
        scope = (self._node(params["scope_id"]) if params.get("scope_id")
                 else None)
        available = mates.parts(model, scope)
        out = {"parts": [{"id": p.id, "name": p.name, "type": p.type}
                         for p in available]}
        if params.get("node_id"):
            node = self._node(params["node_id"])
            definition = mates.definition_of(model, node) or node
            found = anchors.anchors_of(definition, env=self._env(),
                                       fn=self._fn())
            out["node"] = {"id": node.id, "name": node.name}
            out["anchors"] = [{"name": a["name"], "kind": a["kind"],
                               "pos": [round(v, 3) for v in a["pos"]]}
                              for a in found]
            out["can_attach_to"] = [p.name for p
                                    in mates._mate_siblings(node)]
        return out

    # ── Measuring ───────────────────────────────────────────────

    def _node_box(self, node):
        pts = self._world_points(node)
        if not pts:
            raise ToolError(
                f"{node.name} has no geometry in the 3D view — it is "
                "hidden, empty, or 2D-only.")
        return ([min(p[i] for p in pts) for i in range(3)],
                [max(p[i] for p in pts) for i in range(3)])

    @staticmethod
    def _box_dict(lo, hi) -> dict:
        return {"min": [round(v, 3) for v in lo],
                "max": [round(v, 3) for v in hi],
                "size": [round(hi[i] - lo[i], 3) for i in range(3)],
                "center": [round((lo[i] + hi[i]) / 2, 3)
                           for i in range(3)]}

    @staticmethod
    def _blender_info() -> dict:
        from . import photoreal
        path = photoreal.find_blender()
        return {"available": path is not None, "path": path,
                "note": ("render_photo makes photoreal pictures." if path
                         else "Not installed: render_photo is off (free "
                              "at blender.org).")}

    @staticmethod
    def _csg_info() -> dict:
        from . import csg
        on = csg.available()
        return {"available": on, "note": (
            "Manifold is installed: the preview CUTS difference / "
            "intersection / minkowski itself, so render_view, bounds, "
            "mass_properties and probe_surface see the real holes at "
            "once, with or without OpenSCAD. bevel, decimate and "
            "shrinkwrap nodes work." if on else
            "manifold3d is not installed: the preview approximates "
            "booleans and the bevel node cannot run (pip install "
            "manifold3d).")}

    def _t_get_node_bounds(self, params) -> dict:
        nodes = self._nodes(params.get("node_ids"))
        out, los, his = [], [], []
        for node in nodes:
            lo, hi = self._node_box(node)
            los.append(lo)
            his.append(hi)
            out.append({"id": node.id, "name": node.name,
                        **self._box_dict(lo, hi),
                        "approximate": mesh.approximates(node)})
        result = {"nodes": out, "unit": self._unit()}
        if len(out) > 1:
            result["combined"] = self._box_dict(
                [min(lo[i] for lo in los) for i in range(3)],
                [max(hi[i] for hi in his) for i in range(3)])
        if any(e["approximate"] for e in out):
            result["note"] = (
                "Bounds come from the built-in tessellator, which "
                "approximates booleans (a difference shows its first "
                "operand). A cut never grows a part, so a difference's "
                "box is right; an intersection or minkowski can be off.")
        return result

    def _where(self, spec, label):
        """One end of a measurement: ``{"point": [x, y, z]}`` or
        ``{"node": id, "at": "center" | "min" | "max" | <anchor>}``.
        Returns (world point, (node, lo, hi) or None, description)."""
        if not isinstance(spec, dict):
            raise ToolError(
                f"'{label}' must be {{\"point\": [x, y, z]}} or "
                f"{{\"node\": id, \"at\": ...}}.")
        if spec.get("point") is not None:
            try:
                point = [float(v) for v in spec["point"]]
            except (TypeError, ValueError):
                point = []
            if len(point) != 3:
                raise ToolError(f"'{label}.point' must be [x, y, z].")
            return point, None, "point"
        if spec.get("node") is None:
            raise ToolError(f"'{label}' needs a 'point' or a 'node'.")
        node = self._node(spec["node"])
        lo, hi = self._node_box(node)
        box = (node, lo, hi)
        at = str(spec.get("at") or "center").strip()
        if at.lower() in ("center", "centre"):
            return ([(lo[i] + hi[i]) / 2 for i in range(3)], box,
                    f"{node.name} · centre")
        if at.lower() == "min":
            return lo, box, f"{node.name} · min corner"
        if at.lower() == "max":
            return hi, box, f"{node.name} · max corner"
        if node.type not in ("component", "reference"):
            raise ToolError(
                f"Anchors belong to Objects and their instances; "
                f"{node.name} is a {node.type}. Use at: center, min or "
                "max, or measure its Object.")
        definition = mates.definition_of(self._model, node) or node
        found = anchors.anchors_of(definition, env=self._env(),
                                   fn=self._fn())
        match = [a for a in found if a["name"].lower() == at.lower()]
        if not match:
            raise ToolError(
                f"{node.name} has no anchor {at!r}. Use center, min, max "
                f"or one of: {', '.join(a['name'] for a in found[:40])}.")
        pos, _direction = anchors.anchor_world(node, match[0], self._env())
        return pos, box, f"{node.name} · {match[0]['name']}"

    def _vec3(self, params, key):
        value = params.get(key)
        if value is None:
            return None
        try:
            out = [float(v) for v in value]
        except (TypeError, ValueError):
            out = []
        if len(out) != 3:
            raise ToolError(f"'{key}' must be [x, y, z] in mm.")
        return out

    def _t_probe_surface(self, params) -> dict:
        from . import analysis, analysis_dialog
        origin = self._vec3(params, "from")
        if origin is None:
            raise ToolError("'from' is the ray origin [x, y, z] in mm.")
        direction = self._vec3(params, "direction")
        if direction is None:
            to = self._vec3(params, "to")
            if to is None:
                raise ToolError("Give a 'direction' [dx, dy, dz] or a "
                                "'to' point the ray passes through.")
            direction = [to[i] - origin[i] for i in range(3)]
        if math.sqrt(sum(c * c for c in direction)) < 1e-12:
            raise ToolError("The ray direction has zero length.")
        ids = params.get("node_ids")
        if ids:
            nodes = self._nodes(ids)
        else:
            root = self._w._render_scope()[0]
            nodes = [n for n in root.children if n.visible and n.type
                     not in ("variables", "masters", "assign")]
        if not nodes:
            raise ToolError("Nothing to probe: the scope has no visible "
                            "parts.")
        try:
            limit = max(int(params.get("max_hits") or 0), 0)
        except (TypeError, ValueError):
            raise ToolError("'max_hits' must be a whole number.")
        parts, approx = [], False
        for n in nodes:
            tris, a = analysis_dialog.part_tris(self._w, [n])
            approx = approx or a
            parts.append((n.id, tris))
        by_id = {n.id: n for n in nodes}
        hits = []
        for h in analysis.surface_hits(origin, direction, parts, limit):
            node = by_id[h["key"]]
            hits.append({"point": [round(v, 3) for v in h["point"]],
                         "normal": [round(v, 4) for v in h["normal"]],
                         "distance": round(h["distance"], 3),
                         "node_id": node.id, "name": node.name,
                         "entering": h["entering"]})
        length = math.sqrt(sum(c * c for c in direction))
        out = {"hit": hits[0] if hits else None, "hits": hits,
               "ray": {"from": origin,
                       "direction": [round(c / length, 4)
                                     for c in direction]},
               "probed": [n.name for n in nodes], "approximate": approx}
        if not hits:
            out["note"] = ("The ray misses every probed part. Aim it "
                           "with 'to' at a point inside the part, or "
                           "check get_node_bounds.")
        elif approx:
            out["note"] = self._APPROX_NOTE
        return out

    def _t_sample_surface(self, params) -> dict:
        from . import analysis, analysis_dialog
        nodes = self._nodes(params.get("node_ids"))
        try:
            count = int(20 if params.get("count") is None
                        else params["count"])
            seed = int(1 if params.get("seed") is None else params["seed"])
        except (TypeError, ValueError):
            raise ToolError("'count' and 'seed' must be whole numbers.")
        if count < 1 or count > 5000:
            raise ToolError("'count' must be between 1 and 5000.")
        spacing = self._number(params, "spacing") or 0.0
        if spacing < 0:
            raise ToolError("'spacing' must be 0 or more.")
        facing = self._vec3(params, "facing")
        if facing is not None and \
                math.sqrt(sum(c * c for c in facing)) < 1e-12:
            raise ToolError("'facing' has zero length.")
        max_angle = self._number(params, "max_angle")
        max_angle = 90.0 if max_angle is None else max_angle
        within = params.get("within")
        box = None
        if within is not None:
            if not isinstance(within, dict):
                raise ToolError("'within' is {\"min\": [x, y, z], "
                                "\"max\": [x, y, z]}.")
            lo, hi = self._vec3(within, "min"), self._vec3(within, "max")
            if lo is None or hi is None:
                raise ToolError("'within' needs both 'min' and 'max'.")
            box = ([min(lo[i], hi[i]) for i in range(3)],
                   [max(lo[i], hi[i]) for i in range(3)])
        tris, approx = analysis_dialog.part_tris(self._w, nodes)
        if not tris:
            raise ToolError("Those nodes have no surface to sample — "
                            "hidden, empty, or 2D-only.")
        samples = analysis.surface_samples(
            tris, count, spacing, facing, max_angle, box, seed)
        out = {"points": [{"point": [round(v, 3) for v in s["point"]],
                           "normal": [round(v, 4) for v in s["normal"]]}
                          for s in samples],
               "count": len(samples), "wanted": count,
               "seed": seed, "approximate": approx}
        if not samples:
            out["note"] = ("No face passed the filters — widen "
                           "'max_angle' or the 'within' box.")
        elif len(samples) < count:
            out["note"] = (f"Only {len(samples)} points fit at this "
                           "spacing; lower 'spacing' for more.")
        elif approx:
            out["note"] = self._APPROX_NOTE
        return out

    def _t_measure(self, params) -> dict:
        pa, box_a, la = self._where(params.get("a"), "a")
        pb, box_b, lb = self._where(params.get("b"), "b")
        delta = [pb[i] - pa[i] for i in range(3)]
        out = {"a": {"at": la, "point": [round(v, 3) for v in pa]},
               "b": {"at": lb, "point": [round(v, 3) for v in pb]},
               "delta": [round(v, 3) for v in delta],
               "distance": round(math.sqrt(sum(d * d for d in delta)), 3),
               "unit": self._unit()}
        if box_a and box_b and box_a[0] is not box_b[0]:
            _na, alo, ahi = box_a
            _nb, blo, bhi = box_b
            # per axis: > 0 is clearance between the boxes, < 0 how far
            # they run into each other
            gap = [max(blo[i] - ahi[i], alo[i] - bhi[i]) for i in range(3)]
            out["gap"] = [round(g, 3) for g in gap]
            out["overlap"] = all(g < 0 for g in gap)
            out["clearance"] = round(
                math.sqrt(sum(max(g, 0.0) ** 2 for g in gap)), 3)
        return out

    def _t_section(self, params) -> dict:
        from . import section
        axis = str(params.get("axis", "")).lower()
        if axis not in section.PLANES:
            raise ToolError("'axis' must be 'x', 'y' or 'z'.")
        offset = self._number(params, "offset")
        try:
            timeout = float(params.get("timeout", _DEFAULT_WAIT_S))
        except (TypeError, ValueError):
            raise ToolError("'timeout' must be a number of seconds.")
        timeout = min(max(timeout, 0.0), _MAX_WAIT_S)
        if params.get("node_id") is not None:
            node = self._node(params["node_id"])
            tris = self._world_tris(node)
            complete = True
            source = f"built-in tessellation of {node.name}"
            if mesh.approximates(node):
                source += " (booleans approximated)"
        else:
            complete = (self._wait_for_render(timeout)
                        if params.get("wait_for_exact", True)
                        else self._render_settled())
            tris = list(self._w.view3d.model_mesh)   # never a Cut Through
            source = self._w.view3d.source
        if not tris:
            raise ToolError("There is nothing in the 3D view to cut.")
        sec = section.section(tris, axis, offset)
        limit = max(int(params.get("max_width") or 700), 120)
        image = section.draw(sec, limit, int(limit * 0.72))
        u_name, v_name = sec["plane"]
        outlines = []
        for o in sec["outlines"]:
            entry = {"closed": o["closed"], "vertices": len(o["points"]),
                     "area": round(o["area"], 3),
                     "area_mm2": self._in_mm(o["area"], 2),
                     "hole": o["closed"] and o["area"] < 0}
            if params.get("include_points"):
                entry["points"] = [[round(u, 3), round(v, 3)]
                                   for u, v in o["points"]]
            outlines.append(entry)
        result = {IMAGE_KEY: self._png(image), "axis": axis,
                  "offset": round(sec["offset"], 3),
                  "plane": {"u": u_name, "v": v_name},
                  "outlines": outlines, "unit": self._unit(),
                  "area": round(sec["area"], 3),
                  "area_mm2": self._in_mm(sec["area"], 2),
                  "source": source, "render_complete": complete}
        if sec["bounds"]:
            u0, v0, u1, v1 = sec["bounds"]
            result["bounds"] = {u_name: [round(u0, 3), round(u1, 3)],
                                v_name: [round(v0, 3), round(v1, 3)]}
        else:
            k = section.PLANES[axis][0]
            vals = [v[k] for tri in tris for v in tri]
            result["note"] = (
                f"The plane misses the model: it spans {axis} = "
                f"{min(vals):g} to {max(vals):g} "
                f"{units.symbol(self._unit())}.")
        if any(not o["closed"] for o in sec["outlines"]):
            result["note"] = (
                "An outline did not close (drawn dashed red): the mesh "
                "has a gap on this plane — it is not watertight there.")
        return result

    def _t_check_code(self, params) -> dict:
        from .scadparse import parse_scad
        code = params.get("code")
        if not isinstance(code, str) or not code.strip():
            raise ToolError("'code' must be an OpenSCAD program.")
        try:
            root, warnings = parse_scad(code)
        except Exception as exc:
            raise ToolError(f"Could not parse that program: {exc}")
        types = {}
        for node in root.walk():
            if node is not root:
                types[node.type] = types.get(node.type, 0) + 1
        try:
            problems = validate(root)
        except Exception:
            problems = {}
        names = {n.id: n for n in root.walk()}
        return {
            "would_apply": bool(root.children),
            "top_level": len(root.children),
            "nodes": sum(types.values()),
            "types": dict(sorted(types.items())),
            "warnings": list(warnings),
            "problems": [{"node": names[i].name if i in names else i,
                          "type": names[i].type if i in names else "",
                          "message": msg}
                         for i, msg in problems.items()],
        }

    # ── Building ────────────────────────────────────────────────

    def _t_add_node(self, params) -> dict:
        type_name = str(params.get("type", ""))
        if type_name not in NODE_TYPES:
            raise ToolError(
                f"Unknown node type {type_name!r} — call "
                "list_node_types for the vocabulary.")
        values = self._check_params(type_name, params.get("params"))
        parent = (self._node(params["parent_id"])
                  if params.get("parent_id") else self._scope())
        if not parent.is_container():
            raise ToolError(
                f"'{parent.name}' ({parent.type}) cannot hold children.")
        node = self._model.add_node(type_name, values, parent,
                                    params.get("name", ""))
        if params.get("index") is not None:
            self._model.move_node(node, parent, int(params["index"]))
        return {"created": node.id, "type": node.type, "name": node.name,
                "parent": parent.name}

    def _t_set_params(self, params) -> dict:
        changes = params.get("changes")
        if not isinstance(changes, list) or not changes:
            raise ToolError("'changes' must be a non-empty list.")
        model = self._model
        touched, released = [], []
        for change in changes:
            node = self._node(change.get("id"))
            values = self._check_params(node.type, change.get("params"))
            if change.get("name"):
                model.rename(node, str(change["name"]))
            if "visible" in change:
                model.set_visible(node, bool(change["visible"]))
            had_mate = isinstance(node.params.get("mate"), dict)
            for key, value in values.items():
                model.set_param(node, key, value)
            if had_mate and not isinstance(node.params.get("mate"), dict):
                released.append(node.name)
            touched.append(node.id)
        result = {"updated": touched}
        if released:
            result["mates_released"] = released
            result["note"] = (
                "Setting a placement by hand releases the mate — it "
                "would otherwise overwrite the value on the next "
                "re-solve.")
        return result

    def _t_set_pose(self, params) -> dict:
        from . import expr
        if params.get("bones") is not None or params.get("node_id") is not None:
            return self._pose_human(params)
        wanted = params.get("joints")
        if not isinstance(wanted, dict):
            raise ToolError("'joints' must be an object: "
                            "{\"<joint name or id>\": {\"rx\": deg}}, or "
                            "'bones' with a human figure's node_id.")
        model, env = self._model, self._env()
        joints = [n for n in model.root.walk() if n.type == "joint"]
        index = {}
        for joint in joints:
            index.setdefault(str(joint.id), joint)
            index.setdefault(joint.name.lower(), joint)

        def num(node, key, default):
            try:
                return float(expr.resolve(node.params.get(key, default),
                                          env, default))
            except Exception:
                return default
        # check everything first: a typo halfway must not leave half
        # a pose applied
        plan, clamped = [], []
        for key, angles in wanted.items():
            joint = index.get(str(key).lower())
            if joint is None:
                names = ", ".join(j.name for j in joints) or \
                    "none yet — wrap a part in a joint node first"
                raise ToolError(f"No joint called {key!r}. Joints: {names}.")
            if not isinstance(angles, dict) or not angles or \
                    set(angles) - {"rx", "ry", "rz"}:
                raise ToolError(f"The pose for {joint.name} must be an "
                                "object of rx / ry / rz angles in degrees.")
            lo = num(joint, "min_angle", -180.0)
            hi = num(joint, "max_angle", 180.0)
            for axis, value in angles.items():
                try:
                    angle = float(value)
                except (TypeError, ValueError):
                    raise ToolError(f"{joint.name}.{axis} must be a "
                                    "number of degrees.")
                kept = min(max(angle, lo), hi)
                if kept != angle:
                    clamped.append({"joint": joint.name, "axis": axis,
                                    "asked": angle, "set": kept})
                plan.append((joint, axis, kept))
        for joint, axis, angle in plan:
            model.set_param(joint, axis, angle)
        result = {
            "posed": list(dict.fromkeys(j.name for j, _a, _v in plan)),
            "joints": [{"id": j.id, "name": j.name,
                        "angles": [round(num(j, k, 0.0), 3)
                                   for k in ("rx", "ry", "rz")],
                        "pivot": [round(num(j, k, 0.0), 3)
                                  for k in ("px", "py", "pz")],
                        "limits": [num(j, "min_angle", -180.0),
                                   num(j, "max_angle", 180.0)]}
                       for j in joints]}
        if clamped:
            result["clamped"] = clamped
            result["note"] = ("Some angles were past a joint's limits "
                              "and were clamped to them.")
        return result

    def _t_render_photo(self, params) -> dict:
        import os
        import tempfile
        from PyQt5.QtGui import QImage
        from . import photoreal, photoreal_ui
        if photoreal.find_blender() is None:
            raise ToolError(
                "Blender is not installed, so there is no photoreal "
                "render. Tell the user it is free at blender.org (or "
                "set KHERVECAD_BLENDER); render_view still works.")
        path = params.get("path")
        out = path or os.path.join(tempfile.mkdtemp(prefix="kcad_"),
                                   "photo.png")
        size = (int(params.get("width") or 1200),
                int(params.get("height") or 900))
        try:
            photoreal_ui.render_window(
                self._w, out, str(params.get("view") or "current"), size,
                int(params.get("samples") or 64),
                str(params.get("engine") or "cycles"),
                params.get("ground", True) is not False,
                bool(params.get("transparent", False)))
        except (RuntimeError, ValueError) as exc:
            raise ToolError(str(exc))
        image = QImage(out)
        if image.isNull():
            raise ToolError("Blender wrote no readable picture.")
        width = int(params.get("max_width") or 900)
        if image.width() > width:
            from PyQt5.QtCore import Qt
            image = image.scaledToWidth(width, Qt.SmoothTransformation)
        result = {IMAGE_KEY: self._png(image), "size": list(size)}
        if path:
            result["saved"] = path
        return result

    def _t_push_pull_face(self, params) -> dict:
        from . import faceedit, faceedit_ui
        node = self._node(params.get("node_id"))
        point = self._vec3(params, "point")
        try:
            distance = float(params.get("distance"))
            inset = float(params.get("inset") or 0.0)
        except (TypeError, ValueError):
            raise ToolError("'distance' and 'inset' must be numbers.")
        from . import csg
        if not csg.available():
            raise ToolError("push_pull_face needs manifold3d installed.")
        wrapper = node if node.type == "push_pull" else (
            node.parent if node.parent is not None
            and node.parent.type == "push_pull" else None)
        if wrapper is None:
            wrapper = self._model.wrap_nodes([node], "push_pull")
            if wrapper is None:
                raise ToolError(f"{node.name} cannot be wrapped.")
        env = self._env()
        local = [round(v, 4) for v in
                 faceedit_ui.local_point(wrapper, point, env)]
        rows = [list(r) for r in (wrapper.params.get("pushes") or [])]
        rows.append(local + [distance, inset])
        from . import mesh
        src = [t for t, _c, _s in mesh._children_mesh(
            wrapper, env, None, frozenset(), False)]
        _out, missing = faceedit.push_pull(src, rows)
        if len(rows) - 1 in missing:
            raise ToolError(
                f"No flat face at {point} on {node.name} — use a "
                "probe_surface hit point on a flat face.")
        self._model.set_param(wrapper, "pushes", rows)
        return {"node": wrapper.id, "pushes": rows,
                "note": "Rows apply in order; edit or delete one with "
                        "set_params on the push_pull node's `pushes`."}

    def _t_drop_parts(self, params) -> dict:
        from . import physics
        ids = params.get("node_ids")
        if ids:
            nodes = self._nodes(ids)
        else:
            from . import mates
            scope = self._w.builder.isolated_component() \
                if hasattr(self._w.builder, "isolated_component") else None
            nodes = [n for n in mates.parts(self._model, scope)
                     if n.visible]
        if not nodes:
            raise ToolError("Nothing to drop — give node_ids.")
        report = physics.apply(
            self._model, nodes,
            floor=float(params.get("floor") or 0.0),
            settle_parts=params.get("settle", True) is not False,
            gap=float(params.get("gap") or 0.0), env=self._env())
        return {"dropped": report, "unit": self._unit()}

    def _t_reach(self, params) -> dict:
        from . import ik
        node = self._node(params.get("node_id"))
        if params.get("target_node") is not None:
            lo, hi = self._node_box(self._node(params["target_node"]))
            target = [(lo[i] + hi[i]) / 2 for i in range(3)]
        elif params.get("target") is not None:
            target = self._vec3(params, "target")
        else:
            raise ToolError("Give a target [x, y, z] or a target_node.")
        if params.get("offset") is not None:
            off = self._vec3(params, "offset")
            target = [target[i] + off[i] for i in range(3)]
        point = self._vec3(params, "point") if params.get("point") \
            is not None else None
        if ik.human_in(node) is None and not ik.in_joint(node):
            raise ToolError(
                f"{node.name} has nothing to bend: give a human figure, "
                "or a part inside joint nodes (wrap_nodes operation "
                "'joint' with its pivot at the shoulder / elbow).")
        try:
            out = ik.reach(self._model, node, target,
                           params.get("effector"), params.get("chain"),
                           point, self._env())
        except ValueError as exc:
            raise ToolError(str(exc))
        out["target"] = [round(v, 3) for v in target]
        return out

    def _pose_human(self, params) -> dict:
        """set_pose on a human figure: bones of MakeHuman's rig, angles
        in degrees about each bone's head in the body's axes, kept as
        the node's `pose` rows (an axis left out keeps its angle)."""
        from . import human
        if params.get("node_id") is None:
            raise ToolError("Posing a human figure needs its node_id.")
        target = self._node(params["node_id"])
        rig = next((n for n in target.walk() if n.type == "armature"),
                   None)
        if rig is not None and not any(n.type == "human"
                                       for n in target.walk()):
            from . import creature_mcp
            try:
                if params.get("bones"):
                    creature_mcp.set_armature_pose(rig, params["bones"])
                    self._model.node_changed.emit(rig)
                return creature_mcp.armature_report(rig)
            except creature_mcp.CreatureError as exc:
                raise ToolError(str(exc))
        node = self._human_node(self._node(params["node_id"]))
        bones = human.skeleton()["bones"]
        wanted = params.get("bones")
        if wanted is None:
            wanted = {}
        if not isinstance(wanted, dict):
            raise ToolError("'bones' is {\"<bone>\": {\"rx\": deg, "
                            "\"ry\": deg, \"rz\": deg}}.")
        rows = {str(r[0]): [float(v) for v in r[1:4]]
                for r in (node.params.get("pose") or [])
                if isinstance(r, list) and len(r) == 4}
        for name, angles in wanted.items():
            if name not in bones:
                close = [b for b in bones if str(name).lower() in b.lower()][:8]
                raise ToolError(f"No bone named {name!r}."
                                + (f" Did you mean: {', '.join(close)}?"
                                   if close else ""))
            if not isinstance(angles, dict) or set(angles) - {"rx", "ry", "rz"}:
                raise ToolError(f"The pose for {name} is an object of "
                                "rx / ry / rz degrees.")
            current = rows.get(name, [0.0, 0.0, 0.0])
            for axis, value in angles.items():
                try:
                    current["rx ry rz".split().index(axis)] = float(value)
                except (TypeError, ValueError):
                    raise ToolError(f"{name}.{axis} must be a number.")
            rows[name] = current
        pose = [[n] + a for n, a in rows.items() if any(a)]
        if wanted:
            self._model.set_param(node, "pose", pose)
        return {"node": node.id, "pose": pose,
                "bones": sorted(bones),
                "note": ("Angles turn the bone about its head in the "
                         "body's own axes (X across, Y front-back, Z "
                         "up) and carry everything below it: "
                         "upperarm02.L rz lifts the left arm out, "
                         "lowerarm01.L bends the elbow, head rz turns "
                         "the head. Clothes built round the figure "
                         "do not follow — pose first, dress after.")}

    def _t_wrap_nodes(self, params) -> dict:
        op = str(params.get("operation", ""))
        if op not in WRAP_TYPES:
            raise ToolError(
                f"Cannot wrap in {op!r}. Choose one of: "
                f"{', '.join(WRAP_TYPES)}.")
        nodes = self._nodes(params.get("ids"))
        parents = {id(n.parent) for n in nodes}
        if len(parents) > 1:
            raise ToolError(
                "Those nodes have different parents. wrap_nodes works "
                "on siblings — move them together first.")
        if any(n.parent is None for n in nodes):
            raise ToolError("The document root cannot be wrapped.")
        values = self._check_params(op, params.get("params"))
        wrapper = self._model.wrap_nodes(nodes, op)
        if wrapper is None:
            raise ToolError("Nothing to wrap.")
        for key, value in values.items():
            wrapper.params[key] = value
        if params.get("name"):
            wrapper.name = str(params["name"])
        self._model.node_changed.emit(wrapper)
        return {"wrapper": wrapper.id, "type": op, "name": wrapper.name,
                "wrapped": [n.id for n in nodes]}

    def _t_move_node(self, params) -> dict:
        node = self._node(params.get("node_id"))
        parent = self._node(params.get("parent_id"))
        if not parent.is_container():
            raise ToolError(
                f"'{parent.name}' ({parent.type}) cannot hold children.")
        if node.parent is None:
            raise ToolError("The document root cannot be moved.")
        if any(n is node for n in self._model._ancestors(parent)):
            raise ToolError(
                f"'{parent.name}' is inside '{node.name}' — that would "
                "make the tree its own child.")
        index = params.get("index")
        self._model.move_node(node, parent,
                              None if index is None else int(index))
        return {"moved": node.id, "parent": parent.name,
                "index": node.index()}

    def _t_duplicate_node(self, params) -> dict:
        node = self._node(params.get("node_id"))
        if node.parent is None:
            raise ToolError("The document root cannot be duplicated.")
        clone = self._model.duplicate(node)
        return {"created": clone.id, "name": clone.name}

    def _t_delete_nodes(self, params) -> dict:
        nodes = self._nodes(params.get("ids"))
        gone = []
        for node in nodes:
            if node.parent is None:
                continue
            gone.append({"id": node.id, "name": node.name})
            self._model.remove_node(node)
        if not gone:
            raise ToolError("Nothing to delete.")
        return {"deleted": gone}

    def _t_ungroup_node(self, params) -> dict:
        node = self._node(params.get("node_id"))
        if not node.is_container() or node.parent is None:
            raise ToolError(
                f"'{node.name}' is not a container that can be "
                "ungrouped.")
        freed = [c.id for c in node.children]
        self._model.ungroup(node)
        return {"ungrouped": node.name, "freed": freed}

    def _t_set_color(self, params) -> dict:
        nodes = self._nodes(params.get("ids"))
        color = str(params.get("color", ""))
        if not color:
            raise ToolError("Pass a colour, e.g. '#4a90d9'.")
        alpha = float(params.get("alpha", 1.0))
        material = params.get("material")
        if material is not None:
            from .model import MATERIALS
            if material not in MATERIALS:
                raise ToolError(f"Unknown material {material!r}. Choose "
                                f"one of: {', '.join(MATERIALS)}.")
        wrappers = self._model.set_color(nodes, color, alpha, material)
        result = {"colored": [w.id for w in wrappers], "color": color,
                  "alpha": alpha}
        if material is not None:
            result["material"] = material
        return result

    def _t_round_edges(self, params) -> dict:
        nodes = self._nodes(params.get("ids"))
        radius = float(params.get("radius", 1.0))
        wrapper = self._model.round_edges(nodes, radius)
        if wrapper is None:
            raise ToolError("Nothing to round.")
        return {"wrapper": wrapper.id, "radius": radius,
                "note": "minkowski() with a sphere — slow to render; "
                        "keep the radius small."}

    def _t_apply_code(self, params) -> dict:
        from .chat import ChatPanel
        from .scadparse import parse_scad
        code = params.get("code")
        if not isinstance(code, str) or not code.strip():
            raise ToolError("'code' must be an OpenSCAD program.")
        mode = str(params.get("mode", "append")).lower()
        if mode not in ("append", "replace"):
            raise ToolError("'mode' must be 'append' or 'replace'.")
        try:
            root, warnings = parse_scad(code)
        except Exception as exc:
            raise ToolError(f"Could not parse that program: {exc}")
        # The parser never raises on a bad statement: it skips it with a
        # warning and carries on, which is right for importing a file
        # someone else wrote. For a program a client just composed it is
        # the wrong answer — applying nothing while reporting success is
        # a failure it cannot see. So refuse an empty parse.
        if not root.children:
            detail = ("; ".join(warnings[:5]) if warnings
                      else "it declared no geometry")
            raise ToolError(
                f"That program produced no objects: {detail}. Nothing "
                "was applied.")
        model = self._model
        target = (self._node(params["into_id"]) if params.get("into_id")
                  else self._scope())
        added = len(root.children)
        if target is model.root:
            if mode == "replace":
                model.root = root
            else:
                for child in list(root.children):
                    root.remove(child)
                    model.root.add(child)
            model.group_variables()
            model.structure_changed.emit()
        else:
            if not target.is_container():
                raise ToolError(
                    f"'{target.name}' ({target.type}) cannot hold "
                    "children.")
            # A program that is one module plus its call re-imports as a
            # single Object — unwrap it, or the part would nest inside
            # itself. Same helper the built-in assistant uses.
            nodes = ChatPanel._object_contents(root)
            if not nodes:
                raise ToolError(
                    "That program produced nothing to put inside "
                    f"'{target.name}'.")
            for node in list(nodes):
                node.parent.remove(node)
            if mode == "replace":
                for child in list(target.children):
                    target.remove(child)
            added = len(nodes)
            for node in nodes:
                target.add(node)
            model.structure_changed.emit()
        result = {"applied_into": target.name, "mode": mode,
                  "added": added,
                  "nodes": len(list(model.root.walk())) - 1}
        if warnings:
            result["warnings"] = warnings[:12]
        return result

    # ── Parts and assemblies ────────────────────────────────────

    def _t_list_crystals(self, params) -> dict:
        from . import crystal_build
        try:
            return crystal_build.list_crystals(params)
        except crystal_build.BuildError as exc:
            raise ToolError(str(exc))

    def _t_build_crystal(self, params) -> dict:
        from . import crystal_build
        try:
            return crystal_build.build_crystal(self._w, params)
        except crystal_build.BuildError as exc:
            raise ToolError(str(exc))

    def _t_build_surface(self, params) -> dict:
        from . import crystal_build, crystal_surface
        try:
            return crystal_surface.build_surface(self._w, params)
        except crystal_build.BuildError as exc:
            raise ToolError(str(exc))

    def _t_list_molecules(self, params) -> dict:
        from . import molecule_build
        try:
            return molecule_build.list_molecules(params)
        except molecule_build.BuildError as exc:
            raise ToolError(str(exc))

    def _t_list_character_options(self, params) -> dict:
        from . import human_design
        return human_design.options()

    def _t_build_character(self, params) -> dict:
        from . import human_design
        params = dict(params)
        place = {k: params.pop(k) for k in ("x", "y", "rz")
                 if params.get(k) is not None}
        replace_id = params.pop("replace_id", None)
        replace = self._node(replace_id) if replace_id is not None else None
        if replace is not None and not (replace.params or {}).get(
                "character"):
            raise ToolError(f"Node {replace_id} is not a person built by "
                            "build_character or the Human Builder.")
        try:
            part = human_design.insert(
                self._model, params, x=place.get("x"),
                y=place.get("y", 0.0), rz=place.get("rz", 0.0),
                replace=replace)
        except human_design.SpecError as exc:
            raise ToolError(f"{exc}. Call list_character_options.")
        spec = part.params["character"]
        return {"id": part.id, "name": part.name, "spec": spec,
                "garments": human_design.garment_rows(spec),
                "note": "Clothes follow body parts. Look at it with "
                        "render_view (target_node) from Front and Right."}

    def _t_build_molecule(self, params) -> dict:
        from . import molecule_build
        try:
            return molecule_build.build_molecule(self._w, params)
        except molecule_build.BuildError as exc:
            raise ToolError(str(exc))

    def _t_build_reaction(self, params) -> dict:
        from . import molecule_build
        try:
            return molecule_build.build_reaction(self._w, params)
        except molecule_build.BuildError as exc:
            raise ToolError(str(exc))

    def _t_list_proteins(self, params) -> dict:
        from . import protein_build
        return protein_build.list_proteins(params)

    def _t_build_protein(self, params) -> dict:
        from . import molecule_build, protein_build
        try:
            return protein_build.build_protein(self._w, params)
        except molecule_build.BuildError as exc:
            raise ToolError(str(exc))

    def _t_build_house(self, params) -> dict:
        from . import house
        try:
            from . import house_templates
            try:
                params = house_templates.expand(params)
            except KeyError as exc:
                raise ToolError(str(exc.args[0]))
            return house.build_house(self._w, params)
        except house.HouseError as exc:
            raise ToolError(str(exc))

    def _t_get_city(self, params) -> dict:
        from . import city
        return city.get_city(self._w, params)

    def _t_build_city(self, params) -> dict:
        from . import city
        try:
            params = dict(params or {})
            if params.get("path"):
                from . import map_import
                spec = map_import.load_spec(params.pop("path"))
                spec.update(params)
                params = spec
            save_to = params.pop("save_to", None)
            result = city.build_city(self._w, params)
            if save_to and self._model.city:
                from . import map_import
                map_import.save_spec({k: v for k, v in self._model.city.items()
                                      if k != "objects"}, save_to)
                result["saved"] = save_to
            return result
        except city.CityError as exc:
            raise ToolError(str(exc))
        except Exception as exc:
            from . import map_import
            if isinstance(exc, map_import.MapImportError):
                raise ToolError(str(exc))
            raise

    def _t_import_map(self, params) -> dict:
        from . import city, map_import
        import os
        params = dict(params or {})
        folder = None
        if self._model_path():
            folder = os.path.dirname(self._model_path())
        try:
            spec, report, ref = map_import.import_map(params,
                                                      aerial_dir=folder)
        except map_import.MapImportError as exc:
            raise ToolError(str(exc))
        if params.get("path"):
            report["saved"] = params["path"]
            report["saved_bytes"] = map_import.save_spec(spec,
                                                          params["path"])
        if params.get("build", True):
            try:
                built = city.build_city(self._w, dict(spec))
            except city.CityError as exc:
                raise ToolError(str(exc))
            report.update(objects=built["objects"], counts=built["counts"])
        if ref is not None:
            self._model.add_reference_image(ref)
            report["reference_images"] = self._references()
        return report

    def _model_path(self):
        return getattr(self._w, "_path", None)

    def _t_send_to_planetcraft(self, params) -> dict:
        from . import planetcraft

        def num(key, kind):
            return kind(params[key]) if params.get(key) is not None else None
        node = None
        if params.get("node_id") is not None:
            node = self._node(params["node_id"])
        try:
            # left out, speed, health, damage and nature come from the
            # creature (build_creature keeps them on it), then defaults
            args = dict(name=str(params.get("name") or "Creature"),
                        node=node, height=params.get("height"),
                        speed=num("speed", float),
                        health=num("health", int),
                        wild=params.get("wild", True),
                        nature=params.get("nature") or None,
                        damage=num("damage", int))
            if params.get("dry_run"):
                return {"dry_run": True, **planetcraft.summary(
                    planetcraft.build_creature(self._model, **args))}
            return planetcraft.export(self._model, folder=params.get("path"),
                                      **args)
        except planetcraft.PlanetCraftError as exc:
            raise ToolError(str(exc))

    def _t_list_creature_options(self, params) -> dict:
        from . import creature_build
        return creature_build.options()

    def _t_build_creature(self, params) -> dict:
        from . import creature_build, planetcraft
        params = dict(params or {})
        send = bool(params.pop("send", False))
        folder = params.pop("path", None)
        try:
            node, spec, parts = creature_build.build(self._model, params)
        except creature_build.CreatureError as exc:
            raise ToolError(f"{exc} Call list_creature_options.")
        self._model.structure_changed.emit()
        out = {"id": node.id, "name": spec["name"], "plan": spec["plan"],
               "height_mm": spec["height"], "parts": parts,
               "game": {k: spec.get(k) for k in
                        ("nature", "speed", "health", "damage")},
               "note": "Every piece is inside its part (the group named "
                       "Head, Tail, Left leg...). Look at it with "
                       "render_view (Front, Right); keep new pieces inside "
                       "their part's group. Then send_to_planetcraft with "
                       f"node_id {node.id}."}
        if send:
            try:
                out["sent"] = planetcraft.export(
                    self._model, spec["name"], folder=folder, node=node)
            except planetcraft.PlanetCraftError as exc:
                raise ToolError(f"Built it (node {node.id}) but could not "
                                f"send it: {exc}")
        return out

    def _t_list_planetcraft_creatures(self, params) -> dict:
        from . import planetcraft
        try:
            return planetcraft.list_creatures(params.get("path"))
        except planetcraft.PlanetCraftError as exc:
            raise ToolError(str(exc))

    def _t_remove_from_planetcraft(self, params) -> dict:
        from . import planetcraft
        try:
            return planetcraft.remove(params.get("name") or "",
                                      params.get("path"))
        except planetcraft.PlanetCraftError as exc:
            raise ToolError(str(exc))

    def _t_collections(self, params) -> dict:
        from . import part_collections as pc
        model = self._model
        action = params.get("action") or "list"
        name = params.get("name")
        try:
            if action == "create":
                name = pc.create(model, name or "",
                                 self._nodes(params.get("ids") or []))
            elif action == "assign":
                pc.assign(model, self._nodes(params.get("ids")), name)
            elif action in ("show", "hide"):
                pc.set_visible(model, name, action == "show")
            elif action in ("lock", "unlock"):
                pc.set_locked(model, name, action == "lock")
            elif action == "solo":
                pc.solo(model, name)
            elif action == "rename":
                name = pc.rename(model, name, params.get("new_name"))
            elif action == "delete":
                pc.remove(model, name)
            elif action != "list":
                raise ToolError(f"Unknown action '{action}'.")
        except pc.CollectionError as exc:
            raise ToolError(str(exc))
        return {"collections": pc.summary(model), "name": name}

    def _t_make_object(self, params) -> dict:
        nodes = self._nodes(params.get("ids"))
        model = self._model
        if len(nodes) > 1:
            parents = {id(n.parent) for n in nodes}
            if len(parents) > 1:
                raise ToolError(
                    "Those nodes have different parents — group them "
                    "under one parent first.")
            node = model.group_nodes(nodes)
        else:
            node = nodes[0]
        comp = model.make_component(node)
        if comp is None:
            raise ToolError(
                f"'{node.name}' cannot become an Object.")
        if params.get("name"):
            comp = model.enclose_as_part(comp, str(params["name"]))
        return {"object": comp.id, "name": comp.name,
                "visible": comp.visible}

    def _t_add_instance(self, params) -> dict:
        comp = self._node(params.get("node_id"))
        if comp.type != "component":
            raise ToolError(
                f"'{comp.name}' is not an Object. Use make_object "
                "first (or make_master), or add_linked_copy.")
        ref = self._model.add_instance(comp)
        for key, value in self._check_params(
                "reference", params.get("params")).items():
            self._model.set_param(ref, key, value)
        return {"instance": ref.id, "name": ref.name, "of": comp.name}

    def _t_make_master(self, params) -> dict:
        node = self._node(params.get("node_id"))
        ref = self._model.make_master(node)
        if ref is None:
            raise ToolError(f"'{node.name}' cannot become a master.")
        comp = next(c for c in self._model.root.children
                    if c.type == "component"
                    and c.name == ref.params["ref"])
        return {"master": comp.id, "name": comp.name, "object": comp.id,
                "linked_copy": ref.id,
                "note": "The piece is now a hidden Object (Object tab); "
                        "the Linked copy places it."}

    def _t_add_linked_copy(self, params) -> dict:
        master = self._node(params.get("node_id"))
        ref = self._model.instance_master(master)
        for key, value in self._check_params(
                "reference", params.get("params")).items():
            self._model.set_param(ref, key, value)
        return {"copy": ref.id, "name": ref.name, "of": master.name}

    def _t_attach_parts(self, params) -> dict:
        model = self._model
        node = self._node(params.get("node_id"))
        if params.get("detach"):
            mates.detach(model, node)
            return {"detached": node.name}
        parent_name = str(params.get("parent", ""))
        siblings = {p.name: p for p in mates._mate_siblings(node)}
        if parent_name not in siblings:
            raise ToolError(
                f"'{node.name}' cannot attach to {parent_name!r}: a "
                f"mate parent must be a sibling. It can attach to: "
                f"{', '.join(siblings) or '(nothing at this level)'}.")
        child_anchor = str(params.get("anchor", ""))
        parent_anchor = str(params.get("parent_anchor", ""))
        for part, name in ((node, child_anchor),
                           (siblings[parent_name], parent_anchor)):
            definition = mates.definition_of(model, part) or part
            if mates.find_anchor(definition, name, env=self._env(),
                                 fn=self._fn()) is None:
                raise ToolError(
                    f"'{part.name}' has no anchor {name!r} — call "
                    "list_anchors for its names.")
        kind = params.get("kind") or "coincident"
        align = params.get("align") or "opposed"
        if kind not in mates.KINDS:
            raise ToolError(f"Unknown mate kind {kind!r}: one of "
                            f"{', '.join(mates.KINDS)}.")
        if align not in mates.ALIGNS:
            raise ToolError(f"Unknown align {align!r}: opposed or same.")

        def number(key):
            value = params.get(key)
            return None if value is None else float(value)
        mates.attach(model, node, parent_name, child_anchor,
                     parent_anchor, float(params.get("offset", 0.0)),
                     float(params.get("spin", 0.0)), kind=kind,
                     align=align, angle=float(params.get("angle", 0.0)),
                     ratio=number("ratio"), min_offset=number("min_offset"),
                     max_offset=number("max_offset"))
        return {"attached": node.name, "to": parent_name,
                "placement": {k: node.params.get(k)
                              for k in model.PLACEMENT_KEYS}}

    def _t_insert_part(self, params) -> dict:
        from . import library
        part_id = str(params.get("part_id", ""))
        spec = library.PARTS.get(part_id)
        if spec is None:
            raise ToolError(
                f"No library part {part_id!r} — call list_parts.")
        sizes = spec.get("sizes") or {}
        size = params.get("size")
        if size and size not in sizes:
            match = [k for k in sizes if k.split(" ")[0] == size]
            if not match:
                raise ToolError(
                    f"{part_id} has no size {size!r}. It offers: "
                    f"{', '.join(sizes)}.")
            size = match[0]
        dims, size_key = {}, ""
        if sizes:
            keys = list(sizes)
            size_key = size or (keys[1] if len(keys) > 1 else keys[0])
            dims = dict(sizes[size_key])
            dims["_size"] = size_key
        dims.setdefault("port_length",
                        60.0 if sizes is library.CF_SIZES else 30.0)
        overrides = params.get("dims") or {}
        if not isinstance(overrides, dict):
            raise ToolError("'dims' must be an object of mm values.")
        dims.update(overrides)
        colors = spec.get("colors") or []
        if params.get("color"):
            want = str(params["color"]).strip().lower()
            match = [c for c in colors if c.lower() == want]
            if not match:
                raise ToolError(
                    f"{part_id} does not come in {params['color']!r}"
                    + (f". It offers: {', '.join(colors)}." if colors
                       else " — it has no colour choice."))
            dims["_color"] = match[0]
        note = library.prepare_document(self._model, part_id, dims)
        hook = library.insert_hook(part_id)
        if hook is not None:
            # builds itself as several Objects (a finished house, then
            # editable with build_house / the House Builder)
            nodes = hook(self._model, dims)
            for comp in nodes:
                for key in ("x", "y", "z", "rz"):
                    if params.get(key) is not None:
                        comp.params[key] = comp.params.get(key, 0.0) + \
                            float(params[key]) if key == "z" \
                            else float(params[key])
                self._model.node_changed.emit(comp)
            return {"inserted": [c.id for c in nodes],
                    "names": [c.name for c in nodes], "part_id": part_id,
                    "size": size_key or None,
                    "note": spec.get("insert_note") or
                            "Built as a House Builder house: one Object "
                            "per floor; build_house (or the House Builder "
                            "with it selected) edits it."}
        node = library.build_part(part_id, dims)
        # a science part (nm) names its own build — "Armchair nanotube
        # (10, 10)" — and a size word in front would contradict overrides
        label = size_key.split(" ")[0] if size_key and \
            spec.get("unit") != "nm" else ""
        if label and not node.name.startswith(label):
            node.name = f"{label} {node.name}"
        self._model.root.add(node)
        self._model.structure_changed.emit()
        # A library part is a finished part: one opaque row in the Main
        # assembly, its construction editable in the Object tab.
        comp = self._model.enclose_as_part(node, params.get("name", ""))
        placed = False
        for key in ("x", "y", "z", "rz"):
            if params.get(key) is not None:
                try:
                    comp.params[key] = float(params[key])
                except (TypeError, ValueError):
                    raise ToolError(f"'{key}' must be a number.")
                placed = True
        if placed:
            self._model.node_changed.emit(comp)
        result = {"inserted": comp.id, "name": comp.name,
                  "part_id": part_id, "size": size_key or None}
        if note:
            result["note"] = note
        return result

    def _t_select_nodes(self, params) -> dict:
        nodes = self._nodes(params["ids"]) if params.get("ids") else []
        tree = self._w.builder.active_tree()
        tree.select_nodes(nodes)
        return {"selected": [n.id for n in nodes]}

    # ── Document ────────────────────────────────────────────────

    def _t_play_motion(self, params) -> dict:
        """The body lives in motion_play (this module is past its
        size)."""
        from . import motion_play
        try:
            return motion_play.play(self._w, params)
        except (motion_play.MotionError, TypeError, ValueError) as exc:
            raise ToolError(str(exc))

    def _t_set_render_options(self, params) -> dict:
        model, win = self._model, self._w
        if "segments" in params or "segments_on" in params:
            on = bool(params.get("segments_on", model.global_fn_on))
            value = params.get("segments")
            model.set_global_fn(on, None if value is None
                                else max(3, min(512, int(value))))
        if params.get("unit") is not None:
            try:
                model.set_unit(params["unit"])
            except ValueError as exc:
                raise ToolError(str(exc))
        if params.get("real_scale") is not None:
            try:
                model.set_real_scale(params["real_scale"])
            except (TypeError, ValueError) as exc:
                raise ToolError(str(exc))
        if params.get("orientation"):
            name = params["orientation"]
            if name not in ORIENTATIONS:
                raise ToolError(f"Unknown orientation {name!r}.")
            win.view3d.set_view(name)
        elif params.get("fit"):
            win.view3d.fit()
        if params.get("projection"):
            name = params["projection"]
            if name not in PROJECTIONS:
                raise ToolError(f"Unknown projection {name!r}. Choose "
                                f"one of: {', '.join(PROJECTIONS)}.")
            win.set_projection(name)
        if params.get("stage") is not None:
            win.view3d.set_stage(bool(params["stage"]))
        heat = None
        if any(params.get(k) is not None for k in
               ("heatmap", "heat_min_wall", "heat_overhang",
                "heat_draft")):
            from . import heatmap_ui
            try:
                heat = heatmap_ui.set_heatmap(
                    win, params.get("heatmap"), params.get("heat_min_wall"),
                    params.get("heat_overhang"), params.get("heat_draft"))
            except (TypeError, ValueError) as exc:
                raise ToolError(str(exc))
        if params.get("cavity") is not None:
            win.view3d.set_cavity(bool(params["cavity"]))
        if params.get("edges") is not None:
            win.view3d.set_edges(bool(params["edges"]))
        if params.get("time") is not None:
            from . import animate
            animate.set_time(win, float(params["time"]))
        if params.get("smooth") is not None:
            win.view3d.set_smooth(bool(params["smooth"]))
        if params.get("overlay") is not None:
            win.view3d.set_overlay(bool(params["overlay"]))
        if params.get("scale_bar") is not None:
            win.view3d.set_scale_bar(bool(params["scale_bar"]))
        if params.get("grid") is not None:
            win.view3d.set_grid(bool(params["grid"]))
        if params.get("opengl") is not None:
            win.view3d.set_hardware(bool(params["opengl"]))
        if params.get("explode") is not None or params.get("explode_mode"):
            amount = params.get("explode")
            win.set_explode(
                None if amount is None else float(amount) > 0,
                amount=None if not amount else float(amount),
                mode=params.get("explode_mode"))
        axis = params.get("cut")
        if axis is not None or params.get("cut_position") is not None \
                or params.get("cut_flip") is not None:
            if axis == "none":
                win.view3d.set_cut(enabled=False)
            else:
                if axis is not None and axis not in ("x", "y", "z"):
                    raise ToolError("cut must be x, y, z or none.")
                position = params.get("cut_position")
                if position is not None:
                    position = self._number(params, "cut_position")
                    if not 0.0 <= position <= 1.0:
                        raise ToolError("cut_position runs from 0 to 1.")
                win.view3d.set_cut(axis=axis, position=position,
                                   flip=params.get("cut_flip"))
        from . import heatmap_ui
        heat_state = dict(heatmap_ui.state(win))
        stats = heat if heat is not None else getattr(win, "_heat_stats", {})
        if stats:
            heat_state.update({k: (round(v, 4) if isinstance(v, float)
                                   else v) for k, v in stats.items()})
        return {"exploded": win.explode_state(),
                "heatmap": heat_state,
                "unit": self._unit(),
                "real_scale": model.real_scale,
                "scale": units.ratio_text(model.real_scale),
                "global_segments": int(model.global_fn),
                "global_segments_on": bool(model.global_fn_on),
                "projection": win.view3d.projection,
                "stage": bool(win.view3d.stage),
                "opengl": bool(win.view3d.hardware),
                "cavity": bool(win.view3d.cavity),
                "edges": bool(win.view3d.edges),
                "smooth": bool(win.view3d.smooth),
                "overlay": bool(win.view3d.overlay),
                "scale_bar": bool(win.view3d.scale_bar),
                "grid": bool(win.view3d.grid),
                "cut": win.view3d.cut_state()}

    def _guard_unsaved(self, params, tool: str):
        if self._w._dirty and not params.get("discard_unsaved_changes"):
            raise ToolError(
                "The user has unsaved changes. Offer to save_document "
                f"first; pass discard_unsaved_changes: true to {tool} "
                "only if they say to throw the work away.")

    def _fresh(self, path=None, dirty=False):
        """Settle the window after the document was replaced."""
        win = self._w
        win._path = path
        win._dirty = dirty
        win._fitted = False
        win.view3d.user_moved = False
        win.view3d.fit()
        win._update_title()

    def _references(self) -> list:
        return [{"index": i, "path": r.get("path"),
                 "plane": r.get("plane"),
                 "at": [r.get("x"), r.get("y")],
                 "size": [r.get("width"), r.get("height")],
                 "offset": r.get("offset", 0.0),
                 "opacity": r.get("opacity")}
                for i, r in enumerate(self._model.reference_images)]

    def _t_set_reference_image(self, params) -> dict:
        from . import refimage
        model = self._model
        if params.get("clear"):
            model.clear_reference_images()
        elif params.get("remove") is not None:
            index = int(params["remove"])
            if not 0 <= index < len(model.reference_images):
                raise ToolError(f"No reference image {index}; there are "
                                f"{len(model.reference_images)}.")
            model.remove_reference_image(index)
        else:
            path = str(params.get("path") or "")
            if not path:
                raise ToolError("Pass 'path' (an image file), or clear / "
                                "remove.")
            ratio = refimage.aspect(path)
            if ratio is None:
                raise ToolError(f"Could not read an image at {path!r}.")
            plane = {"Top": "Top (XY)", "Front": "Front (XZ)",
                     "Side": "Side (YZ)"}.get(params.get("plane") or "Top")
            if plane is None:
                raise ToolError("'plane' must be Top, Front or Side.")
            width = self._number(params, "width", True) or 100.0
            height = width * ratio
            x, y = self._number(params, "x"), self._number(params, "y")
            opacity = self._number(params, "opacity")
            model.add_reference_image(dict(
                path=path, plane=plane,
                x=-width / 2 if x is None else x,
                y=-height / 2 if y is None else y,
                width=width, height=height,
                offset=self._number(params, "offset") or 0.0,
                opacity=0.5 if opacity is None
                else min(max(opacity, 0.0), 1.0),
                visible=True))
        return {"reference_images": self._references()}

    def _t_load_example(self, params) -> dict:
        from . import examples
        name = str(params.get("name", ""))
        match = [b for n, _c, b in examples.EXAMPLES if n == name]
        if not match:
            raise ToolError(
                f"No example called {name!r} — call list_examples.")
        self._guard_unsaved(params, "load_example")
        examples.load_example(self._model, match[0])
        self._fresh(dirty=True)
        return {"loaded": name,
                "nodes": len(list(self._model.root.walk())) - 1}

    def _t_new_document(self, params) -> dict:
        self._guard_unsaved(params, "new_document")
        self._model.clear()
        self._fresh()
        return self._t_get_document_info({})

    def _t_open_document(self, params) -> dict:
        from . import scadparse
        from .engine import MESH_EXTS
        from . import cadexchange
        path = Path(str(params.get("path", ""))).expanduser()
        if not path.is_file():
            raise ToolError(f"No such file: {path}")
        self._guard_unsaved(params, "open_document")
        suffix = path.suffix.lower()
        extra = {}
        if suffix == ".kcad":
            document.load_kcad(self._model, str(path))
            self._fresh(path=str(path))
        elif suffix in (".scad", ".csg"):
            warnings = scadparse.import_scad(self._model, str(path))
            self._model.enclose_import_as_part(path.stem)
            # An import has no .kcad of its own yet, so it is unsaved
            # work from here on — the same as the File menu's import.
            self._fresh(dirty=True)
            if warnings:
                extra["warnings"] = warnings[:12]
            if not mesh.tessellate(self._model.root, fn=self._fn()):
                extra["note"] = (
                    "The program imported empty — it is probably built "
                    "on custom modules or functions outside the "
                    "importable subset. Add it as a scad_raw node "
                    "instead so the OpenSCAD engine still renders it.")
        elif suffix in MESH_EXTS:
            self._w._import_mesh_path(str(path))
            self._fresh(dirty=True)
        elif suffix in (".svg", ".dxf"):
            self._w._import_drawing_path(str(path))
            self._fresh(dirty=True)
        elif suffix == ".dat":
            self._w._import_surface_path(str(path))
            self._fresh(dirty=True)
        elif suffix in cadexchange.CAD_EXTS:
            problem = cadexchange.missing(suffix)
            if problem:
                raise ToolError(problem)
            quality = str(params.get("quality") or "Normal")
            if quality not in cadexchange.QUALITY:
                raise ToolError("quality must be Draft, Normal or Fine.")
            try:
                parts = cadexchange.read_parts(str(path), quality)
            except (ValueError, OSError, RuntimeError) as exc:
                raise ToolError(str(exc))
            from . import cadexchange_ui
            node = cadexchange_ui.place_parts(
                self._model, str(path), parts, units.to_mm(self._unit()))
            self._fresh(dirty=True)
            extra["object_id"] = node.id
            extra["parts"] = [{"name": p.name, "color": p.color,
                               "triangles": len(p.tris)} for p in parts]
        else:
            raise ToolError(
                f"{suffix or 'That file'} is not something KherveCAD "
                "opens — use .kcad, .scad, .csg, a 2D drawing (.svg, "
                ".dxf), a height map (.dat), a CAD file (.step, .iges, "
                f".3dm, .brep) or a mesh "
                f"({', '.join(MESH_EXTS)}).")
        self._w._add_recent(str(path))
        info = self._t_get_document_info({})
        info["opened"] = str(path)
        info.update(extra)
        return info

    def _t_save_document(self, params) -> dict:
        path = params.get("path") or self._w._path
        if not path:
            raise ToolError(
                "This document has never been saved, so there is "
                "nowhere to save it. Pass an absolute path ending in "
                ".kcad.")
        path = str(Path(str(path)).expanduser())
        if not path.lower().endswith(".kcad"):
            raise ToolError("Save as .kcad. For a program or a mesh use "
                            "export_document.")
        flush = getattr(self._w, "_flush_blueprint", None)
        if flush is not None:
            flush()                 # an edit waiting in the Blueprint
        document.save_kcad(self._model, path)
        self._w._path = path
        self._w._dirty = False
        self._w._add_recent(path)
        self._w._update_title()
        result = {"saved": path}
        from .user_library_dialog import design_saved
        kept = design_saved(self._w, path)
        if kept:
            result["my_library"] = kept
        return result

    def _t_export_movie(self, params) -> dict:
        from . import movie
        try:
            return movie.export_request(self._w, params)
        except movie.MovieError as exc:
            raise ToolError(str(exc))

    def _t_export_drawing(self, params) -> dict:
        from . import drawing, drawing_dialog, drawing_export
        path = str(Path(str(params.get("path", ""))).expanduser())
        suffix = Path(path).suffix.lower()
        if suffix not in drawing_export.WRITERS:
            raise ToolError("A drawing is written as .pdf, .svg, .dxf or "
                            ".png.")
        saved = self._model.drawing
        if params.get("blueprint", True) is not False and saved \
                and saved.get("views"):
            # the user's own sheet: their dimensions and title block
            from . import blueprint
            scene = blueprint.export_saved(self._w, path)
            return {"exported": path, "format": suffix[1:],
                    "blueprint": True, "sheet": scene.sheet,
                    "scale": drawing.scale_label(scene.scale),
                    "views": [v.label_text() for v in scene.views.values()],
                    "annotations": len(scene.notes())}
        views = tuple(params.get("views") or drawing_dialog.STANDARD)
        if any(str(v).lower() in ("current", "current view")
               for v in views):
            from . import make2d
            try:
                make2d.make(self._w, path, hidden=bool(
                    params.get("hidden_lines", False)),
                    sheet=params.get("sheet") or "A4")
            except (ValueError, OSError) as exc:
                raise ToolError(str(exc))
            return {"exported": path, "format": suffix[1:],
                    "views": ["Current view (Make2D)"]}
        bad = [v for v in views if v not in drawing.VIEWS]
        if bad:
            raise ToolError(f"Unknown view(s) {', '.join(bad)}: choose "
                            f"from {', '.join(drawing.VIEWS)}.")
        sheet = params.get("sheet") or "A4"
        if sheet not in drawing.SHEETS:
            raise ToolError(f"Unknown sheet {sheet!r}: "
                            f"{', '.join(drawing.SHEETS)}.")
        section_axis = params.get("section") or None
        if section_axis and section_axis not in ("x", "y", "z"):
            raise ToolError("section must be x, y or z.")
        try:
            lay = drawing_dialog.make_layout(
                self._w, sheet=sheet, views=views,
                dimensions=params.get("dimensions", True) is not False,
                hidden_lines=params.get("hidden_lines", True) is not False,
                section_axis=section_axis, title=params.get("title"),
                scale=(float(params["scale"]) if params.get("scale")
                       else None))
        except ValueError as exc:
            raise ToolError(str(exc))
        drawing_export.export(lay, path)
        return {"exported": path, "format": suffix[1:],
                "sheet": lay["sheet"], "scale": lay["scale_label"],
                "views": [v["name"] for v in lay["views"]]}

    def _t_export_document(self, params) -> dict:
        from .engine import write_stl
        path = str(Path(str(params.get("path", ""))).expanduser())
        suffix = Path(path).suffix.lower()
        if suffix == ".scad":
            document.export_scad(self._model, path)
            return {"exported": path, "format": "scad"}
        if suffix == ".png":
            from . import pngexport
            # the picture should show holes cut, as render_view does
            complete = self._wait_for_render(_DEFAULT_WAIT_S)
            try:
                result = pngexport.export_request(
                    self._w.view3d, path,
                    view=params.get("view") or "current",
                    width=params.get("width"),
                    height=params.get("height"),
                    transparent=bool(params.get("transparent")),
                    exploded=bool(params.get("exploded")),
                    window=self._w)
            except (ValueError, OSError) as exc:
                raise ToolError(str(exc))
            result["render_complete"] = complete
            return result
        from . import cadexchange
        if suffix in cadexchange.CAD_EXTS:
            try:
                report = cadexchange.export_model(
                    self._model.root, path, fn=self._fn(),
                    unit_mm=units.to_mm(self._unit()))
            except (ValueError, OSError, RuntimeError) as exc:
                raise ToolError(str(exc))
            fmt = cadexchange.FORMAT_NAMES[suffix]
            return {"exported": path, "format": fmt,
                    "parts": report.parts,
                    "exact_shapes": report.exact,
                    "faceted_shapes": report.faceted,
                    "faceted_parts": sorted(set(report.faceted_names)),
                    "note": report.sentence(fmt)}
        if suffix not in (".stl", ".3mf", ".off", ".amf", ".csg", ".svg",
                          ".dxf"):
            raise ToolError(
                "Export path must end in .scad, .stl, .3mf, .off, .amf, "
                ".csg, .png, .step, .iges, .brep, .3dm, or .svg / .dxf "
                "for a 2D document.")
        if suffix != ".stl" and not self._w.engine.available:
            raise ToolError(
                f"{suffix[1:].upper()} is written by OpenSCAD and it was "
                "not found. Export .stl, or point the app at OpenSCAD "
                "(Edit > Locate OpenSCAD).")
        unit = self._unit()
        factor = units.to_mm(unit) if params.get("scale_to_mm") else 1.0

        def sized(result):
            """Scale the written file to mm if asked, and say which."""
            if factor != 1.0:
                units.scale_mesh_file(path, factor)
            if unit != "mm":
                result["unit"] = unit
                result["scale"] = factor
                result["units_note"] = (
                    f"Scaled to millimetres (×{factor:g}): the file is "
                    "real size." if factor != 1.0 else
                    units.export_note(unit) + " Written 1:1; pass "
                    "scale_to_mm: true for real size.")
            return result

        if self._w.engine.available:
            error = self._w.engine.export_mesh(self._model.to_scad(),
                                               path)
            if error:
                raise ToolError(f"OpenSCAD export failed:\n{error}")
            return sized({"exported": path, "format": suffix[1:],
                          "exact": True})
        if suffix == ".3mf":
            raise ToolError(
                "3MF is written by OpenSCAD and it was not found. "
                "Export .stl, or point the app at OpenSCAD "
                "(Edit > Locate OpenSCAD).")
        write_stl(mesh.tessellate(self._model.root, fn=self._fn()), path)
        return sized({
            "exported": path, "format": "stl", "exact": False,
            "warning": (
                "Exported with the built-in tessellator because "
                "OpenSCAD was not found. Booleans are APPROXIMATED — a "
                "difference() keeps its first operand and the holes are "
                "not cut. Do not send this to a printer; install "
                "OpenSCAD and export again."
                if mesh.approximates(self._model.root) else
                "Exported with the built-in tessellator (OpenSCAD not "
                "found). Every boolean in it was cut exactly (Manifold), "
                "so the geometry is faithful."),
        })

    def _t_publish_to_printables(self, params) -> dict:
        from . import printables
        title = str(params.get("title", "")).strip()
        if not title:
            raise ToolError("A title is required — it names the "
                            "listing and every file in the bundle.")
        folder = params.get("folder")
        if not folder:
            base = (Path(self._w._path).parent if self._w._path
                    else Path.home() / "Documents")
            folder = base / f"{printables.slug(title)}-printables"
        formats = tuple(params.get("formats") or FORMATS)
        views = tuple(params.get("views") or DEFAULT_VIEWS)
        unknown = [v for v in views if v not in STILL_VIEWS]
        if unknown:
            raise ToolError(
                f"Unknown view(s) {', '.join(unknown)}. Choose from: "
                f"{', '.join(STILL_VIEWS)}.")
        bad = [f for f in formats if f not in FORMATS]
        if bad:
            raise ToolError(
                f"Unknown format(s) {', '.join(bad)}. Choose from: "
                f"{', '.join(FORMATS)}.")
        category = params.get("category") or DEFAULT_CATEGORY
        if category not in CATEGORIES:
            raise ToolError(
                f"Unknown category {category!r}. Choose from: "
                f"{', '.join(CATEGORIES)}.")
        origin = params.get("origin") or DEFAULT_ORIGIN
        if origin not in ORIGINS:
            raise ToolError(
                f"Unknown origin {origin!r}. Choose from: "
                f"{', '.join(ORIGINS)}.")
        bundle = printables.build_bundle(
            self._w, folder, title=title,
            description=str(params.get("description", "")),
            tags=params.get("tags") or [],
            license=str(params.get("license") or DEFAULT_LICENSE),
            formats=formats, views=views,
            summary=str(params.get("summary", "")),
            category=category, origin=origin,
            exploded=params.get("exploded"))
        if params.get("open_browser"):
            printables.reveal(bundle["folder"])
            printables.open_upload_page()
        return {
            "folder": bundle["folder"],
            "files": [Path(f).name for f in bundle["files"]],
            "images": [Path(f).name for f in bundle["images"]],
            "summary": bundle["summary"],
            "category": bundle["category"],
            "warnings": bundle["warnings"],
            "published": False,
            "next_step": (
                "Nothing has been uploaded. Printables has no upload "
                "API, so the user finishes it: open "
                f"{printables.UPLOAD_URL} while signed in, drag in the "
                "files from the folder above, paste "
                "description.txt, and copy the remaining form fields "
                "from upload-form.txt. Tell them that, and do not "
                "describe the model as published."),
        }

    # ── Fillet ──────────────────────────────────────────────────

    def _local_tris(self, node):
        """The node's solid in its own frame (a fillet's children)."""
        from . import bake
        env = bake._codegen_env(node)
        fn = self._model.effective_fn()
        mesh._set_fn(fn)
        try:
            if node.type == "fillet":
                return [t for t, _c, _s in mesh._children_mesh(
                    node, env, None, frozenset(), False)]
            return mesh.tessellate(node, env=env, fn=fn)
        finally:
            mesh._set_fn(None)

    def _t_list_edges(self, params) -> dict:
        from . import fillet
        node = self._node(params.get("node_id"))
        try:
            min_angle = float(params.get("min_angle", fillet.MIN_ANGLE))
        except (TypeError, ValueError):
            raise ToolError("min_angle must be a number of degrees.")
        tris = self._local_tris(node)
        if not tris:
            raise ToolError(f"{node.name} has no solid to take edges from.")
        chains = fillet.chains(tris, min_angle)
        for i, c in enumerate(chains):
            c["index"] = i
        return {"node": node.id, "name": node.name, "edges": chains,
                "approximate": mesh.approximates(node),
                "note": ("Edges come from the built-in mesh: a union of "
                         "overlapping shapes has no edge where they "
                         "meet, and a difference's hole has none — only "
                         "edges a single shape owns are listed.")}

    def _t_fillet_edges(self, params) -> dict:
        from . import fillet
        node = self._node(params.get("node_id"))
        if node.type == "fillet":
            target = node
        elif node.parent is not None and node.parent.type == "fillet":
            target = node.parent
        else:
            if node.parent is None:
                raise ToolError("The document root cannot be filleted.")
            target = self._model.wrap_nodes([node], "fillet")
        seeds = []
        for row in params.get("edges") or []:
            try:
                seed = [float(v) for v in row]
            except (TypeError, ValueError):
                seed = []
            if len(seed) != 6:
                raise ToolError("Each edge is 6 numbers: x1 y1 z1 x2 y2 z2.")
            seeds.append([round(v, 4) for v in seed])
        indices = params.get("chains") or []
        if indices:
            chains = fillet.chains(self._local_tris(target))
            for i in indices:
                if not isinstance(i, int) or not 0 <= i < len(chains):
                    raise ToolError(
                        f"chain index {i!r} is out of range (0-"
                        f"{len(chains) - 1}); call list_edges first.")
                seeds.append(chains[i]["seed"])
        have = [list(r) for r in (target.params.get("edges") or [])]
        for s in seeds:
            if not any(all(abs(a - b) < 1e-3 for a, b in zip(s, h))
                       for h in have):
                have.append(s)
        target.params["edges"] = have
        if params.get("radius") is not None:
            target.params["radius"] = float(params["radius"])
        if params.get("kind") in fillet.KINDS:
            target.params["kind"] = params["kind"]
        if params.get("detail") is not None:
            target.params["detail"] = max(1, int(params["detail"]))
        self._model.node_changed.emit(target)
        errors = validate(self._model.root)
        out = {"fillet": target.id, "name": target.name,
               "edges": len(have), "radius": target.params["radius"],
               "kind": target.params["kind"]}
        if target.id in errors:
            out["error"] = errors[target.id]
        out["note"] = ("The rounding shows in the exact OpenSCAD render "
                       "— call render_view after a moment; the built-in "
                       "preview cannot cut a convex edge.")
        return out

    def _t_mesh_from_photo(self, params) -> dict:
        from . import photo3d, photo3d_dialog
        image = Path(str(params.get("image_path") or "")).expanduser()
        if not image.is_file():
            raise ToolError(f"No such picture: {image}")
        backend = str(params.get("backend") or "tripo")
        if backend not in photo3d.BACKENDS:
            raise ToolError(f"'backend' is one of "
                            f"{', '.join(photo3d.BACKENDS)}.")
        size = self._number(params, "size_mm", True) or 100.0
        key = str(params.get("api_key") or "") or \
            photo3d_dialog.get_key(backend)
        command = str(params.get("command") or "") or \
            photo3d_dialog.get_command()
        if backend != "local" and not key:
            raise ToolError(f"No API key for {backend}: the user sets it "
                            "in AI \u25b8 Mesh from Photo, or pass api_key.")
        if backend == "local" and not command:
            raise ToolError("No local command configured: pass 'command' "
                            "with {image} and {output}, or set it in "
                            "AI \u25b8 Mesh from Photo.")
        try:
            stl = photo3d_dialog.run_blocking(self._w, str(image), backend,
                                              key, command, size)
        except photo3d.Photo3DError as exc:
            raise ToolError(f"Generation failed: {exc}")
        before = {n.id for n in self._model.root.children}
        self._w._import_mesh_path(stl)
        part = next((n for n in self._model.root.children
                     if n.id not in before), None)
        if part is not None and params.get("name"):
            self._model.rename(part, str(params["name"]))
        out = {"imported": stl, "backend": backend, "size_mm": size,
               "part": part.id if part is not None else None,
               "name": part.name if part is not None else None,
               "note": ("One view gives a plausible surface — the far "
                        "side is guessed. set_reference_image with the "
                        "same photo, then sculpt_stroke where "
                        "render_view overlay_reference disagrees.")}
        return out

    # ── faces: landmarks and fitting ────────────────────────────

    def _human_node(self, node):
        if node.type == "human":
            return node
        for n in node.walk():
            if n.type == "human":
                return n
        raise ToolError(f"{node.name} holds no human figure.")

    def _human_kwargs(self, node):
        from . import human
        p, env = node.params, self._env()
        return dict(gender=mesh.rv(p.get("gender", 0.0), env, 0.0),
                    age=mesh.rv(p.get("age", 0.0), env, 0.0),
                    weight=mesh.rv(p.get("weight", 0.0), env, 0.0),
                    height=mesh.rv(p.get("height", 0.0), env, 0.0),
                    stature=mesh.rv(p.get("stature", 1700.0), env, 1700.0),
                    targets=[list(r) for r in (p.get("targets") or [])],
                    warp=[[mesh.rv(v, env) for v in r]
                          for r in (p.get("warp") or [])
                          if isinstance(r, list) and len(r) == 6],
                    warp_radius=mesh.rv(p.get("warp_radius", 45.0), env,
                                        human.DEFAULT_WARP_RADIUS))

    def _reference_pixels(self, world):
        """For each reference image, the pixel where *world* projects."""
        from . import paint
        out = []
        for i, ref in enumerate(self._model.reference_images):
            u, v, _n = paint.PLANES.get(ref.get("plane"),
                                       paint.PLANES[paint.DEFAULT_PLANE])
            picture = paint.load(str(ref.get("path", "")))
            if picture is None:
                out.append({"image": i, "px": None, "py": None})
                continue
            w, h = float(ref.get("width", 100.0)), float(ref.get("height", 100.0))
            px = (world[u] - float(ref.get("x", 0.0))) / w * picture.width
            py = (1.0 - (world[v] - float(ref.get("y", 0.0))) / h) * picture.height
            out.append({"image": i, "px": round(px, 1), "py": round(py, 1)})
        return out

    def _t_face_landmarks(self, params) -> dict:
        from . import human
        node = self._human_node(self._node(params.get("node_id")))
        kw = self._human_kwargs(node)
        m = mesh.ancestor_matrix(node, self._env())
        out = []
        for name, local in human.landmark_points(**kw).items():
            world = mesh.mat_apply(m, local)
            out.append({"name": name, "local": [round(v, 2) for v in local],
                        "world": [round(v, 2) for v in world],
                        "images": self._reference_pixels(world)})
        return {"node": node.id, "landmarks": out,
                "sliders": sorted(human.sliders()),
                "targets": kw["targets"], "warp_rows": len(kw["warp"]),
                "references": len(self._model.reference_images)}

    def _observations(self, rows):
        """[(name, plane, u_mm, v_mm)] from the tool's landmark rows."""
        from . import human, paint
        names = human.landmarks()
        refs = self._model.reference_images
        obs = []
        for row in rows or []:
            if not isinstance(row, dict) or not row.get("name"):
                raise ToolError("Each landmark is {name, image, px, py} "
                                "or {name, plane, u, v}.")
            name = str(row["name"])
            if name not in names:
                raise ToolError(f"Unknown landmark {name!r}; "
                                f"face_landmarks lists them.")
            if row.get("plane") is not None:
                plane = str(row["plane"])
                if plane not in paint.PLANES:
                    raise ToolError("'plane' is Top (XY), Front (XZ) or "
                                    "Side (YZ).")
                u, v = self._number(row, "u"), self._number(row, "v")
                if u is None or v is None:
                    raise ToolError(f"{name}: give 'u' and 'v' in mm.")
                obs.append((name, plane, u, v))
                continue
            index = int(row.get("image", 0) or 0)
            if not 0 <= index < len(refs):
                raise ToolError(f"No reference image {index}; "
                                f"set_reference_image first.")
            ref = refs[index]
            picture = paint.load(str(ref.get("path", "")))
            if picture is None:
                raise ToolError(f"Reference image {index} cannot be read.")
            px, py = self._number(row, "px"), self._number(row, "py")
            if px is None or py is None:
                raise ToolError(f"{name}: give 'px' and 'py'.")
            u = float(ref.get("x", 0.0)) + px / picture.width * float(
                ref.get("width", 100.0))
            v = float(ref.get("y", 0.0)) + (1.0 - py / picture.height) * float(
                ref.get("height", 100.0))
            obs.append((name, str(ref.get("plane", paint.DEFAULT_PLANE)),
                        u, v))
        if not obs:
            raise ToolError("Give at least one landmark.")
        return obs

    def _t_fit_face(self, params) -> dict:
        from . import facefit, human, paint
        node = self._human_node(self._node(params.get("node_id")))
        obs = self._observations(params.get("landmarks"))
        table = human.sliders()
        sliders = params.get("sliders") or list(facefit.DEFAULT_SLIDERS)
        bad = [s for s in sliders if s not in table]
        if bad:
            raise ToolError(f"No face slider named {bad[0]!r}.")
        lam = self._number(params, "stiffness")
        lam = 0.3 if lam is None else max(lam, 1e-4)
        kw = self._human_kwargs(node)
        base_targets = {str(r[0]): float(r[1]) for r in kw["targets"]
                        if isinstance(r, list) and len(r) == 2}
        base_pose = {str(r[0]): [float(v) for v in r[1:4]]
                     for r in (node.params.get("pose") or [])
                     if isinstance(r, list) and len(r) == 4}
        m = mesh.ancestor_matrix(node, self._env())
        # the head's turn, tilt and nod are unknowns too: a photo is
        # rarely square on, and a wrong angle would be forced into the
        # face instead
        HEAD = {"head_turn": ("head", 2), "head_tilt": ("head", 1),
                "head_nod": ("head", 0)}
        fit_head = bool(params.get("fit_head", True))
        names = list(sliders) + (list(HEAD) if fit_head else [])
        bounds = {}
        for name in sliders:
            pairs = table[name]
            bounds[name] = (0.0, 1.0) if all(p[0] is None for p in pairs) \
                else (-1.0, 1.0)
        for name in HEAD:
            bounds[name] = (-45.0, 45.0)
        delta = {name: 5.0 for name in HEAD}

        def merged(weights):
            t = dict(base_targets)
            for k, v in weights.items():
                if k in HEAD:
                    continue
                lo, hi = bounds.get(k, (-1.0, 1.0))
                t[k] = max(lo, min(hi, t.get(k, 0.0) + v))
            return [[k, v] for k, v in t.items() if v]

        def posed(weights):
            rows = {k: list(v) for k, v in base_pose.items()}
            for k, v in weights.items():
                if k in HEAD:
                    bone, axis = HEAD[k]
                    rows.setdefault(bone, [0.0, 0.0, 0.0])[axis] += v
            return [[k] + v for k, v in rows.items() if any(v)]

        def project(weights, warp=None, rows=None):
            lm = human.landmark_points(**dict(
                kw, targets=merged(weights) if rows is None else rows,
                warp=warp, pose=posed(weights)))
            out = []
            for name, plane, u, v in obs:
                world = mesh.mat_apply(m, lm[name])
                a, b = paint.PLANES[plane][:2]
                out.extend((world[a] - u, world[b] - v))
            return out
        weights, before, after = facefit.fit(lambda w: project(w, None),
                                             names, lam, delta, bounds)
        targets = merged(weights)
        pose = posed(weights)
        head = {k: round(v, 2) for k, v in weights.items() if k in HEAD}
        weights = {k: v for k, v in weights.items() if k not in HEAD}
        kw = dict(kw, pose=pose)
        warp_rows = []
        if params.get("warp", True):
            lm = human.landmark_points(**dict(kw, targets=targets, warp=None))
            # the move each landmark still needs, in world, then local
            need = {}
            for name, plane, u, v in obs:
                world = mesh.mat_apply(m, lm[name])
                a, b = paint.PLANES[plane][:2]
                d = need.setdefault(name, [0.0, 0.0, 0.0])
                d[a], d[b] = u - world[a], v - world[b]
            inv = [[m[c][r] for c in range(3)] for r in range(3)]   # R^T
            errors = [(lm[name], mesh.mat_apply_dir(
                [row + [0.0] for row in inv], d)) for name, d in need.items()]
            warp_rows = facefit.residual_warp(errors)
        self._model.set_param(node, "targets", targets)
        self._model.set_param(node, "pose", pose)
        self._model.set_param(node, "warp", warp_rows)
        final = project({}, warp_rows, targets) if warp_rows else None
        kw2 = dict(self._human_kwargs(node), pose=pose)
        lm = human.landmark_points(**kw2)
        per = []
        for name, plane, u, v in obs:
            world = mesh.mat_apply(m, lm[name])
            a, b = paint.PLANES[plane][:2]
            per.append({"name": name, "error_mm": round(
                ((world[a] - u) ** 2 + (world[b] - v) ** 2) ** 0.5, 2)})
        return {"node": node.id, "sliders": weights, "targets": targets,
                "head": head, "pose": pose, "warp_rows": len(warp_rows),
                "rms_mm": {"before": round(before, 2),
                           "sliders": round(after, 2),
                           "warp": round(facefit._rms(final), 2)
                           if final is not None else round(after, 2)},
                "landmarks": per,
                "note": ("Sliders shape the whole face; the warp pins the "
                         "landmarks. render_view with overlay_reference "
                         "to compare, sculpt_stroke for the rest.")}

    def _t_sculpt_stroke(self, params) -> dict:
        from . import sculpt, sculpt_ui
        node = self._node(params.get("node_id"))
        if node.type == "sculpt":
            target = node
        elif node.parent is not None and node.parent.type == "sculpt":
            target = node.parent
        else:
            if node.parent is None:
                raise ToolError("The document root cannot be sculpted.")
            target = self._model.wrap_nodes([node], "sculpt")
        if params.get("mirror") is not None:
            if params["mirror"] not in sculpt.MIRRORS:
                raise ToolError("'mirror' is none, x, y or z.")
            target.params["mirror"] = params["mirror"]
        if params.get("detail") is not None:
            target.params["detail"] = max(0.0, float(params["detail"]))
        for key in ("noise", "noise_scale"):
            if params.get(key) is not None:
                target.params[key] = float(params[key])
        if params.get("seed") is not None:
            target.params["seed"] = int(params["seed"])
        specs = list(params.get("strokes") or [])
        if params.get("kind") is not None or params.get("at") is not None:
            specs.append({k: params.get(k) for k in
                          ("kind", "at", "radius", "strength", "direction",
                           "to")})
        if not specs:
            if any(params.get(k) is not None
                   for k in ("noise", "noise_scale", "seed")):
                self._model.node_changed.emit(target)
                return {"sculpt": target.id, "name": target.name,
                        "added": 0,
                        "strokes": len(target.params.get("strokes") or []),
                        "noise": target.params.get("noise", 0.0)}
            raise ToolError("Give a stroke (kind, at, radius, strength) "
                            "or a list in 'strokes'.")
        world, local = sculpt_ui.meshes(self._w, target)
        rows = [list(r) for r in (target.params.get("strokes") or [])]
        added = 0
        for spec in specs:
            if not isinstance(spec, dict):
                raise ToolError("Each stroke is {kind, at, radius, "
                                "strength, direction}.")
            kind = spec.get("kind", "inflate")
            if sculpt.kind_index(kind) < 0:
                raise ToolError(f"Unknown brush {kind!r}. Choose one of: "
                                f"{', '.join(sculpt.KINDS)}.")
            kind = sculpt.KINDS[sculpt.kind_index(kind)]
            at = self._vec3(spec, "at")
            if at is None:
                raise ToolError("Each stroke needs 'at' [x, y, z].")
            radius = self._number(spec, "radius", True) or 5.0
            strength = spec.get("strength", 1.0)
            try:
                strength = float(strength)
            except (TypeError, ValueError):
                raise ToolError("'strength' must be a number.")
            direction = self._vec3(spec, "direction")
            end = self._vec3(spec, "to")
            tip = None
            if kind in sculpt.LINES:
                if end is None and direction is None:
                    raise ToolError(f"A {kind} is a line: give 'to' "
                                    "[x, y, z], where it ends.")
                if end is not None:
                    direction = [end[k] - at[k] for k in range(3)]
            elif kind == "snake_hook" and end is not None:
                # pulled to a point: the pull is the whole way there
                direction = [end[k] - at[k] for k in range(3)]
                if spec.get("strength") is None:
                    strength = 1.0
            elif kind in ("grab", "elastic_grab") and end is not None:
                pull = [end[k] - at[k] for k in range(3)]
                length = sum(c * c for c in pull) ** 0.5
                direction = pull
                if spec.get("strength") is None:
                    strength = length
            elif kind == "pose":
                tip = self._vec3(spec, "tip")
                if tip is None:
                    raise ToolError("A pose turns a limb about the joint "
                                    "'at': give 'tip' [x, y, z], a point "
                                    "on the limb that moves, 'direction' "
                                    "the rotation axis and 'strength' "
                                    "the angle in degrees.")
            # a batch maps every stroke through the surface as it was:
            # re-baking after each one made 200 wrinkles take minutes
            row = sculpt_ui.stroke_row(kind, at, radius, strength,
                                       direction, world=world, local=local,
                                       tip=tip) \
                if world is not None else \
                sculpt_ui.stroke_row(kind, at, radius, strength, direction,
                                     tip=tip)
            if row is None:
                raise ToolError("That stroke could not be placed on the "
                                "surface.")
            rows.append(row)
            added += 1
        self._model.set_param(target, "strokes", rows)
        errors = validate(self._model.root)
        out = {"sculpt": target.id, "name": target.name, "added": added,
               "strokes": len(target.params.get("strokes") or []),
               "mirror": target.params.get("mirror", "none")}
        if target.id in errors:
            out["error"] = errors[target.id]
        out["note"] = ("Strokes are kept on the node in its own frame; "
                       "render_view to see the result, probe_surface for "
                       "the next one.")
        return out

    def _t_scatter_on_surface(self, params) -> dict:
        from . import creature_mcp
        try:
            return creature_mcp.scatter_on_surface(self._w, params)
        except creature_mcp.CreatureError as exc:
            raise ToolError(str(exc))

    def _t_rig_armature(self, params) -> dict:
        from . import creature_mcp
        try:
            return creature_mcp.rig_armature(self._w, params)
        except creature_mcp.CreatureError as exc:
            raise ToolError(str(exc))

    def _t_shape_key(self, params) -> dict:
        from . import creature_mcp
        try:
            return creature_mcp.shape_key(self._w, params)
        except creature_mcp.CreatureError as exc:
            raise ToolError(str(exc))

    def _t_grow_hair(self, params) -> dict:
        from . import creature_mcp
        try:
            return creature_mcp.grow_hair(self._w, params)
        except creature_mcp.CreatureError as exc:
            raise ToolError(str(exc))

    def _t_paint_stroke(self, params) -> dict:
        from . import creature_mcp
        try:
            return creature_mcp.paint_stroke(self._w, params)
        except creature_mcp.CreatureError as exc:
            raise ToolError(str(exc))

    def _t_exact_part(self, params) -> dict:
        from . import brep
        from .model import validate
        node = self._node(params.get("node_id"))
        exact = next((n for n in node.walk() if n.type == "brep"), None)
        if exact is None:
            try:
                exact = brep.make_exact(self._model, node)
            except ValueError as exc:
                raise ToolError(str(exc))
        for key in ("fillets", "chamfers"):
            rows = [] if params.get("clear") else \
                [list(r) for r in exact.params.get(key) or []]
            for row in params.get(key) or []:
                if len(row) < 4:
                    raise ToolError(f"{key} rows are [x, y, z, size]")
                rows.append(brep.to_local(exact, row[:3])
                            + [float(row[3])])
            if params.get(key) is not None or params.get("clear"):
                self._model.set_param(exact, key, rows)
        out = {"node_id": exact.id,
               "fillets": exact.params.get("fillets"),
               "chamfers": exact.params.get("chamfers")}
        problem = validate(self._model.root).get(exact.id)
        if problem:
            raise ToolError(problem)
        return out

    def _t_make_surface(self, params) -> dict:
        from . import curve_surface
        from .model import validate
        nodes = [self._node(i) for i in params.get("curve_ids") or []]
        kind = str(params.get("kind", "loft"))
        if kind not in curve_surface.KINDS:
            raise ToolError("kind must be one of "
                            + ", ".join(curve_surface.KINDS))
        try:
            surf = curve_surface.make_surface(self._model, nodes, kind)
        except ValueError as exc:
            raise ToolError(str(exc))
        for key in ("thickness", "ruled", "capped", "angle", "height"):
            if key in params:
                surf.params[key] = params[key]
        self._model.node_changed.emit(surf)
        out = {"created": surf.id, "kind": kind,
               "curves": [c.id for c in curve_surface.curves(surf)]}
        problem = validate(self._model.root).get(surf.id)
        if problem:
            out["problem"] = problem
        return out

    def _t_edit_mesh(self, params) -> dict:
        from . import meshedit_mcp
        node = self._node(params.get("node_id"))
        try:
            return meshedit_mcp.edit_mesh(self._w, node, params)
        except meshedit_mcp.EditError as exc:
            raise ToolError(str(exc))

    # ── Checking ────────────────────────────────────────────────

    _APPROX_NOTE = ("The mesh is the built-in preview, which only "
                    "approximates booleans (a difference shows its first "
                    "operand, holes uncut) until the exact render lands.")

    def _check_nodes(self, params):
        from . import analysis_dialog
        ids = params.get("node_ids")
        if ids:
            nodes = self._nodes(ids)
        else:
            nodes = [n for n in self._scope().children
                     if n.visible and n.type not in ("variables",
                                                     "masters", "assign")]
            if not nodes:
                raise ToolError("Nothing to check — the scope is empty.")
        tris, approx = analysis_dialog.part_tris(self._w, nodes)
        if not tris:
            raise ToolError("Those nodes have no geometry to check.")
        return nodes, tris, approx

    def _t_mass_properties(self, params) -> dict:
        from . import analysis
        nodes, tris, approx = self._check_nodes(params)
        material = str(params.get("material") or analysis.DEFAULT_MATERIAL)
        if material not in analysis.MATERIALS:
            raise ToolError("Unknown material. Choose one of: "
                            + ", ".join(analysis.MATERIALS))
        price = float(params.get("price_per_kg") or analysis.DEFAULT_PRICE)
        p = analysis.mass_properties(tris)
        unit = self._unit()
        volume_mm3 = units.mm(p["volume"], unit, 3)
        grams = analysis.mass(volume_mm3, material)
        out = {"nodes": [n.id for n in nodes], "unit": unit,
               "volume": round(p["volume"], 3),
               "area": round(p["area"], 3),
               "volume_mm3": self._in_mm(p["volume"], 3),
               "area_mm2": self._in_mm(p["area"], 2),
               "centre_of_mass": [round(v, 3) for v in p["centroid"]],
               "min": [round(v, 3) for v in p["min"]],
               "max": [round(v, 3) for v in p["max"]],
               "size": [round(v, 3) for v in p["size"]],
               "material": material,
               "mass_g": (round(grams, 2) if abs(grams) >= 0.01
                          else units.significant(grams)),
               "price_per_kg": price,
               "approximate": approx}
        if units.printable(unit):
            out["cost"] = round(analysis.cost(grams, price), 2)
            out["print_time_h_rough"] = round(
                analysis.print_time(volume_mm3), 2)
        else:
            out["cost"] = out["print_time_h_rough"] = None
            out["units_warning"] = (
                f"The document is in {units.name(unit)}: mass is at true "
                "size, but cost and print time are not estimated — no "
                "printer works at that scale 1:1.")
        if approx:
            out["note"] = self._APPROX_NOTE
        return out

    def _t_check_printability(self, params) -> dict:
        from . import analysis
        nodes, tris, approx = self._check_nodes(params)
        report = analysis.print_check(
            tris,
            overhang_deg=float(params.get("overhang_deg")
                               or analysis.DEFAULT_OVERHANG),
            min_wall=float(params.get("min_wall")
                           or analysis.DEFAULT_MIN_WALL),
            unit=self._unit())
        out = {"nodes": [n.id for n in nodes], "summary": report["summary"],
               "checks": report["checks"], "unit": self._unit(),
               "overhang_fraction": round(report["overhang_fraction"], 4),
               "thinnest_wall_mm": self._in_mm(report["thinnest"]),
               "plate_area_mm2": self._in_mm(report["plate_area"], 2, 2),
               "height_mm": self._in_mm(report["height"]),
               "approximate": approx}
        if approx:
            out["note"] = self._APPROX_NOTE
        return out

    def _t_check_interference(self, params) -> dict:
        from . import analysis, analysis_dialog
        ids = params.get("node_ids")
        if ids:
            nodes = self._nodes(ids)
        else:
            nodes = [n for _name, n in analysis_dialog.assembly_parts(
                self._w)]
        if len(nodes) < 2:
            raise ToolError("Give at least two nodes (or have two "
                            "visible parts in the assembly).")
        parts = []
        approx = False
        for n in nodes:
            tris, a = analysis_dialog.part_tris(self._w, [n])
            approx = approx or a
            parts.append((n.name, tris))
        pairs = analysis.interference(parts)
        by_name = {n.name: n.id for n in nodes}
        for p in pairs:
            p["a_id"], p["b_id"] = by_name.get(p["a"]), by_name.get(p["b"])
        out = {"pairs": pairs,
               "overlapping": sum(1 for p in pairs if p["status"] != "clear"),
               "approximate": approx}
        if approx:
            out["note"] = self._APPROX_NOTE
        return out

