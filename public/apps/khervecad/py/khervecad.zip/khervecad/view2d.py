"""2D sketch view — draw, select, move and resize the 2D profiles.

Top-right frame of the main window: a QGraphicsView (Y axis up, like
CAD) showing every visible 2D shape in the tree. The shape tools draw
new objects by dragging; the select tool moves shapes and drags their
resize handles. Every edit writes straight back into the node params,
so the properties panel, code tab and 3D preview follow live.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from PyQt5 import sip
import math
from PyQt5.QtCore import QLineF, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt5.QtGui import (QBrush, QColor, QFont, QPainter, QPainterPath,
                         QPen, QPolygonF)
from PyQt5.QtWidgets import (QGraphicsEllipseItem, QGraphicsItem,
                             QGraphicsLineItem, QGraphicsPathItem,
                             QGraphicsPolygonItem, QGraphicsRectItem,
                             QGraphicsScene, QGraphicsView)

from . import expr, language, units
from .model import SHAPE_2D, SHAPE_3D, CadNode, DocumentModel

SELECT, LINE, RECT, CIRCLE, POLYGON, TEXT, MEASURE, DIMENSION = (
    "select", "line", "rect", "circle", "polygon", "text",
    "measure", "dimension")

#: click within this many pixels of a shape feature (corner, centre,
#: edge midpoint) to snap the measure/dimension tools onto it.
FEATURE_SNAP_PX = 12.0

#: segment cap for the projected part outlines — they are rebuilt on
#: every change, so the shape matters and the resolution does not.
OUTLINE_DETAIL = 14

#: the placement a part carries (and the isolated view zeroes).
_PLACEMENT = ("x", "y", "z", "rx", "ry", "rz")

#: axis colours, the same ones the 3D view's gizmo uses — so X is the
#: same red in both views and the sketch plane reads at a glance.
AXIS_COLORS = ("#d64545", "#3f9e4d", "#3a6fd8")     # X, Y, Z

#: assembly view planes: name -> (horizontal axis, vertical axis)
#: as indices into (x, y, z) and the translate-param keys they map to.
PLANES = {
    "Top (XY)": ((0, 1), ("x", "y")),
    "Front (XZ)": ((0, 2), ("x", "z")),
    "Side (YZ)": ((1, 2), ("y", "z")),
}

_SHAPE_PEN_W = 1.6
HANDLE_SIZE = 9.0
#: zoom range, px per mm — from a whole house or site plan (tens of
#: metres across) down to sub-millimetre detail
MIN_ZOOM, MAX_ZOOM = 0.001, 400.0


def _pen(color: str, width=_SHAPE_PEN_W) -> QPen:
    pen = QPen(QColor(color), width)
    pen.setCosmetic(True)
    return pen


def _fmt_len(value: float, unit: str = "mm") -> str:
    """A tidy length label in the document's unit: no trailing zeros
    (30 mm, 30.5 nm, 36.06 µm)."""
    return units.length(value, unit)


def _resize_cursor(ax: float, ay: float):
    """The directional resize cursor for a drag axis given in scene
    (Y-up) coordinates — ↔ / ↕ / the two diagonals — so a size handle
    shows which way it stretches, not the four-way move sign."""
    axx, ayy = abs(ax), abs(ay)
    if axx < 1e-9 and ayy < 1e-9:
        return Qt.SizeAllCursor
    if axx > 2.4 * ayy:                        # mostly horizontal ↔
        return Qt.SizeHorCursor
    if ayy > 2.4 * axx:                        # mostly vertical ↕
        return Qt.SizeVerCursor
    # diagonal: scene up-right / down-left is "/", the other is "\"
    return Qt.SizeBDiagCursor if (ax > 0) == (ay > 0) \
        else Qt.SizeFDiagCursor


def _point_seg_dist(p: QPointF, a: QPointF, b: QPointF) -> float:
    """Shortest distance from point *p* to segment *a*-*b*."""
    vx, vy = b.x() - a.x(), b.y() - a.y()
    wx, wy = p.x() - a.x(), p.y() - a.y()
    seg2 = vx * vx + vy * vy
    tval = 0.0 if seg2 < 1e-12 else (wx * vx + wy * vy) / seg2
    tval = max(0.0, min(1.0, tval))
    dx, dy = a.x() + tval * vx - p.x(), a.y() + tval * vy - p.y()
    return (dx * dx + dy * dy) ** 0.5



#: projected outline + painted faces of a part, by (plane, content):
#: one edit rebuilds the scene several times (the change, then the tree
#: re-selecting, then the highlight), and a Lego build's 2D faces took
#: ~0.5 s each time
_PART_SHAPES = {}
PART_SHAPE_CACHE = 64


def _fingerprint(colored):
    """A cheap identity of a coloured triangle list: its length and an
    even sample of its triangles and colours."""
    n = len(colored)
    step = max(1, n // 97)
    return (n, hash(tuple((colored[k][0], str(colored[k][1]))
                          for k in range(0, n, step))))

class HandleItem(QGraphicsRectItem):
    """Square resize handle, constant size on screen."""

    def __init__(self, role: str, parent, snap=True, hot=False,
                 cursor=Qt.SizeAllCursor):
        size = HANDLE_SIZE
        super().__init__(-size / 2, -size / 2, size, size, parent)
        self.role = role
        self._snap = snap                  # dimension handles opt out
        self.setFlag(QGraphicsItem.ItemIgnoresTransformations, True)
        if hot:                            # the point picked in the table
            self.setBrush(QBrush(QColor("#e53935")))
            self.setPen(_pen("#b71c1c", 1.6))
        else:
            self.setBrush(QBrush(QColor("#ffffff")))
            self.setPen(_pen("#2176c7", 1.2))
        self.setCursor(cursor)
        self.setAcceptedMouseButtons(Qt.LeftButton)

    def mousePressEvent(self, event):
        parent = self.parentItem()
        if hasattr(parent, "handle_pressed"):
            # record the grab point so the drag is measured as a delta
            parent.handle_pressed(self.role, event.scenePos())
        event.accept()

    def mouseMoveEvent(self, event):
        # the cursor's scene position directly — robust even though the
        # handle ignores view transforms and slides out from under the
        # cursor (mapToScene of event.pos() jitters in that case)
        pos = event.scenePos()
        scene = self.scene()
        got = None
        if self._snap and hasattr(scene, "snap_handle"):
            # the other shapes' points, the origin, ON a centerline (the
            # user: a circle's centre moved onto the centerline)
            got = scene.snap_handle(pos, self.parentItem())
        self._snapped = got
        if got is not None:
            pos = got[0]
        elif self._snap:
            pos = scene.snap(pos)
        # a shape drawn through its rotate / move (view2d_edit.Frame)
        # takes the cursor in its own coordinates
        from .view2d_edit import in_frame_coords
        pos = in_frame_coords(self.parentItem(), pos)
        self.parentItem().handle_dragged(self.role, pos)

    def mouseReleaseEvent(self, event):
        event.accept()
        scene = self.scene()
        got, self._snapped = getattr(self, "_snapped", None), None
        if scene is not None and hasattr(scene, "end_handle_drag"):
            scene.end_handle_drag(self.parentItem(), self.role, got)


class ShapeItem:
    """Mixin for scene items bound to a CadNode."""

    def init_node(self, node, scene):
        self.node = node
        self._scene = scene
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.ItemSendsGeometryChanges, True)
        self.setCursor(Qt.SizeAllCursor)   # the body moves the shape
        self.handles = []
        self._hot_vertex = -1              # point picked in the table

    def rv(self, key, default=0.0) -> float:
        """Param as a number — expressions preview with loop start
        values (editing writes plain numbers back)."""
        return expr.resolve(self.node.params.get(key),
                            self._scene.env_for(self.node), default)

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange and \
                not self._scene.updating:
            # the shape's own corners, centre and edge middles snap onto
            # the origin and other shapes' points (2026-11-12, the user);
            # else the grid as before
            got = self._scene.snap_shape(self, value)
            value = got if got is not None else self._scene.snap(value)
        elif change == QGraphicsItem.ItemPositionHasChanged and \
                not self._scene.updating:
            self._scene.push_move(self)
        elif change == QGraphicsItem.ItemSelectedHasChanged:
            self.refresh_handles()
            if not self._scene.updating:
                self._scene.emit_selection()
        return super().itemChange(change, value)

    #: a selected shape is drawn again in this colour (no dashed box)
    SELECTED_INK = "#1f7ae0"

    def paint(self, painter, option, widget=None):
        """Qt's own "selected" look is a dashed rectangle round the
        item's bounding box — round a slanted line it read as a selected
        rectangle (the user: a line selected shows its two end points and
        nothing else). The flag is dropped and the shape itself is drawn
        over in the accent colour instead."""
        from PyQt5.QtWidgets import QStyle, QStyleOptionGraphicsItem
        selected = bool(option.state & QStyle.State_Selected)
        if selected:
            option = QStyleOptionGraphicsItem(option)
            option.state &= ~QStyle.State_Selected
        self._paint_body(painter, option, widget)
        if selected:
            pen = QPen(QColor(self.SELECTED_INK), 2.4)
            pen.setCosmetic(True)
            pen.setCapStyle(Qt.RoundCap)
            pen.setJoinStyle(Qt.RoundJoin)
            if self.node.params.get("modifier") == "%":
                pen.setStyle(Qt.DashLine)     # construction stays dashed
            painter.save()
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawPath(self._outline_path())
            painter.restore()

    def _paint_body(self, painter, option, widget):
        super(ShapeItem, self).paint(painter, option, widget)

    def _outline_path(self):
        if getattr(self, "_loops", None) is not None:
            return self._loops
        path = QPainterPath()
        if isinstance(self, QGraphicsLineItem):
            line = self.line()
            path.moveTo(line.p1())
            path.lineTo(line.p2())
        elif isinstance(self, QGraphicsRectItem):
            path.addRect(self.rect())
        elif isinstance(self, QGraphicsEllipseItem):
            path.addEllipse(self.rect())
        elif isinstance(self, QGraphicsPolygonItem):
            poly = self.polygon()
            if poly.size():
                path.addPolygon(poly)
                path.closeSubpath()
        elif isinstance(self, QGraphicsPathItem):
            path = self.path()
        return path

    # -------- handles: subclasses define handle roles + positions
    def handle_spec(self):
        return []                                  # [(role, local pos)]

    def refresh_handles(self):
        grabber = self._scene.mouseGrabberItem()
        if grabber is not None and grabber in self.handles:
            return          # never delete the handle being dragged
        for handle in self.handles:
            self._scene.removeItem(handle)
        self.handles = []
        if self.isSelected():
            hot = f"v{self._hot_vertex}"
            # rect/circle handles resize a dimension (directional cursor);
            # line/polygon vertices move a point freely (four-way move)
            free = self.node.type in ("line", "polygon", "text")
            center = self.boundingRect().center()
            for role, pos in self.handle_spec():
                cur = Qt.SizeAllCursor if free or role == "center" \
                    else _resize_cursor(
                    pos.x() - center.x(), pos.y() - center.y())
                handle = HandleItem(role, self, hot=(role == hot),
                                    cursor=cur)
                handle.setPos(pos)
                self.handles.append(handle)

    def set_hot_vertex(self, index):
        """Mark one polygon vertex (the point selected in the properties
        table) so its handle stands out red in the sketch."""
        if index != self._hot_vertex:
            self._hot_vertex = index
            self.refresh_handles()

    def reposition_handles(self):
        spec = dict(self.handle_spec())
        for handle in self.handles:
            if handle.role in spec:
                handle.setPos(spec[handle.role])

    def handle_dragged(self, role, scene_pos):
        pass

    def apply_node(self):
        """Model -> item geometry (called inside scene.updating)."""
        raise NotImplementedError

    def push_pos(self):
        """Item position -> model params after a move."""
        raise NotImplementedError


class LineShapeItem(ShapeItem, QGraphicsLineItem):
    def __init__(self, node, scene):
        super().__init__()
        self.init_node(node, scene)
        self.apply_node()

    def apply_node(self):
        x1, y1 = self.rv("x1"), self.rv("y1")
        self.prepareGeometryChange()        # an arc's bulge moves its box
        self.setPos(x1, y1)
        self.setLine(0, 0, self.rv("x2") - x1, self.rv("y2") - y1)
        if self.node.params.get("modifier") == "%":
            # a construction line: a thin dashed reference line
            pen = _pen("#7a8a99", 1.2)
            pen.setStyle(Qt.DashLine)
        else:
            # drawn as a sketch line, a hair whatever its width (the
            # width only matters once it is extruded on its own)
            pen = _pen("#2e3440", 1.6)
            pen.setCapStyle(Qt.RoundCap)
        self.setPen(pen)
        self.reposition_handles()

    def push_pos(self):
        p = self.node.params
        dx = self.pos().x() - p["x1"]
        dy = self.pos().y() - p["y1"]
        p["x1"] += dx
        p["y1"] += dy
        p["x2"] += dx
        p["y2"] += dy
        self._scene.model.node_changed.emit(self.node)

    def _curve(self):
        """An ARC (sketch_arc) or a SLOT drawn as what it is — a line
        draws as a hair whatever its width, and a slot showed as its
        centre line alone (the user). The path in the item's frame, or
        None for a plain line."""
        from . import sketch_arc, slot2d
        x1, y1 = self.rv("x1"), self.rv("y1")
        x2, y2 = self.rv("x2"), self.rv("y2")
        if sketch_arc.is_arc(self.node):
            pts = sketch_arc.points(x1, y1, x2, y2,
                                    sketch_arc.bulge_of(self.node.params))
            if slot2d.is_slot(self.node):
                pts = sketch_arc.band(pts, self.rv("width", 1.0)) + pts[:1]
        elif slot2d.is_slot(self.node):
            from .mesh import _capsule
            pts = _capsule(x1, y1, x2, y2, self.rv("width", 1.0) / 2.0)
            pts = pts + pts[:1]
        else:
            return None
        path = QPainterPath(QPointF(pts[0][0] - x1, pts[0][1] - y1))
        for x, y in pts[1:]:
            path.lineTo(x - x1, y - y1)
        return path

    def boundingRect(self):
        path = self._curve()
        if path is None:
            return super().boundingRect()
        return path.boundingRect().adjusted(-2, -2, 2, 2)

    def shape(self):
        path = self._curve()
        if path is None:
            return super().shape()
        from PyQt5.QtGui import QPainterPathStroker
        stroker = QPainterPathStroker()
        stroker.setWidth(max(self._tol(), 0.5))
        return stroker.createStroke(path)

    def _tol(self):
        views = self.scene().views() if self.scene() else []
        k = abs(views[0].transform().m11()) if views else 1.0
        return 8.0 / (k or 1.0)

    def _outline_path(self):
        path = self._curve()
        if path is not None:
            return path
        return super()._outline_path()

    def _paint_body(self, painter, option, widget):
        path = self._curve()
        if path is None:
            return super()._paint_body(painter, option, widget)
        painter.setPen(self.pen())
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)
        from . import slot2d
        if slot2d.is_slot(self.node):
            # its centre line and end centres, dashed like SolidWorks'
            # (the user: a slot showed no centre line to dimension to)
            from . import sketch_arc
            x1, y1 = self.rv("x1"), self.rv("y1")
            pts = sketch_arc.points(x1, y1, self.rv("x2"), self.rv("y2"),
                                    sketch_arc.bulge_of(self.node.params))
            centre = QPainterPath(QPointF(pts[0][0] - x1, pts[0][1] - y1))
            for x, y in pts[1:]:
                centre.lineTo(x - x1, y - y1)
            pen = QPen(QColor("#7a8a99"), 0)
            pen.setCosmetic(True)
            pen.setStyle(Qt.DashDotLine)
            painter.setPen(pen)
            painter.drawPath(centre)
            k = abs(painter.worldTransform().m11()) or 1.0
            c = 4.0 / k                      # 4 px crosses
            for x, y in (pts[0], pts[-1]):
                x, y = x - x1, y - y1
                painter.drawLine(QPointF(x - c, y), QPointF(x + c, y))
                painter.drawLine(QPointF(x, y - c), QPointF(x, y + c))

    def handle_spec(self):
        line = self.line()
        out = [("p1", line.p1()), ("p2", line.p2())]
        from . import sketch_arc
        if sketch_arc.is_arc(self.node):
            # the third handle sits ON the arc: drag it to bend
            x1, y1 = self.rv("x1"), self.rv("y1")
            mx, my = sketch_arc.middle(x1, y1, self.rv("x2"), self.rv("y2"),
                                       sketch_arc.bulge_of(self.node.params))
            out.append(("mid", QPointF(mx - x1, my - y1)))
        else:
            # its middle moves the WHOLE line, its ends snapping onto
            # other shapes (2026-11-11, the user)
            out.append(("move", (line.p1() + line.p2()) / 2.0))
        return out

    def _move_whole(self, pos):
        """The line moved so its middle is at *pos* (frame coords); an
        end near another shape's point snaps onto it."""
        from .view2d_edit import Frame
        p = self.node.params
        a = QPointF(self.rv("x1"), self.rv("y1"))
        b = QPointF(self.rv("x2"), self.rv("y2"))
        d = pos - (a + b) / 2.0
        a2, b2 = a + d, b + d
        frame = self.parentItem()
        frame = frame if isinstance(frame, Frame) else None
        to_s = frame.mapToScene if frame else (lambda q: QPointF(q))
        from_s = frame.mapFromScene if frame else (lambda q: QPointF(q))
        best = None
        for end in (a2, b2):
            got = self._scene.snap_handle(to_s(end), self)
            if got is None or got[1] != "point" and got[1] != "origin":
                continue
            q = from_s(got[0])
            dist = math.hypot(q.x() - end.x(), q.y() - end.y())
            if best is None or dist < best[0]:
                best = (dist, q - end)
        if best is not None:
            a2, b2 = a2 + best[1], b2 + best[1]
        p["x1"], p["y1"] = a2.x(), a2.y()
        p["x2"], p["y2"] = b2.x(), b2.y()
        self._scene.model.node_changed.emit(self.node)

    def handle_dragged(self, role, scene_pos):
        p = self.node.params
        if role == "move":
            self._move_whole(scene_pos)
            return
        if role == "mid":
            from . import sketch_arc
            p["bulge"] = round(sketch_arc.bulge_through(
                (self.rv("x1"), self.rv("y1")),
                (self.rv("x2"), self.rv("y2")),
                (scene_pos.x(), scene_pos.y())), 10) or 1e-6
            self._scene.model.node_changed.emit(self.node)
            return
        key_x, key_y = ("x1", "y1") if role == "p1" else ("x2", "y2")
        p[key_x], p[key_y] = scene_pos.x(), scene_pos.y()
        self._scene.model.node_changed.emit(self.node)


class RectShapeItem(ShapeItem, QGraphicsRectItem):
    def __init__(self, node, scene):
        super().__init__()
        self.init_node(node, scene)
        self.setPen(_pen("#2e3440"))
        self.setBrush(_shape_fill(self.node))
        self.apply_node()

    def apply_node(self):
        self.setPos(self.rv("x"), self.rv("y"))
        self.setRect(0, 0, self.rv("width", 1.0),
                     self.rv("height", 1.0))
        self.reposition_handles()

    def push_pos(self):
        p = self.node.params
        p["x"], p["y"] = self.pos().x(), self.pos().y()
        self._scene.model.node_changed.emit(self.node)

    def handle_spec(self):
        rect = self.rect()
        return [("br", rect.bottomRight()), ("tr", rect.topRight()),
                ("bl", rect.bottomLeft()), ("tl", rect.topLeft())]

    def handle_dragged(self, role, scene_pos):
        p = self.node.params
        left, bottom = self.rv("x"), self.rv("y")
        right = left + self.rv("width", 1.0)
        top = bottom + self.rv("height", 1.0)
        if "r" in role:
            right = scene_pos.x()
        else:
            left = scene_pos.x()
        # the roles are Qt's rect corners: Qt's "top" is the SMALLER y,
        # which in this Y-up view is the shape's bottom edge (they were
        # read the other way round, so a corner moved the opposite edge
        # and dragging the upper corner collapsed the rectangle)
        if role in ("tr", "tl"):
            bottom = scene_pos.y()
        else:
            top = scene_pos.y()
        p["x"], p["y"] = min(left, right), min(bottom, top)
        p["width"] = max(abs(right - left), 0.01)
        p["height"] = max(abs(top - bottom), 0.01)
        self._scene.model.node_changed.emit(self.node)


def is_sketch_point(node) -> bool:
    """A sketch POINT or a point copied from the part for a dimension: a
    0.25 mm construction circle. It is a point, whatever the zoom."""
    p = node.params
    try:
        return node.type == "circle" and p.get("modifier") == "%" and \
            abs(float(p.get("radius", 0)) - 0.25) < 1e-9
    except (TypeError, ValueError):
        return False


class CircleShapeItem(ShapeItem, QGraphicsEllipseItem):
    #: half the size of a sketch point's mark, in pixels
    POINT_PX = 4.0

    def __init__(self, node, scene):
        super().__init__()
        self.init_node(node, scene)
        self.setPen(_pen("#2e3440"))
        self.setBrush(_shape_fill(self.node))
        self.apply_node()

    def _point_size(self):
        """Half a sketch point's mark in scene units (a few pixels)."""
        views = self.scene().views() if self.scene() is not None else []
        k = abs(views[0].transform().m11()) if views else 1.0
        return self.POINT_PX / (k or 1.0)

    def paint(self, painter, option, widget=None):
        if not is_sketch_point(self.node):
            return super().paint(painter, option, widget)
        # a small cross, the same on screen at any zoom: drawn at its
        # real 0.25 mm it was a big dashed circle over a part a
        # millimetre across (the user's "random circles")
        s = self._point_size()
        pen = QPen(QColor("#e07b39") if self.isSelected()
                   else QColor("#5b6b7a"), 0)
        pen.setCosmetic(True)
        pen.setWidthF(1.4)
        painter.setPen(pen)
        painter.drawLine(QLineF(-s, 0, s, 0))
        painter.drawLine(QLineF(0, -s, 0, s))

    def shape(self):
        if not is_sketch_point(self.node):
            return super().shape()
        s = self._point_size() * 1.5
        path = QPainterPath()
        path.addRect(QRectF(-s, -s, 2 * s, 2 * s))
        return path

    def apply_node(self):
        r = self.rv("radius", 1.0)
        self.setPos(self.rv("x"), self.rv("y"))
        self.setRect(-r, -r, 2 * r, 2 * r)
        angle = self.rv("angle", 360.0)
        if angle < 360.0:
            # Qt draws a pie when the span is partial; angles match
            # world CCW because the whole view is Y-flipped.
            self.setStartAngle(int(self.rv("start_angle") * 16))
            self.setSpanAngle(int(angle * 16))
        else:
            self.setStartAngle(0)
            self.setSpanAngle(360 * 16)
        self.reposition_handles()

    def push_pos(self):
        p = self.node.params
        p["x"], p["y"] = self.pos().x(), self.pos().y()
        self._scene.model.node_changed.emit(self.node)

    def handle_spec(self):
        # the centre is a handle too: drag it to move the circle
        return [("radius", QPointF(self.rv("radius", 1.0), 0)),
                ("center", QPointF(0, 0))]

    def handle_dragged(self, role, scene_pos):
        p = self.node.params
        if role == "center":
            p["x"], p["y"] = scene_pos.x(), scene_pos.y()
            self._scene.model.node_changed.emit(self.node)
            return
        center = self.pos()
        radius = ((scene_pos.x() - center.x()) ** 2 +
                  (scene_pos.y() - center.y()) ** 2) ** 0.5
        p["radius"] = max(radius, 0.01)
        self._scene.model.node_changed.emit(self.node)


class PolygonShapeItem(ShapeItem, QGraphicsPolygonItem):
    def __init__(self, node, scene):
        super().__init__()
        self.init_node(node, scene)
        self.setPen(_pen("#2e3440"))
        self.setBrush(_shape_fill(self.node))
        self.apply_node()

    def apply_node(self):
        p = self.node.params
        env = self._scene.env_for(self.node)
        self.setPos(self.rv("x"), self.rv("y"))
        # the corners (handles, constraints) are the points as stored; a
        # sketch fillet's arc is drawn from them (sketch_modify.expand)
        self._corners = [QPointF(expr.resolve(x, env), expr.resolve(y, env))
                         for x, y in p["points"]]
        drawn = self._corners
        if p.get("corners"):
            from . import sketch_modify
            drawn = [QPointF(x, y) for x, y in sketch_modify.expand(
                [(q.x(), q.y()) for q in self._corners], p["corners"])]
        self.setPolygon(QPolygonF(drawn))
        self._loops = None
        if p.get("paths") and not p.get("corners"):
            # several loops (an outline and its holes, a part's section):
            # drawn as ONE polygon they were joined by stray lines
            path = QPainterPath()
            path.setFillRule(Qt.OddEvenFill)
            for loop in p["paths"]:
                pts = [drawn[i] for i in loop if 0 <= int(i) < len(drawn)]
                if len(pts) >= 2:
                    path.addPolygon(QPolygonF(pts + [pts[0]]))
            self._loops = path
        self.reposition_handles()

    def shape(self):
        if getattr(self, "_loops", None) is not None:
            return self._loops
        return super().shape()

    def boundingRect(self):
        if getattr(self, "_loops", None) is not None:
            w = self.pen().widthF()
            return self._loops.boundingRect().adjusted(-w, -w, w, w)
        return super().boundingRect()

    def _paint_body(self, painter, option, widget):
        if getattr(self, "_loops", None) is None:
            return super()._paint_body(painter, option, widget)
        painter.setPen(self.pen())
        painter.setBrush(self.brush())
        painter.drawPath(self._loops)

    def push_pos(self):
        p = self.node.params
        p["x"], p["y"] = self.pos().x(), self.pos().y()
        self._scene.model.node_changed.emit(self.node)

    def handle_spec(self):
        # the drawn polygon's corners: a point may be an expression
        # ("w / 2", a loop variable) — QPointF of the raw text crashed
        # the sketch (the user, 2026-10-20)
        corners = getattr(self, "_corners", None)
        if corners is None:
            poly = self.polygon()
            corners = [poly[i] for i in range(poly.count())]
        return [(f"v{i}", QPointF(c)) for i, c in enumerate(corners)]

    def handle_dragged(self, role, scene_pos):
        index = int(role[1:])
        local = scene_pos - self.pos()
        self.node.params["points"][index] = [local.x(), local.y()]
        self._scene.model.node_changed.emit(self.node)


class TextShapeItem(ShapeItem, QGraphicsPathItem):
    def __init__(self, node, scene):
        super().__init__()
        self.init_node(node, scene)
        self.setPen(_pen("#2e3440", 1.0))
        self.setBrush(QBrush(QColor(33, 118, 199, 90)))
        self.apply_node()

    def apply_node(self):
        from PyQt5.QtGui import QTransform
        from . import mesh
        p = dict(self.node.params)
        self.setPos(self.rv("x"), self.rv("y"))
        p["size"] = max(self.rv("size", 10.0), 0.5)
        # the same font, alignment and direction as the preview's outlines
        path, scale = mesh.text_path(p)
        # The view is Y-flipped; flip the glyphs back upright.
        self.setPath(path * QTransform(scale, 0, 0, -scale, 0, 0))
        self.reposition_handles()

    @staticmethod
    def _flip():
        from PyQt5.QtGui import QTransform
        return QTransform(1, 0, 0, -1, 0, 0)

    def push_pos(self):
        p = self.node.params
        p["x"], p["y"] = self.pos().x(), self.pos().y()
        self._scene.model.node_changed.emit(self.node)


class OutlineShapeItem(ShapeItem, QGraphicsPathItem):
    """A 2D shape drawn from its outlines (an imported SVG / DXF): moved
    as a whole by its x / y, no handles — its points live in the file."""

    def __init__(self, node, scene):
        super().__init__()
        self.init_node(node, scene)
        self.setPen(_pen("#2e3440", 1.0))
        self.setBrush(QBrush(QColor(33, 118, 199, 90)))
        self.apply_node()

    def apply_node(self):
        from . import mesh
        x, y = self.rv("x"), self.rv("y")
        self.setPos(x, y)
        path = QPainterPath()
        path.setFillRule(Qt.OddEvenFill)
        for outline in mesh.node_outlines(self.node,
                                          self._scene.env_for(self.node)):
            if len(outline) >= 3:
                path.addPolygon(QPolygonF([QPointF(px - x, py - y)
                                           for px, py in outline]))
                path.closeSubpath()
        self.setPath(path)

    def push_pos(self):
        p = self.node.params
        p["x"], p["y"] = self.pos().x(), self.pos().y()
        self._scene.model.node_changed.emit(self.node)


_ITEM_CLASSES = dict(line=LineShapeItem, rect=RectShapeItem,
                     circle=CircleShapeItem, polygon=PolygonShapeItem,
                     text=TextShapeItem, import_2d=OutlineShapeItem)
# the feature library's 2D shapes (star, rounded polygon, Bézier,
# honeycomb) move as a whole by their x / y
from .organic import features as _features  # noqa: E402

_ITEM_CLASSES.update({t: OutlineShapeItem for t in _features.SHAPES_2D})


#: node types that carry their own move params, so a drag is baked
#: into the node itself instead of wrapping it in a new translate.
MOVABLE_TYPES = ("translate", "union", "component", "reference")
#: selected, these do only their own edit — never a drag that would wrap
#: them in a new Move (a Rotate turns, an extrude grows)
OWN_EDIT_TYPES = ("rotate", "scale", "mirror", "resize", "multmatrix",
                  "linear_extrude", "rotate_extrude")


def _invert3(m):
    """Inverse of a 3x3 matrix (adjugate / determinant), or None when
    it is singular — a zero scale, say."""
    a, b, c = m[0]
    d, e, f = m[1]
    g, h, i = m[2]
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-12:
        return None
    return [[(e * i - f * h) / det, (c * h - b * i) / det,
             (b * f - c * e) / det],
            [(f * g - d * i) / det, (a * i - c * g) / det,
             (c * d - a * f) / det],
            [(d * h - e * g) / det, (b * g - a * h) / det,
             (a * e - b * d) / det]]


def _profile_root(node):
    """The node a 2D shape's profile hangs from: its nearest extrude (or
    other 3D maker) — else its topmost 2D ancestor."""
    probe, top = node.parent, node
    while probe is not None and probe.parent is not None:
        if probe.type in ("linear_extrude", "rotate_extrude") or \
                probe.category == SHAPE_3D:
            return probe
        top = probe
        probe = probe.parent
    return top


def _profile_shapes(focus):
    """The focused shapes plus every other 2D shape of their profiles,
    in tree order, once each."""
    out, seen = [], set()
    for node in focus:
        root = _profile_root(node)
        for n in root.walk():
            if n.category == SHAPE_2D and n.type in _ITEM_CLASSES and \
                    n.visible and n.id not in seen:
                seen.add(n.id)
                out.append(n)
    return out


def _shape_fill(node):
    """A sketch shape's fill: light blue — but only its outline once a
    Regions node uses it (the region is the solid; filled, a hole read as
    material — the user's lever)."""
    parent = node.parent
    if parent is not None and parent.type == "regions":
        return QBrush(Qt.NoBrush)
    return QBrush(QColor(33, 118, 199, 40))


def _construction_look(item, node):
    """Construction geometry (OpenSCAD's % on a sketch shape): dashed,
    unfilled — a reference, never part of the solid."""
    if node.params.get("modifier") != "%":
        return
    pen = QPen(item.pen())
    pen.setStyle(Qt.DashLine)
    pen.setColor(QColor("#7a8a99"))
    item.setPen(pen)
    if hasattr(item, "setBrush"):
        item.setBrush(QBrush(Qt.NoBrush))
    item.setToolTip(language.tr("{name} — construction (not part of the "
                                "solid)").format(name=node.name))


def _is_cut(node) -> bool:
    """Is *node* subtracted by a 2D Difference above it (not its first
    child's line)?"""
    child, probe = node, node.parent
    while probe is not None:
        if probe.type == "difference":
            return probe.children and probe.children[0] is not child
        if probe.type in ("linear_extrude", "rotate_extrude"):
            return False
        child, probe = probe, probe.parent
    return False


def _produces_3d(node) -> bool:
    """True if the subtree makes solid geometry (an assemblable part).
    A Linked copy renders its master, so it counts too."""
    return any(n.category == SHAPE_3D
               or n.type in ("linear_extrude", "rotate_extrude",
                             "reference")
               for n in node.walk())


class PartItem(QGraphicsPathItem):
    """A part (a subtree) shown in the assembly plane. Two flavours:

    - *outline* (theme accent): the assembly overview — one per
      top-level part, draggable to position it (the move commits into a
      translate node so assemblies are ordinary tree structure);
    - *silhouette* (solid amber): the true projected shape of the
      selected object, shown alone so you see exactly that part in its
      real orientation.

    Both are built from a projected triangle soup, so neither may be
    *stroked*: a pen would trace every internal facet and the part
    would read as a hatched wireframe. They are filled instead, the
    overview lightly and the selected silhouette solidly. Only a
    single editable primitive (*blue*) has a real outline — its path
    is simplified into one.
    """

    def __init__(self, node, scene, path, label, movable=True,
                 dashed=True, dims=None, blue=False, faces=None):
        super().__init__()
        self.node = node
        self._scene = scene
        self._movable = movable
        self._dims = dims or []            # dimension-edit handle specs
        #: the part's own coloured faces, painter-ordered
        #: (`planview.plan_faces`): drawn instead of the flat fill, so an
        #: overview part looks like itself — the path stays its shape
        self._faces = faces
        self.handles = []
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        if movable:
            self.setFlag(QGraphicsItem.ItemIsMovable, True)
            self.setCursor(Qt.SizeAllCursor)   # the body moves the part
        self.setFlag(QGraphicsItem.ItemSendsGeometryChanges, True)
        from .style import tokens
        if dashed:
            color = QColor(tokens()["select"])
            pen = QPen(Qt.NoPen)
            fill_alpha = 64
        elif blue:
            # an editable primitive: a crisp blue outline + light fill,
            # like a 2D sketch shape, with its size handles on top. The
            # sketch blue is fixed (matches the handles), not the theme
            # accent — so it stays blue under the Sand/gold theme too.
            color = QColor("#2176c7")
            pen = QPen(color, 1.6)
            pen.setCosmetic(True)
            fill_alpha = 45
        else:
            # solid filled silhouette — no pen, or the internal
            # triangle edges would show as a wireframe
            color = QColor("#ff8c1a")         # isolated-part accent
            pen = QPen(Qt.NoPen)
            fill_alpha = 150
        self.setPen(pen)
        self._label_color = QColor(color)
        fill = QColor(color)
        fill.setAlpha(fill_alpha)
        self.setBrush(QBrush(fill))
        if not blue:
            # a soup path is heavy and static; cache its raster so
            # panning/redraw stay smooth (re-rasters only on zoom)
            self.setCacheMode(QGraphicsItem.DeviceCoordinateCache)
        self.setPath(path)
        rect = path.boundingRect()
        self._label = label
        self._label_pos = QPointF(rect.left(), rect.bottom())

    def paint(self, painter, option, widget=None):
        if self._faces:
            from .planview import paint_faces
            paint_faces(painter, self._faces)
            if self.isSelected():               # tint, don't hide, it
                tint = QColor(self._label_color)
                tint.setAlpha(70)
                painter.fillPath(self.path(), tint)
        else:
            super().paint(painter, option, widget)
        painter.save()
        painter.translate(self._label_pos)
        painter.scale(1, -1)                  # the view is Y-flipped
        font = painter.font()
        size = max(self.path().boundingRect().height() * 0.09, 2.0)
        font.setPointSizeF(size)
        painter.setFont(font)
        painter.setPen(self._label_color)
        painter.drawText(QPointF(0, -size * 0.4), self._label)
        painter.restore()

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange and \
                not self._scene.updating:
            return self._scene.snap(value)
        if change == QGraphicsItem.ItemSelectedHasChanged:
            self._refresh_dim_handles()
            if not self._scene.updating:
                self._scene.emit_selection()
        return super().itemChange(change, value)

    # -------- dimension handles (editable primitive sizes in 2D)
    def _refresh_dim_handles(self):
        for handle in self.handles:
            if handle.scene() is not None:
                self._scene.removeItem(handle)
        self.handles = []
        if self.isSelected() and self._dims:
            for spec in self._dims:
                handle = HandleItem(spec["role"], self, snap=False,
                                    cursor=_resize_cursor(*spec["axis"]))
                handle.setPos(spec["tip"])
                self.handles.append(handle)

    def handle_pressed(self, role, scene_pos):
        """Remember the grab point and starting value so the drag is a
        stable delta rather than an absolute re-projection each frame."""
        spec = next((d for d in self._dims if d["role"] == role), None)
        if spec is not None:
            spec["_grab"] = scene_pos
            spec["_start"] = spec["value"]

    def handle_dragged(self, role, scene_pos):
        spec = next((d for d in self._dims if d["role"] == role), None)
        if spec is None or "_grab" not in spec:
            return
        ax, ay = spec["axis"]
        denom = ax * ax + ay * ay
        if denom < 1e-12:
            return
        # how far the cursor has moved *along the handle's axis* since
        # the grab, in local mm — measured from a fixed reference so it
        # never jitters, and unaffected by the handle itself moving
        travel = ((scene_pos.x() - spec["_grab"].x()) * ax
                  + (scene_pos.y() - spec["_grab"].y()) * ay) / denom
        value = spec["_start"] + travel * spec["factor"]
        # snap the resulting dimension to the grid (not the cursor — that
        # was what made the drag erratic); a plain round keeps radii on
        # nice increments without any jitter
        if self._scene.snap_enabled:
            g = self._scene.grid_size
            value = round(value / g) * g
        value = max(value, spec["minval"])
        self.node.params[spec["param"]] = round(value, 4)
        self._scene.model.node_changed.emit(self.node)
        # slide the grabbed handle to reflect the new size (feedback)
        mag = value / spec["factor"]
        for handle in self.handles:
            if handle.role == role:
                handle.setPos(QPointF(spec["anchor"].x() + mag * ax,
                                      spec["anchor"].y() + mag * ay))

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        self.queue_commit()

    def queue_commit(self):
        """Bake this drop into the model on the **next event-loop
        turn**.

        Committing writes the move, which rebuilds the scene — and the
        rebuild deletes this item while Qt is still delivering the
        release event to it. Returning into a freed object takes the
        whole process down (0xC0000409 on Windows). By the time the
        timer fires the event is fully delivered and the item is no
        longer the mouse grabber, so tearing it down is safe. The
        callback holds the *scene* (which outlives the rebuild), never
        `self`."""
        if not self._movable:
            return
        scene, node, delta = self._scene, self.node, self.pos()
        QTimer.singleShot(0, lambda: scene.commit_part_move(node, delta))


# ------------------------------------------------------------------ scene

class SketchScene(QGraphicsScene):
    """All visible 2D shapes of the document + the drawing tools."""

    selection_changed = pyqtSignal(list)      # list of CadNode
    node_created = pyqtSignal(object)         # CadNode
    measure_changed = pyqtSignal(str)         # live mm readout
    plane_changed = pyqtSignal(str)           # view auto-switched plane
    status = pyqtSignal(str)                  # note for the status bar
    polygon_changed = pyqtSignal(int)         # points placed (0 = none)

    def __init__(self, model: DocumentModel, parent=None):
        super().__init__(-2000, -2000, 4000, 4000, parent)
        self.model = model
        self.tool = SELECT
        self.plane = "Top (XY)"                # assembly view plane
        self.grid_size = 0.5
        self.snap_enabled = True
        self.show_grid = True
        self.show_dims = False                 # automatic sizes (opt-in)
        self.updating = False
        self._items = {}                       # node id -> shape item
        self._part_items = {}                  # node id -> part item
        self._draft = None                     # item being drawn
        self._draft_start = None
        self._poly_points = []
        self._poly_items = []                  # its rubber band + markers
        self._frames = []                      # view2d_edit: (frame, node)
        self._gizmos = []                      # view2d_edit: the dial
        #: a line / rectangle / circle started with a CLICK: it follows
        #: the cursor and the next click ends it (Fusion, SolidWorks)
        self._click_mode = False
        self._swallow_release = False
        self._part_dirty = False
        self._highlight_ids = set()            # selected nodes
        self._highlight_items = []
        self._point_hl = (None, -1)            # (polygon id, vertex idx)
        # measure/dimension tools: two scene points (mm) + the live end
        self._measure_a = None
        self._measure_b = None
        self._measure_cursor = None
        #: callable returning the Object the scene is isolated to (the
        #: Object tab's active component) or None — re-resolved on
        #: every rebuild so undo restores never leave a stale node.
        self.isolation_resolver = None
        #: () -> sketch_focus.Focus or None: which sketch is on show in
        #: the one-canvas Sketch Mode (only its shapes are drawn then)
        self.sketch_focus = None
        model.structure_changed.connect(self.rebuild)
        model.node_changed.connect(self._node_changed)
        model.dimensions_changed.connect(self.update)
        model.references_changed.connect(self.update)
        # repaint the overlay so auto size-on-selection follows the pick
        self.selectionChanged.connect(self.update)
        self.rebuild()

    def set_plane(self, plane: str):
        if plane in PLANES and plane != self.plane:
            self.plane = plane
            self.clear_measure()               # points belong to a plane
            self.drop_drafts()
            self.rebuild()

    # ------------------------------------------------------------ sync
    def env_for(self, node) -> dict:
        """Variables visible to *node* for preview purposes: document
        assigns plus ancestor loop variables at their first value."""
        env = {}
        for n in self.model.root.walk():
            if n.type == "assign" and n.visible:
                var = str(n.params.get("variable", "")).strip()
                if var:
                    env[var] = expr.resolve(n.params.get("value", 0),
                                            env, 0.0)
        ancestor = node.parent
        while ancestor is not None:
            if ancestor.type in ("for_loop", "while_loop"):
                values = ancestor.loop_values(env)
                var = str(ancestor.params.get("variable", "i")) or "i"
                env.setdefault(var, values[0] if values else 0.0)
            ancestor = ancestor.parent
        return env

    def scope_frame(self):
        """Context manager: while the Object tab isolates the scene,
        show the active Object **in its own local frame** — forced
        visible (a definition is hidden in Main) and its assembly
        placement zeroed, exactly as the 3D view does. Without the
        force-visible, tessellating a hidden Object yields nothing and
        `selected_world_tris` falls back to the selected node's own
        subtree, drawing it with none of its ancestor transforms — so
        the view and the drag mapping disagreed about which way is
        which, and a part dragged left went right."""
        from contextlib import contextmanager

        @contextmanager
        def ctx():
            scope = self.isolation_resolver() if self.isolation_resolver \
                else None
            if scope is None:
                yield
                return
            saved = {k: scope.params.get(k, 0.0) for k in _PLACEMENT
                     if k in scope.params}
            was_visible = scope.visible
            for key in saved:
                scope.params[key] = 0.0
            scope.visible = True
            try:
                yield
            finally:
                scope.params.update(saved)
                scope.visible = was_visible
        return ctx()

    def scope_root(self):
        """The node the scene draws: the active Object while the Object
        tab isolates the views, else the document root. Everything that
        walks the tree starts here, so a part that lives in the Main
        assembly never leaks into an Object being edited (and vice
        versa) — the two tabs are visually independent."""
        iso = self.isolation_resolver() if self.isolation_resolver \
            else None
        return iso if iso is not None else self.model.root

    def _create(self, type_: str, params: dict):
        """Add a drawn shape — inside the active Object while the
        Object tab has the viewers isolated, else at the top level."""
        iso = self.isolation_resolver() if self.isolation_resolver \
            else None
        parent = None
        if self.sketch_focus is not None:
            # Edit Sketch: a shape drawn now joins THAT sketch
            try:
                flt = self.sketch_focus()
                parent = flt.parent_for_new(self) if flt else None
            except Exception:
                parent = None
        if parent is None:
            parent = self._sketch_group(iso)
        return self.model.add_node(type_, params, parent=parent)

    #: the turn that lays a sketch's XY onto each view plane
    SKETCH_TURNS = {"Front (XZ)": (90.0, 0.0, 0.0),
                    "Side (YZ)": (90.0, 0.0, 90.0)}

    def _sketch_group(self, iso):
        """Where a shape drawn on this plane goes. Top: the scope itself.
        Front / Side: ONE "<plane> sketch" rotate in the scope, turned so
        the shape lies in that plane — a line drawn in Front used to
        land flat in XY, in 3D only, never shown in 2D (the user)."""
        turn = self.SKETCH_TURNS.get(self.plane)
        if turn is None:
            return iso
        scope = iso if iso is not None else self.model.root
        name = self.plane.split()[0] + " sketch"
        for child in scope.children:
            if child.type == "rotate" and child.name == name:
                return child
        rot = self.model.add_node(
            "rotate", dict(x=turn[0], y=turn[1], z=turn[2]), parent=scope,
            name=name)
        return rot

    def snap(self, pos: QPointF) -> QPointF:
        hint = None
        try:
            # the face sketched on: its centres, corners, origin, edges
            from . import face_outline
            got = face_outline.snap(self, pos)
            if got is not None:
                hint = got
                return got[0]
            # then the sketch's own shapes: centres, ends, corners,
            # middles, the origin (the user: "if there is a centre, a
            # line… I should snap to it")
            got = self._shape_snap(pos)
            if got is not None:
                hint = got
                return got[0]
            # a rectangle's diagonals and their crossing (diagonals.py)
            from . import diagonals2d
            got = diagonals2d.snap(self, pos)
            if got is not None:
                hint = got
                return got[0]
            # then ON a line, arc or circle — a centre placed there slides
            # along it (Point on curve; 2026-11-11, the user: "the centre
            # on the line, not fixed to a point")
            if getattr(self, "tool", SELECT) != SELECT and \
                    self._draft is None:
                from . import circle_snap
                on = circle_snap.on_curve(self, pos)
                if on is not None:
                    hint = (on[0], "on_line")
                    return on[0]
        finally:
            self._set_snap_hint(hint)
        if not self.snap_enabled:
            return pos
        g = self.snap_step()
        return QPointF(round(pos.x() / g) * g, round(pos.y() / g) * g)

    #: the finest the snap grid gets on screen (pixels a step)
    SNAP_GRID_PX = 10.0

    def snap_step(self):
        """The grid step a click snaps to: `grid_size`, made FINER while
        that is coarse on screen — the largest 1-2-5 step not above it
        still `SNAP_GRID_PX` pixels wide (2026-11-10, the user: Sketch
        Mode on a 0.84 x 0.5 mm face under the 0.5 mm grid — a circle
        could only land on the face's corners). As the 3D sketch does
        (Sketch3DTool.grid_at)."""
        import math
        g = float(self.grid_size) or 1.0
        views = self.views()
        if not views:
            return g
        k = abs(views[0].transform().m11())          # pixels per mm
        if k <= 0:
            return g
        want = self.SNAP_GRID_PX / k
        if want >= g:
            return g
        base = 10.0 ** math.floor(math.log10(want))
        for f in (1.0, 2.0, 5.0, 10.0):
            if f * base >= want - 1e-12:
                return min(g, round(f * base, 9))
        return g

    # -------------------------------------------------- feature snapping
    def _item_feature_points(self, item):
        """Snap targets for one shape/part item, in *scene* coords:
        corners, centres and edge midpoints — the points you dimension
        to on a drawing."""
        pts = []
        if isinstance(item, QGraphicsLineItem):
            ln = item.line()
            a, b = ln.p1(), ln.p2()
            pts = [a, b, (a + b) / 2.0]
        elif isinstance(item, QGraphicsEllipseItem):
            r = item.rect()
            c = r.center()
            pts = [c, QPointF(c.x(), r.top()), QPointF(c.x(), r.bottom()),
                   QPointF(r.left(), c.y()), QPointF(r.right(), c.y())]
        elif isinstance(item, QGraphicsRectItem):
            r = item.rect()
            tl, tr = r.topLeft(), r.topRight()
            bl, br = r.bottomLeft(), r.bottomRight()
            pts = [tl, tr, bl, br, r.center(),
                   (tl + tr) / 2.0, (bl + br) / 2.0,
                   (tl + bl) / 2.0, (tr + br) / 2.0]
        elif isinstance(item, QGraphicsPolygonItem):
            # corners and the middle of every side (the user: lock a
            # circle on the middle of any line of any shape)
            poly = list(item.polygon())
            if len(poly) > 1 and poly[0] == poly[-1]:
                poly = poly[:-1]
            pts = poly + [(poly[i] + poly[(i + 1) % len(poly)]) / 2.0
                          for i in range(len(poly))] if len(poly) > 1 \
                else poly
        elif isinstance(item, QGraphicsPathItem):
            for poly in item.path().toSubpathPolygons():
                pts += list(poly)
            pts.append(item.boundingRect().center())
        return [item.mapToScene(p) for p in pts]

    def snap_shape(self, item, value):
        """A whole shape dragged to item position *value*: the position
        that puts one of ITS feature points (corner, centre, middle of a
        side, a line's ends) on the origin or on another shape's point,
        nearest first within FEATURE_SNAP_PX; None when nothing is near
        (the caller then snaps to the grid)."""
        views = self.views()
        if not views or not self.snap_enabled:
            return None
        if len([i for i in self.selectedItems()
                if isinstance(i, ShapeItem)]) > 1:
            return None        # several move together: each snapping
                               # on its own would pull them apart
        try:
            own = self._item_feature_points(item)
        except Exception:
            return None
        if not own:
            return None
        parent = item.parentItem()
        to_s = parent.mapToScene if parent is not None else (lambda p: p)
        from_s = parent.mapFromScene if parent is not None else (
            lambda p: p)
        shift = to_s(value) - to_s(item.pos())
        moved = [p + shift for p in own]
        cache = getattr(self, "_drag_targets", None)
        if cache is None or cache[0] is not item:
            # gathered ONCE a drag (the other shapes stand still)
            targets = [(QPointF(0, 0), "origin")]
            for other in self.items():
                if not isinstance(other, ShapeItem) or other is item or \
                        not other.isVisible() or other.parentItem() is item:
                    continue
                try:
                    targets += [(p, "point")
                                for p in self._item_feature_points(other)]
                except Exception:
                    continue
            cache = self._drag_targets = (item, targets)
        targets = cache[1]
        self._shape_drag = item
        tol = FEATURE_SNAP_PX / max(views[0].px_per_mm(), 1e-6)
        best = None
        for p in moved:
            for t, kind in targets:
                d = math.hypot(t.x() - p.x(), t.y() - p.y())
                if d < tol and (best is None or d < best[0]):
                    best = (d, p, t, kind)
        if best is None:
            self._set_snap_hint(None)
            return None
        _d, p, t, kind = best
        self._set_snap_hint((QPointF(t), kind))
        return value + (from_s(t) - from_s(p))

    def snap_handle(self, pos, moving):
        """Where a dragged handle snaps: another shape's point (end,
        centre, corner, middle) or the origin, else the nearest point ON
        a centerline (a construction line). ``(point, kind, item)`` or
        None; the marker shows what it snapped to."""
        views = self.views()
        if not views:
            return None
        tol = FEATURE_SNAP_PX / max(views[0].px_per_mm(), 1e-6)
        best, best_d = None, tol
        for item in self.items():
            if not isinstance(item, ShapeItem) or item is moving or \
                    not item.isVisible():
                continue
            try:
                pts = self._item_feature_points(item)
            except Exception:
                continue
            for p in pts:
                d = math.hypot(p.x() - pos.x(), p.y() - pos.y())
                if d < best_d:
                    best, best_d = (QPointF(p), "point", item), d
        d = math.hypot(pos.x(), pos.y())
        if d < best_d:
            best, best_d = (QPointF(0, 0), "origin", None), d
        if best is None:
            for item in self.items():
                if not isinstance(item, LineShapeItem) or item is moving \
                        or item.node.params.get("modifier") != "%":
                    continue
                ln = item.line()
                a, b = item.mapToScene(ln.p1()), item.mapToScene(ln.p2())
                dx, dy = b.x() - a.x(), b.y() - a.y()
                t = ((pos.x() - a.x()) * dx + (pos.y() - a.y()) * dy) / (
                    dx * dx + dy * dy or 1.0)
                t = min(1.0, max(0.0, t))
                q = QPointF(a.x() + t * dx, a.y() + t * dy)
                d = math.hypot(q.x() - pos.x(), q.y() - pos.y())
                if d < best_d:
                    best, best_d = (q, "on_line", item), d
        self._handle_drag = True
        self._set_snap_hint((best[0], best[1]) if best else None)
        return best

    def end_handle_drag(self, moving, role, got):
        """A handle let go: drop the marker; a circle's centre left ON a
        centerline is tied to it (point on curve), as SolidWorks adds the
        relation when you drop a point on a line."""
        self._handle_drag = False
        self._set_snap_hint(None)
        if got is not None and moving is not None and \
                getattr(moving, "node", None) is not None and \
                moving.node.parent is not None:
            # dropped ON a point, an intersection, a line: tied there, as
            # it would be if drawn there (2026-11-11, the user: "if it
            # changes position I expected it to follow")
            from . import sketch_touch
            try:
                sketch_touch.relate(self.model, moving.node)
            except Exception:
                pass
        if got is None or got[1] != "on_line" or role != "center" or \
                moving is None or got[2] is None:
            return
        node, line = moving.node, got[2].node
        parent = node.parent
        if parent is None or line.parent is not parent:
            return
        from . import sketch_constraints as sc
        try:
            sc.add(self.model, parent, "point_on",
                   [sc.ref_of(parent, node, "c"),
                    sc.ref_of(parent, line, "l")])
        except Exception:                       # a conflict: leave it
            pass

    def _tangent_radius(self, centre, radius):
        """The dragged radius, snapped to touch a nearby circle, arc or
        line (remembered for the Tangent relation)."""
        from . import circle_snap
        got = circle_snap.tangent_radius(self, centre, radius)
        if got is None:
            self._circle_tangent = None
            return radius
        r, node, ent = got
        self._circle_tangent = (node, ent)
        self.status.emit(language.tr("Tangent to {name}").format(
            name=node.name))
        return r

    def _set_snap_hint(self, hint):
        """What the cursor snaps to now, drawn by the view (a marker and
        its name: the user could not see that it snapped)."""
        old = getattr(self, "_snap_hint", None)
        self._snap_hint = hint
        if (old is None) != (hint is None) or (
                old is not None and hint is not None and
                (old[0] != hint[0] or old[1] != hint[1])):
            for v in self.views():
                v.viewport().update()

    def _shape_snap(self, pos):
        # drawing only: a drag in Select moves shapes, and would stick to
        # the very points it is moving
        if getattr(self, "tool", SELECT) == SELECT:
            return None
        views = self.views()
        if not views:
            return None
        ppm = views[0].px_per_mm()
        tol = FEATURE_SNAP_PX / max(ppm, 1e-6)
        best, best_d, kind_best = None, tol, "point"
        grabbed = self.mouseGrabberItem()
        for item in self.items():
            if not isinstance(item, ShapeItem):
                continue
            # (not the shape being dragged: it would stick to itself. Only
            # that one — a shape just drawn stays SELECTED, and skipping
            # every selected shape lost the rectangle's side middles to
            # the next circle, 2026-11-13, the user)
            if item.isSelected() and grabbed is not None and (
                    grabbed is item or grabbed.parentItem() is item):
                continue
            try:
                pts = self._item_feature_points(item)
            except Exception:
                continue
            for p in pts:
                d = ((p.x() - pos.x()) ** 2 + (p.y() - pos.y()) ** 2) ** 0.5
                if d < best_d:
                    best, best_d, kind_best = p, d, "point"
        # and the shapes hidden inside a Regions (its rectangle's centre,
        # its circle's): the user could not snap to them
        from . import face_outline
        try:
            for x, y, kind, _owner in face_outline.scope_points(self) + \
                    [(0.0, 0.0, "origin", None)]:
                d = ((x - pos.x()) ** 2 + (y - pos.y()) ** 2) ** 0.5
                if d < best_d:
                    best, best_d, kind_best = QPointF(x, y), d, kind
        except Exception:
            pass
        if best is None:
            return None
        return QPointF(best), kind_best

    def feature_points(self):
        """Every snap target on every visible shape/part."""
        pts = []
        for item in self.items():
            if isinstance(item, (ShapeItem, PartItem)):
                pts += self._item_feature_points(item)
        try:                             # where the shapes cross
            from . import sketch_line
            pts += sketch_line.crossings(self)
        except Exception:
            pass
        return pts

    def snap_feature(self, scene_pos):
        """Snap to the nearest shape feature within a few pixels; else
        grid-snap. Returns ``(point, on_feature)``."""
        views = self.views()
        ppm = views[0].px_per_mm() if views else 4.0
        tol = FEATURE_SNAP_PX / max(ppm, 1e-6)
        best, best_d = None, tol
        for p in self.feature_points():
            d = ((p.x() - scene_pos.x()) ** 2 +
                 (p.y() - scene_pos.y()) ** 2) ** 0.5
            if d < best_d:
                best, best_d = p, d
        if best is not None:
            return best, True
        return self.snap(scene_pos), False

    # ----------------------------------------------------- measure tool
    def clear_measure(self):
        if self._measure_a is not None or self._measure_b is not None:
            self._measure_a = self._measure_b = self._measure_cursor = None
            self.measure_changed.emit("")
            self.update()

    def unit(self) -> str:
        """The document unit's symbol, for every length this view
        prints ("mm", "nm", "µm", ...)."""
        return units.symbol(getattr(self.model, "unit", "mm"))

    def _emit_measure(self, a, b):
        dx, dy = b.x() - a.x(), b.y() - a.y()
        dist = (dx * dx + dy * dy) ** 0.5
        u = self.unit()
        self.measure_changed.emit(
            f"distance: {dist:.2f} {u}    Δ {dx:.2f}, {dy:.2f} {u}")

    #: the sketch area that always exists, mm; the scene grows past it
    #: to take in whatever is drawn. It used to be fixed: a 14 m house
    #: sat mostly outside a 4 m square, so Fit could not frame it and
    #: the view would not scroll or zoom out onto the rest of it.
    BASE_RECT = QRectF(-2000.0, -2000.0, 4000.0, 4000.0)

    def fit_scene_rect(self):
        """Size the scene to everything drawn plus its own span of margin
        each side, and never smaller than what a view shows now (so a
        zoomed-out view keeps its place)."""
        rect = QRectF(self.BASE_RECT).united(self.itemsBoundingRect())
        pad = max(rect.width(), rect.height())
        rect = rect.adjusted(-pad, -pad, pad, pad)
        for view in self.views():
            rect = rect.united(
                view.mapToScene(view.viewport().rect()).boundingRect())
        if rect != self.sceneRect():
            self.setSceneRect(rect)

    def rebuild(self):
        if self.mouseGrabberItem() is not None:
            # something is being dragged: a rebuild now would delete it
            # under the cursor and the next mouse move would touch freed
            # memory (a segfault dragging a shape inside a Move + Rotate,
            # 2026-10-19). It runs once the button is released.
            self._rebuild_pending = True
            return
        self._rebuild_pending = False
        self._rebuild_items()
        self.fit_scene_rect()

    def _after_release(self):
        """Run a rebuild that waited for the drag to end — on the next
        event-loop turn, never inside the release event itself."""
        if self.mouseGrabberItem() is None and \
                not getattr(self, "_handle_drag", False):
            self._set_snap_hint(None)          # a dragged shape let go
            self._shape_drag = None
            self._drag_targets = None
            if getattr(self, "_drag_nodes", None):
                self._flush_drag()             # the final position
        if getattr(self, "_rebuild_pending", False) \
                and self.mouseGrabberItem() is None:
            self._rebuild_pending = False
            QTimer.singleShot(0, self.rebuild)

    def _rebuild_items(self):
        from . import part_collections
        from . import view2d_edit
        with part_collections.hiding(self.model):
            self._rebuild_items_now()
            # what a selected container holds is shown but locked: only
            # the container's own edit (a Move's drag, a Rotate's dial)
            view2d_edit.lock_contents(self)
            view2d_edit.add_gizmos(self)       # a selected rotate's dial
        locked = part_collections.locked_names(self.model)
        if locked:                  # a locked collection: look, not touch
            for item in list(self._items.values()) \
                    + list(self._part_items.values()):
                node = getattr(item, "node", None)
                if node is not None and \
                        part_collections.of(node) in locked:
                    item.setFlag(QGraphicsItem.ItemIsSelectable, False)
                    item.setFlag(QGraphicsItem.ItemIsMovable, False)
                    item.setCursor(Qt.ArrowCursor)
        from . import sketch_section
        for item in list(self._items.values()):
            # the model's edges a sketch closes with: shown, never picked
            # or dragged — clicks reach the region under it (the user
            # moved it, trying to make a region from the line)
            if sketch_section.is_section(getattr(item, "node", None)):
                item.setFlag(QGraphicsItem.ItemIsSelectable, False)
                item.setFlag(QGraphicsItem.ItemIsMovable, False)
                item.setAcceptedMouseButtons(Qt.NoButton)
                item.setCursor(Qt.ArrowCursor)
                for h in getattr(item, "handles", ()):
                    h.setVisible(False)

    def _rebuild_items_now(self):
        self.updating = True
        selected = {n.id for n in self.selected_nodes()}
        from . import view2d_edit
        view2d_edit.clear(self)                # frames take their shapes
        for item in list(self._items.values()) \
                + list(self._part_items.values()) \
                + self._highlight_items:
            if sip.isdeleted(item):            # went with its frame
                continue
            if item.scene() is self:
                self.removeItem(item)
        self._items.clear()
        self._part_items.clear()
        self._highlight_items = []

        # Sketch Mode (SolidWorks / Fusion): the model is painted behind
        # the sketch (sketch_backdrop) and only THAT sketch's shapes are
        # drawn — never a profile alone, a part's silhouette or another
        # plane's sketch
        flt = None
        if self.sketch_focus is not None:
            try:
                flt = self.sketch_focus()
            except Exception:
                flt = None
        focus = self._focus_shapes() if flt is None else []
        if focus:
            # profile-edit mode: the selected 2D profile is shown alone
            # and fully editable (drag points to resize, drag the shape
            # to move) in its own sketch coordinates, at any plane — so
            # a profile buried in a part can be reshaped from the 2D
            # view without opening the Top plane.
            # ... with the other shapes of the same profile (a polygon
            # and the circle a Difference cuts from it): shown with it,
            # the cut ones dashed — the circle was invisible (2026-10-21)
            focus_ids = {n.id for n in focus}
            from . import hide_show
            for node in _profile_shapes(focus):
                cls = _ITEM_CLASSES.get(node.type)
                if cls is None or (node.params.get("modifier") == "%"
                                   and not hide_show.shows_construction()):
                    continue
                item = cls(node, self)
                _construction_look(item, node)
                self.addItem(item)
                self._items[node.id] = item
                if _is_cut(node):
                    pen = QPen(item.pen())
                    pen.setStyle(Qt.DashLine)
                    item.setPen(pen)
                    if hasattr(item, "setBrush"):  # a line has no fill
                        item.setBrush(QBrush(Qt.NoBrush))
                    item.setToolTip(language.tr(
                        "{name} — cut away by the Difference").format(
                            name=node.name))
                if node.id in focus_ids:
                    item.setSelected(True)
                    self._apply_point_hl(item, node)
            self.updating = False
            return

        if flt is None and self._isolating():
            # show only the selected object(s), as their true projected
            # shape in the current plane
            seen = set()
            for node_id in self._highlight_ids:
                node = self.model.find(node_id)
                target = self._isolate_target(node) if node else None
                if target is None or target.id in seen:
                    continue
                seen.add(target.id)
                item = self._make_silhouette(target)
                if item is not None:
                    self.addItem(item)
                    self._part_items[target.id] = item
                    item.setSelected(True)
            self.updating = False
            return

        # the Object tab isolates the scene to the active Object: its
        # contents behave exactly like a small document of their own
        iso = self.isolation_resolver() if self.isolation_resolver \
            else None
        scope = iso if iso is not None else self.model.root
        if True:
            # sketch mode: individual 2D shapes are editable — every one
            # lying in the plane on show (a Front sketch in Front)
            from . import hide_show
            hide_cons = not hide_show.shows_construction()
            for node in scope.walk():
                if hide_cons and node.params.get("modifier") == "%":
                    continue          # Hide/Show Items: construction off
                if node.category == SHAPE_2D and \
                        node.type in _ITEM_CLASSES and \
                        self._branch_visible(node, stop=iso) and \
                        view2d_edit.on_view_plane(self, node) and \
                        (flt is None or flt.shows(self, node)):
                    item = _ITEM_CLASSES[node.type](node, self)
                    _construction_look(item, node)
                    # drawn through its rotate / move / scale, as in 3D
                    view2d_edit.add_shape(self, item, node)
                    self._items[node.id] = item
                    if node.id in selected:
                        item.setSelected(True)
                        self._apply_point_hl(item, node)
            # the area each Regions keeps, under its (outlined) shapes
            from . import region_area
            region_area.add_all(self, scope,
                                selected | set(self._highlight_ids),
                                shows=None if flt is None else
                                (lambda n: flt.shows(self, n)))
            # blue while a shape can move, black once held, red when
            # over defined (SolidWorks)
            from . import sketch_state
            sketch_state.apply(self, flt)
        # assembly mode: every top-level part gets a draggable outline
        # (in Sketch Mode the model's own picture is behind the sketch)
        for node in scope.children if flt is None else ():
            if node.visible and _produces_3d(node):
                item = self._make_part_item(node)
                if item is not None:
                    # under the sketch: drawn over it, the part hid the
                    # user's lines
                    item.setZValue(-2)
                    self.addItem(item)
                    self._part_items[node.id] = item
                    if node.id in selected:
                        item.setSelected(True)
        self.updating = False

    def _apply_point_hl(self, item, node):
        if self._point_hl[0] == node.id \
                and hasattr(item, "set_hot_vertex"):
            item.set_hot_vertex(self._point_hl[1])

    def set_point_highlight(self, node, index):
        """Highlight one polygon vertex in red — the point the user
        picked in the properties Points table."""
        self._point_hl = (node.id if node is not None else None, index)
        item = self._items.get(node.id) if node is not None else None
        if item is not None and hasattr(item, "set_hot_vertex"):
            item.set_hot_vertex(index)

    # ------------------------------------------------------- highlight
    def set_highlight(self, nodes):
        """Select these objects: a 3D part isolates in the 2D view
        (only it is shown, in its real projected shape); 2D sketch
        shapes just get selected in place."""
        self._highlight_ids = {n.id for n in nodes}
        self._point_hl = (None, -1)            # fresh selection, no point
        # selecting a single primitive jumps to the plane that shows its
        # size handles, so you land straight on the editable view
        if len(nodes) == 1:
            best = self._best_edit_plane(nodes[0])
            if best is not None and best != self.plane:
                self.plane = best
                self.plane_changed.emit(best)
        self.rebuild()

    def _isolate_target(self, node):
        """The object to show alone for *node*: the node itself if it
        makes 3D geometry, else the nearest ancestor part that does
        (so clicking a flange's profile or revolve shows the flange).
        Returns None for a bare top-level 2D sketch shape."""
        if node is None:
            return None
        if _produces_3d(node):
            return node
        stop = self.scope_root()
        probe = node.parent
        while probe is not None and probe is not stop:
            if _produces_3d(probe):
                return probe
            probe = probe.parent
        return None

    def _isolating(self) -> bool:
        """True when the selection is (or lives inside) a solid part we
        should show alone, rather than editing 2D sketch shapes."""
        return any(self._isolate_target(self.model.find(nid))
                   is not None for nid in self._highlight_ids)

    def _focus_shapes(self):
        """Selected 2D profiles that live *inside* a solid part — shown
        alone and directly editable in the sketch view, at any plane.
        Takes priority over isolating the 3D part they belong to. Bare
        top-level sketch shapes are left to normal sketch mode."""
        out, seen = [], set()
        for nid in self._highlight_ids:
            node = self.model.find(nid)
            if node is not None and node.category == SHAPE_2D \
                    and node.id not in seen \
                    and self._isolate_target(node) is not None:
                seen.add(node.id)
                out.append(node)
        return out

    def focus_shape_rect(self):
        """Scene bounds of the profile(s) in profile-edit mode, so the
        view can frame them; None when not editing a profile."""
        rect = None
        for node in self._focus_shapes():
            item = self._items.get(node.id)
            if item is None:
                continue
            box = item.sceneBoundingRect()
            rect = box if rect is None else rect.united(box)
        return rect

    def isolated_bounds(self):
        """Scene bounds of the object shown alone — a 3D part silhouette
        or an edited 2D profile — so the view can zoom to fit it on
        selection. None when the whole assembly is on screen."""
        if not (self._isolating() or self._focus_shapes()):
            return None
        rect = None
        for item in list(self._part_items.values()) \
                + list(self._items.values()):
            box = item.sceneBoundingRect()
            rect = box if rect is None else rect.united(box)
        return rect

    def _make_silhouette(self, node):
        """The selected node's real projected outline in the current
        plane — the union of its projected triangles, so concavities
        and bores show and the shape is correctly oriented."""
        from . import mesh as mesh_mod
        (ai, bi), _keys = PLANES[self.plane]
        dims = self._dim_handles(node)
        editable = node.type in ("cylinder", "cube", "sphere")
        if editable:
            # an editable primitive: show a SINGLE instance (its own mesh
            # through the first-iteration world transform), so a bolt hole
            # inside a for-loop reads as one editable cylinder, not every
            # copy — and it lines up with the size handles.
            mat = self._world_matrix(node)
            local = mesh_mod.tessellate(node, self.env_for(node),
                                        fn=self.model.effective_fn())
            tris = [tuple(mesh_mod.transform_point(mat, v) for v in tri)
                    for tri in local]
        else:
            # a low-detail tessellation keeps the silhouette light; the
            # winding-fill union of the projected triangles is the real
            # filled shape (holes and concavities included), built
            # instantly — no simplify() (it explodes on helical threads).
            with self.scope_frame():
                tris = mesh_mod.selected_world_tris(
                    self.scope_root(), {node.id}, detail=OUTLINE_DETAIL,
                    fn=self.model.effective_fn())
        path = self._projected_path(tris)
        if path is None:
            return None
        if editable:
            path = path.simplified()           # crisp outline like a shape
        # A selected part is draggable when the move has somewhere to
        # go: a node that carries its own position (a Move/translate, a
        # Group, an Object or an instance) takes it directly at any
        # depth — highlight a Move and you can drag it in the plane —
        # and a top-level part gets a translate wrapped round it.
        # Only what the SELECTED node can do (2026-10-19, the user: "a
        # rotate can only rotate, a translate only translate"): a node
        # carrying its own position moves, and so does a solid placed at
        # the top level; a Rotate, an extrude, a boolean... does not —
        # dragging one used to wrap it in a new Move.
        movable = (node.type in MOVABLE_TYPES
                   or (node.parent is self.scope_root()
                       and node.type not in OWN_EDIT_TYPES))
        return PartItem(node, self, path, node.name, movable=movable,
                        dashed=False, dims=dims, blue=editable)

    def _projected_path(self, tris):
        """The real filled outline of *tris* in the current plane — the
        winding-fill union of the projected triangles, so concavities
        and bores show. None when there is nothing to draw."""
        if not tris:
            return None
        (ai, bi), _keys = PLANES[self.plane]
        path = QPainterPath()
        path.setFillRule(Qt.WindingFill)
        for tri in tris:
            p0, p1, p2 = ((v[ai], v[bi]) for v in tri)
            # a closed solid's front and back faces project with
            # opposite winding and would cancel under WindingFill, so
            # force every projected triangle the same way (CCW) — then
            # the union fills solidly into the true silhouette
            area = ((p1[0] - p0[0]) * (p2[1] - p0[1])
                    - (p2[0] - p0[0]) * (p1[1] - p0[1]))
            pts = (p0, p1, p2) if area >= 0 else (p0, p2, p1)
            path.addPolygon(QPolygonF([QPointF(x, y) for x, y in pts]))
        return path

    def _world_matrix(self, node):
        """4x4 transform mapping *node*'s local coordinates to the
        frame **this view draws in** — the product of its ancestor
        transforms up to the scope root (exclusive), with expressions
        resolved (loop vars at their first value). A Group, Object or
        instance is a transform too: it carries its own placement
        (x/y/z + rx/ry/rz), exactly as the tessellator applies it.

        Stopping at the scope root is what keeps the drag honest: the
        Object tab shows an Object at its own origin, so its assembly
        placement must not enter the mapping. In Main the scope root
        is the document root and nothing is skipped."""
        from . import mesh as mesh_mod
        stop = self.scope_root()
        chain = []
        probe = node.parent
        while probe is not None and probe is not stop:
            chain.append(probe)
            probe = probe.parent
        mat = mesh_mod.mat_identity()
        builders = dict(translate=mesh_mod.mat_translate,
                        rotate=mesh_mod.mat_rotate,
                        scale=mesh_mod.mat_scale,
                        mirror=mesh_mod.mat_mirror)
        for anc in reversed(chain):                # root .. parent order
            # only the placement params, resolved one by one: rp() walks
            # EVERY param, and a part's "anchors" list is not points
            if anc.type in builders:
                default = 1.0 if anc.type == "scale" else 0.0
                x, y, z = self._placement(anc, ("x", "y", "z"), default)
                px, py, pz = self._placement(anc, ("px", "py", "pz"))
                mat = mesh_mod.mat_mul(mat, mesh_mod.transform_mat(
                    anc.type, dict(x=x, y=y, z=z, px=px, py=py, pz=pz)))
            elif anc.type in ("union", "component", "reference"):
                x, y, z = self._placement(anc, ("x", "y", "z"))
                rx, ry, rz = self._placement(anc, ("rx", "ry", "rz"))
                mat = mesh_mod.mat_mul(mat, mesh_mod.mat_mul(
                    mesh_mod.mat_translate(x, y, z),
                    mesh_mod.mat_rotate(rx, ry, rz)))
        return mat

    def _placement(self, node, keys, default=0.0):
        env = self.env_for(node)
        return [expr.resolve(node.params.get(key, default), env, default)
                for key in keys]

    def _best_edit_plane(self, node):
        """The assembly plane that exposes the most editable size handles
        for a selected primitive, so selecting e.g. a Z-cylinder jumps to
        a side view where its height *and* radius are draggable rather
        than a plane where it is just a bare circle."""
        if node is None or node.type not in ("cylinder", "cube", "sphere",
                                             "linear_extrude"):
            return None
        counts = {pl: len(self._dim_handles(node, plane=pl))
                  for pl in PLANES}
        if not any(counts.values()):
            return None
        # most handles wins; keep the current plane on a tie (no churn)
        return max(PLANES, key=lambda pl: (counts[pl], pl == self.plane))

    def _dim_handles(self, node, plane=None):
        """Editable size handles for a 3D primitive in the current plane
        — cylinder radii + height, cube sides, sphere radius — mapped
        through the node's ancestor transforms so a drag in the plane
        changes the right parameter. Handles whose axis points along the
        view direction (invisible here) are dropped."""
        from . import mesh as mesh_mod
        if node.type not in ("cylinder", "cube", "sphere",
                             "linear_extrude"):
            return []
        (ai, bi), _keys = PLANES[plane or self.plane]
        env = self.env_for(node)
        mat = self._world_matrix(node)

        def val(key, default=0.0):
            return expr.resolve(node.params.get(key, default), env,
                                default)

        def project(p):                            # local point -> 2D
            w = mesh_mod.transform_point(mat, p)
            return QPointF(w[ai], w[bi])

        def direction(d):                          # local dir -> 2D vec
            w = (mat[0][0] * d[0] + mat[0][1] * d[1] + mat[0][2] * d[2],
                 mat[1][0] * d[0] + mat[1][1] * d[1] + mat[1][2] * d[2],
                 mat[2][0] * d[0] + mat[2][1] * d[1] + mat[2][2] * d[2])
            return (w[ai], w[bi])

        px, py, pz = val("x"), val("y"), val("z")
        center = bool(node.params.get("center"))
        out = []

        def add(role, param, anchor3, dir3, mag, factor):
            ax = direction(dir3)
            if ax[0] * ax[0] + ax[1] * ax[1] < 1e-9:
                return                             # edge-on in this plane
            anchor = project(anchor3)
            out.append(dict(
                role=role, param=param, anchor=anchor, axis=ax,
                factor=factor, minval=0.1, value=mag * factor,
                tip=QPointF(anchor.x() + ax[0] * mag,
                            anchor.y() + ax[1] * mag)))

        if node.type == "linear_extrude":
            from .view2d_edit import extrude_dims
            extrude_dims(self, node, plane, add, val, direction)
        elif node.type == "cylinder":
            h = val("height")
            z0 = pz - (h / 2 if center else 0.0)
            z1 = z0 + h
            # radius direction most visible in this plane
            radial = max(((1, 0, 0), (0, 1, 0)),
                         key=lambda d: sum(c * c for c in direction(d)))
            add("radius_bottom", "radius_bottom", (px, py, z0), radial,
                val("radius_bottom"), 1.0)
            add("radius_top", "radius_top", (px, py, z1), radial,
                val("radius_top"), 1.0)
            add("height", "height", (px, py, z0), (0, 0, 1), h, 1.0)
        elif node.type == "sphere":
            radial = max(((1, 0, 0), (0, 1, 0), (0, 0, 1)),
                         key=lambda d: sum(c * c for c in direction(d)))
            add("radius", "radius", (px, py, pz), radial,
                val("radius"), 1.0)
        else:                                       # cube
            w, d, hh = val("width"), val("depth"), val("height")
            if center:
                # grows symmetrically about the centre: dragging a face
                # by t changes the dimension by 2t
                add("width", "width", (px, py, pz), (1, 0, 0), w / 2, 2.0)
                add("depth", "depth", (px, py, pz), (0, 1, 0), d / 2, 2.0)
                add("height", "height", (px, py, pz), (0, 0, 1),
                    hh / 2, 2.0)
            else:
                # anchored at its min corner: drag the far face, the
                # dimension is just the distance to it
                cx, cy, cz = px + w / 2, py + d / 2, pz + hh / 2
                add("width", "width", (px, cy, cz), (1, 0, 0), w, 1.0)
                add("depth", "depth", (cx, py, cz), (0, 1, 0), d, 1.0)
                add("height", "height", (cx, cy, pz), (0, 0, 1), hh, 1.0)
        return out

    def _make_part_item(self, node):
        """One draggable outline for a part in the assembly view. It is
        the part's **real projected shape**, not a convex hull of it: a
        cross tube used to read as an octagon and a flange as a plain
        rectangle, so the 2D view looked nothing like the 3D one. The
        tessellation is capped to a low detail, which keeps the path
        cheap enough to rebuild on every change.

        It is painted in the part's **own colours**, faces ordered far
        -> near along the viewing axis (`planview.plan_faces`): one flat
        translucent fill made a house a single tan rectangle. A floor the
        House Builder built is cut like a floor plan in the Top view
        (`_plan_cut`), so its rooms show rather than its roof."""
        from . import mesh as mesh_mod
        from . import planview
        colored = mesh_mod.tessellate_colored(
            node, self.env_for(node), fn=self.model.effective_fn(),
            detail=OUTLINE_DETAIL)
        cut = self._plan_cut(node, colored)
        if cut is not None:
            colored = [(t, c) for t, c in colored
                       if min(v[2] for v in t) < cut]
        if not colored:
            return None
        key = (self.plane, _fingerprint(colored))
        hit = _PART_SHAPES.get(key)
        if hit is None:
            tris = [t for t, _c in colored]
            hit = (self._projected_path(tris),
                   planview.plan_faces(colored, self.plane))
            if len(_PART_SHAPES) >= PART_SHAPE_CACHE:
                _PART_SHAPES.pop(next(iter(_PART_SHAPES)))
            _PART_SHAPES[key] = hit
        return PartItem(node, self, hit[0], node.name, faces=hit[1])

    def _plan_cut(self, node, colored):
        """The z a House Builder floor is cut at when seen from the Top
        (its slab top + `house.PLAN_CUT`), or None for anything else —
        an ordinary part is seen whole, roof and all."""
        house = getattr(self.model, "house", None) or {}
        if self.plane != "Top (XY)" or not colored or \
                node.type != "component" or \
                node.name not in (house.get("objects") or []):
            return None
        floor = next((f for f in house.get("floors") or []
                      if f.get("name") == node.name), None)
        if floor is None:
            return None                     # the Garden: nothing over it
        from .house import PLAN_CUT, SLAB_THICKNESS
        slab = float(floor.get("slab_thickness", SLAB_THICKNESS))
        bottom = min(v[2] for t, _c in colored for v in t)
        return bottom + slab + PLAN_CUT

    def _anchor_snap(self, node, delta):
        """Magnetic assembly snap: if dropping *node* puts one of its
        anchors within a few pixels of another Object's anchor (in the
        current plane), adjust the move so they land exactly on each
        other."""
        from . import anchors as anc
        views = self.views()
        ppm = views[0].px_per_mm() if views else 4.0
        tol = 10.0 / max(ppm, 1e-6)
        (ai, bi), _keys = PLANES[self.plane]
        env = anc.doc_env(self.model)
        fn = self.model.effective_fn()
        mine = anc.world_markers(node, env=env, fn=fn)
        targets = []
        for other in self.model.components():
            if other is not node and other.visible:
                targets.extend(anc.world_markers(other, env=env, fn=fn))
        best = None
        for marker in mine:
            mx = marker["pos"][ai] + delta.x()
            my = marker["pos"][bi] + delta.y()
            for target in targets:
                d = ((target["pos"][ai] - mx) ** 2
                     + (target["pos"][bi] - my) ** 2) ** 0.5
                if d < tol and (best is None or d < best[0]):
                    best = (d, target["pos"][ai] - marker["pos"][ai],
                            target["pos"][bi] - marker["pos"][bi])
        if best is not None:
            return QPointF(best[1], best[2])
        return delta

    def commit_part_move(self, node, delta):
        """A part outline was dropped: bake the move into the object.
        Translate nodes and Groups carry their own position, so those
        are edited in place; anything else is wrapped in a translate.
        Objects snap anchor-to-anchor, and dragging a mated Object
        detaches it (the drag is the user taking control back)."""
        if abs(delta.x()) < 1e-9 and abs(delta.y()) < 1e-9:
            return
        from .mates import detach, mate_of, slide_to
        # a snapped part is driven by its mate, which re-solves on every
        # change and would overwrite the drop before it reached the
        # screen — the drag is the user taking control back. A
        # concentric mate is the exception: the part is free along its
        # axis, so the drop becomes its new slide (see below)
        slides = (mate_of(node) or {}).get("kind") == "concentric"
        if mate_of(node) is not None and not slides:
            detach(self.model, node)
        else:
            # ...but a mate on an ANCESTOR still holds: moving content
            # inside a snapped part shifts that part's anchors, so the
            # mate re-solves and slides it back. Nothing appears to
            # move, which reads as a broken drag unless we say why.
            stop, probe = self.scope_root(), node.parent
            while probe is not None and probe is not stop:
                if mate_of(probe) is not None:
                    self.status.emit(
                        f"{probe.name} is snapped to "
                        f"{mate_of(probe)['parent']}, so it follows that "
                        f"mate — detach it to move this freely.")
                    break
                probe = probe.parent
        if node.type == "component" and self.snap_enabled:
            delta = self._anchor_snap(node, delta)
        move = self._local_move(node, delta)
        # a Move, Group, Object or Linked copy carries its own position
        if node.type in MOVABLE_TYPES:
            env = self.env_for(node)
            for key, value in zip(("x", "y", "z"), move):
                if abs(value) < 1e-9:
                    continue
                node.params[key] = round(
                    expr.resolve(node.params.get(key, 0.0), env, 0.0)
                    + value, 4)
            if slides:
                slide_to(self.model, node, env)   # keep the mate, slid
            self.model.node_changed.emit(node)
            return
        parent, index = node.parent, node.index()
        wrapper = CadNode("translate",
                          self.model.unique_name("translate"),
                          {key: round(value, 4)
                           for key, value in zip(("x", "y", "z"), move)
                           if abs(value) > 1e-9})
        wrapper.name = f"Position ({node.name})"
        parent.remove(node)
        wrapper.add(node)
        parent.add(wrapper, index)
        self.model.structure_changed.emit()

    def _local_move(self, node, delta):
        """A drag is measured in *world* mm in the current plane, but a
        node's move params live in its **parent's** frame: under a
        rotated or mirrored ancestor the two are different directions.
        Map the world delta through the inverse of the ancestor chain's
        linear part, so dragging a Move inside a rotated group follows
        the cursor instead of shooting off sideways. Returns the delta
        as (dx, dy, dz) in the node's own frame."""
        (ai, bi), _keys = PLANES[self.plane]
        world = [0.0, 0.0, 0.0]
        world[ai] = delta.x()
        world[bi] = delta.y()
        mat = self._world_matrix(node)
        inverse = _invert3([[mat[r][c] for c in range(3)]
                            for r in range(3)])
        if inverse is None:                    # degenerate: best effort
            return tuple(world)
        return tuple(sum(inverse[r][c] * world[c] for c in range(3))
                     for r in range(3))

    @staticmethod
    def _branch_visible(node, stop=None):
        """Effective visibility; *stop* (exclusive) lets the isolated
        Object view ignore the Object's own Main-tab visibility."""
        while node is not None and node is not stop:
            if not node.visible:
                return False
            node = node.parent
        return True

    def _node_changed(self, node):
        if node.is_container() and self.mouseGrabberItem() is not None:
            # a handle on a rotate / extrude is being dragged: re-place
            # in place, never rebuild under the cursor
            from . import view2d_edit
            view2d_edit.live_update(self)
            return
        if node.is_container():
            # A group's visibility change affects every descendant.
            self.rebuild()
            return
        item = self._items.get(node.id)
        if item is not None and self.mouseGrabberItem() is not None:
            # a handle of THIS shape is held (a circle dragged by its
            # centre on the Front plane): follow the mouse now — the
            # rebuild waits for the release, so it only moved then
            self.updating = True
            item.apply_node()
            self.updating = False
            self.update()
            return
        if node.id in {n.id for n in self._focus_shapes()}:
            # editing the isolated profile: update it in place so an
            # in-progress point drag is never torn down by a rebuild
            if item is not None:
                self.updating = True
                item.apply_node()
                self.updating = False
            else:
                self.rebuild()
            return
        if self._in_part(node):
            if self.mouseGrabberItem() is not None:
                self._part_dirty = True        # refresh after the drag
            else:
                self.rebuild()                 # part outline changed
            return
        should_show = (self.plane == "Top (XY)"
                       and node.category == SHAPE_2D
                       and self._branch_visible(node))
        if (item is not None) != should_show:
            self.rebuild()
        elif item is not None:
            self.updating = True
            item.apply_node()
            self.updating = False
            self.update()                # auto dims track a live resize

    def _in_part(self, node) -> bool:
        probe = node
        while probe is not None:
            if probe.id in self._part_items:
                return True
            probe = probe.parent
        return False

    #: ms between model updates while a shape is dragged: each one runs
    #: the whole after-edit chain (constraints, references, 3D, code), and
    #: one per mouse move made a rectangle crawl (2026-11-12, the user)
    DRAG_EMIT_MS = 100

    def push_move(self, item):
        self.updating = True
        model = self.model
        dragging = self.mouseGrabberItem() is not None
        if dragging:
            model.blockSignals(True)     # params now, the signal later
        try:
            item.push_pos()
        finally:
            if dragging:
                model.blockSignals(False)
        item.apply_node()
        self.updating = False
        if dragging:
            self._drag_nodes = getattr(self, "_drag_nodes", None) or []
            if item.node not in self._drag_nodes:
                self._drag_nodes.append(item.node)
            if not getattr(self, "_drag_timer_on", False):
                self._drag_timer_on = True
                QTimer.singleShot(self.DRAG_EMIT_MS, self._flush_drag)

    def _flush_drag(self):
        """The dragged shapes' model update (throttled; the last one on
        release)."""
        self._drag_timer_on = False
        nodes, self._drag_nodes = getattr(self, "_drag_nodes", None) or [], []
        for n in nodes:
            try:
                self.model.node_changed.emit(n)
            except RuntimeError:
                pass

    def selected_nodes(self):
        return [item.node for item in self.selectedItems()
                if isinstance(item, (ShapeItem, PartItem))]

    def emit_selection(self):
        """Report the selection on the **next event-loop turn**.

        This runs from an item's `itemChange` while Qt is still inside
        `QGraphicsItem::mousePressEvent`; listeners call `set_highlight`,
        which rebuilds the scene and frees the item being clicked — Qt
        then touched the freed item and the process segfaulted (clicking
        a House Builder floor in the 2D view). Coalesced, so a
        clearSelection + select pair reports once."""
        if getattr(self, "_selection_pending", False):
            return
        self._selection_pending = True
        QTimer.singleShot(0, self._flush_selection)

    def _flush_selection(self):
        self._selection_pending = False
        self.selection_changed.emit(self.selected_nodes())

    def select_nodes(self, nodes):
        self.updating = True
        self.clearSelection()
        for node in nodes:
            item = self._items.get(node.id) \
                or self._part_items.get(node.id)
            if item:
                item.setSelected(True)
        self.updating = False

    def _item_under(self, scene_pos):
        """Top-most item under *scene_pos* (handles included), or None
        for genuinely empty space. Uses the view transform so
        constant-size handles hit-test correctly."""
        views = self.views()
        if views:
            return self.itemAt(scene_pos, views[0].transform())
        hits = self.items(scene_pos)
        return hits[0] if hits else None

    def _isolated(self) -> bool:
        """True while a single object is shown alone — a 3D part
        silhouette or a 2D profile in edit mode."""
        return self._isolating() or bool(self._focus_shapes())

    # ------------------------------------------------------------ tools
    def mousePressEvent(self, event):
        if self.tool in (MEASURE, DIMENSION) \
                and event.button() == Qt.LeftButton:
            pt, _ = self.snap_feature(event.scenePos())
            if self._measure_a is None or self._measure_b is not None:
                self._measure_a = self._measure_cursor = pt   # (re)start
                self._measure_b = None
            else:
                self._measure_b = pt                          # finish
                self._emit_measure(self._measure_a, self._measure_b)
                if self.tool == DIMENSION:                    # keep it
                    self.model.add_dimension(
                        (self._measure_a.x(), self._measure_a.y()),
                        (self._measure_b.x(), self._measure_b.y()),
                        self.plane)
                    self._measure_a = self._measure_b = None
                    self._measure_cursor = None
            self.update()
            event.accept()
            return
        if self.tool == LINE:
            from . import sketch_line        # SolidWorks-style, chained
            sketch_line.press(self, event)
            return
        if self.tool == POLYGON and event.button() == Qt.LeftButton:
            from . import sketch_line
            start = self._poly_points[-1] if self._poly_points else None
            pt, info = sketch_line.snap(self, event.scenePos(), start)
            self._poly_flags = getattr(self, "_poly_flags", [])
            if start is not None:
                self._poly_flags.append(info.get("angle"))
            else:
                self._poly_flags = []
            self._poly_snapped = pt
        pos = self.snap(event.scenePos())
        if self.tool == POLYGON and event.button() == Qt.LeftButton:
            pos = self._poly_snapped
        if self._click_mode and self._draft is not None:
            if event.button() == Qt.LeftButton:
                self._finish_draft(pos)        # the second click
                self._swallow_release = True
            else:
                self.drop_drafts()             # right-click: never mind
            event.accept()
            return
        from . import sketch_tools, sketch_constrain_ui
        if sketch_tools.handles(self.tool):
            sketch_tools.press(self, event)
            return
        if sketch_constrain_ui.handles(self.tool):
            sketch_constrain_ui.press(self, event)
            return
        from . import sketch_modify
        if sketch_modify.handles(self.tool):
            sketch_modify.press(self, event)
            return
        if self.tool == POLYGON and event.button() == Qt.RightButton:
            if len(self._poly_points) >= 3:
                self.finish_polygon()             # right-click finishes
            elif self._poly_points:
                self.status.emit(language.tr(
                    "A polygon needs at least 3 points — keep clicking, or "
                    "Esc to cancel."))
            event.accept()
            return
        if event.button() != Qt.LeftButton or self.tool == SELECT:
            if (self.tool == SELECT and event.button() == Qt.LeftButton
                    and self._isolated()
                    and self._item_under(event.scenePos()) is None):
                # while a part or profile is isolated, empty-space clicks
                # must not clear the selection — you deselect from the
                # object tree only. Clicks on the shape (or its resize
                # handles) still fall through to super() so it stays
                # editable and draggable.
                event.accept()
                return
            super().mousePressEvent(event)
            return
        if self.tool == LINE:
            self._draft_start = pos
            self._draft = self.addLine(pos.x(), pos.y(), pos.x(), pos.y(),
                                       _pen("#2176c7"))
        elif self.tool == RECT:
            self._draft_start = pos
            self._draft = self.addRect(QRectF(pos, pos), _pen("#2176c7"))
        elif self.tool == CIRCLE:
            self._draft_start = pos
            self._draft = self.addEllipse(QRectF(pos, pos),
                                          _pen("#2176c7"))
        elif self.tool == POLYGON:
            from . import polygon_draw
            if polygon_draw.near_first(self, event.scenePos()):
                self.finish_polygon()          # back on the first point
                event.accept()
                return
            if not self._poly_points:
                self.status.emit(language.tr(
                    "Polygon: click to add points; finish by clicking the "
                    "first point, right-click, Enter or Finish below. "
                    "Backspace takes a point back, Esc cancels."))
            self._poly_points.append(pos)
            self._update_poly_draft(pos)
            self.polygon_changed.emit(len(self._poly_points))
        elif self.tool == TEXT:
            node = self._create("text", dict(x=pos.x(), y=pos.y()))
            self.node_created.emit(node)
        event.accept()

    def mouseMoveEvent(self, event):
        if getattr(self, "tool", SELECT) not in (SELECT, MEASURE) and \
                not event.buttons():
            # hovering with a drawing tool: show what it would snap to
            # (the marker; the user saw no sign of snapping)
            try:
                self.snap(event.scenePos())
            except Exception:
                pass
        if self.tool in (MEASURE, DIMENSION):
            if self._measure_a is not None and self._measure_b is None:
                pt, _ = self.snap_feature(event.scenePos())
                self._measure_cursor = pt
                self._emit_measure(self._measure_a, pt)
                self.update()
            event.accept()
            return
        from . import sketch_tools
        from . import sketch_constrain_ui as _scu
        if self.tool == _scu.DELETE:
            _scu.delete_move(self, event)
            event.accept()
            return
        if self.tool == _scu.DIMENSION:
            _scu.hover(self, event)          # what a click would pick
        if _scu.handles(self.tool) and self.tool != _scu.DIMENSION:
            _scu.hover(self, event)
            event.accept()
            return
        if sketch_tools.handles(self.tool):
            sketch_tools.move(self, event)
            return
        if self.tool == "sk_trim":
            from . import sketch_modify, sketch_trim
            if sketch_modify.power_move(self, event):
                event.accept()
                return
            sketch_trim.hover_2d(self, event.scenePos())
        if self.tool in ("sk_fillet", "sk_chamfer"):
            from . import sketch_corner
            sketch_corner.hover_2d(self, event.scenePos())
        if self.tool == LINE:
            from . import sketch_line
            sketch_line.move(self, event)
            return
        pos = self.snap(event.scenePos())
        if self.tool == POLYGON and self._poly_points:
            from . import sketch_line
            start = self._poly_points[-1]
            pos, info = sketch_line.snap(self, event.scenePos(), start)
            self._update_poly_draft(pos)
            sketch_line.draw_overlay(self, start, pos, info)
            event.accept()
            return
        if self._draft is not None and self._draft_start is not None:
            start = self._draft_start
            if self.tool == LINE:
                self._draft.setLine(start.x(), start.y(),
                                    pos.x(), pos.y())
                length = ((pos.x() - start.x()) ** 2 +
                          (pos.y() - start.y()) ** 2) ** 0.5
                self.measure_changed.emit(
                    f"length: {length:.1f} {self.unit()}   "
                    f"Δ {pos.x() - start.x():.1f}, "
                    f"{pos.y() - start.y():.1f} {self.unit()}")
            elif self.tool == RECT:
                rect = QRectF(start, pos).normalized()
                self._draft.setRect(rect)
                self.measure_changed.emit(
                    f"{rect.width():.1f} × {rect.height():.1f} "
                    f"{self.unit()}")
            elif self.tool == CIRCLE:
                radius = ((pos.x() - start.x()) ** 2 +
                          (pos.y() - start.y()) ** 2) ** 0.5
                radius = self._tangent_radius(start, radius)
                self._draft.setRect(start.x() - radius,
                                    start.y() - radius,
                                    2 * radius, 2 * radius)
                self.measure_changed.emit(
                    f"r = {radius:.1f} {self.unit()}   "
                    f"Ø {2 * radius:.1f} {self.unit()}")
            event.accept()
            return
        if self.tool == POLYGON and self._poly_points:
            self._update_poly_draft(pos)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        try:
            self._release(event)
        finally:
            self._after_release()

    def _release(self, event):
        from . import sketch_tools
        self._power_last = None            # a power-trim stroke ends
        if sketch_tools.handles(self.tool):
            sketch_tools.release(self, event)
            return
        if self._swallow_release:              # the click that ended it
            self._swallow_release = False
            event.accept()
            return
        if self._click_mode:                   # still following the cursor
            event.accept()
            return
        if self._draft is None or self._draft_start is None:
            super().mouseReleaseEvent(event)
            if self._part_dirty and self.mouseGrabberItem() is None:
                self._part_dirty = False
                self.rebuild()
            return
        pos = self.snap(event.scenePos())
        from .polygon_draw import px_to_scene
        moved = ((event.scenePos().x() - event.buttonDownScenePos(
            Qt.LeftButton).x()) ** 2 + (event.scenePos().y()
                                        - event.buttonDownScenePos(
                Qt.LeftButton).y()) ** 2) ** 0.5
        if moved < px_to_scene(self, 4.0):
            # a click, not a drag: the shape follows the cursor and the
            # next click ends it, as in Fusion and SolidWorks (dragging
            # still works). A click used to make a zero-size shape that
            # was thrown away, so nothing at all appeared.
            self._click_mode = True
            self.status.emit(language.tr(
                "Click again where the {shape} should end — or drag next "
                "time. Esc or right-click cancels.").format(
                    shape=language.tr({LINE: "line", RECT: "rectangle",
                                       CIRCLE: "circle"}.get(self.tool,
                                                             "shape"))))
            event.accept()
            return
        self._finish_draft(pos)
        event.accept()

    def _finish_draft(self, pos):
        """Turn the line / rectangle / circle being drawn from
        `_draft_start` to *pos* into a node."""
        start = self._draft_start
        if self._draft is not None and self._draft.scene() is self:
            self.removeItem(self._draft)
        self._draft = None
        self._draft_start = None
        self._click_mode = False
        node = None
        # too small to be meant: a few PIXELS, not half a millimetre — on
        # a part a millimetre across every shape was thrown away and
        # nothing could be drawn (2026-11-10, the user's 0.84 mm face)
        from .polygon_draw import px_to_scene
        tiny = min(0.5, px_to_scene(self, 3.0))
        if self.tool == LINE and (pos - start).manhattanLength() > tiny:
            node = self._create("line", dict(
                x1=start.x(), y1=start.y(), x2=pos.x(), y2=pos.y()))
        elif self.tool == RECT:
            rect = QRectF(start, pos).normalized()
            if rect.width() > tiny and rect.height() > tiny:
                node = self._create("rect", dict(
                    x=rect.x(), y=rect.y(),
                    width=rect.width(), height=rect.height()))
        elif self.tool == CIRCLE:
            radius = ((pos.x() - start.x()) ** 2 +
                      (pos.y() - start.y()) ** 2) ** 0.5
            radius = self._tangent_radius(start, radius)
            target = getattr(self, "_circle_tangent", None)
            self._circle_tangent = None
            if radius > tiny:
                node = self._create("circle", dict(
                    x=start.x(), y=start.y(), radius=radius))
                from . import circle_snap      # touching what it snapped to
                circle_snap.tie(self.model, node, target)
        if node is not None:
            self.node_created.emit(node)

    def mouseDoubleClickEvent(self, event):
        from . import sketch_tools
        if self.tool == LINE:
            from . import sketch_line
            sketch_line.double_click(self, event)
            return
        if sketch_tools.handles(self.tool):
            sketch_tools.double_click(self, event)
            return
        if self.tool == POLYGON and len(self._poly_points) >= 3:
            self.finish_polygon()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def _update_poly_draft(self, cursor):
        from . import polygon_draw
        self._clear_poly_items()
        if not self._poly_points:
            return
        for path, pen, fill in polygon_draw.draft_items(self, cursor):
            item = self.addPath(path, pen)
            if fill is not None:
                item.setBrush(fill)
            item.setZValue(1e6)
            item.setAcceptedMouseButtons(Qt.NoButton)
            self._poly_items.append(item)

    def _clear_poly_items(self):
        for item in self._poly_items:
            if item.scene() is self:
                self.removeItem(item)
        self._poly_items = []

    def undo_polygon_point(self):
        """Take the last polygon point back (Backspace, the bar)."""
        if not self._poly_points:
            return
        self._poly_points.pop()
        flags = getattr(self, "_poly_flags", [])
        if flags:
            flags.pop()
        cursor = self._poly_points[-1] if self._poly_points else None
        if cursor is None:
            self._clear_poly_items()
        else:
            self._update_poly_draft(cursor)
        self.polygon_changed.emit(len(self._poly_points))

    def drop_drafts(self):
        """Throw away whatever is half drawn — a polygon's points and
        rubber band, a line / rectangle / circle being dragged. Changing
        tool or plane does this: before, the half-drawn shape's line
        stayed on the sketch as a dead line nothing could select or
        delete, and the points came back with the polygon tool."""
        from . import sketch_tools, sketch_constrain_ui
        sketch_tools.drop(self)
        sketch_constrain_ui.drop(self)
        from . import sketch_modify
        sketch_modify.drop(self)
        from . import sketch_line
        sketch_line.drop(self)
        self._poly_flags = []
        had = bool(self._poly_points)
        self._poly_points = []
        self._clear_poly_items()
        if self._draft is not None:
            if self._draft.scene() is self:
                self.removeItem(self._draft)
            self._draft = None
        self._draft_start = None
        self._click_mode = False
        if had:
            self.polygon_changed.emit(0)

    def finish_polygon(self):
        points = self._poly_points
        self._poly_points = []
        self._clear_poly_items()
        self.polygon_changed.emit(0)
        if len(points) < 3:
            return
        origin = points[0]
        node = self._create("polygon", dict(
            x=origin.x(), y=origin.y(),
            points=[[p.x() - origin.x(), p.y() - origin.y()]
                    for p in points]))
        self.node_created.emit(node)
        from . import sketch_line
        flags = list(getattr(self, "_poly_flags", []))
        # the closing side: H / V if it happens to be exactly so
        a, b = points[-1], points[0]
        flags.append("h" if abs(a.y() - b.y()) < 1e-6 else
                     "v" if abs(a.x() - b.x()) < 1e-6 else None)
        sketch_line.polygon_relations(self.model, node, flags)
        self._poly_flags = []
        sketch_line.end_chain(self)

    def cancel_tool(self):
        self.drop_drafts()
        self.clear_measure()

    def delete_selection(self):
        for node in self.selected_nodes():
            self.model.remove_node(node)


# ------------------------------------------------------------------- view

class SketchView(QGraphicsView):
    """Y-up graphics view with grid, pan and zoom."""

    cursor_moved = pyqtSignal(QPointF)
    clipboard_op = pyqtSignal(str)          # "cut" | "copy" | "paste"
    zoom_changed = pyqtSignal(float)        # pixels per mm
    step_object = pyqtSignal(int)           # +1 next / -1 previous

    def __init__(self, scene: SketchScene, parent=None):
        super().__init__(scene, parent)
        self.setRenderHints(QPainter.Antialiasing)
        self.setMouseTracking(True)
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        # dimension/measure overlays are drawn at viewport-fixed positions
        # that move with the shape; repaint the whole viewport each change
        # so old labels are erased rather than smeared into ghost trails.
        self.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.scale(4, -4)                     # Y up, sensible start zoom
        self.centerOn(30, 20)
        from . import polygon_draw
        polygon_draw.attach(self)              # Finish / Undo / Cancel bar

    def px_per_mm(self) -> float:
        """Pixels per model unit (a millimetre unless the document says
        otherwise)."""
        return abs(self.transform().m11())

    def _unit(self) -> str:
        scene = self.scene()
        return scene.unit() if hasattr(scene, "unit") else "mm"

    # ------------------------------------------------ middle-button pan
    def mouseDoubleClickEvent(self, event):
        """With the Select tool: zoom in on the spot, and back out on the
        next double-click (view_anim)."""
        scene = self.scene()
        if event.button() == Qt.LeftButton and \
                getattr(scene, "tool", SELECT) == SELECT:
            from . import view_anim
            view_anim.toggle_2d(self, self.mapToScene(event.pos()))
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            from . import dim_edit
            if dim_edit.press(self, event.pos()):
                event.accept()
                return
        if event.button() == Qt.MiddleButton:
            self._pan_last = event.pos()
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if getattr(self, "_pan_last", None) is not None:
            delta = event.pos() - self._pan_last
            self._pan_last = event.pos()
            h = self.horizontalScrollBar()
            v = self.verticalScrollBar()
            h.setValue(h.value() - delta.x())
            v.setValue(v.value() - delta.y())
            event.accept()
            return
        from . import dim_edit
        if dim_edit.move(self, event.pos()):
            event.accept()
            return
        self.cursor_moved.emit(self.mapToScene(event.pos()))
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            from . import dim_edit
            if dim_edit.release(self, event.pos()):
                event.accept()
                return
        if event.button() == Qt.MiddleButton and \
                getattr(self, "_pan_last", None) is not None:
            self._pan_last = None
            self.setCursor(Qt.CrossCursor if self.scene().tool != SELECT
                           else Qt.ArrowCursor)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def set_tool(self, tool):
        scene = self.scene()
        if tool == DIMENSION:
            # Add dimension IS the sketch dimension: part of the sketch
            # and driving it, not a loose annotation on every 2D view
            from . import sketch_constrain_ui
            tool = sketch_constrain_ui.DIMENSION
        if tool not in (MEASURE, DIMENSION):
            scene.clear_measure()
        if tool != scene.tool:
            scene.drop_drafts()                # nothing half drawn left
        scene.tool = tool
        if tool == SELECT:
            self.setDragMode(QGraphicsView.RubberBandDrag)
            self.setCursor(Qt.ArrowCursor)
        else:
            self.setDragMode(QGraphicsView.NoDrag)
            self.setCursor(Qt.CrossCursor)

    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect)
        scene = self.scene()
        refs = getattr(getattr(scene, "model", None), "reference_images",
                       None)
        if refs:                        # under the grid, like a backdrop
            from . import refimage
            refimage.draw_2d(painter, refs, scene.plane)
        if scene.show_grid:
            self._draw_grid(painter, rect)
        # the MODEL seen square on, behind a sketch on a face (SolidWorks'
        # Normal To: sketch_backdrop.py)
        try:
            from . import sketch_backdrop
            scene._backdrop_on = sketch_backdrop.paint(self, painter)
        except Exception:               # never raise out of a paint
            scene._backdrop_on = False
        # the face sketched on / the part cut by the sketch plane: UNDER
        # the sketch shapes (painted over them it hid a thin line — the
        # user's horizontal line — and veiled every shape)
        from . import face_outline
        try:
            face_outline.paint(scene, painter)
        except Exception:               # never raise out of a paint
            pass
        try:
            from . import diagonals2d
            diagonals2d.paint(scene, painter)
        except Exception:               # never raise out of a paint
            pass

    def _draw_grid(self, painter, rect):
        scene = self.scene()
        from .style import tokens
        t = tokens()
        g = scene.grid_size
        # keep the lines at least 6 px apart, however far out: coarsening
        # only once left a 0.5 mm grid drawing ~10^5 lines (1.6 s a
        # frame) when zoomed out onto a house
        while g * abs(self.transform().m11()) < 6:
            g *= 5
        minor = QPen(QColor(t["border"]))
        minor.setCosmetic(True)
        major = QPen(QColor(t["border"]).darker(115))
        major.setCosmetic(True)
        left = int(rect.left() / g) - 1
        right = int(rect.right() / g) + 1
        bottom = int(rect.top() / g) - 1
        top = int(rect.bottom() / g) + 1
        for i in range(left, right + 1):
            painter.setPen(major if i % 5 == 0 else minor)
            painter.drawLine(QPointF(i * g, rect.top()),
                             QPointF(i * g, rect.bottom()))
        for j in range(bottom, top + 1):
            painter.setPen(major if j % 5 == 0 else minor)
            painter.drawLine(QPointF(rect.left(), j * g),
                             QPointF(rect.right(), j * g))
        # the two axis lines through the origin, each tinted with its
        # own axis colour (the 3D gizmo's), so which axis runs which way
        # reads at a glance even when the origin is off screen
        (ai, bi), _keys = PLANES[scene.plane]
        for index, (start, end) in ((ai, (QPointF(rect.left(), 0),
                                          QPointF(rect.right(), 0))),
                                    (bi, (QPointF(0, rect.top()),
                                          QPointF(0, rect.bottom())))):
            color = QColor(AXIS_COLORS[index])
            color.setAlpha(150)
            axis = QPen(color)
            axis.setCosmetic(True)
            axis.setWidthF(1.4)
            painter.setPen(axis)
            painter.drawLine(start, end)

    #: length of the origin gizmo's arrows, in pixels (screen space, so
    #: it stays the same size at every zoom).
    GIZMO_PX = 34.0

    def _draw_origin_gizmo(self, painter, ai, bi):
        """A small labelled cross at the sketch origin: one arrow per
        axis, in the axis colour, pointing the POSITIVE way — the 2D
        answer to the 3D view's gizmo. Drawn in screen space, and only
        when the origin is actually on screen (the corner letters cover
        the rest)."""
        origin = self.mapFromScene(QPointF(0.0, 0.0))
        w, h = self.viewport().width(), self.viewport().height()
        margin = self.GIZMO_PX + 18
        if not (-margin < origin.x() < w + margin
                and -margin < origin.y() < h + margin):
            return
        ox, oy = float(origin.x()), float(origin.y())
        font = painter.font()
        font.setPointSize(9)
        font.setBold(True)
        painter.setFont(font)
        # screen y grows downward while the sketch's vertical axis grows
        # up, so the vertical arrow points to -y on screen
        for index, (dx, dy) in ((ai, (1.0, 0.0)), (bi, (0.0, -1.0))):
            color = QColor(AXIS_COLORS[index])
            tip = QPointF(ox + dx * self.GIZMO_PX,
                          oy + dy * self.GIZMO_PX)
            painter.setPen(QPen(color, 1.8))
            painter.drawLine(QPointF(ox, oy), tip)
            # arrow head
            head = QPolygonF([
                tip,
                QPointF(tip.x() - dx * 7 - dy * 3.5,
                        tip.y() - dy * 7 - dx * 3.5),
                QPointF(tip.x() - dx * 7 + dy * 3.5,
                        tip.y() - dy * 7 + dx * 3.5)])
            painter.setBrush(QBrush(color))
            painter.setPen(Qt.NoPen)
            painter.drawPolygon(head)
            painter.setPen(QPen(color, 1.4))
            painter.drawText(QPointF(tip.x() + (5 if dx else 4),
                                     tip.y() + (13 if dy >= 0 else -5)),
                             "XYZ"[index])
        painter.setBrush(Qt.NoBrush)

    def _paint_shape_points(self, painter):
        """The points a selected or dragged shape snaps by — corners,
        centre (a cross), middles of its sides — as small blue dots
        (2026-11-12, the user: "center, midpoints of a rectangle is not
        seen, so I do not know if I snap it")."""
        scene = self.scene()
        item = getattr(scene, "_shape_drag", None)
        items = [item] if item is not None else [
            i for i in scene.selectedItems() if isinstance(i, ShapeItem)]
        if not items or len(items) > 4:
            return
        k = abs(self.transform().m11()) or 1.0
        r = 3.0 / k
        pen = QPen(QColor("#1f7ae0"), 1.5)
        pen.setCosmetic(True)
        painter.save()
        painter.setPen(pen)
        painter.setBrush(QBrush(QColor(255, 255, 255)))
        for it in items:
            try:
                pts = scene._item_feature_points(it)
                centre = it.mapToScene(it.boundingRect().center())
            except Exception:
                continue
            for p in pts:
                painter.drawEllipse(QPointF(p), r, r)
            painter.drawLine(QPointF(centre.x() - 2 * r, centre.y()),
                             QPointF(centre.x() + 2 * r, centre.y()))
            painter.drawLine(QPointF(centre.x(), centre.y() - 2 * r),
                             QPointF(centre.x(), centre.y() + 2 * r))
        painter.restore()

    def drawForeground(self, painter, rect):
        from . import face_outline       # the face sketched on, grey
        try:
            self._paint_shape_points(painter)
        except Exception:               # never raise out of a paint
            pass
        try:
            face_outline.paint_hint(self, painter)
        except Exception:               # never raise out of a paint
            pass
        super().drawForeground(painter, rect)
        try:                            # the face's other sketches' sizes
            from . import sketch_dims_face
            sketch_dims_face.paint(self, painter)
        except Exception:               # never raise out of a paint
            pass
        try:                            # what the sketch is locked to
            from . import sketch_dims3d
            sketch_dims3d.paint_references_2d(self, painter)
        except Exception:               # never raise out of a paint
            pass
        try:                            # a sketch pattern's copies
            from . import sketch_pattern
            sketch_pattern.paint(self.scene(), painter)
        except Exception:               # never raise out of a paint
            pass
        try:                            # the piece Trim would remove
            from . import sketch_trim
            sketch_trim.paint_2d(self, painter)
        except Exception:               # never raise out of a paint
            pass
        try:                            # what a fillet / chamfer takes
            from . import sketch_corner
            sketch_corner.paint_2d(self, painter)
        except Exception:               # never raise out of a paint
            pass
        self._dim_hits = []           # every clickable value, this paint
        from . import sketch_constrain_ui
        try:
            sketch_constrain_ui.paint(self, painter)
        except Exception:               # never raise out of a paint
            pass
        from .style import tokens
        t = tokens()
        painter.save()
        painter.resetTransform()
        color = QColor(t["gutter"])
        painter.setPen(QPen(color, 1.4))
        font = painter.font()
        font.setPointSize(9)
        font.setBold(True)
        painter.setFont(font)

        # axis letters for the active plane (X/Y/Z), in the axis colour
        (ai, bi), _keys = PLANES[self.scene().plane]
        h_axis, v_axis = "XYZ"[ai], "XYZ"[bi]
        w, h = self.viewport().width(), self.viewport().height()
        painter.setPen(QPen(QColor(AXIS_COLORS[ai]), 1.4))
        painter.drawText(w - 46, h - 12, f"{h_axis} →")
        painter.setPen(QPen(QColor(AXIS_COLORS[bi]), 1.4))
        painter.drawText(10, 34, f"{v_axis}")
        painter.drawText(8, 46, "↑")
        painter.setPen(QPen(color, 1.4))
        self._draw_origin_gizmo(painter, ai, bi)

        # scale bar, in the document's unit (a label: one model unit is
        # one scene unit whatever it stands for)
        ppm = self.px_per_mm()
        bar_mm = None
        for k in range(-3, 6):
            for m in (1, 2, 5):
                length = m * 10 ** k
                if 60 <= length * ppm <= 170:
                    bar_mm = length
                    break
            if bar_mm:
                break
        if bar_mm:
            px = bar_mm * ppm
            x0, y0 = 14, h - 16
            painter.setPen(QPen(QColor(t["text"]), 1.6))
            painter.drawLine(x0, y0, int(x0 + px), y0)
            painter.drawLine(x0, y0 - 5, x0, y0 + 5)
            painter.drawLine(int(x0 + px), y0 - 5, int(x0 + px),
                             y0 + 5)
            label = f"{bar_mm:g} {self._unit()}"
            painter.setFont(font)
            painter.drawText(int(x0 + px / 2 - 20), y0 - 8, label)
        # measurement + dimension annotations, drawn in view space so
        # text and arrows keep a constant size at any zoom
        self._draw_placed_dims(painter)
        self._draw_auto_dims(painter)
        self._draw_measure(painter)
        painter.restore()

    # ----------------------------------------------------- dimensions
    def _dim_screen(self, painter, pa, pb, *, color, bg, text,
                    offset=0.0, dots=True):
        """Core dimension renderer in *view/pixel* space: an offset
        dimension line with extension lines, arrowheads and a value
        chip. ``pa``/``pb`` are the measured points (QPointF, px)."""
        from math import hypot
        vx, vy = pb.x() - pa.x(), pb.y() - pa.y()
        plen = hypot(vx, vy)
        if plen < 1e-6:
            return
        ux, uy = vx / plen, vy / plen           # along the line
        nx, ny = -uy, ux                         # perpendicular
        oa = QPointF(pa.x() + nx * offset, pa.y() + ny * offset)
        ob = QPointF(pb.x() + nx * offset, pb.y() + ny * offset)
        pen = QPen(color, 1.5)
        pen.setCosmetic(True)
        thin = QPen(color, 1.0)
        thin.setCosmetic(True)
        if abs(offset) > 0.5:                    # extension lines
            gx, gy = nx * 3, ny * 3              # small gap off geometry
            over = QPointF(nx * (offset + 4), ny * (offset + 4))
            painter.setPen(thin)
            painter.drawLine(QPointF(pa.x() + gx, pa.y() + gy),
                             QPointF(pa.x() + over.x(), pa.y() + over.y()))
            painter.drawLine(QPointF(pb.x() + gx, pb.y() + gy),
                             QPointF(pb.x() + over.x(), pb.y() + over.y()))
        painter.setPen(pen)
        painter.drawLine(oa, ob)
        painter.setBrush(QBrush(color))
        for tip, sgn in ((oa, 1.0), (ob, -1.0)):
            base = QPointF(tip.x() + sgn * ux * 9, tip.y() + sgn * uy * 9)
            painter.drawPolygon(QPolygonF([
                tip,
                QPointF(base.x() + nx * 4, base.y() + ny * 4),
                QPointF(base.x() - nx * 4, base.y() - ny * 4)]))
        if dots:
            for p in (pa, pb):
                painter.drawEllipse(p, 2.6, 2.6)
        mid = QPointF((oa.x() + ob.x()) / 2 + nx * 12,
                      (oa.y() + ob.y()) / 2 + ny * 12)
        font = painter.font()
        font.setBold(True)
        painter.setFont(font)
        fm = painter.fontMetrics()
        tw, th = fm.horizontalAdvance(text), fm.height()
        chip = QRectF(mid.x() - tw / 2 - 5, mid.y() - th / 2 - 2,
                      tw + 10, th + 4)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(bg))
        painter.drawRoundedRect(chip, 4, 4)
        painter.setPen(QPen(color, 1.0))
        painter.setBrush(Qt.NoBrush)
        painter.drawText(chip, Qt.AlignCenter, text)
        ctx = getattr(self, "_dim_ctx", None)
        if ctx is not None:               # a value you can click to type
            self._dim_hits.append((QRectF(chip), ctx))

    def _draw_dim(self, painter, a_scene, b_scene, *, color, bg,
                  text=None, offset=0.0, dots=True):
        """Dimension between two *scene* points (model units)."""
        from math import hypot
        if text is None:
            dist = hypot(a_scene.x() - b_scene.x(),
                         a_scene.y() - b_scene.y())
            text = _fmt_len(dist, self._unit())
        self._dim_screen(painter,
                         QPointF(self.mapFromScene(a_scene)),
                         QPointF(self.mapFromScene(b_scene)),
                         color=color, bg=bg, text=text,
                         offset=offset, dots=dots)

    def _draw_measure(self, painter):
        scene = self.scene()
        a = getattr(scene, "_measure_a", None)
        b = scene._measure_b if scene._measure_b is not None \
            else scene._measure_cursor
        if a is None or b is None:
            return
        from .style import tokens
        t = tokens()
        self._draw_dim(painter, a, b,
                       color=QColor(t["select"]), bg=QColor(t["card"]))

    # ------------------------------------------------- placed dimensions
    def _draw_placed_dims(self, painter):
        """Saved dimension annotations for the current plane."""
        scene = self.scene()
        dims = getattr(scene.model, "dimensions", [])
        if not dims:
            return
        from .style import tokens
        t = tokens()
        color, bg = QColor(t["gutter"]), QColor(t["card"])
        for d in dims:
            if d.get("plane") != scene.plane:
                continue
            self._draw_dim(painter,
                           QPointF(d["a"][0], d["a"][1]),
                           QPointF(d["b"][0], d["b"][1]),
                           color=color, bg=bg, dots=True)

    def _dimension_at(self, view_pos):
        """Index of the placed dimension whose line lies under *view_pos*
        (a viewport QPoint), or None."""
        scene = self.scene()
        p = QPointF(view_pos)
        best, best_d = None, FEATURE_SNAP_PX
        for i, d in enumerate(getattr(scene.model, "dimensions", [])):
            if d.get("plane") != scene.plane:
                continue
            pa = QPointF(self.mapFromScene(QPointF(d["a"][0], d["a"][1])))
            pb = QPointF(self.mapFromScene(QPointF(d["b"][0], d["b"][1])))
            dist = _point_seg_dist(p, pa, pb)
            if dist < best_d:
                best, best_d = i, dist
        return best

    def contextMenuEvent(self, event):
        from . import sketch_tools
        from . import sketch_constrain_ui
        from . import dim_edit
        if dim_edit.context_menu(self, event.pos(), event.globalPos()):
            event.accept()                     # a dimension's own menu
            return
        if self.scene().tool in (POLYGON, LINE) or \
                sketch_tools.handles(self.scene().tool) or \
                sketch_constrain_ui.handles(self.scene().tool) or \
                self.scene().tool in ("sk_trim", "sk_extend",
                                      "sk_fillet", "sk_chamfer",
                                      "sk_mirror",
                                      "regions", "make_region"):
            event.accept()                     # right-click finished it
            return
        model = self.scene().model
        dims = getattr(model, "dimensions", [])
        if not dims:
            super().contextMenuEvent(event)
            return
        from PyQt5.QtWidgets import QMenu
        menu = QMenu(self)
        idx = self._dimension_at(event.pos())
        if idx is not None:
            menu.addAction("Delete dimension",
                           lambda: model.remove_dimension(idx))
        menu.addAction("Clear all dimensions", model.clear_dimensions)
        menu.exec_(event.globalPos())

    # ---------------------------------------------- auto size on select
    def _draw_auto_dims(self, painter):
        """When shapes are selected, annotate each one's own size — the
        way a part is dimensioned on a 2D drawing."""
        scene = self.scene()
        if not getattr(scene, "show_dims", True) or \
                getattr(self, "no_dims", False):
            return
        # every shape's sizes, all the time (the user: "like the other
        # programs ... a rectangle's X and Y, a circle's radius ... a
        # polygon several"), the selected ones in the accent colour
        from .style import tokens
        t = tokens()
        color, bg = QColor(t["gutter"]), QColor(t["card"])
        accent = QColor(t.get("accent", "#2176c7"))
        if not hasattr(self, "_dim_hits"):
            self._dim_hits = []              # (chip rect, what it sizes)
        # a shape with Smart Dimensions shows those, not its automatic
        # sizes on top of them (SolidWorks; the two hid each other)
        from . import sketch_constraints as sc
        sized = set()
        values = []                      # the numbers they already show
        for cont in sc.containers(scene.model):
            for row in sc.rows(cont):
                if "value" not in row:
                    continue
                try:
                    values.append(float(row["value"]))
                except (TypeError, ValueError):
                    pass
                for ref in row.get("refs", ()):
                    try:
                        sized.add(id(sc.entity(cont, ref)[0]))
                    except (KeyError, ValueError, IndexError):
                        pass
        for item in list(scene.items()):
            if not isinstance(item, (ShapeItem, PartItem)) or \
                    not item.isVisible() or item.scene() is not scene:
                continue
            if id(getattr(item, "node", None)) in sized:
                continue
            if isinstance(item, PartItem) and values:
                # the part's own box size, when a Smart Dimension already
                # says it (98 mm under 98.0), is only a second label
                r = item.sceneBoundingRect()
                if any(abs(v - w) < 0.05 for v in values
                       for w in (r.width(), r.height())):
                    continue
            try:
                self._auto_dim_item(painter, item,
                                    accent if item.isSelected() else color,
                                    bg)
            except Exception:              # never raise out of a paint
                continue
            finally:
                self._dim_ctx = None

    def _geometry_rect(self, item):
        """The shape's true local rect (mm) — from its own geometry, not
        ``sceneBoundingRect`` which the cosmetic pen stroke inflates."""
        if isinstance(item, (QGraphicsRectItem, QGraphicsEllipseItem)):
            return item.rect()
        if isinstance(item, QGraphicsPolygonItem):
            return item.polygon().boundingRect()
        if isinstance(item, QGraphicsPathItem):
            return item.path().boundingRect()
        return item.boundingRect()

    def _auto_dim_item(self, painter, item, color, bg):
        node = getattr(item, "node", None)
        if isinstance(item, CircleShapeItem):        # ⌀ across the centre
            self._dim_ctx = (node, "diameter", None)
            c = item.mapToScene(item.rect().center())
            r = abs(item.rect().width()) / 2.0
            self._draw_dim(painter,
                           QPointF(c.x() - r, c.y()),
                           QPointF(c.x() + r, c.y()),
                           color=color, bg=bg, dots=False,
                           text="⌀ " + _fmt_len(2 * r, self._unit()))
            return
        if isinstance(item, PolygonShapeItem):       # every side's length
            self._polygon_edge_dims(painter, item, color, bg)
            return
        if isinstance(item, LineShapeItem):          # length beside it
            self._dim_ctx = (node, "length", None)
            ln = item.line()
            self._draw_dim(painter, item.mapToScene(ln.p1()),
                           item.mapToScene(ln.p2()),
                           color=color, bg=bg, dots=False, offset=18)
            return
        lr = self._geometry_rect(item)
        if lr.width() < 1e-6 or lr.height() < 1e-6:
            return
        if isinstance(item, PartItem):
            self._cylinder_label(painter, item, color, bg)
            node = None                    # a part's box is not typed
        st = item.sceneTransform()
        if abs(st.m12()) > 1e-9 or abs(st.m21()) > 1e-9:
            # turned by a rotate above it: dimension along its own
            # edges, not round the level box that holds it
            unit = self._unit()
            self._dim_ctx = (node, "width", None) if node else None
            self._draw_dim(painter, item.mapToScene(lr.topLeft()),
                           item.mapToScene(lr.topRight()), color=color,
                           bg=bg, dots=False, offset=18,
                           text=_fmt_len(lr.width(), unit))
            self._dim_ctx = (node, "height", None) if node else None
            self._draw_dim(painter, item.mapToScene(lr.topRight()),
                           item.mapToScene(lr.bottomRight()), color=color,
                           bg=bg, dots=False, offset=18,
                           text=_fmt_len(lr.height(), unit))
            return
        pts = [QPointF(self.mapFromScene(item.mapToScene(c))) for c in
               (lr.topLeft(), lr.topRight(), lr.bottomLeft(),
                lr.bottomRight())]
        xs = [p.x() for p in pts]
        ys = [p.y() for p in pts]
        sl, sr, stop, sbot = min(xs), max(xs), min(ys), max(ys)
        # width below the box, height on the right (screen space)
        unit = self._unit()
        self._dim_ctx = (node, "width", None) if node else None
        self._dim_screen(painter, QPointF(sl, sbot), QPointF(sr, sbot),
                         color=color, bg=bg,
                         text=_fmt_len(lr.width(), unit),
                         offset=22, dots=False)
        self._dim_ctx = (node, "height", None) if node else None
        self._dim_screen(painter, QPointF(sr, sbot), QPointF(sr, stop),
                         color=color, bg=bg,
                         text=_fmt_len(lr.height(), unit),
                         offset=22, dots=False)

    def _cylinder_label(self, painter, item, color, bg):
        """A part made of one cylinder also says its diameter (its
        width / height are the box dimensions)."""
        node = getattr(item, "node", None)
        cyls = [n for n in node.walk() if n.type == "cylinder"] \
            if node is not None else []
        if len(cyls) != 1:
            return
        p = cyls[0].params
        from .expr import resolve
        try:
            r1 = float(resolve(p.get("radius_bottom", 10), {}, 10))
            r2 = float(resolve(p.get("radius_top", r1), {}, r1))
        except (TypeError, ValueError):
            return
        text = "⌀ " + _fmt_len(2 * r1, self._unit()) if abs(r1 - r2) < 1e-9 \
            else "⌀ %s / %s" % (_fmt_len(2 * r1, self._unit()),
                                _fmt_len(2 * r2, self._unit()))
        c = self.mapFromScene(item.sceneBoundingRect().center())
        fm = painter.fontMetrics()
        w = fm.horizontalAdvance(text) + 8
        box = QRectF(c.x() - w / 2, c.y() - fm.height() / 2 - 2, w,
                     fm.height() + 4)
        painter.save()
        painter.setPen(QPen(color, 1))
        painter.setBrush(QBrush(bg))
        painter.drawRoundedRect(box, 3, 3)
        painter.drawText(box, int(Qt.AlignCenter), text)
        painter.restore()

    def _polygon_edge_dims(self, painter, item, color, bg):
        """Each side of a selected polygon with its length — the arc
        pieces of a fillet (short sides) are left out."""
        import math
        poly = item.polygon()
        n = poly.count()
        if n < 3:
            return
        sides = [(poly.at(i), poly.at((i + 1) % n)) for i in range(n)]
        lens = [math.hypot(b.x() - a.x(), b.y() - a.y()) for a, b in sides]
        longest = max(lens) or 1.0
        unit = self._unit()
        node = getattr(item, "node", None)
        for i, ((a, b), L) in enumerate(zip(sides, lens)):
            if L < max(0.15 * longest, 1e-6) and n > 4:
                continue
            # a rounded polygon's drawn sides are not its own sides
            self._dim_ctx = (node, "edge", i) if node is not None and \
                not node.params.get("corners") else None
            self._draw_dim(painter, item.mapToScene(a), item.mapToScene(b),
                           color=color, bg=bg, dots=False, offset=14,
                           text=_fmt_len(L, unit))

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.zoom(factor)

    def zoom(self, factor):
        current = abs(self.transform().m11())
        if MIN_ZOOM < current * factor < MAX_ZOOM:
            self.scale(factor, factor)
            if hasattr(self.scene(), "fit_scene_rect"):
                self.scene().fit_scene_rect()   # room to zoom out onto
        self.zoom_changed.emit(self.px_per_mm())

    def zoom_reset(self):
        self.resetTransform()
        self.scale(4, -4)
        self.centerOn(30, 20)
        self.zoom_changed.emit(self.px_per_mm())

    def _fit_rect(self, rect):
        if rect.isNull() or rect.width() < 1e-6:
            return
        rect = rect.adjusted(-rect.width() * 0.08,
                             -rect.height() * 0.08,
                             rect.width() * 0.08,
                             rect.height() * 0.08)
        scale = min(self.viewport().width() / rect.width(),
                    self.viewport().height() / rect.height())
        scale = max(min(scale, MAX_ZOOM), MIN_ZOOM)
        self.resetTransform()
        self.scale(scale, -scale)
        if hasattr(self.scene(), "fit_scene_rect"):
            self.scene().fit_scene_rect()       # or centerOn is clamped
        self.centerOn(rect.center())
        self.zoom_changed.emit(self.px_per_mm())

    def frame_rect(self, rect):
        """Fit a specific scene rectangle (used when a profile opens
        for editing)."""
        self._fit_rect(rect)

    def fit_content(self):
        """Fit everything drawn in the sketch (Ctrl+Shift+F)."""
        self._fit_rect(self.scene().itemsBoundingRect())

    def zoom_selection(self):
        """Fit the selected objects."""
        items = self.scene().selectedItems()
        if not items:
            return
        rect = items[0].sceneBoundingRect()
        for item in items[1:]:
            rect = rect.united(item.sceneBoundingRect())
        self._fit_rect(rect)

    def event(self, e):
        from PyQt5.QtCore import QEvent
        if e.type() == QEvent.KeyPress and \
                e.key() in (Qt.Key_Tab, Qt.Key_Backtab):
            self.step_object.emit(1 if e.key() == Qt.Key_Tab else -1)
            return True
        if e.type() == QEvent.ShortcutOverride and \
                e.key() in (Qt.Key_Delete, Qt.Key_Backspace):
            # a dimension selected: Delete is ITS, not the window's
            # (which would delete the selected shape)
            from . import dim_edit
            if dim_edit.selected(self) is not None:
                e.accept()
                return True
        return super().event(e)

    def keyPressEvent(self, event):
        from PyQt5.QtGui import QKeySequence
        from . import sketch_tools, sketch_constrain_ui, sketch_regions
        scene = self.scene()
        from . import dim_edit
        if event.key() in (Qt.Key_Delete, Qt.Key_Backspace) and \
                dim_edit.delete_key(self):
            return                            # the selected dimension
        if event.key() == Qt.Key_Q:
            self.step_object.emit(-1)         # Q: up / previous
        elif event.key() == Qt.Key_A:
            self.step_object.emit(1)          # A: down / next
        elif event.matches(QKeySequence.Copy):
            self.clipboard_op.emit("copy")
        elif event.matches(QKeySequence.Cut):
            self.clipboard_op.emit("cut")
        elif event.matches(QKeySequence.Paste):
            self.clipboard_op.emit("paste")
        elif event.key() == Qt.Key_Escape:
            scene.cancel_tool()
        elif sketch_tools.handles(scene.tool) and \
                sketch_tools.key(scene, event):
            pass
        elif scene.tool in ("regions", "make_region") and \
                sketch_regions.key(scene, event):
            pass
        elif scene.tool == "sk_mirror" and \
                __import__("khervecad.sketch_mirror",
                           fromlist=["key"]).key(scene, event):
            pass
        elif scene.tool in ("sk_lpattern", "sk_cpattern") and \
                __import__("khervecad.sketch_pattern",
                           fromlist=["key"]).key(scene, event):
            pass
        elif sketch_constrain_ui.handles(scene.tool) and \
                sketch_constrain_ui.key(scene, event):
            pass
        elif scene.tool == LINE and \
                __import__("khervecad.sketch_line",
                           fromlist=["key"]).key(scene, event):
            pass
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter) and \
                scene.tool == POLYGON:
            scene.finish_polygon()
        elif event.key() == Qt.Key_Backspace and scene.tool == POLYGON \
                and scene._poly_points:
            scene.undo_polygon_point()
        elif event.key() == Qt.Key_Delete:
            scene.delete_selection()
        else:
            super().keyPressEvent(event)
