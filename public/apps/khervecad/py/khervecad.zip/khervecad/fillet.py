"""Fillet / chamfer chosen edges — SolidWorks' Fillet feature (Qt-free).

OpenSCAD has no edges, only solids, so "round this edge" has to be
built from what a solid can do: subtract material along a convex edge,
add it along a concave one. That is exactly the rolling-ball fillet:

- The part's mesh is scanned for **crease edges** — edges where two
  faces meet at more than `MIN_ANGLE` (`crease_edges`), each knowing
  its two faces and whether it is convex (a box corner) or concave (an
  inside corner).
- A picked edge is **propagated** along tangent-continuous creases
  (`chain`): one click on a cylinder's rim takes the whole rim, one
  click on a box edge stops at the corners where three creases meet.
- Along each chain a **strip** is built (`strip`): at every vertex the
  cross-section is the kite between the edge and the fillet circle
  tangent to both faces (`profile`) — for a chamfer, the triangle
  between the two setback lines — mitred at the chain's corners and
  capped at its ends.
- Convex chains become **cuts** (difference), concave ones **adds**
  (union). `compute()` returns both as triangle lists; codegen writes
  them as polyhedra into ``kcad_fillet(...) { children }`` whose helper
  does the boolean, so the exact OpenSCAD render and the STL are truly
  filleted. The built-in preview cannot cut, so it shows the children
  plus the concave fillers (the exact per-part render lands a moment
  later, as it does for any difference).

Edges are remembered as geometry — the seed segment's two endpoints in
the part's own frame — and re-found by nearest match each time the
part is regenerated, so editing the part keeps its fillets; an edge
that no longer exists is reported by validation, never guessed.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import json
import math

#: two faces meeting at less than this (degrees) are one smooth surface
#: — a cylinder's facets, a sphere's — not an edge to fillet
MIN_ANGLE = 20.0

#: a chain follows the next crease while the turn between consecutive
#: edges stays under this (degrees): round a rim, stop at a corner
MAX_TURN = 35.0

#: a `through` vertex is followed at any turn below this (degrees)
HAIRPIN = 150.0
#: how far (mm, plus this fraction of the part's size) a remembered
#: edge may drift from a crease and still be the same edge
#: params key of the picks' places in the part (fraction)
PLACES = "fillet_places"
#: the NAMES of the faces at each picked edge / of each picked face
#: (face_names): the edge is found by them after any rebuild
NAMES = "fillet_names"
FIND_TOL = 0.5
FIND_FRAC = 0.01

KINDS = ("round", "chamfer")

#: how much a cutter section is grown about its centroid so no face of
#: it is coplanar with the part (see profile)
GROW = 0.003

OPERATION = "op"

NODE_TYPES = {
    "fillet": dict(
        label="Fillet edges", category=OPERATION,
        icon="mdi.rounded-corner",
        params=dict(radius=2.0, kind="round", detail=6, edges=[]),
        # "faces" (schema-only): rows [x, y, z, nx, ny, nz] — a picked
        # FACE, whose every edge is rounded, found again on each rebuild
        schema=[("radius", "Radius (chamfer: setback)", "float",
                 0.01, 1e4),
                ("kind", "Kind", "choice", list(KINDS), None),
                ("detail", "Segments across the round", "int", 1, 64),
                ("edges", "Edges", "rows",
                 ["X1", "Y1", "Z1", "X2", "Y2", "Z2"], None),
                ("faces", "Faces", "rows",
                 ["X", "Y", "Z", "NX", "NY", "NZ"], None)]),
}

#: OpenSCAD: the boolean the fillet compiles to. The polyhedra are
#: baked by this module; the importer ignores them and rebuilds the
#: node from radius / kind / detail / edges and the children.
HELPER = """\
module kcad_fillet(radius = 2, kind = "round", detail = 6, edges = [],
                   faces = [], cuts = [], adds = []) {
    union() {
        difference() {
            children();
            for (c = cuts)
                polyhedron(points = c[0], faces = c[1], convexity = 4);
        }
        for (a = adds)
            polyhedron(points = a[0], faces = a[1], convexity = 4);
    }
}"""


# ----------------------------------------------------------- vectors
def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _mul(a, k):
    return (a[0] * k, a[1] * k, a[2] * k)


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def _len(a):
    return math.sqrt(_dot(a, a))


def _unit(a):
    n = _len(a)
    return _mul(a, 1.0 / n) if n > 1e-12 else (0.0, 0.0, 0.0)


def _vkey(v):
    return (round(v[0], 5), round(v[1], 5), round(v[2], 5))


def _normal(tri):
    a, b, c = tri
    return _unit(_cross(_sub(b, a), _sub(c, a)))


# ------------------------------------------------------ crease edges
class Edge:
    """A crease: ``a -> b`` as traversed by face L (counter-clockwise),
    face R traverses it the other way. *angle* is the dihedral in
    degrees, *convex* True for an outside corner."""

    __slots__ = ("a", "b", "nl", "nr", "angle", "convex", "il", "ir")

    def __init__(self, a, b, nl, nr, angle, convex, il=-1, ir=-1):
        self.a, self.b, self.nl, self.nr = a, b, nl, nr
        self.angle, self.convex = angle, convex
        self.il, self.ir = il, ir        # the two triangles (face_names)

    @property
    def mid(self):
        return _mul(_add(self.a, self.b), 0.5)

    @property
    def direction(self):
        return _unit(_sub(self.b, self.a))

    @property
    def length(self):
        return _len(_sub(self.b, self.a))


def crease_edges(tris, min_angle: float = MIN_ANGLE) -> list:
    """Every edge of *tris* (counter-clockwise triangles) shared by two
    faces meeting at more than *min_angle* degrees."""
    normals = [_normal(t) for t in tris]
    directed = {}
    for i, tri in enumerate(tris):
        keys = [_vkey(v) for v in tri]
        for k in range(3):
            directed[(keys[k], keys[(k + 1) % 3])] = (i, tri[k],
                                                      tri[(k + 1) % 3])
    cos_min = math.cos(math.radians(min_angle))
    out = []
    for (ka, kb), (i, a, b) in directed.items():
        if ka >= kb:
            continue                     # each undirected edge once
        other = directed.get((kb, ka))
        if other is None:
            continue                     # an open border, not an edge
        j = other[0]
        nl, nr = normals[i], normals[j]
        cos = max(-1.0, min(1.0, _dot(nl, nr)))
        if cos > cos_min:
            continue
        angle = math.degrees(math.acos(cos))
        convex = _dot(_cross(nl, nr), _sub(b, a)) > 0.0
        out.append(Edge(a, b, nl, nr, angle, convex, i, j))
    return out


def _turn(d0, d1) -> float:
    return math.degrees(math.acos(max(-1.0, min(1.0, _dot(d0, d1)))))


def chain(edges, seed, max_turn: float = MAX_TURN, through=None) -> dict:
    """The tangent-continuous run of creases through *seed* (an Edge
    from *edges*): ``{"points": [...], "edges": [Edge...], "closed":
    bool, "convex": bool}`` with the edges oriented along the run.
    At a vertex the crease that turns least is followed, while the
    turn stays under *max_turn* and the convexity matches — or, at a
    vertex where *through(vertex key)* is true, at any turn short of a
    hairpin (bevel.py mitres a pocket's rim round its corners)."""
    by_vertex = {}
    for e in edges:
        by_vertex.setdefault(_vkey(e.a), []).append(e)
        by_vertex.setdefault(_vkey(e.b), []).append(e)

    def oriented(e, start_key):
        """*e* as (Edge traversed from start_key, direction)."""
        if _vkey(e.a) == start_key:
            return e, e.direction
        flipped = Edge(e.b, e.a, e.nr, e.nl, e.angle, e.convex)
        return flipped, flipped.direction

    used = {id(seed)}                    # shared: a run never doubles back

    def walk(start_edge, forward):
        """Edges continuing from one end of the seed, in order, and
        whether the run came round to the seed again (a closed rim)."""
        run = []
        cur = start_edge if forward else \
            Edge(start_edge.b, start_edge.a, start_edge.nr,
                 start_edge.nl, start_edge.angle, start_edge.convex)
        while True:
            end_key = _vkey(cur.b)
            limit = HAIRPIN if through and through(end_key) else max_turn
            best, best_turn = None, limit
            for cand in by_vertex.get(end_key, ()):
                if cand.convex != seed.convex:
                    continue
                o, d = oriented(cand, end_key)
                turn = _turn(cur.direction, d)
                if cand is seed:
                    if forward and turn < limit and run:
                        return run, True     # back at the seed: closed
                    continue
                if id(cand) in used:
                    continue
                if turn < best_turn:
                    best, best_turn = (cand, o), turn
            if best is None:
                return run, False
            cand, o = best
            used.add(id(cand))
            run.append(o)
            cur = o

    ahead, closed = walk(seed, True)
    if closed:
        ordered = [seed] + ahead
    else:
        behind, _ = walk(seed, False)
        # behind is oriented away from the seed: flip it back
        behind = [Edge(e.b, e.a, e.nr, e.nl, e.angle, e.convex)
                  for e in reversed(behind)]
        ordered = behind + [seed] + ahead
    points = [e.a for e in ordered]
    if not closed:
        points.append(ordered[-1].b)
    return dict(points=points, edges=ordered, closed=closed,
                convex=seed.convex)


# ----------------------------------------------------------- profile
def profile(edge, radius: float, kind: str, detail: int) -> tuple:
    """The cutter's cross-section for *edge*: ``(u, v, points2d)`` —
    a frame perpendicular to the edge (u into face L, v = t x u, so
    u x v = t) and the polygon in it: the edge point E, the tangent
    point on L, the arc (or nothing, for a chamfer) and the tangent
    point on R. The polygon is oriented counter-clockwise in (u, v)."""
    t = edge.direction
    dl = _unit(_cross(edge.nl, t))         # into face L, away from the edge
    dr = _unit(_cross(t, edge.nr))         # into face R
    u = dl
    v = _unit(_cross(t, u))
    x_r, y_r = _dot(dr, u), _dot(dr, v)
    beta = math.acos(max(-1.0, min(1.0, _dot(dl, dr))))   # between faces
    beta = max(beta, math.radians(1.0))
    if kind == "chamfer":
        s = radius
        pts = [(0.0, 0.0), (s, 0.0), (s * x_r, s * y_r)]
    else:
        s = radius / math.tan(beta / 2.0)
        cx, cy = _mul_2d(_unit_2d((1.0 + x_r, y_r)),
                         radius / math.sin(beta / 2.0))
        tl, tr = (s, 0.0), (s * x_r, s * y_r)
        a0 = math.atan2(tl[1] - cy, tl[0] - cx)
        a1 = math.atan2(tr[1] - cy, tr[0] - cx)
        sweep = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi  # short way
        n = max(int(detail), 1)
        pts = [(0.0, 0.0), tl]
        for k in range(1, n):
            a = a0 + sweep * k / n
            pts.append((cx + radius * math.cos(a), cy + radius * math.sin(a)))
        pts.append(tr)
    if _area2d(pts) < 0:
        pts = [pts[0]] + pts[1:][::-1]
    # Grow the section a hair about its centroid: its two straight
    # sides would otherwise lie exactly IN the faces they trim, and a
    # boolean on coplanar faces leaves slivers (a saw-tooth round a
    # rim). Grown, the sides sit just outside a convex corner's faces
    # (cut) or just inside a concave one's (filled) — the fillet moves
    # by a few microns, the boolean becomes clean.
    n = len(pts)
    cx = sum(x for x, _y in pts) / n
    cy = sum(y for _x, y in pts) / n
    grow = 1.0 + GROW
    pts = [(cx + (x - cx) * grow, cy + (y - cy) * grow) for x, y in pts]
    return u, v, pts


def _mul_2d(p, k):
    return (p[0] * k, p[1] * k)


def _unit_2d(p):
    n = math.hypot(*p)
    return (p[0] / n, p[1] / n) if n > 1e-12 else (1.0, 0.0)


def _area2d(pts):
    total = 0.0
    for i, (x1, y1) in enumerate(pts):
        x2, y2 = pts[(i + 1) % len(pts)]
        total += x1 * y2 - x2 * y1
    return total / 2.0


# ------------------------------------------------------------- strip
#: a picked FACE's rim carries on along creases turning less than this
#: (degrees) — a curved end's facets, not another face's edge met at an
#: angle (Exercise 8: at 35 the rim ran on under the clevis's boss)
FACE_TURN = 20.0

#: faces turning less than this from one crease to the next are one
#: faceted surface, whose normals `smoothed` averages
SMOOTH_TURN = 20.0


def smoothed(run: dict, radius: float) -> list:
    """The run's edges with each face normal averaged over the edges
    within *radius* along the run, as long as the faces turn less than
    `SMOOTH_TURN` from this edge's. A curved side is facets, and where
    two features cut the same arc at different segment counts its
    facets ZIG-ZAG (Exercise 8's clevis rim: normals alternating 1-8°
    back and forth): a profile per facet put a notch in the fillet at
    every joint. A real corner (a box's rim) turns too far to blend."""
    edges = run["edges"]
    n = len(edges)
    if n < 2:
        return edges
    lens = [e.length for e in edges]
    s = [0.0]
    for x in lens[:-1]:
        s.append(s[-1] + x)
    mids = [s[i] + lens[i] / 2 for i in range(n)]
    total = s[-1] + lens[-1]
    cos_max = math.cos(math.radians(SMOOTH_TURN))
    closed = run["closed"]
    out = []
    for i, e in enumerate(edges):
        sum_l, sum_r = _mul(e.nl, lens[i]), _mul(e.nr, lens[i])
        for step in (1, -1):
            j = i
            for _k in range(n - 1):
                j += step
                if closed:
                    j %= n
                elif not 0 <= j < n:
                    break
                if j == i:
                    break
                d = abs(mids[j] - mids[i])
                if closed:
                    d = min(d, total - d)
                if d > radius:
                    break
                o = edges[j]
                if _dot(o.nl, e.nl) < cos_max or _dot(o.nr, e.nr) < cos_max:
                    break
                sum_l = _add(sum_l, _mul(o.nl, lens[j]))
                sum_r = _add(sum_r, _mul(o.nr, lens[j]))
        out.append(Edge(e.a, e.b, _unit(sum_l), _unit(sum_r), e.angle,
                        e.convex, e.il, e.ir))
    return out


def strip(run: dict, radius: float, kind: str, detail: int,
          section=None) -> list:
    """Counter-clockwise triangles of the cutter (or filler) along a
    chain: one ring per chain vertex, mitred between its two edges,
    walls between rings, caps at open ends. *section(edge)* replaces
    `profile` (bevel.py's superellipse profiles)."""
    edges = smoothed(run, radius)
    profiles = [section(e) if section else
                profile(e, radius, kind, detail) for e in edges]
    m = len(profiles[0][2])
    if any(len(p[2]) != m for p in profiles):
        return []                          # pragma: no cover

    def offsets(i):
        u, v, pts = profiles[i]
        return [_add(_mul(u, x), _mul(v, y)) for x, y in pts]

    def mitre(o0, o1, t0, t1, room=float("inf")):
        """The corner ring: where the two edges' profiles meet — each
        profile point slid along its own edge until the two lines meet
        (summing whole offsets once cut a face's rim twice as deep down
        the sides). *room* is how far a point may slide before it passes
        a neighbouring ring."""
        k = 1.0 + _dot(t0, t1)
        if k < 0.2:                        # a hairpin: just average
            return [_mul(_add(a, b), 0.5) for a, b in zip(o0, o1)]
        b = _dot(t0, t1)
        reach = max(max(_len(p) for p in o0), max(_len(p) for p in o1))
        if 1.0 - b * b < 1e-4:             # straight on
            return [_mul(_add(a, c), 0.5) for a, c in zip(o0, o1)]
        out = []
        for p0, p1 in zip(o0, o1):
            # where the two offset lines p0 + l t0 and p1 + m t1 meet
            # (the middle of their closest approach): on a faceted side
            # the two profiles' points lie in the two facets, and the
            # lines meet ON the ridge between them. Bending only the
            # in-plane parts put a tapered face's leg 0.05 mm off the
            # ridge, and a fin stood at every facet joint (Exercise 8's
            # clevis rim).
            d = _sub(p1, p0)
            e, f = _dot(t0, d), _dot(t1, d)
            den = 1.0 - b * b
            lam = (e - b * f) / den
            mu = (b * e - f) / den
            if max(abs(lam), abs(mu)) > min(4.0 * reach, room) + 1e-9:
                # lines all but parallel, or meeting past a neighbouring
                # ring (a zig-zag rim of 0.06 mm steps): the strip would
                # fold back on itself
                out.append(_mul(_add(p0, p1), 0.5))
                continue
            out.append(_mul(_add(_add(p0, _mul(t0, lam)),
                                 _add(p1, _mul(t1, mu))), 0.5))
        return out

    dirs = [e.direction for e in edges]
    lens = [e.length for e in edges]
    offs = [offsets(i) for i in range(len(edges))]
    rings = []
    n = len(edges)
    if run["closed"]:
        for i in range(n):
            prev = (i - 1) % n
            o = mitre(offs[prev], offs[i], dirs[prev], dirs[i],
                      min(lens[prev], lens[i]))
            rings.append([_add(edges[i].a, p) for p in o])
    else:
        rings.append([_add(edges[0].a, p) for p in offs[0]])
        for i in range(1, n):
            o = mitre(offs[i - 1], offs[i], dirs[i - 1], dirs[i],
                      min(lens[i - 1], lens[i]))
            rings.append([_add(edges[i].a, p) for p in o])
        rings.append([_add(edges[-1].b, p) for p in offs[-1]])
    tris = []
    spans = list(zip(rings, rings[1:]))
    if run["closed"]:
        spans.append((rings[-1], rings[0]))
    for lower, upper in spans:
        for k in range(m):
            k1 = (k + 1) % m
            a, b, c, d = lower[k], lower[k1], upper[k1], upper[k]
            tris.append((a, b, c))
            tris.append((a, c, d))
    if not run["closed"]:
        from .mesh import triangulate
        for ring, pts2d, reverse in ((rings[0], profiles[0][2], True),
                                     (rings[-1], profiles[-1][2], False)):
            for a, b, c in triangulate(pts2d):
                idx = [pts2d.index(p) for p in (a, b, c)]
                pa, pb, pc = (ring[i] for i in idx)
                tris.append((pa, pc, pb) if reverse else (pa, pb, pc))
    return tris


# ------------------------------------------------------------ compute
def _seg_dist(p, a, b) -> float:
    ab = _sub(b, a)
    denom = _dot(ab, ab) or 1e-12
    t = max(0.0, min(1.0, _dot(_sub(p, a), ab) / denom))
    return _len(_sub(p, _add(a, _mul(ab, t))))


def _faces_of(e):
    """The two faces meeting at a crease, order-free, and its kind: what
    names an edge after the part has changed shape."""
    a, b = list(e.nl), list(e.nr)
    if (a > b):
        a, b = b, a
    return [round(v, 6) for v in a + b] + [1.0 if e.convex else 0.0]


def _same_faces(e, want):
    """*e* has the faces (and convexity) *want* remembered."""
    n1, n2, convex = tuple(want[:3]), tuple(want[3:6]), want[6] > 0.5
    if bool(e.convex) != convex:
        return False
    for p, q in ((e.nl, e.nr), (e.nr, e.nl)):
        if _dot(p, n1) > 0.999 and _dot(q, n2) > 0.999:
            return True
    return False


def _edge_by_fraction(edges, seed, box):
    """The crease parallel to the remembered one at the same place IN
    THE PART (box fractions) — the seed's own spot is gone after an
    edit. When the faces meeting at it were remembered too (seed[9:16])
    the crease between faces facing the same ways wins however far it
    moved in the box: an L's inside corner goes from a quarter to half
    way across when its leg is widened, past any fraction tolerance (the
    user: a fillet stopped working after a Smart Dimension change)."""
    d = _unit(_sub(tuple(seed[3:6]), tuple(seed[:3])))
    want = seed[6:9]
    faces = seed[9:16] if len(seed) >= 16 else None
    best = best_same = None
    for e in edges:
        if abs(_dot(e.direction, d)) < 0.9:
            continue
        mid = _mul(_add(e.a, e.b), 0.5)
        dist = _fdist(fraction(mid, box), want)
        if best is None or dist < best[0]:
            best = (dist, e)
        if faces is not None and _same_faces(e, faces) and \
                (best_same is None or dist < best_same[0]):
            best_same = (dist, e)
    if best_same is not None:
        return best_same[1]
    return best[1] if best is not None and best[0] < 0.25 else None


def find_edge(edges, seed, size: float):
    """The crease nearest the remembered segment *seed* (6 numbers),
    or None: the seed's midpoint must lie within tolerance of the
    crease segment (so a rim re-tessellated at another segment count
    is still the same rim), roughly parallel to it."""
    a, b = tuple(seed[:3]), tuple(seed[3:6])
    mid = _mul(_add(a, b), 0.5)
    d = _unit(_sub(b, a))
    tol = FIND_TOL + FIND_FRAC * size
    best, best_dist = None, None
    for e in edges:
        if abs(_dot(e.direction, d)) < 0.9:
            continue
        dist = _seg_dist(mid, e.a, e.b)
        if dist > tol:
            continue
        if best_dist is None or dist < best_dist:
            best, best_dist = e, dist
    return best


def mesh_size(tris) -> float:
    if not tris:
        return 0.0
    pts = [v for t in tris for v in t]
    return max(max(p[i] for p in pts) - min(p[i] for p in pts)
               for i in range(3))


def _clip_to_box(body, box, eps=1e-6):
    """A concave strip cut back to the part's box and capped, so a
    fillet wider than the face it rolls onto stops at the part's edge
    as SolidWorks' does (2026-11-14, Exercise 52: the rib's R32 foot on
    a base 28 mm wider than the rib stood 4 mm out past it)."""
    from . import csg, cutaway
    lo, hi = box
    vals = [p for t in body for p in t]
    if all(lo[k] - eps <= p[k] <= hi[k] + eps for p in vals
           for k in range(3)):
        return body
    if csg.available():
        # Manifold keeps it one closed solid (a fanned clip + cap left
        # it open, and a Difference after the fillet stopped cutting)
        import manifold3d as m
        rows = [(t, None, False) for t in body]
        solid = csg.to_manifold(rows, {})
        if solid is not None:
            cube = m.Manifold.cube([hi[k] - lo[k] for k in range(3)]
                                   ).translate(list(lo))
            return csg.to_triangles(solid ^ cube)
    for axis, k in cutaway.AXES.items():
        for flip, plane in ((False, hi[k]), (True, lo[k])):
            vals = [p[k] for t in body for p in t]
            if not vals:
                return []
            past = max(vals) > plane + eps if not flip else \
                min(vals) < plane - eps
            if not past:
                continue
            cap = cutaway.caps(body, axis, plane, flip)
            body = cutaway.clip(body, None, axis, plane, flip)[0] + cap
    return body


def _box(tris):
    pts = [v for t in tris for v in t]
    lo = [min(p[i] for p in pts) for i in range(3)]
    hi = [max(p[i] for p in pts) for i in range(3)]
    return lo, hi


def fraction(point, box):
    """Where *point* sits in the part's box, 0..1 per axis — a top edge
    stays at z = 1 however tall the part grows (the user: a fillet must
    follow the face when the extrusion's height changes)."""
    lo, hi = box
    return [((point[i] - lo[i]) / (hi[i] - lo[i])) if hi[i] - lo[i] > 1e-9
            else 0.5 for i in range(3)]


def _fdist(a, b):
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


#: a picked face found again when the part changed is the one facing
#: within this of the remembered direction (cos): a rib made longer
#: tilts its slope by degrees (the user's 25 -> 35)
FACE_TURN_COS = 0.9


def face_edges(tris, edges, row, tol=1e-3, box=None, found=None):
    """The crease edges round the flat face a [x, y, z, nx, ny, nz] row
    names, holes included: the coplanar triangles joined to the one
    nearest the point, and every crease with that region on one side
    only. Found again on each rebuild, so a hole cut into the face
    later is rounded too (SolidWorks keeps the FACE, not its edges)."""
    p, n = row[:3], _unit(row[3:6])
    normals = [_normal(t) for t in tris]
    facing = [i for i, t in enumerate(tris) if _dot(normals[i], n) > 0.9999]
    on = [i for i in facing
          if abs(_dot(_sub(tris[i][0], p), n)) < max(tol, 1e-4)]

    def centre(t):
        return _mul(_add(_add(t[0], t[1]), t[2]), 1.0 / 3.0)
    if on:
        start = min(on, key=lambda i: _len(_sub(centre(tris[i]), p)))
    elif len(row) >= 9 and box is not None:
        # the face moved (a taller extrusion) or turned (a rib made
        # longer tilts its slope — the user's fillet on it vanished): the
        # face facing about the same way at the same place IN THE PART,
        # by its box fractions; the latest direction known wins
        want = row[6:9]
        n = _unit(row[9:12]) if len(row) >= 12 else n
        near = [i for i, m in enumerate(normals)
                if _dot(m, n) > FACE_TURN_COS]
        if not near:
            return []
        start = min(near, key=lambda i: _fdist(
            fraction(centre(tris[i]), box), want)
            + 2.0 * (1.0 - _dot(normals[i], n)))
        n = normals[start]
        plane = _dot(tris[start][0], n)
        on = [i for i, m in enumerate(normals) if _dot(m, n) > 0.9999
              and abs(_dot(tris[i][0], n) - plane) < max(tol, 1e-4)]
    else:
        return []
    by_edge = {}
    for i in on:
        keys = [_vkey(v) for v in tris[i]]
        for k in range(3):
            by_edge.setdefault(frozenset((keys[k], keys[(k + 1) % 3])),
                               []).append(i)
    region, todo = {start}, [start]
    while todo:
        i = todo.pop()
        keys = [_vkey(v) for v in tris[i]]
        for k in range(3):
            for j in by_edge.get(frozenset((keys[k], keys[(k + 1) % 3])),
                                 ()):
                if j not in region:
                    region.add(j)
                    todo.append(j)
    if found is not None:
        # where the face is now and which way it looks, to be found
        # again from there after the next change
        cs = [centre(tris[i]) for i in region]
        found["centre"] = _mul(
            [sum(c[k] for c in cs) for k in range(3)], 1.0 / len(cs))
        found["normal"] = list(normals[start])
        found["start"] = start
    tri_of = {}
    for i, t in enumerate(tris):
        keys = [_vkey(v) for v in t]
        for k in range(3):
            tri_of[(keys[k], keys[(k + 1) % 3])] = i
    out = []
    for e in edges:
        ka, kb = _vkey(e.a), _vkey(e.b)
        sides = (tri_of.get((ka, kb)), tri_of.get((kb, ka)))
        if sum(1 for x in sides if x in region) == 1:
            out.append(e)
    return out


def _place_key(values):
    return ",".join("%g" % round(v, 4) for v in values[:6])


def _pair(names, e):
    """The names of the two faces meeting at crease *e*, or None."""
    if names is None or e.il < 0 or e.ir < 0:
        return None
    a, b = names[e.il], names[e.ir]
    if a is None or b is None or a == b:
        return None
    return sorted((a, b))


def compute(tris, seeds, radius: float, kind: str = "round",
            detail: int = 6, min_angle: float = MIN_ANGLE,
            faces=(), places=None, names=None, named=None) -> dict:
    """``{"cuts": [tris...], "adds": [tris...], "missing": [seed...],
    "chains": n}`` for the remembered *seeds* on the mesh *tris*."""
    edges = crease_edges(tris, min_angle)
    size = mesh_size(tris)
    box = _box(tris) if tris else None
    cuts, adds, missing, seen = [], [], [], set()
    # 1. every edge to round: each picked edge with its tangent run (one
    #    click takes a cylinder's whole rim)
    chosen = {}
    by_key = {}
    for y in edges:
        by_key.setdefault(frozenset((_vkey(y.a), _vkey(y.b))), []).append(y)

    def take_run(e, max_turn=MAX_TURN):
        """*e* and the tangent-continuous creases running on from it
        (SolidWorks' tangent propagation): a face's rim carries on round
        a rounded end the face itself does not include (Exercise 8's
        clevis arms stopped square where their round ends began)."""
        for x in chain(edges, e, max_turn)["edges"]:
            for y in by_key.get(frozenset((_vkey(x.a), _vkey(x.b))), ()):
                chosen[id(y)] = y

    for seed in seeds:
        try:
            values = [float(v) for v in seed]
        except (TypeError, ValueError):
            missing.append(seed)
            continue
        if len(values) not in (6, 9):
            missing.append(seed)
            continue
        key = _place_key(values)
        want = (named or {}).get(key) if names is not None else None
        if want and len(want) == 2:
            # by NAME: every crease between the two faces it lies between,
            # wherever the rebuilt part put them
            hits = [y for y in edges if _pair(names, y) == sorted(want)]
            if hits:
                for y in hits:
                    chosen[id(y)] = y
                continue
        known = (places or {}).get(key) or \
            (values[6:9] if len(values) == 9 else None)
        e = find_edge(edges, values[:6], size)
        moved = False
        if e is None and known and box is not None:
            e = _edge_by_fraction(edges, values[:6] + list(known), box)
            moved = e is not None
        if e is None:
            missing.append(seed)
            continue
        if places is not None and box is not None and (
                moved or len(places.get(key) or ()) < 10):
            # remember where it sits in the part and which faces meet at
            # it, for when it moves — kept up to date as it moves
            mid = _mul(_add(e.a, e.b), 0.5)
            places[key] = [round(v, 6) for v in fraction(mid, box)] + \
                _faces_of(e)
        pair = _pair(names, e)
        if named is not None and pair and key not in named:
            named[key] = pair
        take_run(e)
    for row in faces or ():
        try:
            values = [float(v) for v in row]
        except (TypeError, ValueError):
            missing.append(row)
            continue
        key = _place_key(values)
        want = (named or {}).get(key) if names is not None else None
        if want and len(want) == 1:
            # by NAME: the face(s) the feature made, however it moved
            region = {i for i, n in enumerate(names) if n == want[0]}
            hits = [y for y in edges
                    if (y.il in region) != (y.ir in region)]
            if hits:
                for y in hits:
                    if id(y) not in chosen:
                        take_run(y, FACE_TURN)
                continue
        known = (places or {}).get(key)
        probe = values[:6] + list(known) if known and len(values) == 6 \
            else values
        where = {}
        found = face_edges(tris, edges, probe, size * 1e-5, box,
                           found=where) if len(values) in (6, 9) else []
        if not found:
            missing.append(row)
        elif places is not None and box is not None and where:
            # its place in the part and its direction NOW, so a run of
            # changes keeps finding it
            places[key] = [round(v, 6) for v in
                           fraction(where["centre"], box)] + \
                [round(v, 6) for v in where["normal"]]
            start = where.get("start", -1)
            if named is not None and names is not None and \
                    key not in named and 0 <= start < len(names) and \
                    names[start] is not None:
                named[key] = [names[start]]
        for y in found:
            if id(y) not in chosen:
                take_run(y, FACE_TURN)
    picked = list(chosen.values())
    # 2. join them: where exactly two chosen edges of one kind meet (a
    #    face's rim turning a corner, the L's inside corner) the run
    #    turns the corner MITRED — separate strips with square ends left
    #    a sharp point at every corner and notched the inside one (the
    #    user, 2026-10-21); where three meet it stops
    count = {}
    for x in picked:
        for key in (_vkey(x.a), _vkey(x.b)):
            count[(key, x.convex)] = count.get((key, x.convex), 0) + 1
    runs = []
    around = None                     # face normals at each vertex
    for e in picked:
        run = chain(picked, e, through=lambda key, k=e.convex:
                    count.get((key, k), 0) == 2)
        key = frozenset(_vkey(p) for p in run["points"])
        if key in seen:
            continue
        seen.add(key)
        runs.append(run)
        body = strip(run, float(radius), kind, int(detail),
                     section=_chamfer_section(kind, float(radius),
                                              int(detail)))
        if around is None:
            around = _vertex_normals(tris)
        body = _trim_ends(body, run, around)
        if not body:
            continue
        if _runs_away(body, run, float(radius)):
            # faces meeting almost flat (a rib ending on a tube nearly
            # tangent): the profile reaches to infinity — leave the edge
            # sharp rather than add a strip metres long (Exercise 7)
            missing.append(list(run["points"][0]) +
                           list(run["points"][-1]))
            continue
        if not run["convex"] and box is not None:
            body = _clip_to_box(body, box)
            if not body:
                continue
        (cuts if run["convex"] else adds).append(body)
    # 3. corners where THREE chosen edges of one kind meet (a face's rim
    #    and the upright edge under it): the strips stop square there and
    #    left a sliver standing (the user's chamfer). Bevel's corner
    #    piece — the rolling ball's patch, or a chamfer's triangle — fills
    #    the gap between them.
    cuts.extend(_corner_pieces(edges, runs, float(radius), kind,
                               int(detail), adds))
    return dict(cuts=cuts, adds=adds, missing=missing, chains=len(seen))


#: a strip may reach this many radii past its edge's own box
REACH = 4.0


def _runs_away(body, run, radius):
    """True when a fillet strip reaches far past its edge."""
    pts = run["points"]
    lo = [min(p[k] for p in pts) - REACH * radius for k in range(3)]
    hi = [max(p[k] for p in pts) + REACH * radius for k in range(3)]
    return any(not (lo[k] <= v[k] <= hi[k])
               for t in body for v in t[:3] for k in range(3))


def _vertex_normals(tris):
    """{vertex key: [face normals round it]} (distinct directions)."""
    out = {}
    for t in tris:
        n = _normal(t)
        for v in t:
            have = out.setdefault(_vkey(v), [])
            if not any(_dot(n, m) > 0.9999 for m in have):
                have.append(n)
    return out


def _trim_ends(body, run, around):
    """*body* (a run's strip) cut at each end of an OPEN run by the faces
    the edge runs into: a strip ends square across its edge, and where
    the edge meets the next face at a slant (a rib's sloped top running
    down onto the base) that square end reached through that face and
    carved into the base and the upright — the user's rounding stood up
    the wrong way at the rib's foot. As SolidWorks stops a fillet at the
    face its edge ends on, the strip keeps only the side of each such
    face's plane that the edge itself is on."""
    if run.get("closed") or not body or len(run["points"]) < 2:
        return body
    from . import csg
    if not csg.available():
        return body
    edges = run["edges"]
    ends = ((run["points"][0], edges[0], run["points"][1]),
            (run["points"][-1], edges[-1], run["points"][-2]))
    planes = []
    for p, e, inner in ends:
        q = _add(p, _mul(_sub(inner, p), 0.25))   # a point of the edge
        for m in around.get(_vkey(p), ()):
            if any(abs(_dot(m, f)) > 0.999 for f in (e.nl, e.nr)):
                continue                  # the edge's own two faces
            side = _dot(m, _sub(q, p))
            if abs(side) < 1e-6:
                continue                  # the edge runs along it
            n = m if side > 0 else _mul(m, -1.0)
            planes.append((n, _dot(n, p)))
    if not planes:
        return body
    try:
        solid = csg.to_manifold([(t, None, False) for t in body], {})
        if solid is None:
            return body
        for n, off in planes:
            solid = solid.trim_by_plane(tuple(n), off)
        out = csg.to_triangles(solid)
    except Exception:                       # pragma: no cover
        return body
    return out or body


def _chamfer_section(kind, radius, detail):
    """A chamfer's strips cut with Bevel's own profile, so the corner
    piece (bevel.corners, built on the same planes) meets them exactly —
    the fillet's grown triangle sat a hair off and the boolean left
    doubled edges. None (the usual profile) for a round."""
    if kind != "chamfer":
        return None
    try:
        from . import bevel
    except Exception:                       # pragma: no cover
        return None
    e = bevel.exponent(0.25)
    return lambda edge: bevel.section(edge, radius, max(detail, 1), e)


WELD_MAX = 0.05      # mm


def _weld_slivers(rows, tol=2e-3):
    """Merge vertices closer than *tol* (mm) in a boolean's coloured
    rows and drop what collapses: where a corner piece meets the strips
    beside it the cut leaves edges of a few microns — doubled edges a
    print check fails and the view draws as a stray line."""
    cell = {}
    def snap(v):
        k = tuple(int(round(c / tol)) for c in v)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    hit = cell.get((k[0] + dx, k[1] + dy, k[2] + dz))
                    if hit is not None and max(abs(a - b) for a, b in
                                               zip(hit, v)) <= tol:
                        return hit
        cell[k] = tuple(v)
        return tuple(v)
    out, seen = [], set()
    for row in rows:
        tri, rest = row[0], row[1:]
        t = tuple(snap(v) for v in tri)
        if t[0] == t[1] or t[1] == t[2] or t[0] == t[2]:
            continue
        key = frozenset(t)
        if key in seen:                     # a face and its twin: both go
            seen.discard(key)
            out = [r for r in out if frozenset(r[0]) != key]
            continue
        seen.add(key)
        out.append((t,) + tuple(rest))
    return out


def _open_edges(rows):
    """Directed edges with no partner running the other way."""
    count = {}
    for row in rows:
        t = [tuple(v) for v in row[0]]
        for a, b in ((t[0], t[1]), (t[1], t[2]), (t[2], t[0])):
            count[(a, b)] = count.get((a, b), 0) + 1
    return sum(max(0, n - count.get((b, a), 0))
               for (a, b), n in count.items())


def _corner_pieces(edges, runs, radius, kind, detail, adds):
    """Triangles of the corner cutters (convex corners); concave ones go
    to *adds*. Nothing without Manifold."""
    from . import csg
    if not runs or not csg.available():
        return []
    try:
        from . import bevel
        e = bevel.exponent(0.25 if kind == "chamfer" else 0.5)
        pieces = bevel.corners(edges, runs, radius, detail, e)
    except Exception:                       # pragma: no cover
        return []
    out = []
    for piece, convex in pieces:
        tris = csg.to_triangles(piece)
        if tris:
            (out if convex else adds).append(tris)
    return out


def chains(tris, min_angle: float = MIN_ANGLE) -> list:
    """Every distinct crease chain of *tris*, for listing (an assistant
    picks by geometry, a person by clicking): dicts with the seed
    segment, ends, length, dihedral, convexity, closed and centre."""
    edges = crease_edges(tris, min_angle)
    out, seen = [], set()
    for e in edges:
        run = chain(edges, e)
        key = frozenset(_vkey(p) for p in run["points"])
        if key in seen:
            continue
        seen.add(key)
        pts = run["points"]
        length = sum(x.length for x in run["edges"])
        centre = [sum(p[i] for p in pts) / len(pts) for i in range(3)]
        out.append(dict(
            seed=[round(v, 4) for v in (*e.a, *e.b)],
            start=[round(v, 4) for v in pts[0]],
            end=[round(v, 4) for v in pts[-1]],
            segments=len(run["edges"]), length=round(length, 3),
            angle=round(sum(x.angle for x in run["edges"])
                        / len(run["edges"]), 1),
            convex=run["convex"], closed=run["closed"],
            centre=[round(v, 4) for v in centre]))
    out.sort(key=lambda c: (-c["length"], c["centre"]))
    return out


# ---------------------------------------------------- node integration
_CACHE = {}
_CACHE_SIZE = 16


def _num(value, env, default):
    from .mesh import rv
    return rv(value, env, default)


def _merged(rows):
    """The children as ONE solid: parts that touch or overlap (an ear
    standing on a plate) are unioned (Manifold), so the inside corner
    where they meet is an edge to round — and rounding it ADDS material
    (the user's R2: each part alone has no such edge, and the click took
    the ear's own bottom edge, rounding it away). As they were when
    Manifold is missing or a piece is not a closed solid."""
    tris = [tri for tri, _c, _s in rows]
    try:
        from . import csg
        if not csg.available():
            return tris
        solid = csg.to_manifold(rows, {})
        if solid is None:
            return tris
        merged = csg.to_triangles(solid)
        return merged or tris
    except Exception:
        return tris


def baked(node, env) -> dict:
    """compute() for a fillet node, cached by content: the children's
    local mesh and the node's parameters.

    The children are tessellated at the segment count OpenSCAD will
    render them with — the document-wide $fn in force during codegen
    (model._FN_OVERRIDE) or the preview's (mesh._FN_OVERRIDE). A cut
    built round a 24-gon rim misses a 45-gon one."""
    from . import bake, document, mesh
    from . import model as model_mod
    fn = mesh._FN_OVERRIDE
    if fn is None:
        fn = model_mod._FN_OVERRIDE
    key = json.dumps([document.node_to_dict(node), fn,
                      sorted((k, repr(v)) for k, v in env.items())],
                     sort_keys=True, default=str)
    hit = _CACHE.get(key)
    if hit is None:
        p = node.params
        saved, saved_detail = mesh._FN_OVERRIDE, mesh._DETAIL
        # always at full detail: the 2D view tessellates parts under a
        # detail cap, and a cutter baked round a coarse rim would be
        # served from the cache to the program and miss the fine one
        mesh._set_fn(fn)
        mesh._DETAIL = None
        try:
            rows = mesh._children_mesh(node, env, None, frozenset(), False)
        finally:
            mesh._set_fn(saved)
            mesh._DETAIL = saved_detail
        src = _merged(rows)
        # where each picked edge / face sits in the part (box fractions),
        # kept beside the picks so they follow the part when it changes
        # (the user); never written into the program
        places = p.get(PLACES)
        if not isinstance(places, dict):
            places = p[PLACES] = {}
        named = p.get(NAMES)
        if not isinstance(named, dict):
            named = p[NAMES] = {}
        try:                      # each face named by what made it
            from . import face_names
            names = face_names.names(node, env, src)
        except Exception:
            names = None
        result = compute(src, p.get("edges") or [],
                         _num(p.get("radius", 2.0), env, 2.0),
                         str(p.get("kind", "round")),
                         int(_num(p.get("detail", 6), env, 6.0)),
                         faces=p.get("faces") or [], places=places,
                         names=names, named=named)
        result["cut_polys"] = [bake.to_polyhedron(t) for t in result["cuts"]]
        result["add_polys"] = [bake.to_polyhedron(t) for t in result["adds"]]
        hit = _CACHE[key] = result
        while len(_CACHE) > _CACHE_SIZE:
            _CACHE.pop(next(iter(_CACHE)))
    return hit


def statement(node, fmt) -> str:
    from . import bake
    p = node.params
    try:
        result = baked(node, bake._codegen_env(node))
        cut_polys, add_polys = result["cut_polys"], result["add_polys"]
    except Exception:                       # validation has flagged it
        cut_polys, add_polys = [], []

    def polys(items):
        if not items:
            return "[]"
        return "[\n    " + ",\n    ".join(
            f"[{bake._rows_wrapped(pts, fmt)}, {bake._rows_wrapped(fcs, fmt)}]"
            for pts, fcs in items) + "\n    ]"
    kind = p.get("kind", "round") if p.get("kind") in KINDS else "round"
    return (f"kcad_fillet(radius = {fmt(p.get('radius', 2.0))}, "
            f'kind = "{kind}", detail = {fmt(p.get("detail", 6))}, '
            f"edges = {bake._rows(p.get('edges') or [], fmt)},"
            + (f" faces = {bake._rows(p['faces'], fmt)},"
               if p.get("faces") else "") + "\n"
            f"    cuts = {polys(cut_polys)},\n"
            f"    adds = {polys(add_polys)})")


def build(parser, positional, named):
    """scadparse builder for kcad_fillet: parameters back, baked
    polyhedra ignored (the children in the block rebuild them)."""
    from .model import CadNode
    from .scadparse import _num as num
    edges = named.get("edges", [])
    rows = ([[num(v) for v in row] for row in edges
             if isinstance(row, list) and len(row) == 6]
            if isinstance(edges, list) else [])
    kind = named.get("kind", "round")
    try:
        detail = int(num(named.get("detail", 6), 6))
    except (TypeError, ValueError):
        detail = 6
    params = dict(
        radius=num(named.get("radius", 2.0), 2.0),
        kind=kind if kind in KINDS else "round", detail=detail,
        edges=rows)
    faces = named.get("faces", [])
    face_rows = [[num(v) for v in row] for row in faces
                 if isinstance(row, list) and len(row) == 6] \
        if isinstance(faces, list) else []
    if face_rows:
        params["faces"] = face_rows
    return CadNode("fillet", NODE_TYPES["fillet"]["label"], params)


def check(node, env):
    from .model import _contains_3d
    parent = node.parent
    while parent is not None:
        if parent.type in ("for_loop", "while_loop", "if_else"):
            kind = parent.type.replace("_", " ").replace(" loop", "")
            return ("a fillet is baked into the program, so it can't sit "
                    f"inside a {kind} — put the {kind} inside the fillet")
        parent = parent.parent
    if not any(c.type != "assign" for c in node.children):
        return "empty — put the solid to round inside"
    if not _contains_3d(node):
        return "a fillet rounds the edges of a solid — this holds only 2D"
    p = node.params
    if str(p.get("kind", "round")) not in KINDS:
        return "kind must be 'round' or 'chamfer'"
    rows = p.get("edges") or []
    if not isinstance(rows, list):
        return "edges: give rows of start x, y, z, end x, y, z"
    for number, row in enumerate(rows):
        if not isinstance(row, list) or len(row) not in (6, 9):
            return f"edge {number} needs 6 values: start x y z, end x y z"
    if not rows:
        return None                          # nothing picked yet: fine
    try:
        result = baked(node, env)
    except Exception as exc:                 # pragma: no cover
        return f"fillet failed: {exc}"
    if result["missing"]:
        n = len(result["missing"])
        return (f"{n} of {len(rows)} edges not found on the part any "
                "more (it changed) — pick them again")
    return None


def tess(node, env, color, sel, selected):
    """Preview: the children minus the convex cuts (through Manifold,
    csg.py) plus the concave fillers. Without Manifold, or when a cut
    fails, the cuts are left to the exact OpenSCAD render, as for any
    difference."""
    from . import csg, mesh
    out = list(mesh._children_mesh(node, env, color, sel, selected))
    try:
        result = baked(node, env)
    except Exception:
        return out
    if result["cuts"] and csg.available():
        tools = [row for body in result["cuts"]
                 for row in mesh._emit(body, color, selected)]
        cut = csg.boolean("difference", [out, tools])
        if cut is None:
            csg.FAILED.add(node.id)
        else:
            csg.FAILED.discard(node.id)
            size = abs(float(_num(node.params.get("radius", 2.0), env,
                                  2.0)))
            # capped: 2.5 % of a 48 mm radius merged corners 0.9 mm apart,
            # and the plate under the fillet lost a long thin wedge of its
            # top (the user's cut left a strip along that edge)
            welded = _weld_slivers(cut, max(2e-3, min(size * 0.025,
                                                      WELD_MAX)))
            # the weld must not OPEN the solid (2026-11-14, Exercise 55: an
            # arm edge running tangent into a hub left 3 open edges, and
            # the Difference after the fillet stopped cutting)
            out = welded if _open_edges(welded) <= _open_edges(cut) \
                else cut
    for body in result["adds"]:
        out.extend(mesh._emit(body, color, selected))
    return out


def uses_booleans(node) -> bool:
    """True when the exact render will differ from the preview — a
    convex edge is filleted by subtraction."""
    return bool(node.params.get("edges"))
