"""MCP (Model Context Protocol) stdio server for KherveCAD.

This module is the *client-facing half* of KherveCAD's MCP support.
It speaks JSON-RPC 2.0 over stdin/stdout — the transport every MCP host
(Claude Desktop, Claude Code, Cursor, Zed, Continue, …) knows how to
launch — and forwards each ``tools/call`` to a running KherveCAD
window over a loopback socket (see ``mcp_bridge.py``).

The split matters: CAD tools have to edit a live object tree and read
back what the viewers are showing, so they must run inside the
application's GUI thread.  The MCP host, by contrast, wants to spawn a
short-lived subprocess it owns.  This file is that subprocess; it
deliberately imports **no Qt and no third-party package**, so it starts
in milliseconds and works from any Python.

Run it directly with::

    python -m khervecad.mcp_server

or, for a frozen build::

    KherveCAD.exe --mcp-server

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from __future__ import annotations

import base64
import json
import os
import socket
import sys
from typing import Any, List, Optional


# ── Protocol constants ─────────────────────────────────────────────

#: Spec revisions we know how to speak.  We echo the client's choice
#: when it is one of these, otherwise we answer with our newest.
SUPPORTED_PROTOCOLS = ("2025-06-18", "2025-03-26", "2024-11-05")
LATEST_PROTOCOL = SUPPORTED_PROTOCOLS[0]

SERVER_NAME = "khervecad"

#: Endpoint file written by the in-app bridge; names host, port, token.
ENDPOINT_FILENAME = "mcp-bridge.json"

_CONNECT_TIMEOUT = 5.0    # seconds to establish the bridge socket
_CALL_TIMEOUT = 600.0     # an exact OpenSCAD render is legitimately slow


# ── Endpoint discovery ─────────────────────────────────────────────

def state_dir() -> str:
    """Directory holding KherveCAD's per-user runtime state.

    Kept free of Qt so both halves of the MCP stack agree on the path
    without the stdio server having to import PyQt5.
    """
    if sys.platform.startswith("win"):
        base = (os.environ.get("LOCALAPPDATA")
                or os.path.expanduser("~\\AppData\\Local"))
        return os.path.join(base, "KherveCAD")
    if sys.platform == "darwin":
        return os.path.expanduser(
            "~/Library/Application Support/KherveCAD")
    base = (os.environ.get("XDG_CONFIG_HOME")
            or os.path.expanduser("~/.config"))
    return os.path.join(base, "KherveCAD")


def endpoint_path() -> str:
    """Full path of the bridge endpoint description file."""
    return os.path.join(state_dir(), ENDPOINT_FILENAME)


def read_endpoint(path: Optional[str] = None) -> Optional[dict]:
    """Load the endpoint file, or None when the app is not serving."""
    try:
        with open(path or endpoint_path(), "r", encoding="utf-8") as fh:
            info = json.load(fh)
    except Exception:
        return None
    if not isinstance(info, dict) or "port" not in info:
        return None
    return info


_NOT_RUNNING = (
    "KherveCAD is not reachable.\n\n"
    "The MCP server drives a live KherveCAD window, so the "
    "application must be running with its bridge enabled:\n"
    "  1. Start KherveCAD.\n"
    "  2. Enable AI ▸ Connect to Claude (Simple).\n"
    "Then retry — no need to restart this MCP connection."
)


class BridgeError(RuntimeError):
    """Raised when the running application cannot be reached."""


#: Sent to the client on initialize.  The host writes its own system
#: prompt, so everything a model must know before rebuilding someone
#: else's open document has to travel with the connection.
_INSTRUCTIONS = """\
These tools drive a LIVE KherveCAD window — a parametric CAD app whose \
document is a TREE of objects that compiles 1:1 to an OpenSCAD program. \
OpenSCAD is the engine, so what you build is real solid geometry, not a \
picture of one. Everything you do appears immediately in the document \
open in front of the user.

CHECK THE LIBRARY FIRST. Before modelling anything the user asks for \
— a part, a piece of furniture, a fastener, a building, a vehicle, a \
molecule — call list_parts with `search` set to a word or two from the \
request (try a synonym if nothing comes back; list_examples too). If a \
part fits, insert_part it (and set its size / colour) instead of \
building it from scratch, and say which part you used. Model it \
yourself only when nothing in the library fits, or the user asks for \
a custom build — and then tell them the library had no match.
MY LIBRARY. The user keeps their own parts (their saves and yours) in \
~/Documents/KherveCAD Library, one folder per AREA of work (Sport, House \
& home, Trees & plants, Molecules, Unit cells & crystals...); list_parts \
searches them too, descriptions included, under 'My library: <area>' — \
reuse one before modelling again. Every Object created or changed in \
the window is SAVED AUTOMATICALLY a few seconds later, titled by its \
name — so name every Object descriptively (what it is + key size, never \
'Object 2', which is skipped). When a design looks right, call \
save_to_library on it with its area, a descriptive title and a real \
DESCRIPTION (purpose, dimensions, parameters and what they change, \
construction, how to reuse) plus tags: later autosaves keep that text, \
and it is how the next request finds the part.
A stadium, arena or sports ground is ONE insert_part of a 'Sport: \
stadiums' part (size = the sport, colour = the seats; rows, upper_rows, \
roof 0/1/2 and changing as dims) — never hand-build the bowl.

The tree is the single source of truth:
- Every node is one OpenSCAD statement. 2D shapes (rect, circle, \
polygon, text, line), 3D primitives (cube, sphere, cylinder), \
operations that WRAP their children (translate, rotate, scale, mirror, \
linear_extrude, rotate_extrude, offset, color), booleans (union = \
group, difference, intersection, hull, minkowski) and control flow \
(for_loop, while_loop, if_else, assign).
- Call list_node_types ONCE at the start: it gives every type, its \
parameters and their ranges. Guessing a parameter name wastes a call.
- get_document_info first, then list_tree. Nodes are addressed by the \
integer `id` from list_tree; ids are stable while a node lives, but \
undo and open rebuild the tree, so re-read them afterwards.
- Numbers may be EXPRESSIONS as strings: "wall * 2", "i * 10", \
"cos(a) * r". That is how a loop variable or a document variable \
reaches a parameter, and it is what makes a model parametric. Prefer \
an assign node plus expressions over hard-coded numbers when the user \
asks for something adjustable.

Two ways to build, and they compose:
- Node by node — add_node, set_params, wrap_nodes (this is how a \
difference or an extrude is applied: it wraps the nodes you name), \
move_node, duplicate_node, delete_nodes.
- apply_code — hand it an OpenSCAD program and it is PARSED INTO REAL \
NODES, not pasted as text. For anything with structure this is far \
faster than a dozen add_node calls, and the result is still an ordinary \
editable tree. Read get_code first to see the program as it stands. \
The importer reads real OpenSCAD: resize, multmatrix, render, let, \
echo, assert, intersection_for, children() in modules, vector maths, \
strings, function literals — each becomes an editable node. A call it \
cannot turn into objects is KEPT as a scad_raw node (OpenSCAD code the \
engine renders exactly), with a warning, never dropped. Libraries work: \
start the program with `include <BOSL2/std.scad>` or `use \
<MCAD/involute_gears.scad>` (list_scad_libraries says which are \
installed; ask the user before install_scad_library) — library calls \
that import cleanly become objects, the rest stay code. Expressions \
over variables stay expressions, so an imported or applied program is \
parametric. Annotate adjustable variables the OpenSCAD Customizer way — \
`/* [Size] */` tabs, a `// description` line above, `width = 40; // \
[10:5:200]` or `lid = "snap"; // [snap, screw]` — and they become \
sliders and drop-downs in the Variables sheet. Mechanical features are \
nodes too: `kcad_gear(kind = "spur" | "helical" | "herringbone" | \
"internal" | "rack" | "bevel" | "worm", m = 2, teeth = 20, \
pressure_angle = 20, thickness = 6, helix = 20, bore = 5, backlash = \
0.1)` — true involute teeth; two gears mesh at m (z1 + z2) / 2 apart; \
`kcad_thread(kind = "metric" | "trapezoidal" | "square" | "buttress" | \
"pipe" | "bottle", diameter = 8, pitch = 1.25, length = 16, starts = 1, \
left_hand = false, internal = false, clearance = 0.2)` (internal = the \
tap to subtract for a nut); `kcad_hole(kind = "plain" | "counterbore" | \
"countersink" | "nut_trap" | "heat_insert" | "slot" | "teardrop", \
diameter = 3.2, depth = 10, head_diameter = 6, head_depth = 3.2)` — the \
solid to subtract, top at z = 0. Also `kcad_knurl(diameter, length, \
count, depth, angle)`, `kcad_polyhedron(kind = "icosahedron" | \
"truncated_icosahedron" | …, radius)`, and 2D `kcad_star(points, radius, \
inner_radius)`, `kcad_rounded_polygon(corners = [[x, y, r], …])`, \
`kcad_bezier_shape(controls = [[x, y], …])` (point, control, control per \
curve), `kcad_honeycomb(size = [w, h], cell, wall, margin)`, \
`kcad_textured(shape = "cylinder" | "panel", pattern = "diamonds" | \
"ribs" | "waves" | "bricks" | "hexes" | "dimples" | "checkers", diameter, \
height, period, relief)`; to add an svg_path shape use add_node with \
d = "M 0 0 L 40 0 A 10 10 0 0 1 40 20 Z" (y up). A wire, cable, \
handrail or bent rod is `kcad_curve(points = [[x, y, z], …], style = \
"smooth" | "straight", closed = false, thickness = 2)` — a 3D curve \
through the points, exported to STEP as an exact B-spline pipe.
- Other CAD programs: open_document reads STEP / IGES / Rhino .3dm / \
.brep (named, coloured parts, one Object); export_document writes \
.step / .iges with EXACT surfaces for primitives, extrusions, revolves, \
booleans and curves (others faceted, listed in the result) and .3dm as \
meshes. Send STEP when the user wants to continue in Fusion, \
SolidWorks, Onshape, FreeCAD or Rhino. exact_part fillets / chamfers \
an imported STEP part's TRUE edges (world points on them).
- Rhino-style surfaces: draw curves, then make_surface (loft / sweep / \
sweep2 / patch / revolve / extrude) — exact, thickened into a solid \
when open. Smooth organic forms: add_node type subd with a polyhedron \
cage inside (or kcad_subd), shaped by edit_mesh on the cage. Surface \
checks: set_render_options heatmap draft / curvature / zebra. A line \
drawing from the current camera: export_drawing views ["Current"].
- A turntable movie / video / advert / GIF of the model turning: \
export_movie path ".mp4" or ".gif" (seconds, fps, turns, size, \
elevation; motion "light" keeps the model still and sweeps the light) — set up the look first (colours, materials, a Cut \
Through, the platform); every frame is the 3D view as the user sees it.
- Beyond OpenSCAD's own shapes, apply_code understands KherveCAD's \
helpers, which parse into editable nodes: `kcad_sweep(path = [[x, y, \
z], ...], smooth = 3, twist = 0, scale = 1, wall = 0, closed = false) \
{ <2D profile> }` drives a flat profile along a 3D path — pipes (wall > \
0 hollows it), handrails, cable runs, springs, O-rings (closed = true); \
`kcad_loft(sections = [[x, y, z, rx, ry], ...])` is a tube through \
elliptical sections; kcad_capsule / kcad_ellipsoid / kcad_rounded_box \
are the organic solids; `kcad_pattern(kind = "linear" | "polar" | \
"grid", count = 6, step = [dx, dy, dz], angle = 360, axis = "z", rise = \
0, counts = [nx, ny, nz]) { … }` repeats its children — a bolt circle \
(polar, angle 360 spreads count copies evenly; below 360 they span the \
angle), a row (linear), a spiral stair (polar with rise), a peg board \
(grid) — with no loop variable to invent; `kcad_shell(thickness = 2, \
open = "top") { … }` hollows a solid into an even-walled shell (a cup: \
open = "top"; "none" for a closed hollow), and `kcad_fillet(radius = 2, \
kind = "round", edges = [[x1, y1, z1, x2, y2, z2], ...]) { … }` rounds \
the edges listed (get them from list_edges, or use fillet_edges). \
To round or chamfer EVERY sharp edge of a part at once — a machined \
block, a printed case, an enclosure — wrap it in `kcad_bevel(width = \
1, segments = 4, profile = 0.5, angle = 30, which = "convex") { … }` \
(profile 0.5 round, 0.25 flat chamfer; which "convex" / "concave" / \
"both"; rounded ball corners where three edges meet; the part keeps \
its size) instead of fillet_edges edge by edge or a minkowski that \
grows it. A part too heavy to draw or export (a scan, a sculpt, a \
tree, threads) goes in `kcad_decimate(ratio = 0.25, tolerance = 0) { \
… }` (keep a quarter of the triangles; or tolerance = 0.05 mm, \
invisible on a print). To put one shape ON another — a garment, cap, \
strap, sticker or armour plate on a body, a label on a bottle — wrap \
BOTH in `kcad_shrinkwrap(mode = "nearest", offset = 0.5, keep = \
"outside") { piece; target; }`: the FIRST child is pressed onto the \
rest (drawn too), offset mm off its surface; keep "outside" moves only \
what sinks in, "all" lays it flat on the surface; mode "project" with \
axis "-z" drops it straight down. Give a blocky piece `detail = 2` so \
it has vertices to bend. A part check_printability calls not \
watertight — a union of overlapping pieces, an imported scan, a folded \
sculpt — or that bevel / shrinkwrap / a boolean refuses, goes in \
`kcad_remesh(voxel = 0.5, snap = true) { … }`: one closed solid again \
(voxel = the detail kept, mm). A lattice, cage, lamp shade or geodesic \
dome: `kcad_wireframe(thickness = 1.5, sides = 6, angle = 1, joints = \
true) { <shape> }` makes every real edge a strut (angle 1 skips flat \
faces' diagonals); nest kcad_decimate inside for fewer, longer struts. \
Fabric that hangs — a tablecloth, a cape, a sheet over furniture, a \
flag — is `kcad_cloth(lift = 20, detail = 5, thickness = 1, steps = \
120, substeps = 12, friction = 0.6, pins = [[x1, y1, z1, x2, y2, z2]]) \
{ <2D shape>; <what it falls on> }`: the 2D shape FIRST (the cloth, \
laid flat lift mm above the rest), the colliders after (drawn too); \
pins hold the cloth inside each box. Never model drapery by hand. \
To change a FLAT face of an existing part — raise it, sink a pocket, \
thin a plate — use push_pull_face (point = a probe_surface hit on the \
face, distance > 0 out / < 0 in, inset leaves a rim) rather than \
rebuilding the part; to cut a part by a plane, wrap it in \
`kcad_bisect(px, py, pz, nx, ny, nz, keep = "above" | "below" | \
"both", gap)`. To smooth a faceted part but keep its real edges — a \
low-poly cage, a revolve with too few sides — `kcad_subdivide(levels = \
2, sharp = 40) { … }`: edges sharper than 40° stay crisp. \
To shape a part BY ITS VERTICES — a wedge, a nose cone, a hull, a \
low-poly figure, the corner no primitive gives — use edit_mesh \
(Blender's Edit Mode; the user has it as Tab over the 3D view): \
operation open converts the part into a polyhedron (a cube is 8 \
vertices, 6 quads) and lists its vertices in world mm; then move \
(`delta`, `proportional` mm for a smooth pull, `mirror` for both \
halves), extrude chosen faces out by `distance`, subdivide them for \
more vertices, split_edge / poke to add one, merge, dissolve, smooth; \
box-model a creature with inset (a face border `thickness` mm, inner part \
pushed `depth` — then extrude it into a horn or snout), loop_cut (`edge`: \
an edge loop round a limb to bend it at), knife (a plane through `at` \
with `normal`), bridge (two face regions joined by a tube: arm to body, \
a handle) and spin (faces swept round an axis in `steps`, `taper` to a \
point: a curling horn or tusk). \
Choose vertices by index or a world box (`within`). Every call keeps \
the solid closed. Start from a coarse cube or cylinder, not a fine \
sphere — a few vertices are easy to place. \
Prefer a sweep to a chain of hull()s. For a body whose cross-sections \
have corners (a car, a boat hull), `kcad_section_loft(heights = [[z0], \
[z1], ...], smooth = 0)` with one 2D child shape per section, in \
order, lofts through them.
- NAME EVERY PIECE YOU BUILD. End EVERY shape line — each cube(), \
sphere(), cylinder(), capsule… — with a short comment saying which part \
of the model it is: `cube([4, 4, 12]);  // Front-left leg`, \
`sphere(1.5);  // Left eye`. Label blocks on their opening line too \
(`for (i = [0:3]) {  // Legs`, `color("white") {  // Socks`), but a \
labelled block is not enough: every shape inside needs its own label, \
or the tree shows rows of bare "Cube". The tree then reads "Cube \
[Front-left leg]". Plain words, 2–5 of them, one statement per line; no \
banner comments (`// ---- Legs ----`, `// ======`), no sizes or \
sentences in the label. With add_node pass name="Cube [Front-left leg]".
- EXPLAIN OBJECTS. Most users do not know KherveCAD's Objects. \
Whenever you create or use one (make_object, add_instance, \
add_linked_copy, make_master, or a module in apply_code — a \
parameterless module becomes an Object), tell the user in one or two \
plain sentences what you made, why, and where it lives: e.g. "I built \
the leg once as an Object (see the Object tab) and placed four \
instances in Main, so changing the leg changes all four."

Modelling a real object (a car, an aircraft, a building, a product):
- Find its REAL DIMENSIONS before building anything — search the web \
if you can (and give the user the source), else ask. Pin the exact \
variant first: a 1966 Mini is 3.05 m long, a 2024 one 3.88 m.
- Look for a multi-view drawing (a blueprint: side, front, top) too, or \
ask the user for one. Ask before downloading a picture: it is a private \
reference, never to ship in the library or publish. Cut it into single \
views (`python -m khervecad.tools.refsheet` in a KherveCAD checkout \
trims each view and prints true-size placements) and place each with \
set_reference_image at TRUE SIZE: a vehicle's side view on Front (XZ), \
its front view on Side (YZ), its top view on Top (XY).
- Build over the drawing, then check: orthographic render_view from \
Front, Right and Top against the pictures, and bounds_mm against the \
real size. No drawing exists for most creatures and one-off designs — \
use real sizes of comparable things and design by eye.

Parts and assemblies — this is the part KherveCAD cares most about:
- An **Object** (node type "component") is a part DEFINITION: it \
compiles to its own OpenSCAD module. The Main tab is an assembly of \
Objects and instances of them; the Object tab is where a part is built.
- make_object promotes nodes into a part; add_instance places another \
copy of the same Object into the assembly, each with its own placement \
and colour. Build a part ONCE and instance it, rather than duplicating \
its geometry.
- attach_parts mates one part to another anchor-to-anchor (BOSL2 \
attach(), no constraint solver): the anchors coincide and their \
directions oppose. list_anchors gives the names — every part has \
automatic bounding-box anchors (Origin, 6 face centres, 12 edge \
midpoints, 8 corners) plus any the user picked. A mate is live: move \
the parent and the child follows.
- collections groups parts to show / hide / lock together (the \
Collections tab) — put a house's walls, roof and furniture each in one, \
or a mechanism's moving parts, so the user can hide the roof to look in. \
Hidden is a view setting: exports keep everything.
- make_master / add_linked_copy place one piece many times (even in a \
loop): the piece becomes a hidden Object and each copy calls it, so \
editing it changes every copy.

Motion — mechanisms, orreries, anything that MOVES:
- Drive it from ONE annotated document variable, the OpenSCAD \
Customizer way: `angle = 0;  // [0:5:360]` with a `// description` line \
above and a `/* [Motion] */` group. The user then gets a slider with a \
play button that sweeps it, and you can step it yourself with \
set_params on that assign node. Real time, not frames: give a wheel \
its true turns per unit and a planet its true period, so the same \
variable drives everything in step.
- Make every moving piece its OWN Object, and let the moving variable \
reach it ONLY through PLACEMENT — the Object's x/y/z/rx/ry/rz, or \
translate / rotate / scale wrapped around it. Then its mesh is built \
once and each frame only moves it, which is the difference between a \
mechanism that runs at a touch and one that stutters.
- NEVER let the moving variable reach GEOMETRY inside a part: a \
cube's size, a cylinder's height, a gear's teeth, a polygon's points, \
a loft's sections, anything a boolean or a kcad_* helper is built \
from. That re-cuts the solid every single frame. Compute the moving \
numbers in assign nodes and spend them on placement only.
- Position parts with expressions, not by writing new numbers each \
step: `translate([r * cos(angle), r * sin(angle), 0])`, a crank pin at \
`sqrt(rod * rod - y * y)`, a driven gear at `-angle * n1 / n2`. The \
model then holds the whole motion, and it exports as one OpenSCAD \
program that anyone can run.
- Keep moving parts light and boolean-free where you can: the \
built-in preview draws them every frame, and a part with a boolean in \
it has to go back through OpenSCAD. Capsules, cylinders, gears and \
coloured primitives move freely; a part that must be cut is best cut \
once and then only moved.
- When the user asks you to make it MOVE, ROTATE, SPIN, RUN, ANIMATE \
or show it "in action", finish with play_motion: it presses the \
Customizer's play so the motion runs in front of them — building the \
motion without playing it leaves them looking at a still model. With \
no arguments it finds the motion slider; `spin` with a part's id \
makes a still part (a planet, a wheel, a turntable) turn about its own \
axis in one call. play: false stops it.
- Library ▸ Mechanisms & motion already holds worked examples — gear \
pair, crank and piston, rack and pinion, cam, four-bar, planetary, XY \
table, scissor lift, robot arm — and Library ▸ Solar System holds \
orreries on real orbits. insert_part one and read it with get_code to \
see the shape of a fast mechanism before writing your own.
- For an OpenSCAD-native animation ($t, 0 to 1 over a loop) use \
set_render_options time; the same rule applies, $t belongs in \
placement, never in the geometry of a part.

Crystals, lattices and nanoparticles:
- NEVER type a crystal's atoms by hand. list_crystals gives the \
library — FCC/BCC/HCP metals, diamond and zinc-blende semiconductors, \
wurtzite, rock salt, CsCl, fluorite, rutile, anatase, perovskite, \
alpha-quartz, graphite, h-BN — with space group, cell, atoms per cell, \
density and polyhedra; build_crystal builds from it, or from `custom` \
(a, b, c, alpha, beta, gamma and every atom of the conventional cell in \
fractional coordinates, from a paper or a CIF) when the material is \
missing. Every library crystal is a ready Part Library part too: \
insert_part with part_id "crystal_<key>" (its unit cell) or \
"supercell_<key>" (size "2x2x2" to "6x6x6") — the quickest start.
- Work in NANOMETRES (build_crystal switches an empty document to nm) \
and in the builder's hierarchy, each level its own Object: the UNIT \
CELL (atoms at covalent radii, the lattice box, coordination polyhedra \
such as SiO4 tetrahedra), a SUPERCELL (for loops over na x nb x nc \
cells), a PARTICLE (sphere, hemisphere, cube, box, cylinder, hexagonal \
prism or octahedron filled with cells or with N x N x N blocks). build \
"hierarchy" makes all three side by side — the clearest answer to "show \
me what this nanoparticle is made of"; build "scatter" spreads `count` \
copies of one particle over `area_nm`, each resting on the plane and \
never touching — nanoparticles dispersed on a substrate.
- Mind the scale: a 10 nm particle holds tens of thousands of atoms and \
a 100 nm one tens of millions. Atoms are the costliest to draw, \
polyhedra (one solid per coordination unit) about ten times lighter, \
blocks lighter still. fill "auto" keeps cells while the view can draw \
them and switches to blocks beyond; dry_run returns the counts and \
triangles without building. A refused build says what to change — do \
that, do not retry the same call.
- Tell the user what one entity stands for ("each block is 10^3 unit \
cells = 3000 SiO2") and which prefixed variables reshape it (radius, \
block size, gap on the Variables tab). Look with render_view: \
orthographic from Top shows the lattice down the c-axis.

Surfaces, graphene, graphite, nanotubes and fullerenes:
- A crystal SURFACE (a slab cut along a plane): build_surface with a \
library crystal and any Miller index — Si(111), Cu(100), rutile (110), \
quartz (0001), GaN (10-10) — `repeat` cells across and `layers` deep, \
the top at z = 0. Every library crystal's usual faces are also ready \
parts: list_parts category "Surfaces: Metals" (also Semiconductors, \
Ionic salts, Oxides, Carbon & nitrides), part_id \
"surface_<key>_<hkl>" ("surface_si_111", "surface_gan_10m10" — a minus \
sign is written m), dims surf_repeat and surf_layers.
- GRAPHENE and GRAPHITE: insert_part from category "Surfaces: \
Graphene & graphite" — graphene_sheet, graphene_bilayer_ab / _aa, \
graphene_trilayer_aba / _abc, graphene_twisted (dims twist in degrees; \
21.79, 13.17, 9.43 and 5.09 are the commensurate moiré angles), \
graphene_ribbon_armchair / _zigzag and graphene_quantum_dot (edges \
capped with hydrogen), graphene_vacancy, graphene_n_doped, \
graphite_surface and graphite_step (HOPG (0001), dims sheet_layers). \
Sizes are in NANOMETRES: dims width, depth, length, diameter. Sheets, \
stacks and graphite arrive as a parametric loop program (variables nx, \
ny, layers, gap, twist inside the Object): to change the flake, \
set_params on those variables rather than rebuilding it.
- NANOTUBES: insert_part from "Crystals (nanotubes)" — \
nanotube_armchair (dims tube_n: an (n, n) tube), nanotube_zigzag \
(tube_n: (n, 0)), nanotube_chiral (tube_n, tube_m with m <= n), \
nanotube_multiwall (inner armchair tube_n, tube_walls ~0.34 nm apart), \
nanotube_capped (a (5, 5) tube closed by C60 halves); every one takes \
length in nm. The diameter is 0.0783 x sqrt(n² + nm + m²) nm, so a \
(10, 10) tube is 1.36 nm across.
- FULLERENES: build_molecule compound "c60" (also "c20", "c70", \
"c80"), or insert_part "fullerene_c60" etc. (category "Molecules: \
Fullerenes"). C60's 6-6 bonds are drawn double.
- Never place graphene, nanotube or fullerene atoms by hand or with \
SMILES: these parts build them on their exact lattice (C-C 0.142 nm, \
every carbon with 2-3 neighbours). Everything is in nm and an empty \
document switches to nm by itself; very large sizes are refused by the \
triangle budget, so choose a few nm.

Villages, towns, cities, parks and landmarks:
- ALWAYS call get_city first. It lists every valid building style, \
wall, roof, road kind, tree species, terrain and library piece id, with \
a worked example spec, and returns the city the document already holds \
(`current`). Never guess a style name or a part id.
- build_city takes a whole spec: `layout` (village/town/city) or your \
own roads, buildings, lights, trees and props (any library piece: a \
park, a pitch, a traffic light, a landmark, a bridge), optionally ON a \
`terrain` (hills, mountain, valley...: roads follow the slopes, \
buildings stand on levelled pads — a street grid on hills is San \
Francisco). Coordinates are mm, centred on the origin; a building's \
front faces -Y and rz (0-360) turns it towards its road.
- build_city REPLACES the city by default. To change one: get_city, \
edit `current` (move a building, add a road...), send it back whole. \
To add pieces to what is there, pass mode "add".
- A REAL place (a named street, village, an address): use import_map \
with center [lat, lon] + radius_m — the app downloads OpenStreetMap \
outlines and roads, England's LiDAR ground, building heights and trees, \
and optionally the aerial photo. Never transcribe map coordinates into \
build_city by hand. Large specs go through files: import_map path=, \
build_city path= / save_to=.
- Single pieces for any document: insert_part with a part_id from \
list_parts (categories Buildings, Trees, Park & sport, Lighting & \
signals, Landscape, Landmarks, Skyscrapers, Bridges) and x, y, z, rz to \
place it. Landmarks and bridges are true size (the Golden Gate is \
2.7 km): pick a "Model" size for a desk-sized one.
- Look with render_view: orientation Top for the plan, azimuth / \
elevation / target / distance for a street-level view.

Houses:
- Build a house with build_house — rooms, doors, windows and furniture \
in one call. Put furniture against a wall with `wall` (+ `along`) \
rather than computing coordinates: the builder reads each part's depth \
and turns it to face the room. Each piece becomes its own Object inside \
its floor's Object. Look with render_view from Top, orthographic.

Air conditioning — a split system always has an INDOOR unit and an \
OUTDOOR one, piped together THROUGH A WALL; never draw that pipework \
by hand:
- One insert_part of "hvac_split_system" (category "Air \
conditioning", size = the BTU rating) builds both units AND the \
liquid + insulated-gas refrigerant lines and condensate drain between \
them, routed straight through a wall sleeve. dims wall_thickness, \
outdoor_offset (the outdoor unit's sideways shift along the wall), \
outdoor_gap (its clearance off the wall face) and indoor_height (the \
indoor unit's mounting height) shape the run; leave them unset for \
sensible defaults.
- Placing it against a real wall: the part's own origin (x, y, z = 0, \
rz) is the FLOOR directly below where the indoor unit hangs, with its \
BACK flush on the wall's inside face — put x/y/rz there (rz turns the \
whole system to face into the room) and set wall_thickness to that \
wall's real thickness (get_node_bounds on the wall, or the house \
spec's own wall thickness) so the pipe run neither floats short of \
the outside face nor pokes through it.
- Need the two units on their own (different rooms, a longer run, a \
bend round a corner) — insert_part "hvac_indoor_unit" (it hangs near \
the ceiling by itself in a House Builder room) and \
"hvac_outdoor_unit" (ground-standing) separately, then pipe them: \
both cabinets carry the same three connectors — liquid, insulated \
gas, drain — at their BACK face, near the bottom-left corner; \
probe_surface the back of each to find the exact points, then a \
`kcad_sweep(path = [[x, y, z], ...]) { circle(r = 8); }` (or a chain \
of capsules for a short bare run) carries the bundle from one to the \
other through the wall.

People & characters:
- Build people with build_character (call list_character_options \
first): a preset (Doctor, Chef, Runner, Grandmother, Construction \
worker, …) and/or choices for body, skin, arm gesture, leg stance, \
hair, beard, glasses, hat, top, bottom, coat, shoes and gloves. \
Clothes are coloured by BODY PART (the `outfit` node round the `human` \
figure), so they stay on in any pose. Invent clothes the catalogue \
lacks with `garments` rows [part, colour, material] — parts chest, \
waist, hips, shoulder, upper_arm, forearm, hand, upper_thigh, thigh, \
shin, ankle, foot, neck, head, groups torso / arm / leg / body, '.L' \
or '.R' for one side. What stands off the body (a bag, a tie, a crown, \
a tool in a hand) is ordinary geometry you add beside the figure, \
placed with face_landmarks and probe_surface. NEVER model a person \
from spheres and capsules when build_character can.

Detail, age and texture (creatures, faces, hands, worn things):
- A smooth blend of primitives reads as plastic. Make the form with \
`kcad_blend(radius, detail)` — detail is cells across the part, up to \
400, so a 250 mm head at 250 is ~1 mm — then wrap it, innermost first: \
`kcad_weathering(...) color("#6f8545") kcad_sculpt(strokes = [...], \
noise = 0.12, noise_scale = 1.5, seed = 1) kcad_blend(...) { ... }`. \
The COLOUR goes outside the sculpt (a baked node keeps only its shape) \
and inside the weathering (its base).
- Sculpt strokes are rows [kind, x, y, z, radius, strength, dx, dy, \
dz] in the part's own frame (world mm when nothing above moves it); \
kinds 0 grab, 1 inflate, 2 smooth, 3 flatten, 4 pinch, 5 CREASE, 6 \
RIDGE. A crease carves a groove `strength` mm deep from (x, y, z) to \
(x+dx, y+dy, z+dz), `radius` mm either side; a ridge raises one. Age a \
face with them: 3-5 wavy forehead creases (each 3-4 short strokes, \
0.4-0.8 mm deep), frown lines between the brows, crow's feet fanning \
from each eye corner, a deep nasolabial fold nose -> mouth corner, \
bags under the eyes (inflate + a crease below), neck rings; ridges for \
temple and forearm veins and the tendons on the back of a hand; creases \
across every finger joint. `noise` (mm) and `noise_scale` roughen it \
all (pores ~0.1 mm at 1.5 mm, lumps ~0.6 mm at 8 mm). sculpt_stroke \
does the same from world points (`to` ends a crease / ridge).
- CREATURE brushes (kinds 7-13): 7 snake_hook pulls a horn, tentacle, \
spike or tail out of the surface along (dx, dy, dz) mm (strength \
scales it; sculpt_stroke takes `to`), refining the stretched skin by \
itself — pull from the forehead for horns, from the spine for spikes, \
from the rump for a tail; 8 draw raises along the patch's own normal; \
9 clay_strips lays square slabs of clay `strength` mm thick — build \
shoulders, pecs, brow masses in overlapping strips; 10 layer raises an \
even plate (a scale, a scute, an armour plate); 11 elastic_grab drags \
with a soft falloff the whole body follows (a jaw jutting, a belly \
sagging); 12 pose rows have 12 values [12, jx, jy, jz, blend radius, \
angle °, ax, ay, az, tipx, tipy, tipz] — turn the limb that holds the \
tip about the joint, the rest stays (bend an arm, droop a neck, curl a \
tail; sculpt_stroke takes `tip`); 13 mask freezes the patch (strength \
0-1, negative frees it) so later strokes leave it alone. Order \
matters: mask first, then sculpt.
- `kcad_weathering(cavity_color, cavity, edge_color, edge, depth, \
reach, mottle_color, mottle, mottle_scale, spot_color, spots, \
spot_size, seed, tints = [[x, y, z, radius, r, g, b, strength], ...])` \
colours every face from the shape: creases deeper than `depth` mm get \
the dark `cavity_color`, crests the pale `edge_color`, plus blotches, \
age spots (`spots` 0-1) and tints (a red eye rim, a darker nose). Use \
it on skin, leather, stone, rust; the preview and pictures show it, \
OpenSCAD's own render is one colour.

Creature skin — displace: real scales, cracked hide, warts, chitin \
plates, wrinkled skin are a DISPLACE round the body, not painted \
colour: `kcad_displace(pattern = "scales", strength = 0.8, scale = 5) \
{ body }` — patterns scales (round plates + grooves), shingles \
(overlapping toward `axis`, e.g. "-x" for a fish swimming +x), cracks \
(use a negative strength), warts (`density` 0-1), chitin (flat plates, \
bevelled seams), ridges (wrinkles), noise (lumps), image (a greyscale \
picture on a plane). `scale` is one scale/wart in mm, `strength` its \
height, `within` [[x,y,z],[x,y,z]] a region (a belly of finer scales, a \
back of plates — stack two displaces with different regions). Put it \
OUTSIDE the sculpt and INSIDE color/weathering: `kcad_weathering(...) \
color(...) kcad_displace(...) kcad_sculpt(...) kcad_blend(...) {...}` — \
weathering then darkens every groove by itself.

Creature body — skin: the fastest monster body is a SKIN: a stick \
skeleton grown into one smooth body. `kcad_skin(nodes = [[x, y, z, \
radius, parent], ...], pose = [[point, rx, ry, rz], ...], smooth = 8, \
detail = 100);` — rows are skeleton points with the body's thickness \
there, `parent` the row it joins (-1 for the root): pelvis, spine, \
chest, neck, head, shoulders → elbows → hands, hips → knees → feet, \
tail. Joints blend over `smooth` mm. Pose rows bend it and the body is \
regrown whole. Then sculpt (muscle, brow, snout), displace (scales), \
scatter (spikes), grow_hair, weathering; rig_armature from_skin when the \
sculpted body must still pose.

Creature rig — armature: to POSE a sculpted/blended creature (one \
skin), never cut it into joint pieces: rig_armature with bones in world \
mm ([{name, parent, head, tail}] — spine, neck, Head, each leg as 2-3 \
bones, Tail as 2-4), then set_pose (node_id + bones) or reach (IK, a \
bone name as effector). In code: `kcad_armature(bones = [["spine", "", \
x, y, z, x, y, z], ["Head", "spine", ...]], pose = [["Head", 0, 20, \
0]]) { body }`, OUTSIDE the sculpt/displace and inside the colour. Bone \
names Head / Tail / Left wing / Front left leg make PlanetCraft walk it.

Expressions — shape keys: a blink, jaw open, snarl or breath is a \
SHAPE KEY, never a second model: shape_key with `key` + `strokes` \
(sculpt brushes in world mm) and `slider` true, then play_motion to \
show it moving. In code `kcad_shape_keys(keys = [["blink", "blink"]], \
strokes = [[0, kind, x, y, z, radius, strength, dx, dy, dz], ...]) { \
face }` with a variable `blink = 0; // [0:0.01:1]`.

Creature hair — manes, beards, fur tufts, whiskers are grow_hair \
STRANDS, not spheres or a hair cap: `count` 500-3000, `length`, \
`gravity` 0.5-0.9 for a mane, `clumps` 40-80 + `clump_strength` 0.7 so \
it reads as locks, `within` for the scalp / chin / spine, `color`. Short \
dense fur on a body: the Fur material on its colour is cheaper; strands \
for tufts. In code `kcad_hair_strands(count = 1200, length = 40, ...) { \
head }`.

Creature colour — paint: stripes, war paint, blood, scars, a pale \
belly are paint_stroke (world points from probe_surface; `to` for a \
line), never extra solids laid on the skin. Order outermost first: \
`kcad_weathering(...) kcad_vertex_paint(strokes = [...]) color(...) \
kcad_displace(...) kcad_sculpt(...) { body }`.

Creature detail — scatter: spikes, warts, scales, barnacles, teeth, \
eye clusters are ONE scatter, not hand-placed copies. Model the piece at \
the origin pointing up +Z (base at z = 0), then scatter_on_surface with \
piece_id + surface_id: `count`/`spacing` over the whole surface, \
`facing` "+z" + `max_angle` for the top of a back, `within` for a \
region, or `path` (world points along a spine or jaw) for a row, \
`taper` for smaller ones at the ends; `sink` 0.5-2 mm so they sit IN \
the skin. In code: `kcad_scatter(count = 40, ..., placements = []) { \
piece; body }` — placements are recomputed, leave them empty.

Creatures and monsters for the PlanetCraft game:
- PlanetCraft (the user's voxel game) makes a model WALK when it arrives \
as named parts: a group called Head (nods at its neck), Tail, Left wing \
and Right wing, and each leg by end and side — Left leg / Right leg for \
two, Front left leg … Back right leg for four. Everything else is the \
body. Anything not in a named group does not move. KNEES: a group or bone \
named for a leg's LOWER half — Front left shin, Back right leg lower, \
Left foot, a paw, a hoof — becomes that leg's shin, hung on a knee that \
bends as the leg swings (put it inside the leg's group or give it its own \
bone); found legs of a four-legged model get knees by themselves.
- For a monster, troll, dragon, beast or any creature for the game, use \
build_creature: a preset (list_creature_options — Troll, Ogre, Goblin, \
Orc, Minotaur, Yeti, Cyclops, Gargoyle, Imp, Dragon, Dire wolf, Cave \
bear, Boar, Basilisk, Giant spider, Serpent, Slime) or a plan (biped, \
winged, quadruped, spider, serpent, slime) with height (mm, real size: \
1 block = 1 m), colours and features. Every piece lands in the right \
group. render_view it (Front and Right), change what the user asks for, \
keeping each new piece INSIDE its part's group (into_id on apply_code), \
and never give a piece of the body a name with head, tail, wing or leg \
in it — that name would make it a joint.
- Then send_to_planetcraft with its node_id (or build_creature with \
send=true). nature says what the game does with it: monster hunts the \
player, person walks about and looks at you, animal grazes and bolts; \
a built creature carries its own nature, speed, health and damage. A \
running game picks it up within seconds and puts it in front of the \
player; it is also in the game's Creatures book (menu ▸ Creatures) — \
tell the user so, with the book_url the send returns. \
list_planetcraft_creatures says what the game already has; \
remove_from_planetcraft takes one out.
- A model the user made themselves: name its groups as above (the tree \
labels do it), or send it as it is — unnamed legs under a clear middle \
are found automatically — and check the parts the send reports.

Molecules and chemical reactions:
- Build molecules with build_molecule — from the compound library \
(list_molecules: about 490 — gases, acids, bases and ions, VSEPR \
shapes, hydrocarbons, alcohols, carbonyls, acids, solvents, \
biomolecules, benzene derivatives, polycyclic aromatics, and the \
common medicines by what they treat: pain, antibiotics, heart, brain, \
stomach and allergy, hormones and vitamins) or from any SMILES you know (ethanol CCO, caffeine \
Cn1cnc2c1c(=O)n(C)c(=O)n2C). NEVER place atoms by hand: the builder \
gives every atom its VSEPR shape (lone pairs included) and closes the \
rings. Nanometres, like the crystals.
- Write reactions with build_reaction the way a chemist writes them: \
'2 H2 + O2 -> 2 H2O', 'N2 + 3 H2 <=> 2 NH3'. Leave coefficients out \
and it balances them; it always reports whether atoms and charge \
balance — tell the user when they do not rather than hiding it. \
Species outside the library go in as smiles:... .
- Every library compound is also a Part Library part (insert_part \
"molecule_<key>", categories "Molecules: ...").
- Build proteins with build_protein. For a REAL protein (crambin, \
ubiquitin, haemoglobin, GFP, spike…) use its fold: pdb_id for an RCSB \
entry, uniprot for the AlphaFold model — never invent coordinates. A \
sequence is built with ideal geometry on its secondary structure \
(helix, strand, or letters like CEEEETTEEEEC for a hairpin): right for \
helices, strands and hairpins, but NOT folded — say so, and mention the \
clash count it returns. Cartoon style by default; list_proteins has \
presets, styles and colours.

Gravity — drop_parts lets parts fall onto the floor or each other and \
tip over onto a stable face: put things ON a table, stack, lay out a \
print bed, or find out whether a design falls over — instead of \
computing z and tilts by hand.

Posing — say WHERE, not the angles: `reach` puts a figure's hand / \
foot / head, or the tip of a part inside nested joint nodes (robot \
arm, lamp, crane), on a point (a probe_surface hit, or target_node = \
another part) and solves the angles itself — far better than guessing \
set_pose rotations. Build an arm as joint { upper; joint { fore; \
gripper } } with each pivot at its hinge, then reach.

For a picture the USER keeps — a listing, a presentation, "show me \
what it will look like" — render_photo (Blender Cycles: real light, \
reflections, glass) when get_document_info's blender.available; \
render_view remains the quick check while building.

Look at what you built:
- To SEE where a part will fail to print, set_render_options heatmap = \
"thickness" (red = wall thinner than heat_min_wall) or "overhang" (red \
= needs support), then render_view — thin spots and overhangs are \
painted on the model; the result gives the thinnest wall and the red \
fraction. Fix, look again, then heatmap = "off".
- render_view returns a PNG of the 3D preview as an image. LOOK AT IT \
after anything non-trivial, and use `orientation` to check another side \
— a part that is wrong is obvious in the picture and invisible in the \
tree. It shows what is on screen right now: the built-in preview \
immediately, replaced by the exact OpenSCAD render as parts finish.
- The built-in preview CUTS booleans exactly (Manifold) when \
get_document_info's `exact_preview_booleans.available` is true: holes, \
threads and pockets are in the picture, the bounds, mass_properties and \
probe_surface at once. Only then may you trust a difference() without \
OpenSCAD; a boolean on a flat 2D or open operand still shows its first \
operand (get_node_bounds flags it `approximate`).
- Details go ON a surface, not near it: probe_surface casts a ray at \
the model and returns the hit point, its outward normal and the part, \
so an eye, a knob or a boss sits on a lofted body at point + normal × \
inset instead of a guessed coordinate. Details that come in numbers \
(curls, tubercles, rivets) come from sample_surface: N evenly spread \
points with normals over the faces looking a given way.
- CHECK, do not assume. After building anything meant to be printed, \
run check_printability (watertight, overhangs, thin walls, footprint) \
and fix what it names; after placing or mating parts run \
check_interference (do they overlap?); mass_properties gives volume, \
mass and cost when the user asks how heavy or how much.

Working rules:
- Everything you do is one undoable step per call: the user gets their \
model back with a single Ctrl+Z. Their unsaved work is real, so \
new_document, open_document and load_example refuse to discard it \
unless you pass discard_unsaved_changes — offer to save instead.
- get_document_info reports validation errors (bad expressions, empty \
extrusions, 3D inside an extrude, a revolve crossing the axis). Fix \
them; the app paints those nodes red for the user.
- Sizes are in the document's unit — millimetres unless \
get_document_info says otherwise ("unit": nm, um, cm, m, in). The unit \
is a label, never a rescale: a 0.49 nm lattice cell in a nanometre \
document is written 0.49. set_render_options unit changes it.
- The user controls what you may do (Tools > MCP Server). A refusal \
naming an access level is their setting, not a bug — tell them what you \
needed rather than working around it.
"""


# ── Bridge client ──────────────────────────────────────────────────

class BridgeClient:
    """Line-delimited JSON client for the in-app bridge.

    Connects lazily and reconnects on demand so that the MCP host may
    start this process before (or after) KherveCAD itself, and so a
    restart of the application does not require a restart of the host.
    """

    def __init__(self, endpoint_file: Optional[str] = None):
        self._endpoint_file = endpoint_file
        self._sock: Optional[socket.socket] = None
        self._buf = b""
        self._token = ""
        self._next_id = 0

    # ── Connection handling ─────────────────────────────────────

    def close(self):
        if self._sock is not None:
            try:
                self._sock.close()
            except Exception:
                pass
        self._sock = None
        self._buf = b""

    def _connect(self):
        info = read_endpoint(self._endpoint_file)
        if info is None:
            raise BridgeError(_NOT_RUNNING)
        self._token = str(info.get("token", ""))
        host = str(info.get("host", "127.0.0.1"))
        port = int(info["port"])
        try:
            sock = socket.create_connection(
                (host, port), timeout=_CONNECT_TIMEOUT)
        except OSError as exc:
            # A stale endpoint file (app killed without cleanup) looks
            # exactly like "not running" from here — say so plainly
            # rather than leaking a connection-refused traceback.
            raise BridgeError(f"{_NOT_RUNNING}\n\n(socket error: {exc})")
        sock.settimeout(_CALL_TIMEOUT)
        self._sock = sock
        self._buf = b""

    def _readline(self) -> bytes:
        assert self._sock is not None
        while b"\n" not in self._buf:
            chunk = self._sock.recv(65536)
            if not chunk:
                raise BridgeError(
                    "KherveCAD closed the connection mid-request. "
                    "The application may have quit.")
            self._buf += chunk
        line, _, self._buf = self._buf.partition(b"\n")
        return line

    def request(self, method: str, params: Optional[dict] = None) -> Any:
        """Send one request, returning its ``result`` payload."""
        for attempt in (0, 1):
            if self._sock is None:
                self._connect()
            self._next_id += 1
            payload = {
                "id": self._next_id,
                "token": self._token,
                "method": method,
                "params": params or {},
            }
            try:
                assert self._sock is not None
                self._sock.sendall(
                    (json.dumps(payload) + "\n").encode("utf-8"))
                line = self._readline()
            except BridgeError:
                self.close()
                if attempt == 0:
                    continue          # app restarted: reconnect once
                raise
            except OSError as exc:
                self.close()
                if attempt == 0:
                    continue
                raise BridgeError(f"Bridge I/O error: {exc}")
            try:
                reply = json.loads(line.decode("utf-8"))
            except Exception:
                self.close()
                raise BridgeError("Malformed reply from KherveCAD.")
            if reply.get("error"):
                raise BridgeError(str(reply["error"]))
            return reply.get("result")
        raise BridgeError(_NOT_RUNNING)


# ── Result shaping ─────────────────────────────────────────────────

#: Key a tool result uses to hand back a rendered picture.  A CAD app
#: that could only describe itself in JSON would be half blind, so this
#: travels to the model as a real MCP image block.
IMAGE_KEY = "image_png_base64"


def tool_content(result: Any) -> List[dict]:
    """MCP content blocks for a bridge tool result.

    A result carrying a PNG becomes an image block (plus the rest of
    the result as text), so the model can actually look at the part.
    """
    if isinstance(result, dict) and result.get(IMAGE_KEY):
        data = str(result[IMAGE_KEY])
        rest = {k: v for k, v in result.items() if k != IMAGE_KEY}
        blocks: List[dict] = [{"type": "image", "data": data,
                               "mimeType": "image/png"}]
        if rest:
            blocks.append({"type": "text",
                           "text": json.dumps(rest, indent=2,
                                              default=str)})
        return blocks
    return [{"type": "text",
             "text": json.dumps(result, indent=2, default=str)}]


def valid_png_b64(data: str) -> bool:
    """True when *data* decodes to something with a PNG signature."""
    try:
        raw = base64.b64decode(data, validate=True)
    except Exception:
        return False
    return raw[:8] == b"\x89PNG\r\n\x1a\n"


# ── MCP server ─────────────────────────────────────────────────────

def _log(msg: str):
    """Diagnostics go to stderr — stdout carries the protocol."""
    sys.stderr.write(f"[khervecad-mcp] {msg}\n")
    sys.stderr.flush()


class McpServer:
    """Minimal, dependency-free MCP server over stdio."""

    def __init__(self, bridge: BridgeClient):
        self._bridge = bridge
        self._tools_cache: Optional[List[dict]] = None

    # ── Dispatch ────────────────────────────────────────────────

    def handle(self, msg: dict) -> Optional[dict]:
        """Handle one JSON-RPC message; None means 'no reply'."""
        method = msg.get("method")
        msg_id = msg.get("id")
        if method is None:                    # a response — ignore
            return None
        try:
            if method == "initialize":
                result = self._initialize(msg.get("params") or {})
            elif method in ("notifications/initialized",
                            "notifications/cancelled",
                            "initialized"):
                return None                   # notifications: no reply
            elif method == "ping":
                result = {}
            elif method == "tools/list":
                result = {"tools": self._list_tools()}
            elif method == "tools/call":
                result = self._call_tool(msg.get("params") or {})
            elif method in ("resources/list", "resources/templates/list"):
                # Declared empty rather than unsupported so hosts that
                # probe every capability do not surface an error.
                key = ("resourceTemplates"
                       if method.endswith("templates/list")
                       else "resources")
                result = {key: []}
            elif method == "prompts/list":
                result = {"prompts": []}
            else:
                if msg_id is None:
                    return None
                return _error(msg_id, -32601, f"Unknown method: {method}")
        except BridgeError as exc:
            if msg_id is None:
                return None
            return _error(msg_id, -32000, str(exc))
        except Exception as exc:              # never take the loop down
            if msg_id is None:
                return None
            return _error(msg_id, -32603, f"Internal error: {exc}")
        if msg_id is None:
            return None
        return {"jsonrpc": "2.0", "id": msg_id, "result": result}

    # ── Methods ─────────────────────────────────────────────────

    def _initialize(self, params: dict) -> dict:
        asked = params.get("protocolVersion")
        version = (asked if asked in SUPPORTED_PROTOCOLS
                   else LATEST_PROTOCOL)
        # Best-effort: the app may not be up yet, and initialize must
        # never fail for that reason.
        app_version = "unknown"
        try:
            status = self._bridge.request("get_status")
            app_version = str((status or {}).get("version", "unknown"))
        except Exception:
            pass
        return {
            "protocolVersion": version,
            "capabilities": {
                "tools": {"listChanged": False},
                "resources": {},
                "prompts": {},
            },
            "serverInfo": {
                "name": SERVER_NAME,
                "title": "KherveCAD",
                "version": app_version,
            },
            "instructions": _INSTRUCTIONS,
        }

    def _list_tools(self) -> List[dict]:
        if self._tools_cache is None:
            tools = self._bridge.request("list_tools") or []
            self._tools_cache = [
                {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "inputSchema": t.get(
                        "input_schema", {"type": "object",
                                         "properties": {}}),
                }
                for t in tools
            ]
        return self._tools_cache

    def _call_tool(self, params: dict) -> dict:
        name = params.get("name")
        if not name:
            raise BridgeError("tools/call requires a tool name.")
        args = params.get("arguments") or {}
        result = self._bridge.request(
            "call_tool", {"name": name, "input": args})
        is_error = isinstance(result, dict) and "error" in result
        return {"content": tool_content(result), "isError": bool(is_error)}


def _error(msg_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id,
            "error": {"code": code, "message": message}}


# ── Entry point ────────────────────────────────────────────────────

def serve(endpoint_file: Optional[str] = None) -> int:
    """Run the stdio loop until stdin closes."""
    bridge = BridgeClient(endpoint_file)
    server = McpServer(bridge)
    stdin = sys.stdin.buffer
    stdout = sys.stdout.buffer
    _log(f"listening on stdio; endpoint="
         f"{endpoint_file or endpoint_path()}")
    while True:
        line = stdin.readline()
        if not line:
            break
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line.decode("utf-8"))
        except Exception as exc:
            _log(f"bad JSON on stdin: {exc}")
            continue
        # A host may batch messages into a JSON array.
        batch = msg if isinstance(msg, list) else [msg]
        replies = [r for r in (server.handle(m) for m in batch)
                   if r is not None]
        for reply in replies:
            stdout.write((json.dumps(reply) + "\n").encode("utf-8"))
        if replies:
            stdout.flush()
    bridge.close()
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    endpoint_file = None
    if "--endpoint" in args:
        i = args.index("--endpoint")
        if i + 1 < len(args):
            endpoint_file = args[i + 1]
    return serve(endpoint_file)


if __name__ == "__main__":
    sys.exit(main())
