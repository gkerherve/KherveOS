"""Sketch dimensions on the 3D view (2026-10-25, the user: "show the
dimensions in the 3D view too"). Each sketch's driving dimensions are
drawn where its Object is: in the Object tab on the Object edited, in
Main on every placed instance of it (an Object's definition is hidden
and only its instances show) and on a visible part where it stands.

Linear dimensions (length, distance, h/v distance, point to line) as a
dimension line with extension lines, arrows and the value, offset
square to what they measure (the 2D view's dragged `offset`, else a
default); diameters, radii and angles as their value beside what they
size. Painted by `View3D` through its `overlay_painters` hook, never in
clean pictures (exports, Printables stills).

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import math

from . import sketch_constraints as sc

LINEAR = ("distance", "hdistance", "vdistance", "length", "point_line")
OFFSET_MM = 8.0          # default distance of the dimension line, model


def _mul(a, b):
    from .mesh import mat_mul
    return mat_mul(a, b)


def _apply(m, p):
    x, y, z = p
    return (m[0][0] * x + m[0][1] * y + m[0][2] * z + m[0][3],
            m[1][0] * x + m[1][1] * y + m[1][2] * z + m[1][3],
            m[2][0] * x + m[2][1] * y + m[2][2] * z + m[2][3])


def _top(node, root):
    while node.parent is not None and node.parent is not root:
        node = node.parent
    return node


def _under(node, scope):
    while node is not None:
        if node is scope:
            return True
        node = node.parent
    return False


def assembly_mode(window):
    """The Main tab and no sketch open: parts, not their sketches."""
    if getattr(window, "_sketch3d_tool", None) is not None:
        return False                 # sketching: its relations show
    builder = getattr(window, "builder", None)
    if builder is None or builder.isolated_component() is not None:
        return False
    from . import sketch_mode
    if sketch_mode.sketching(window) or \
            getattr(window, "_face_sketch", None) is not None:
        return False
    return True


def _switched_off(node):
    """Inside a feature that is suppressed or rolled back: its sketch's
    dimensions go with it (they stood in the air over the part)."""
    from . import suppress
    while node is not None:
        if suppress.is_off(node):
            return True
        node = node.parent
    return False


def _in_object(c, root):
    probe = c
    while probe is not None and probe is not root:
        if probe.type == "component":
            return True
        probe = probe.parent
    return False


def placements(window):
    """[(container, 4x4 matrix to the world)] for every sketch with
    dimensions that the 3D view shows now."""
    from . import mesh
    model = window.model
    root = model.root
    scope = window._render_scope()[0]
    iso = scope if scope is not root else None
    out = []
    conts = [c for c in sc.containers(model) if sc.rows(c)
             and not _switched_off(c)]
    if iso is None and assembly_mode(window):
        # the assembly (Main tab, not sketching): an Object's sketch
        # dimensions stay in its Object tab (the user: none at all here)
        conts = [c for c in conts if not _in_object(c, root)]
    if iso is not None:
        with window._isolated_frame(iso):
            for c in conts:
                if _under(c, iso):
                    m = _mul(mesh.ancestor_matrix(c, {}, stop=iso),
                             mesh.node_matrix(c, {}))
                    out.append((c, m))
        return out
    for c in conts:
        top = _top(c, root)
        if top.visible and top is not root:
            m = _mul(mesh.ancestor_matrix(c, {}),
                     mesh.node_matrix(c, {}))
            out.append((c, m))
            continue
        if top is root:
            out.append((c, mesh.node_matrix(c, {})))
            continue
        if top.type != "component":
            continue
        # a hidden definition: drawn on each instance of it
        inside = mesh.node_matrix(c, {}) if c is top else _mul(
            mesh.ancestor_matrix(c, {}, stop=top), mesh.node_matrix(c, {}))
        for ref in root.walk():
            if ref.type == "reference" and ref.visible and \
                    ref.params.get("ref") == top.name:
                place = _mul(mesh.ancestor_matrix(ref, {}),
                             mesh.node_matrix(ref, {}))
                out.append((c, _mul(place, inside)))
    return out


def _local(cont, row):
    """(kind, points) of a dimension in the sketch's own 2D frame."""
    kind = row["kind"]
    ents = [sc.entity(cont, r) for r in row["refs"]]
    if kind == "length":
        node, name = ents[0]
        return "linear", list(sc._line(node, name, {}))
    if kind == "point_line":
        (pn, pname), (ln, lname) = ents
        p = sc._point(pn, pname, {})
        a, b = sc._line(ln, lname, {})
        dx, dy = b[0] - a[0], b[1] - a[1]
        d2 = dx * dx + dy * dy or 1.0
        t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / d2
        return "linear", [p, (a[0] + dx * t, a[1] + dy * t)]
    if kind in LINEAR:
        (an, aname), (bn, bname) = ents
        pa = sc._point(an, aname, {})
        pb = sc._point(bn, bname, {})
        if kind == "hdistance":
            pb = (pb[0], pa[1])
        elif kind == "vdistance":
            pb = (pa[0], pb[1])
        return "linear", [pa, pb]
    if kind in ("diameter", "radius"):
        # a leader from the centre out through the edge (SolidWorks' R8):
        # [centre, the point on the edge, where the value sits]; a slot's
        # end leans away from the slot
        node, name = ents[0]
        c, r = sc._circle(node, name, {})
        ux, uy = 0.707, 0.707
        if node.type == "line" and name in ("a1", "a2"):
            a = sc._point(node, "p1", {})
            b = sc._point(node, "p2", {})
            dx, dy = (b[0] - a[0], b[1] - a[1]) if name == "a2" else \
                (a[0] - b[0], a[1] - b[1])
            L = math.hypot(dx, dy) or 1.0
            ux, uy = dx / L * 0.707 + dy / L * 0.707, \
                dy / L * 0.707 - dx / L * 0.707
        edge = (c[0] + r * ux, c[1] + r * uy)
        out = (c[0] + (r + max(r, 6.0)) * ux, c[1] + (r + max(r, 6.0)) * uy)
        return "leader", [c, edge, out]
    spots = []
    for node, name in ents:
        k = sc.kind_of(node, name)
        if k == "line":
            a, b = sc._line(node, name, {})
            spots.append(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2))
        elif k == "point":
            spots.append(sc._point(node, name, {}))
    if not spots:
        return None, []
    return "label", [(sum(p[0] for p in spots) / len(spots),
                      sum(p[1] for p in spots) / len(spots))]


def _centre(cont, row):
    """The centre of the shape a dimension's first pick belongs to."""
    try:
        node, _name = sc.entity(cont, row["refs"][0])
        if node.type in ("rect", "circle"):
            return sc._point(node, "c", {})
        if node.type == "line" and float(node.params.get("width", 0) or 0):
            # a slot's centre line: the dimension goes OUTSIDE the slot,
            # half its width plus a gap (SolidWorks' 24 above it)
            a = sc._point(node, "p1", {})
            b = sc._point(node, "p2", {})
            return ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        if node.type == "polygon":
            pts = [sc._point(node, "v%d" % i, {})
                   for i in range(len(node.params["points"]))]
            return (sum(p[0] for p in pts) / len(pts),
                    sum(p[1] for p in pts) / len(pts))
    except (KeyError, ValueError, IndexError, TypeError):
        pass
    return None


def _is_reference(cont, row):
    try:
        node, _name = sc.entity(cont, row["refs"][0])
    except (KeyError, ValueError, IndexError):
        return False
    p = node.params
    return bool(p.get("ref_world") or p.get("ref_source") or
                p.get("ref_face")) or str(node.name).startswith("Reference")


def _text(row):
    from . import dim_more
    return dim_more.text(row)


def _closed_solids(mesh):
    """The triangles of *mesh* in pieces with thickness, as an (n, 3, 3)
    array: flat sketch faces in the view are not solids and hide nothing."""
    import numpy as np
    tris = np.asarray(mesh, dtype=np.float64).reshape(-1, 3, 3)
    if not len(tris):
        return tris
    keys = np.round(tris.reshape(-1, 3) / 1e-4).astype(np.int64)
    _u, vid = np.unique(keys, axis=0, return_inverse=True)
    vid = vid.reshape(-1, 3)
    edges = {}
    for t, (a, b, c) in enumerate(vid.tolist()):
        for e in ((a, b), (b, c), (c, a)):
            edges.setdefault((min(e), max(e)), []).append(t)
    parent = list(range(len(vid)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for faces in edges.values():
        for f in faces[1:]:
            parent[root(f)] = root(faces[0])
    # Only a FLAT piece is not a solid. Asking every edge to have exactly
    # two faces let one sliver, or two parts touching along an edge, take
    # the whole model out: dimensions then showed through it (the user)
    pieces = {}
    for t in range(len(vid)):
        pieces.setdefault(root(t), []).append(t)
    keep = []
    for faces in pieces.values():
        pts = tris[faces].reshape(-1, 3)
        pts = pts - pts.mean(axis=0)
        if np.linalg.svd(pts, compute_uv=False)[-1] > 1e-3:
            keep.extend(faces)
    return tris[keep]


def _occluder(window):
    """seen(world point) -> False when a solid of the 3D view stands
    between it and the eye (2026-10-31, the user: a dimension showed
    through the part, "it should not go through the solid"). A ray
    toward the eye against the view's closed pieces, kept per mesh
    serial; everything is seen without numpy or a solid."""
    view = getattr(window, "view3d", None)
    if view is None or not view.mesh:
        return lambda p: True
    try:
        import numpy as np
    except ImportError:
        return lambda p: True
    serial = getattr(view, "_mesh_serial", None)
    cache = getattr(view, "_dims_solid", None)
    if cache is None or cache[0] != serial:
        try:
            tris = _closed_solids(view.mesh)
        except Exception:
            tris = None
        cache = view._dims_solid = (serial, tris)
    tris = cache[1]
    if tris is None or not len(tris):
        return lambda p: True
    v0 = tris[:, 0]
    e1, e2 = tris[:, 1] - v0, tris[:, 2] - v0
    eye, _r, _u, forward = view._camera()
    ortho = view.projection == "Orthographic"
    size = float(np.ptp(tris.reshape(-1, 3), axis=0).max()) or 1.0
    eps = size * 1e-4                       # off the face it may lie on

    def seen(p):
        p = np.asarray(p, dtype=np.float64)
        if ortho:
            d = -np.asarray(forward, dtype=np.float64)
            limit = np.inf
        else:
            d = np.asarray(eye, dtype=np.float64) - p
            limit = float(np.linalg.norm(d))
            d = d / (limit or 1.0)
        o = p + d * eps
        h = np.cross(d, e2)
        a = np.einsum("ij,ij->i", e1, h)
        ok = np.abs(a) > 1e-12
        f = np.where(ok, 1.0 / np.where(ok, a, 1.0), 0.0)
        s = o - v0
        u = f * np.einsum("ij,ij->i", s, h)
        q = np.cross(s, e1)
        v = f * (q @ d)
        t = f * np.einsum("ij,ij->i", e2, q)
        hit = ok & (u >= 0) & (v >= 0) & (u + v <= 1) & (t > eps) & \
            (t < limit)
        return not bool(hit.any())

    return seen


def _selected_sketches(window, conts):
    """ids of the containers that belong to what is selected in the
    tree: the feature clicked, its sketch, or a shape of it."""
    try:
        picked = window.builder.active_tree().selected_nodes()
    except Exception:
        return set()
    if not picked:
        return set()
    from . import face_sketch
    tops = [face_sketch.group_of(n) or n for n in picked]
    return {id(c) for c in conts
            if any(_under(c, t) or _under(t, c) for t in tops)}


def paint(window, painter, project, skip=(), hits=True, occlude=True,
          colour="#1565c0"):
    """Draw every shown sketch's dimensions; *project* maps a world
    point to (x, y, depth) in view pixels or None. The 2D view's face
    sketch reuses it (sketch_dims_face): *skip* the sketch being edited,
    no clickable *hits*, no 3D occlusion, grey."""
    from PyQt5.QtCore import QPointF, QRectF, Qt
    from PyQt5.QtGui import QBrush, QColor, QFont, QPen, QPolygonF
    if hits:
        window._dims3d_hits = []            # (chip rect, sketch, row)
    # the switch is for dimensions: a sketch being drawn shows its relations
    show = getattr(window.scene, "show_sketch_dims", True)
    if not show and getattr(window, "_sketch3d_tool", None) is None:
        return
    try:
        placed = placements(window)
    except Exception:                       # never break the paint
        return
    placed = [(c, m) for c, m in placed
              if not any(_under(c, s) for s in skip)]
    if not placed:
        return
    ink = QColor(colour)
    pen = QPen(ink, 1.4)
    pen.setCosmetic(True)
    thin = QPen(ink, 1.0)
    thin.setCosmetic(True)
    font = QFont(painter.font())
    font.setBold(True)
    font.setPointSize(max(8, font.pointSize()))
    painter.save()
    painter.setRenderHint(painter.Antialiasing, True)
    painter.setFont(font)
    fm = painter.fontMetrics()

    def scr(m, p):
        q = project(_apply(m, (p[0], p[1], 0.0)))
        return None if q is None else QPointF(q[0], q[1])

    def jac(m, p):
        """Screen pixels per sketch mm along x and y at *p*: how a mouse
        drag maps back onto the sketch plane."""
        o, ex, ey = scr(m, p), scr(m, (p[0] + 1, p[1])), \
            scr(m, (p[0], p[1] + 1))
        if None in (o, ex, ey):
            return None
        return ((ex.x() - o.x(), ex.y() - o.y()),
                (ey.x() - o.x(), ey.y() - o.y()))

    shown = []

    def chip(at, text, cont=None, index=None, drag=None):
        shown.append(text)
        tw = fm.horizontalAdvance(text)
        rect = QRectF(at.x() - tw / 2 - 5, at.y() - fm.height() / 2 - 2,
                      tw + 10, fm.height() + 4)
        if cont is not None and hits:
            window._dims3d_hits.append((QRectF(rect), cont, index, drag))
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(255, 255, 255, 230)))
        painter.drawRoundedRect(rect, 4, 4)
        painter.setPen(QPen(ink, 1.0))
        painter.setBrush(Qt.NoBrush)
        painter.drawText(rect, int(Qt.AlignCenter), text)

    try:
        seen = _occluder(window) if occlude else None
    except Exception:
        seen = None

    # the SELECTED feature's dimensions show through the part, as
    # SolidWorks' do when a feature is clicked: a base grown past where
    # its width was written hid the number under itself, and a boss
    # stands on its own sketch (2026-11-10: neither could be clicked)
    front = _selected_sketches(window, [c for c, _m in placed])
    if front and hits and getattr(window, "_sketch3d_tool", None) is None \
            and getattr(window.view3d, "_dim3d_editor", None) is None:
        # a feature clicked in the tree shows ITS dimensions alone, as a
        # plane clicked there shows that plane (2026-11-13, the user:
        # with every sketch's sizes on, which were the Boss's could not
        # be told); nothing selected, a sketch being drawn or a value
        # being typed (any dimension can be linked) show them all
        placed = [(c, m) for c, m in placed if id(c) in front]
    through = [False]

    def vis(m, p):
        """Is the sketch point *p* in front of every solid?"""
        return seen is None or through[0] or \
            seen(_apply(m, (p[0], p[1], 0.0)))

    def seg(m, a, b):
        """A line from *a* to *b* (sketch mm), drawn only where no
        solid stands in front of it (the user: a dimension must never
        show through the part, whatever plane its sketch is on)."""
        # fewer rays while the view is being turned: they were the
        # largest cost of a frame; the still picture gets them all
        moving = getattr(window.view3d, "_mode", None) is not None
        n = (MOVING_SAMPLES if moving else SEG_SAMPLES) \
            if seen is not None else 1
        ps = [(a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n)
              for i in range(n + 1)]
        ok = [vis(m, p) for p in ps]
        run = None
        for i in range(len(ps)):
            if ok[i] and run is None:
                run = i
            if run is not None and (not ok[i] or i == len(ps) - 1):
                j = i if ok[i] else i - 1
                if j > run:
                    qa, qb = scr(m, ps[run]), scr(m, ps[j])
                    if qa is not None and qb is not None:
                        painter.drawLine(qa, qb)
                run = None

    for cont, m in placed if show else ():
        through[0] = id(cont) in front
        for index, row in enumerate(sc.rows(cont)):
            if "value" not in row:
                continue
            try:
                what, pts = _local(cont, row)
            except (KeyError, ValueError, IndexError, TypeError):
                continue
            if what == "leader":
                at = row.get("leader_at")
                if isinstance(at, (list, tuple)) and len(at) == 2:
                    # dragged: the value sits there, the leader swings to
                    # it through the edge
                    c, e = pts[0], pts[1]
                    r = math.hypot(e[0] - c[0], e[1] - c[1])
                    dx, dy = at[0] - c[0], at[1] - c[1]
                    dl = math.hypot(dx, dy) or 1.0
                    pts = [c, (c[0] + r * dx / dl, c[1] + r * dy / dl),
                           (float(at[0]), float(at[1]))]
                pc, pe, po = (scr(m, p) for p in pts)
                if None not in (pc, pe, po):
                    painter.setPen(pen)
                    seg(m, pts[0], pts[2])
                    painter.setBrush(QBrush(ink))
                    ex, ey = pe.x() - pc.x(), pe.y() - pc.y()
                    el = math.hypot(ex, ey) or 1.0
                    ux, uy = ex / el, ey / el
                    base = QPointF(pe.x() - ux * 8, pe.y() - uy * 8)
                    if vis(m, pts[1]):
                        painter.drawPolygon(QPolygonF([
                            pe, QPointF(base.x() - uy * 3.5,
                                        base.y() + ux * 3.5),
                            QPointF(base.x() + uy * 3.5,
                                    base.y() - ux * 3.5)]))
                    painter.setBrush(Qt.NoBrush)
                    if vis(m, pts[0]):
                        painter.drawEllipse(pc, 2.0, 2.0)
                    if not vis(m, pts[2]):
                        continue
                    chip(po, _text(row), cont, index,
                         dict(kind="leader", jac=jac(m, pts[2]),
                              at=list(pts[2])))
                continue
            if what == "label":
                at = scr(m, pts[0])
                if at is not None and vis(m, pts[0]):
                    chip(QPointF(at.x() + 6, at.y() - 6), _text(row),
                         cont, index)
                continue
            if what != "linear":
                continue
            (ax, ay), (bx, by) = pts
            L = math.hypot(bx - ax, by - ay)
            if L < 1e-9:
                continue
            nx, ny = -(by - ay) / L, (bx - ax) / L
            off = row.get("offset")
            if not isinstance(off, (int, float)):
                # by default OUTSIDE the shape it measures
                off = OFFSET_MM
                try:
                    node0, _n0 = sc.entity(cont, row["refs"][0])
                    w = float(node0.params.get("width", 0) or 0) \
                        if node0.type == "line" else 0.0
                except (KeyError, ValueError, IndexError, TypeError):
                    w = 0.0
                if w:
                    off = w / 2.0 + OFFSET_MM
                c = _centre(cont, row)
                if c is not None and (c[0] - ax) * nx + (c[1] - ay) * ny > 0:
                    off = -off
            pa, pb = scr(m, (ax, ay)), scr(m, (bx, by))
            oa = scr(m, (ax + nx * off, ay + ny * off))
            ob = scr(m, (bx + nx * off, by + ny * off))
            if None in (pa, pb, oa, ob):
                continue
            la = (ax + nx * off, ay + ny * off)
            lb = (bx + nx * off, by + ny * off)
            painter.setPen(thin)
            seg(m, (ax, ay), la)
            seg(m, (bx, by), lb)
            painter.setPen(pen)
            seg(m, la, lb)
            sx, sy = ob.x() - oa.x(), ob.y() - oa.y()
            sl = math.hypot(sx, sy) or 1.0
            ux, uy = sx / sl, sy / sl
            painter.setBrush(QBrush(ink))
            for tip, sgn, lp in ((oa, 1.0, la), (ob, -1.0, lb)):
                if not vis(m, lp):
                    continue
                base = QPointF(tip.x() + sgn * ux * 8, tip.y() + sgn * uy * 8)
                painter.drawPolygon(QPolygonF([
                    tip, QPointF(base.x() - uy * 3.5, base.y() + ux * 3.5),
                    QPointF(base.x() + uy * 3.5, base.y() - ux * 3.5)]))
            painter.setBrush(Qt.NoBrush)
            if not vis(m, ((la[0] + lb[0]) / 2, (la[1] + lb[1]) / 2)):
                continue
            chip(QPointF((oa.x() + ob.x()) / 2, (oa.y() + ob.y()) / 2),
                 _text(row), cont, index,
                 dict(kind="linear", jac=jac(m, (ax, ay)), n=(nx, ny),
                      offset=off))
    if hits:
        _paint_relations(window, painter, placed, scr, vis, font)
    painter.restore()
    return shown


def _related(window, placed):
    """The sketches belonging to what is highlighted: a selected part,
    feature or sketch holds them, or a selected shape is in them."""
    from . import constrain3d
    if isinstance(getattr(window.view3d, "edit_tool", None),
                  constrain3d.Constrain3D):
        return list(placed)         # adding or deleting them: all of them
    sk = getattr(window, "_sketch3d_tool", None)
    if sk is not None and sk.group is not None:     # the one being drawn
        out = [(c, m) for c, m in placed
               if c is sk.holder or c is sk.group]
        if out:
            return out
    ids = getattr(window, "_selected_ids", set()) or set()
    if not ids:
        return []
    out = []
    for c, m in placed:
        probe, hit = c, False
        while probe is not None and not hit:
            hit = probe.id in ids
            probe = probe.parent
        if not hit:
            hit = any(n.id in ids for n in c.walk())
        if hit:
            out.append((c, m))
    return out


def _spot(cont, ref):
    """Where a relation's mark sits for one of its entities."""
    k, g = sc._geom(cont, ref, {})
    if k == "point":
        return g
    if k == "line":
        (a, b) = g
        return ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    (c, r) = g
    return (c[0], c[1] + r)


#: what a sketch is locked to, drawn on the part
REF_INK = (230, 120, 20)


def references(cont):
    """What sketch *cont* is tied to the part by, in its own (x, y):
    {"edges": [((x, y), (x, y))], "points": [(x, y)]} — the part's edges
    its points ride on, the corners / middles / centres they are pinned
    to, and the points, edges and faces copied in for a dimension
    (shown or hidden)."""
    edges, points = [], []
    for row in sc.rows(cont):
        kind = row.get("kind")
        if kind == "on_edge" and row.get("edge"):
            e = row["edge"]
            edges.append(((e[0], e[1]), (e[2], e[3])))
        elif kind == "fix" and row.get("at") and (
                row.get("model") or _is_reference(cont, row)):
            points.append((row["at"][0], row["at"][1]))
            if row.get("edge") and row.get("model") in ("mid", "on"):
                e = row["edge"]
                edges.append(((e[0], e[1]), (e[2], e[3])))
    for node in cont.children:
        p = node.params
        if not (p.get("ref_world") or p.get("ref_source") or
                p.get("ref_face") or str(node.name).startswith("Reference")):
            continue
        try:
            if node.type == "line":
                edges.append(((float(p["x1"]), float(p["y1"])),
                              (float(p["x2"]), float(p["y2"]))))
            elif node.type == "circle":
                points.append((float(p["x"]), float(p["y"])))
        except (KeyError, TypeError, ValueError):
            continue
    return {"edges": edges, "points": points}


def _paint_references(painter, cont, m, scr):
    from PyQt5.QtCore import QPointF, Qt
    from PyQt5.QtGui import QBrush, QColor, QPen
    refs = references(cont)
    if not refs["edges"] and not refs["points"]:
        return
    ink = QColor(*REF_INK)
    painter.save()
    painter.setRenderHint(painter.Antialiasing, True)
    pen = QPen(ink, 2.6, Qt.DashLine)
    painter.setPen(pen)
    for a, b in refs["edges"]:
        qa, qb = scr(m, a), scr(m, b)
        if qa is not None and qb is not None:
            painter.drawLine(qa, qb)
    painter.setPen(QPen(ink, 2.0))
    painter.setBrush(QBrush(QColor(255, 255, 255, 220)))
    for p in refs["points"]:
        q = scr(m, p)
        if q is not None:
            painter.drawEllipse(QPointF(q), 5.0, 5.0)
            painter.drawPoint(q)
    painter.restore()


def paint_references_2d(view, painter):
    """The same in the 2D sketch (Sketch Mode): what the sketch on show
    is locked to, over the part's picture — scene coordinates."""
    from PyQt5.QtCore import QPointF, Qt
    from PyQt5.QtGui import QBrush, QColor, QPen
    from . import sketch_constrain_ui as ui
    scene = view.scene()
    focus = scene.sketch_focus() if getattr(scene, "sketch_focus", None) \
        else None
    if focus is None:
        return
    items = {it.node.id: it for it in ui._shape_items(scene)}
    k = abs(view.transform().m11()) or 1.0
    ink = QColor(*REF_INK)
    painter.save()
    painter.setRenderHint(painter.Antialiasing, True)
    for cont in ui.shown_containers(scene):
        refs = references(cont)
        item = next((items[c.id] for c in cont.children if c.id in items),
                    None)
        frame = item.parentItem() if item is not None else None

        def at(p):
            q = QPointF(p[0], p[1])
            return frame.mapToScene(q) if frame is not None else q
        pen = QPen(ink, 0, Qt.DashLine)
        pen.setCosmetic(True)
        pen.setWidthF(2.2)
        painter.setPen(pen)
        for a, b in refs["edges"]:
            painter.drawLine(at(a), at(b))
        pen = QPen(ink, 0)
        pen.setCosmetic(True)
        pen.setWidthF(1.8)
        painter.setPen(pen)
        painter.setBrush(QBrush(QColor(255, 255, 255, 220)))
        for p in refs["points"]:
            painter.drawEllipse(at(p), 5.0 / k, 5.0 / k)
    painter.restore()


def _paint_relations(window, painter, placed, scr, vis, font):
    """The relations of the sketch being worked on, on the 3D view, as
    relation_marks' tiles. Until 2026-11-10 every sketch of a highlighted
    part showed its marks (2026-11-01); the user then chose SolidWorks'
    way — marks in the sketch being edited, a selected feature showing
    only what it is locked to. Only what is seen."""
    from .sketch_constrain_ui import MARK
    window._relation_hits = []      # (mark rect, sketch, row index)
    rel = _related(window, placed)
    if not rel:
        return
    from . import constrain3d
    tooling = isinstance(getattr(window.view3d, "edit_tool", None),
                         constrain3d.Constrain3D)
    if not tooling:
        # a feature is SELECTED: what it is locked to is shown on the
        # part, so it can be found (the user: "each view is forgetting
        # its locking reference ... we should be able to find them")
        for cont, m in rel:
            try:
                _paint_references(painter, cont, m, scr)
            except Exception:                # never break the paint
                import traceback
                traceback.print_exc()
    from . import relation_marks as rm
    if not (tooling or rm.shown()):
        return                       # View ▸ Sketch Relations is off
    # the marks belong to the sketch being worked on (SolidWorks): the
    # one drawn, the one a relation tool edits, or a sketch / shape the
    # user selected — a selected FEATURE shows what it is locked to only
    editing = rel if tooling else _being_edited(window, rel)
    taken = {}
    for cont, m in editing:
        for index, row in enumerate(sc.rows(cont)):
            if "value" in row or row.get("kind") not in MARK:
                continue
            if rm.hidden(cont, row):
                continue             # two points made one: no mark
            if tooling and row.get("kind") == "fix" and \
                    _is_reference(cont, row):
                # the pin of a point / edge copied from the part for a
                # dimension: not a relation the user made (while adding
                # dimensions a lock showed on every corner one had
                # touched). With the feature SELECTED they are shown.
                continue
            for ref in rm.spots(row["kind"], row["refs"]):
                try:
                    p = _spot(cont, ref)
                except (KeyError, ValueError, IndexError, TypeError):
                    continue
                if not vis(m, p):
                    continue
                q = scr(m, p)
                if q is None:
                    continue
                key = (round(q.x() / 8), round(q.y() / 8))
                dx = taken.get(key, 0)
                taken[key] = dx + rm.SIZE + 3
                rect = rm.rect_at(q.x(), q.y(), dx)
                rm.paint(painter, rect, row["kind"])
                window._relation_hits.append((rect, cont, index))


def _being_edited(window, rel):
    """The sketches of *rel* the user is working IN: the one drawn by
    the 3D sketch tool, or one whose own Group / Regions or shapes are
    selected (not a feature above it)."""
    from .model import SHAPE_2D
    sk = getattr(window, "_sketch3d_tool", None)
    drawing = {id(c) for c in (getattr(sk, "holder", None),
                               getattr(sk, "group", None)) if c is not None}
    ids = getattr(window, "_selected_ids", set()) or set()
    out = []
    for c, m in rel:
        if id(c) in drawing or c.id in ids or (
                c.params.get("face_sketch") and c.id in ids) or any(
                n.id in ids and (n.category == SHAPE_2D or n.type == "regions")
                for n in c.walk()):
            out.append((c, m))
            continue
        probe = c.parent
        if probe is not None and probe.params.get("face_sketch") and \
                probe.id in ids:
            out.append((c, m))         # the face sketch holding it
    return out


DRAG_PX = 4

#: rays along each dimension line: it is drawn in pieces where seen
SEG_SAMPLES = 16
MOVING_SAMPLES = 3


def press(window, pos):
    """A press on a dimension's value in the 3D view: a drag moves it out
    of the way (SolidWorks), a click without moving types a new value.
    True when taken."""
    for hit in getattr(window, "_dims3d_hits", []):
        rect, cont, index = hit[:3]
        drag = hit[3] if len(hit) > 3 else None
        if rect.adjusted(-3, -3, 3, 3).contains(pos.x(), pos.y()):
            window._dim3d_drag = dict(rect=rect, cont=cont, index=index,
                                      info=drag, start=pos, moved=False)
            return True
    return False


def _to_local(jac, dx, dy):
    """A screen move (px) as a move in the sketch (mm)."""
    (ax, ay), (bx, by) = jac
    det = ax * by - bx * ay
    if abs(det) < 1e-9:
        return None
    return ((dx * by - bx * dy) / det, (ax * dy - dx * ay) / det)


def move(window, pos):
    d = getattr(window, "_dim3d_drag", None)
    if d is None:
        return False
    dx, dy = pos.x() - d["start"].x(), pos.y() - d["start"].y()
    if not d["moved"] and math.hypot(dx, dy) < DRAG_PX:
        return True
    info = d["info"]
    if not info or not info.get("jac"):
        return True
    local = _to_local(info["jac"], dx, dy)
    if local is None:
        return True
    d["moved"] = True
    row = sc.rows(d["cont"])[d["index"]]
    if info["kind"] == "linear":
        n = info["n"]
        row["offset"] = round(info["offset"] + local[0] * n[0]
                              + local[1] * n[1], 3)
    else:
        row["leader_at"] = [round(info["at"][0] + local[0], 3),
                            round(info["at"][1] + local[1], 3)]
    window.view3d.update()
    return True


def release(window, pos):
    d = getattr(window, "_dim3d_drag", None)
    if d is None:
        return False
    window._dim3d_drag = None
    if d["moved"]:
        cont = d["cont"]
        cont.params[sc.KEY] = sc.rows(cont)
        window.model.node_changed.emit(cont)     # one undo step
    else:
        edit(window, d["rect"], d["cont"], d["index"])
    return True


def edit(window, rect, cont, index):
    """Type a new value in place (dim_link's editor: a click on another
    dimension meanwhile links this one to it)."""
    from . import dim_link
    from .sketch_constrain_ui import _value
    row = sc.rows(cont)[index]
    view = window.view3d

    def commit(text):
        try:
            if sc.rows(cont)[index].get("driven"):
                # typing a size into a driven (bracketed) dimension makes
                # it DRIVING again, at the new value
                sc.set_driven(window.model, cont, index, False)
            sc.set_value(window.model, cont, index, _value(text))
        except sc.Conflict as exc:
            raise ValueError(str(exc))
        view.update()
    if row.get("driven"):
        view.flash("Driven dimension: it only measures. Type a value to "
                   "make it driving, or Esc.", 6000)
    return dim_link.open_editor(window, rect, str(row.get("value", "")),
                                commit, ("sketch", cont, index))
