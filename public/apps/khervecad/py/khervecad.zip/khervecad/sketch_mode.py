"""Fusion's sketch mode: one canvas, 2D only while sketching.

Fusion and SolidWorks have no 2D view beside the 3D one: Create Sketch
turns the canvas to the sketch plane, a SKETCH tab of tools appears,
Finish Sketch goes back to the model. KherveCAD's classic window keeps
both views stacked; in the Fusion Interface Style (2026-10-19, the
user chose the simple version) the right column shows ONE of them in
the same place: the 3D view, and the 2D sketch view while sketching —
entered by Create Sketch or by picking a drawing tool, left by the
Finish Sketch button floating on the sketch.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from PyQt5.QtCore import QEvent, QObject, Qt, QTimer
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QAction, QLabel, QPushButton

from . import icons, language, tooltips

tooltips.TIPS.setdefault("create_sketch", (
    "Sketch Mode",
    "Sketch in 2D, SolidWorks' way: the 3D view turns to look straight "
    "at where you sketch and becomes the sketch. What it sketches on "
    "follows what is selected.",
    ["A 2D shape (or the extrude holding it) selected: edit that sketch.",
     "A part selected: click the face of it to sketch on.",
     "Nothing selected: the current plane (Top, Front or Side).",
     "Click Exit Sketch Mode (same button) to turn back to 3D."],
    "Right-click a shape in the tree ▸ Edit Sketch does the same."))


#: styles with one canvas and the other view small in its corner
ONE_CANVAS = ("Fusion", "SolidWorks")


def active(win) -> bool:
    """True when the window works Fusion's way (one canvas)."""
    # SolidWorks sketches the same way (2026-10-20, the user)
    return getattr(win, "_interface_style", "") in ONE_CANVAS


def sketching(win) -> bool:
    return bool(getattr(win, "_sketching", False))


def create_action(win):
    """The SKETCH tab's Create Sketch action, made once per window."""
    act = getattr(win, "_create_sketch_act", None)
    if act is None:
        act = QAction(icons.icon("mdi.pencil-box-outline", "#0696d7"),
                      language.tr("Sketch Mode"), win)
        act.setData("create_sketch")
        from . import toolbars
        toolbars.remember_glyph(act, "mdi.pencil-box-outline", "draw")
        tooltips.apply(act, "create_sketch")
        # a 2D shape selected: Edit Sketch — turn to it first (normal_to)
        act.triggered.connect(lambda: _create_or_edit(win))
        win._create_sketch_act = act
    return act


def _create_or_edit(win):
    """Create Sketch / Exit Sketch, one button (the user): sketching, it
    leaves; else the 3D view turns onto the plane and the sketch opens."""
    if sketching(win):
        finish(win)
        return
    if _in_3d(win):
        win._sketch3d_tool.finish()
        return
    from . import normal_to
    if active(win):
        normal_to.create(win)
    else:
        enter(win)


def _in_3d(win):
    """The tool drawing a sketch on a face in the 3D view, if running."""
    return getattr(win, "_sketch3d_tool", None) is not None


def sync_create(win):
    """The button reads Exit Sketch while sketching."""
    act = getattr(win, "_create_sketch_act", None)
    if act is not None:
        # on two lines: one was too long for the ribbon's big button
        text = language.tr("Exit Sketch") + "\n" + language.tr("Mode") \
            if sketching(win) or _in_3d(win) else language.tr("Sketch Mode")
        kind = _feature_of(win)
        if kind:
            # leaving MAKES the feature: say so (2026-11-13, the user was
            # surprised by an extrude after "Exit Sketch Mode")
            from . import cut_feature
            text = language.tr("Finish") + "\n" + \
                language.tr(cut_feature.ALL[kind][0])
        act.setText(text)


def _feature_of(win):
    """The Boss / Cut kind the open sketch makes on leaving, or ''."""
    from . import cut_feature
    g = getattr(win, "_face_sketch", None)
    tool = getattr(win, "_sketch3d_tool", None)
    if g is None and tool is not None:
        g = getattr(tool, "group", None)
    kind = g.params.get(cut_feature.KEY) if g is not None else None
    return kind if kind in cut_feature.ALL else ""


class _FinishButton(QPushButton):
    """Fusion's green FINISH SKETCH, top-right of the sketch."""

    def __init__(self, win):
        super().__init__("✓  " + language.tr("FINISH SKETCH"), win.view2d)
        self.setObjectName("finishSketch")
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet(
            "#finishSketch { background: #2e9a46; color: white; border: "
            "none; border-radius: 3px; padding: 6px 14px; font-weight: "
            "bold; } #finishSketch:hover { background: #38b153; }")
        self.clicked.connect(lambda: finish(win))
        self._view = win.view2d
        self._view.installEventFilter(self)
        self.place()

    def place(self):
        self.adjustSize()
        area = self._view.viewport().geometry()
        # left of the floating nav bar, which holds the top-right corner
        nav = getattr(self._view, "nav_bar", None)
        right = nav.x() - 10 if nav is not None and nav.isVisible() \
            else area.right() - 10
        self.move(right - self.width(), area.top() + 10)
        self.raise_()

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Resize, QEvent.Show):
            self.place()
        return False


def _button(win):
    b = getattr(win, "_finish_sketch", None)
    if b is None:
        b = win._finish_sketch = _FinishButton(win)
    return b


def _plane_buttons_shown(win, on):
    """The 2D bar's Front / Top / Right buttons, or Exit Sketch."""
    for w in list((getattr(win, "_plane_buttons", None) or {}).values()) \
            + [getattr(win, "_plane_line", None)]:
        try:
            if w is not None:
                w.setVisible(on)
        except RuntimeError:
            pass
    b = getattr(win, "_exit_sketch_btn", None)
    if b is not None:
        try:
            b.setVisible(not on)
        except RuntimeError:
            pass


def _show(win, sketch: bool):
    vibe = bool(getattr(win, "_vibe_act", None)
                and win._vibe_act.isChecked())
    win.view2d.setVisible(sketch and not vibe)
    win.view3d.setVisible(not sketch or vibe)
    b = _button(win)
    # the green FINISH SKETCH is not drawn (2026-10-21, the user: remove
    # it from the 2D view); picking a 3D tab or tool leaves the sketch
    b.setVisible(False)
    # on a face the sketch has its own plane: the Front / Top / Right
    # buttons are not for it ("Top" stood lit on a front face)
    # ... nor for any sketch here: the 3D view chose the plane, so the
    # 2D bar offers Exit Sketch instead (2026-11-11, the user)
    _plane_buttons_shown(win, not sketch)
    bar = getattr(win.view2d, "nav_bar", None)
    if bar is not None:
        bar.place()
    # the small 3D view in the sketch's corner and the small sketch in
    # the 3D view's are OFF (2026-11-10, the user: "when we are in 3D,
    # we're in 3D view; when we are in 2D view, we're in 2D view") unless
    # View ▸ Corner Views While Sketching is ticked
    if not corner_views():
        for name in ("_sketch_inset", "_sketch_mini2d"):
            w = getattr(win, name, None)
            if w is not None:
                w.hide()
        return
    inset = _inset(win)
    inset.setVisible(sketch and not vibe)
    mini = _mini2d(win)
    mini.setVisible(not sketch and not vibe)
    if not sketch:
        mini.place()
        mini.redraw()
        QTimer.singleShot(0, mini.place)
    if sketch:
        inset.place()
        inset.redraw()
        # the splitter sizes a view it just showed on the next turn
        QTimer.singleShot(0, inset.place)


#: QSettings key: the corner views (off unless asked for)
CORNER_KEY = "sketch/corner_views"


def corner_views() -> bool:
    from PyQt5.QtCore import QSettings
    v = QSettings("Kherve", "KherveCAD").value(CORNER_KEY, False)
    return v in (True, "true", "1", 1)


def set_corner_views(win, on):
    from PyQt5.QtCore import QSettings
    QSettings("Kherve", "KherveCAD").setValue(CORNER_KEY, bool(on))
    if active(win):
        _show(win, sketching(win))


def corner_action(win):
    """View ▸ Corner Views While Sketching, made once per window."""
    act = getattr(win, "_corner_views_act", None)
    if act is None:
        act = QAction(language.tr("Corner Views While Sketching"), win)
        act.setCheckable(True)
        act.setChecked(corner_views())
        act.setStatusTip(language.tr(
            "A small 3D view in the sketch's corner, and the sketch small "
            "in the 3D view's (SolidWorks and Fusion styles)."))
        act.toggled.connect(lambda on: set_corner_views(win, on))
        win._corner_views_act = act
    return act



def enter(win):
    """Create Sketch: the canvas becomes the 2D sketch."""
    if not active(win):
        return
    win._sketching = True
    sync_create(win)
    # a 3D part / extrude picked: the sketch is about its 2D shape —
    # select that one (the user: "it is the 2D shape that matters")
    from . import normal_to
    from .model import SHAPE_2D
    tree = win.builder.active_tree()
    picked = tree.selected_nodes()
    if picked and not any(n.category == SHAPE_2D for n in picked):
        shape = normal_to.sketch_node(win)
        if shape is not None:
            tree.select_nodes([shape])
    _show(win, True)
    # the scene shows THIS sketch only from now on (sketch_focus)
    try:
        win.view2d.scene().rebuild()
    except Exception:
        pass
    QTimer.singleShot(0, lambda: _frame_2d(win))
    if getattr(win, "ribbon", None) is not None:
        win.ribbon.show_tab("sketch")
    win.view2d.setFocus()


def finish(win):
    """Finish Sketch: back to the 3D model, Select tool."""
    win._sketching = False
    win._sketch_edit_node = None
    try:                                  # the overview again
        win.view2d.scene().rebuild()
    except Exception:
        pass
    sync_create(win)
    from .view2d import SELECT
    for act in win._tool_group.actions():
        if act.data() == SELECT:
            act.setChecked(True)
    win.view2d.set_tool(SELECT)
    if active(win):
        _show(win, False)
        # the ribbon stays on the Sketch tab (the user: Exit Sketch should
        # not take the tools away)
        # the 3D view comes back framed on what was picked (else the
        # whole model): it kept the camera it had before the sketch and
        # the picked part could be nowhere on it (2026-10-20, the user)
        # the 3D view turns back at the sketch's size — no zoom (the user)
        from . import normal_to
        QTimer.singleShot(0, lambda: normal_to.back(win))


#: how much further back than a tight fit the 3D view comes back
FRAME_MARGIN = 1.8


def _picked_rect(win):
    """The scene rectangle of what is picked — the part shown alone, the
    selected shapes — else of the whole drawing; None when empty."""
    scene = win.view2d.scene()
    rect = win.scene.isolated_bounds()
    if rect is None:
        for item in scene.selectedItems():
            box = item.sceneBoundingRect()
            rect = box if rect is None else rect.united(box)
    if rect is None or rect.isEmpty():
        rect = scene.itemsBoundingRect()
    return None if rect.isEmpty() else rect


def _frame_2d(win):
    """Opening the sketch shows what is picked, as leaving it shows it
    in 3D (the sketch could open zoomed out on empty paper)."""
    rect = _picked_rect(win)
    if rect is not None and win.view2d.isVisible():
        win.view2d.frame_rect(rect)


def _frame_3d(win):
    from . import viewnav
    view = win.view3d
    if view.isVisible() and (view.highlight_mesh or view.mesh):
        viewnav.focus_3d(view)
        view.distance *= FRAME_MARGIN        # room round it, like Fusion
        view.update()


def tool_chosen(win, tool):
    """A drawing tool picked while the 3D model shows: start sketching."""
    from .view2d import MEASURE, SELECT
    from . import constrain3d, sketch_constrain_ui
    if _in_3d(win):
        # the sketch icons drive the sketch being drawn in 3D
        win._sketch3d_tool.tool_icon(tool)
        return
    from . import drag_feature
    if drag_feature.pause_for(win, tool):
        return
    constrain3d.end(win)
    if active(win) and not sketching(win) and tool == MEASURE:
        # the 2D ruler measures in the sketch view, which is not on
        # show: Evaluate ▸ Measure did nothing one could see. Measure in
        # 3D instead — click a face or an edge, then another (the user,
        # 2026-11-12)
        from . import measure3d
        select = [a for a in win._tool_group.actions()
                  if a.data() == SELECT]
        if select:
            select[0].setChecked(True)
        win.view2d.set_tool(SELECT)
        if not measure3d.start(win):
            message = language.tr(
                "Measure: there is no part to click yet")
            win.statusBar().showMessage(message, 8000)
            win.view3d.flash(message)
        return
    if active(win) and not sketching(win) and \
            sketch_constrain_ui.handles(tool) and \
            constrain3d.start(win, tool):
        return        # constraints work in the 3D view too (the user)
    if active(win) and not sketching(win) and tool not in (SELECT,
                                                           MEASURE):
        from . import cut_feature, sketch3d, sketch3d_tools as more
        from .view2d import CIRCLE, LINE, RECT
        if cut_feature.IN_3D and tool in more.MODIFY:
            more.start_modify(win, tool)
            return
        if cut_feature.IN_3D and tool in more.REGIONS:
            more.start_regions(win, tool)
            return
        if cut_feature.IN_3D and (more.draws(tool) or
                                  tool in (CIRCLE, LINE, RECT)):
            # drawn in 3D: first a plane or a face to draw on
            sketch3d.start(win).tool_icon(tool)
            return
        enter(win)


def apply(win, style):
    """The Interface Style changed: one canvas (Fusion) or both."""
    if style in ONE_CANVAS:
        _show(win, sketching(win))
        return
    win._sketching = False
    _plane_buttons_shown(win, True)       # the classic 2D view: planes
    for name in ("_finish_sketch", "_sketch_inset", "_sketch_mini2d"):
        b = getattr(win, name, None)
        if b is not None:
            b.hide()
    vibe = bool(getattr(win, "_vibe_act", None)
                and win._vibe_act.isChecked())
    win.view2d.setVisible(not vibe)
    win.view3d.setVisible(True)


def after_vibe(win):
    """Vibe Model switched: in Fusion the canvas follows the sketch."""
    if active(win):
        _show(win, sketching(win))


class _Resizable:
    """A corner view the user can make smaller or larger (2026-10-21,
    the user: "that small view needs to be resizable to make it even
    smaller"): a grip in its TOP-LEFT corner — it sits in the
    bottom-right of its view, so that corner is the free one — drags
    the size, remembered per view in QSettings `<KEY>`."""

    GRIP = 14
    MIN_W, MIN_H, MAX_W, MAX_H = 90, 64, 640, 460

    def _init_size(self):
        from PyQt5.QtCore import QSettings
        value = QSettings("Kherve", "KherveCAD").value(self.KEY)
        try:
            w, h = (int(v) for v in str(value).split("x"))
        except (TypeError, ValueError):
            w, h = type(self).W, type(self).H
        self.W = max(self.MIN_W, min(self.MAX_W, w))
        self.H = max(self.MIN_H, min(self.MAX_H, h))
        self.setFixedSize(self.W, self.H)
        self.setMouseTracking(True)
        self._grab = None

    def _on_grip(self, pos):
        return pos.x() < self.GRIP and pos.y() < self.GRIP

    def set_size(self, w, h, save=True):
        self.W = int(max(self.MIN_W, min(self.MAX_W, w)))
        self.H = int(max(self.MIN_H, min(self.MAX_H, h)))
        self.setFixedSize(self.W, self.H)
        if getattr(self, "_twin_view", None) is not None:
            self._twin_view.resize((self.W - 2) * 3, (self.H - 2) * 3)
        self.place()
        self.redraw()
        if save:
            from PyQt5.QtCore import QSettings
            QSettings("Kherve", "KherveCAD").setValue(
                self.KEY, "%dx%d" % (self.W, self.H))

    def _grip_press(self, event):
        if event is not None and event.button() == Qt.LeftButton and \
                self._on_grip(event.pos()):
            # the bottom-right corner stays put, the top-left follows
            self._grab = (event.globalPos(), self.W, self.H)
            return True
        return False

    def mouseMoveEvent(self, event):
        if self._grab is not None:
            start, w, h = self._grab
            d = event.globalPos() - start
            self.set_size(w - d.x(), h - d.y(), save=False)
            return
        self.setCursor(Qt.SizeFDiagCursor if self._on_grip(event.pos())
                       else Qt.PointingHandCursor)

    def mouseReleaseEvent(self, event):
        if self._grab is not None:
            self._grab = None
            self.set_size(self.W, self.H)            # remember it

    def paintEvent(self, event):
        super().paintEvent(event)
        from PyQt5.QtGui import QPainter, QPen, QColor
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor("#7d8892"), 1.2))
        for k in (4, 8, 12):                     # three diagonal ridges
            p.drawLine(2, k, k, 2)
        p.end()


class Inset(_Resizable, QLabel):
    """The model in 3D, small, in the sketch's bottom-right corner while
    sketching (2026-10-19, the user: "in the right bottom corner of the
    2D, see the 3D still"). A picture from the 3D view's own camera
    (`View3D.snapshot`), redrawn when the model changes; a click on it
    finishes the sketch."""

    W, H = 280, 200
    KEY = "sketch/inset_size"

    def __init__(self, win):
        super().__init__(win.view2d)
        self.win = win
        self.setObjectName("sketchInset")
        self._init_size()
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(language.tr("The model in 3D — click to finish "
                                    "the sketch"))
        self.setStyleSheet("#sketchInset { border: 1px solid #9aa4ad; "
                           "border-radius: 3px; background: #e9edf1; }")
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(250)
        self._timer.timeout.connect(self.redraw)
        win.model.structure_changed.connect(self.later)
        win.model.node_changed.connect(self.later)
        # the tree's selection reaches the sketch scene: the part picked
        # is tinted in the corner as in the full 3D view
        win.view2d.scene().selectionChanged.connect(self.later)
        win.view2d.installEventFilter(self)

    def later(self, *args):
        if self.isVisible():
            self._timer.start()

    def redraw(self):
        try:                  # the 3D view's own angle, the whole model
            img, _state = self.win.view3d.snapshot(
                self.W - 2, self.H - 2, frame=True, zoom=0.8, clean=True,
                highlight=True)
        except Exception:                   # never break the sketch
            return
        if img is not None:
            self.setPixmap(QPixmap.fromImage(img))

    def place(self):
        area = self.win.view2d.viewport().geometry()
        self.move(area.right() - self.W - 12, area.bottom() - self.H - 12)
        self.raise_()

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Resize, QEvent.Show,
                            QEvent.LayoutRequest):
            QTimer.singleShot(0, self.place)
        return False

    def mousePressEvent(self, event):
        if not self._grip_press(event):
            finish(self.win)


def _inset(win):
    got = getattr(win, "_sketch_inset", None)
    if got is None:
        got = win._sketch_inset = Inset(win)
    return got


class Mini2D(_Resizable, QLabel):
    """The sketch, small, in the 3D view's corner (the user, same day:
    "in the 3D view, the same thing, a 2D view on the side"): the 2D
    scene drawn Y-up round what it holds, the selection showing as the
    sketch shows it; a click starts sketching."""

    W, H = 240, 170
    KEY = "sketch/mini2d_size"

    def __init__(self, win):
        super().__init__(win.view3d)
        self.win = win
        self.setObjectName("sketchMini")
        self._init_size()
        self.setAlignment(Qt.AlignCenter)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(language.tr("The sketch in 2D — click to sketch"))
        self.setStyleSheet("#sketchMini { border: 1px solid #9aa4ad; "
                           "border-radius: 3px; background: #ffffff; }")
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(250)
        self._timer.timeout.connect(self.redraw)
        win.model.structure_changed.connect(self.later)
        win.model.node_changed.connect(self.later)
        win.view2d.scene().selectionChanged.connect(self.later)
        win.view3d.installEventFilter(self)

    def later(self, *args):
        if self.isVisible():
            self._timer.start()

    def redraw(self):
        """The sketch, drawn by a twin sketch view of the SAME scene
        (grid when on, axes, colours, selection) framed on what is
        picked, else the whole drawing, and shrunk into the corner.

        A twin, never the user's own 2D view: borrowing that one showed
        a cropped, empty patch — hidden in its splitter it is squashed
        to no height, and its own zoom was whatever the sketch last had
        (the user's door handle: the cylinder seen in 2D was gone from
        the corner after going back to 3D)."""
        from PyQt5.QtCore import QSize
        from PyQt5.QtWidgets import QWidget
        try:
            twin = self._twin()
            rect = _picked_rect(self.win)
            if rect is not None:
                twin.frame_rect(rect)
            port = twin.viewport()
            pix = QPixmap(port.size())
            pix.fill(Qt.white)
            port.render(pix, flags=QWidget.RenderFlags(
                QWidget.DrawWindowBackground))
            pix = pix.scaled(QSize(self.W - 2, self.H - 2),
                             Qt.KeepAspectRatio, Qt.SmoothTransformation)
        except Exception:                   # never break the 3D view
            return
        self.setPixmap(pix)

    def _twin(self):
        """An off-screen SketchView on the document's scene, the corner's
        own camera (3x the corner's size, so lines stay fine)."""
        twin = getattr(self, "_twin_view", None)
        if twin is None:
            from PyQt5.QtWidgets import QWidget
            from .view2d import SketchView
            twin = SketchView(self.win.view2d.scene())
            twin.no_dims = True          # the corner picture: shapes only
            twin.setAttribute(Qt.WA_DontShowOnScreen, True)
            # never a window the app waits for: a "shown" twin kept
            # KherveCAD running after its window closed, and it could
            # not be opened again (the user, 2026-10-20)
            twin.setAttribute(Qt.WA_QuitOnClose, False)
            twin.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            twin.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            twin.resize((self.W - 2) * 3, (self.H - 2) * 3)
            twin.show()                       # lays it out, off screen
            for w in twin.findChildren(QWidget):
                if w.parent() is twin and w is not twin.viewport():
                    w.hide()                  # its polygon bar & co
            self._twin_view = twin
            self.destroyed.connect(twin.deleteLater)
            self.win.destroyed.connect(twin.deleteLater)
        return twin

    def place(self):
        r = self.win.view3d.rect()
        nav = getattr(self.win.view3d, "nav_bar", None)
        lift = nav.height() + 18 if nav is not None and \
            nav.isVisible() and getattr(nav, "anchor", "") == \
            "bottom-centre" else 12
        self.move(r.right() - self.W - 12, r.bottom() - self.H - lift)
        self.raise_()

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Resize, QEvent.Show):
            QTimer.singleShot(0, self.place)
        return False

    def mousePressEvent(self, event):
        if not self._grip_press(event):
            enter(self.win)


def _mini2d(win):
    got = getattr(win, "_sketch_mini2d", None)
    if got is None:
        got = win._sketch_mini2d = Mini2D(win)
    return got


def selection_changed(win):
    """The selection moved (tree or sketch): both corner views follow."""
    for name in ("_sketch_mini2d", "_sketch_inset"):
        got = getattr(win, name, None)
        if got is not None:
            got.later()
