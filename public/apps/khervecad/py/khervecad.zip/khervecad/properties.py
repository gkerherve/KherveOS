"""Properties panel — edit the parameters of the selected object.

Every node type declares a parameter schema in ``model.NODE_TYPES``;
this panel turns the schema of the selected node into live editors
(x/y/radius for a circle, height/twist for a linear extrude, ...).
Edits go straight into the model, so the 2D view, 3D view and code
tab follow immediately.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License or (at your
option) any later version, as published by the Free Software
Foundation, either version 3 of the License.
"""

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox,
                             QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                             QPlainTextEdit, QPushButton, QScrollArea,
                             QSpinBox, QTableWidget, QTableWidgetItem,
                             QVBoxLayout, QWidget)

from . import icons, language
from .rowsedit import ChoiceBox, RowsEditor
from .model import NODE_TYPES, DocumentModel, fmt


def _cell(v) -> str:
    """A point coordinate as the table shows it: a number tidily, an
    expression ("w / 2", "r * cos(a)") as written — the table used to
    crash on one, which also stopped the 2D view following the
    selection (the user's polygon)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return f"{v:g}"
    return str(v)


def _value(text):
    """A typed cell: a number, else an expression kept as text; blank is
    an edit still going."""
    text = text.strip()
    if not text:
        raise ValueError("blank")
    try:
        return float(text)
    except ValueError:
        return text


class VarOrValueEdit(QComboBox):
    """Editor for numeric params: type a fixed number or expression, or
    pick one of the document's variables from the dropdown.

    "12.5" stores a float; a variable name or "i * 10 + 2" stores the
    expression string (resolved by codegen/preview with variables and
    loop values in scope).
    """

    def __init__(self, on_commit, variables, parent=None):
        super().__init__(parent)
        self._on_commit = on_commit
        self._variables = variables            # callable -> list[str]
        self.setEditable(True)
        self.setInsertPolicy(QComboBox.NoInsert)
        self.lineEdit().setPlaceholderText(
            language.tr("value, expression or variable"))
        self.lineEdit().editingFinished.connect(self._commit)
        self.activated.connect(lambda _i: self._commit())

    def showPopup(self):
        # refresh the variable list every time the dropdown opens, so it
        # always reflects the current document
        text = self.currentText()
        self.blockSignals(True)
        self.clear()
        self.addItems(self._variables())
        self.setEditText(text)
        self.blockSignals(False)
        super().showPopup()

    def set_value(self, value):
        self.setEditText(fmt(value) if not isinstance(value, str)
                         else value)

    def _commit(self):
        text = self.currentText().strip()
        if not text:
            return
        try:
            value = float(text)
        except ValueError:
            value = text
        self._on_commit(value)


class MultilineEdit(QPlainTextEdit):
    """A monospaced multi-line editor (for the raw-OpenSCAD `code`
    param). Commits on focus-out, so the model doesn't regenerate on
    every keystroke."""

    def __init__(self, on_commit, parent=None):
        super().__init__(parent)
        self._on_commit = on_commit
        font = QFont("Consolas")
        font.setStyleHint(QFont.Monospace)
        self.setFont(font)
        self.setMinimumHeight(160)
        self.setLineWrapMode(QPlainTextEdit.NoWrap)

    def focusOutEvent(self, event):
        super().focusOutEvent(event)
        self._on_commit(self.toPlainText())


class PointsEditor(QWidget):
    """Small table editor for polygon points."""

    #: the row (= vertex index) the user selected, -1 for none.
    point_selected = pyqtSignal(int)

    _ROW_H = 20

    def __init__(self, points, on_change, parent=None):
        super().__init__(parent)
        self._on_change = on_change
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.table = QTableWidget(len(points), 2)
        self.table.setHorizontalHeaderLabels(
            [language.tr("X"), language.tr("Y")])
        from .rowsedit import compact_table
        compact_table(self.table, self._ROW_H)
        for row, (x, y) in enumerate(points):
            self.table.setItem(row, 0, QTableWidgetItem(_cell(x)))
            self.table.setItem(row, 1, QTableWidgetItem(_cell(y)))
        from .rowsedit import fit_columns
        fit_columns(self.table)
        self.table.itemChanged.connect(lambda _i: self._emit())
        self.table.currentCellChanged.connect(
            lambda cur, _c, _pr, _pc: self.point_selected.emit(cur))
        layout.addWidget(self.table)
        self._fit_height()

        buttons = QHBoxLayout()
        from .rowsedit import small_button
        buttons.setSpacing(2)
        add = small_button("mdi.plus", language.tr(
            "Insert a point after the selected one, on the midpoint "
            "of its edge (keeps the outline)"), self._add_row)
        remove = small_button("mdi.minus", language.tr(
            "Remove the selected point"), self._remove_row)
        up = small_button("mdi.arrow-up", language.tr(
            "Move the point one place earlier — it lands midway "
            "between its new neighbours"), lambda: self._move_row(-1))
        down = small_button("mdi.arrow-down", language.tr(
            "Move the point one place later — it lands midway "
            "between its new neighbours"), lambda: self._move_row(1))
        buttons.addWidget(add)
        buttons.addWidget(remove)
        buttons.addWidget(up)
        buttons.addWidget(down)
        buttons.addStretch()
        layout.addLayout(buttons)

    def _fit_height(self):
        """Size the table to its rows, up to 15, so it shows the points
        without its own scrollbar (the panel scrolls if needed)."""
        from .rowsedit import fit_table_height
        fit_table_height(self.table, 15, self._ROW_H)

    def _read_points(self):
        """Current table contents as floats, or None if a cell is
        blank/invalid (an edit still in progress)."""
        points = []
        for row in range(self.table.rowCount()):
            try:
                x = _value(self.table.item(row, 0).text())
                y = _value(self.table.item(row, 1).text())
            except (TypeError, ValueError, AttributeError):
                return None
            points.append([x, y])
        return points

    def _fill(self, points):
        """Replace the whole table from a list of points."""
        self.table.blockSignals(True)
        self.table.setRowCount(len(points))
        for row, (x, y) in enumerate(points):
            self.table.setItem(row, 0, QTableWidgetItem(_cell(x)))
            self.table.setItem(row, 1, QTableWidgetItem(_cell(y)))
        self.table.blockSignals(False)
        self._fit_height()

    def _move_row(self, delta):
        """Move the selected point one place up/down in the ring and
        drop it midway between its two new neighbours."""
        pts = self._read_points()
        if not pts:
            return
        row = self.table.currentRow()
        new = row + delta
        if row < 0 or new < 0 or new >= len(pts):
            return
        pts.insert(new, pts.pop(row))          # reorder
        count = len(pts)
        prev = pts[(new - 1) % count]
        nxt = pts[(new + 1) % count]
        pts[new] = [round((prev[0] + nxt[0]) / 2, 4),
                    round((prev[1] + nxt[1]) / 2, 4)]
        self._fill(pts)
        self.table.setCurrentCell(new, 0)
        self._on_change(pts)

    def _add_row(self):
        # split the edge leaving the selected vertex: the new point sits
        # at that edge's midpoint, so the polygon keeps its shape and you
        # just get a fresh vertex to drag. With nothing selected, split
        # the closing edge (last -> first) rather than spiking to origin.
        pts = self._read_points()
        if not pts:
            return
        count = len(pts)
        cur = self.table.currentRow()
        idx = cur if 0 <= cur < count else count - 1
        nxt = (idx + 1) % count
        from .expr import resolve
        num = lambda v: float(resolve(v, {}, 0.0))     # noqa: E731
        mx = round((num(pts[idx][0]) + num(pts[nxt][0])) / 2, 4)
        my = round((num(pts[idx][1]) + num(pts[nxt][1])) / 2, 4)
        self.table.blockSignals(True)
        self.table.insertRow(idx + 1)
        self.table.setItem(idx + 1, 0, QTableWidgetItem(f"{mx:g}"))
        self.table.setItem(idx + 1, 1, QTableWidgetItem(f"{my:g}"))
        self.table.blockSignals(False)
        self._fit_height()
        self.table.setCurrentCell(idx + 1, 0)       # ready to edit
        self._emit()

    def _remove_row(self):
        row = self.table.currentRow()
        if row < 0:
            row = self.table.rowCount() - 1
        if row >= 0 and self.table.rowCount() > 3:
            self.table.removeRow(row)
            self._fit_height()
            self.table.selectRow(min(row, self.table.rowCount() - 1))
            self._emit()

    def _emit(self):
        points = self._read_points()
        if points is not None:
            self._on_change(points)


#: editors shown as a table: named above, the full width of the panel
TABLE_KINDS = ("points", "rows")
#: what a table holds, when its short name does not say
TABLE_TIPS = {
    ("polygon", "paths"): "One outline per row, as point numbers (counted "
                          "from 0). An outline inside another is a hole. "
                          "Empty: every point, in order.",
    ("fillet", "edges"): "The edges this fillet rounds, each as its start "
                         "and end point (x y z). + picks more on the "
                         "model; − removes the selected row.",
    ("fillet", "faces"): "The faces whose every edge is rounded — holes "
                         "included, even ones cut later. Each is a point "
                         "on the face and its normal. + picks more on the "
                         "model.",
    ("polygon", "corners"): "Sketch fillets: the corner's number (from 0), "
                            "its radius, and 1 for a chamfer.",
}


class PropertiesPanel(QScrollArea):
    """Bottom-left panel: parameter editors for the selected node."""

    #: (polygon node, vertex index) selected in a Points table, so the
    #: 2D view can highlight that vertex.
    point_selected = pyqtSignal(object, int)

    def __init__(self, model: DocumentModel, parent=None):
        super().__init__(parent)
        self.model = model
        self.node = None
        self._updating = False
        self.setWidgetResizable(True)
        self._body = QWidget()
        self.setWidget(self._body)
        self._layout = QVBoxLayout(self._body)
        self._layout.setContentsMargins(6, 4, 6, 4)
        self._layout.setSpacing(3)
        from .rowsedit import COMPACT_QSS
        self._body.setStyleSheet(COMPACT_QSS)
        self._editors = {}
        model.node_changed.connect(self._node_changed)
        model.structure_changed.connect(self._structure_changed)
        self.set_node(None)

    # ---------------------------------------------------------- build
    def set_node(self, node):
        self.node = node
        self._editors.clear()
        self._clear_layout(self._layout)
        if node is None:
            hint = QLabel(language.tr("Select an object in the tree\n"
                                      "to edit its properties."))
            hint.setAlignment(Qt.AlignCenter)
            hint.setEnabled(False)
            self._layout.addStretch()
            self._layout.addWidget(hint)
            self._layout.addStretch()
            return

        from . import sketch_section
        if sketch_section.is_section(node):
            # generated, not drawn: say what it is instead of editors
            # that would break its link to the model
            title = QLabel("<b>%s</b>" % language.tr(sketch_section.NAME))
            self._layout.addWidget(title)
            text = QLabel(language.tr(sketch_section.EXPLAIN))
            text.setWordWrap(True)
            self._layout.addWidget(text)
            self._layout.addStretch()
            return
        spec = NODE_TYPES[node.type]
        from . import slot2d
        slot = slot2d.is_slot(node)
        label = spec["label"]
        if node.type == "linear_extrude":
            from . import extrude_props
            label = extrude_props.title(node)
        title = QLabel("<b>%s</b>" % language.tr("Slot" if slot
                                                  else label))
        self._layout.addWidget(title)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setVerticalSpacing(3)
        form.setHorizontalSpacing(6)
        name_edit = QLineEdit(node.name)
        name_edit.editingFinished.connect(
            lambda: self._rename(name_edit.text()))
        form.addRow(language.tr("Name"), name_edit)
        self._construction = None
        if node.category == "2d" and node.type != "text":
            # SolidWorks' Line / Circle properties: "For construction"
            # (2026-11-11, the user) — dashed, left out of the solid
            # (OpenSCAD's %), still used by relations and dimensions
            box = QCheckBox(language.tr("For construction"))
            box.setToolTip(language.tr(
                "Construction geometry: drawn dashed, used by relations "
                "and dimensions, never part of the solid."))
            box.toggled.connect(self._set_construction)
            self._construction = box
            form.addRow("", box)

        if slot:
            # a slot's own sizes, not the line's two ends (the user)
            for key, label in slot2d.FIELDS:
                editor = VarOrValueEdit(
                    lambda v, k=key: self._set_slot(k, v),
                    self._variable_names)
                self._editors["slot:" + key] = editor
                form.addRow(language.tr(label), editor)
        self._extrude = None
        self._locked = None
        if node.type != "linear_extrude" and not slot:
            # a sketch (its Group, Regions, a revolve…): what it is held
            # by and how it can still move — the extrude says it too
            from . import sketch_lock
            try:
                has = sketch_lock.container_of(node) is not None and \
                    node.category != "2d"
            except Exception:
                has = False
            if has:
                self._locked = QLabel()
                self._locked.setWordWrap(True)
                form.addRow(language.tr("Locked to"), self._locked)
        if node.type == "linear_extrude" and not slot:
            # in the words of the Extrude window (the user): profiles,
            # direction, end condition, distances, reverse — then twist,
            # scale, slices
            from . import extrude_props
            extrude_props.build(self, form, node)
        self._origin = None
        from . import sketch_tools2 as _s2
        if _s2.origin_parts(node) is not None:
            # a Point with its X / Y centerlines: their lengths (the user:
            # "not easily available")
            group = _s2.origin_parts(node)[0]
            boxes = {}
            for key, label in (("x", "X centerline length (mm)"),
                               ("y", "Y centerline length (mm)")):
                spin = QDoubleSpinBox()
                spin.setRange(0.01, 1e6)
                spin.setDecimals(3)
                spin.setKeyboardTracking(False)
                spin.valueChanged.connect(
                    lambda v, k=key, g=group: None if self._updating else
                    _s2.set_arms(self.model, g, v if k == "x" else None,
                                 v if k == "y" else None))
                form.addRow(language.tr(label), spin)
                boxes[key] = spin
            self._origin = (group, boxes)
        from . import pattern_props
        self._pattern = None
        pattern_loop = pattern_props.loop_for(node)
        if pattern_loop is not None:
            # a Sketch Pattern: its numbers, not the loop's From / To
            # and an "i * 360 / 6" to type (2026-11-11, the user)
            pattern_props.build(self, form, pattern_loop)
        for key, label, kind, minimum, maximum in (
                [] if slot or node.type == "linear_extrude" or
                pattern_loop is not None
                else spec["schema"]):
            editor = self._make_editor(key, kind, minimum, maximum)
            if editor is not None:
                self._editors[key] = editor
                if kind in TABLE_KINDS:
                    # a table's name goes ABOVE it, the table takes the
                    # whole width (beside it, a long name squeezed every
                    # field of the form into half the panel)
                    head = QLabel(language.tr(label))
                    tip = TABLE_TIPS.get((node.type, key))
                    if tip:
                        head.setToolTip(language.tr(tip))
                        editor.setToolTip(language.tr(tip))
                    form.addRow(head)
                    form.addRow(editor)
                else:
                    form.addRow(language.tr(label), editor)
        self._layout.addLayout(form)
        self._layout.addStretch()
        self._load_values()

    def _variable_names(self):
        """Names of every document variable, offered in numeric fields."""
        names = []
        for node in self.model.root.walk():
            if node.type == "assign":
                var = str(node.params.get("variable", "")).strip()
                if var and var not in names:
                    names.append(var)
        return names

    def _make_editor(self, key, kind, minimum, maximum):
        if kind == "float":
            return VarOrValueEdit(
                lambda v, k=key: self._set_param(k, v),
                self._variable_names)
        if kind == "int":
            box = QSpinBox()
            box.setRange(int(minimum), int(maximum))
            box.valueChanged.connect(
                lambda v, k=key: self._set_param(k, int(v)))
            return box
        if kind == "bool":
            box = QCheckBox()
            box.toggled.connect(
                lambda v, k=key: self._set_param(k, bool(v)))
            return box
        if kind == "str":
            box = QLineEdit()
            box.editingFinished.connect(
                lambda b=None, k=key: self._set_param(
                    k, self._editors[k].text()))
            return box
        if kind == "text":
            return MultilineEdit(
                lambda v, k=key: self._set_param(k, v))
        if kind == "points":
            editor = PointsEditor(
                self.node.params[key],
                lambda pts, k=key: self._set_param(k, pts))
            editor.point_selected.connect(
                lambda idx: self.point_selected.emit(self.node, idx))
            return editor
        if kind == "color":
            button = QPushButton()
            button.clicked.connect(lambda _=False, k=key, b=button:
                                   self._pick_color(k, b))
            return button
        if kind == "rows":
            from .rowsedit import OPTIONAL_ROWS
            on_add = None
            win = self.window()
            if self.node.type == "fillet" and key in ("edges", "faces") \
                    and hasattr(win, "start_fillet_pick"):
                # + picks on the model, not a row of zeros to type into
                node = self.node
                on_add = lambda n=node, w=win: w.start_fillet_pick(n)
            return RowsEditor(self.node.params.get(key) or [], minimum,
                              lambda rows, k=key: self._set_param(k, rows),
                              allow_empty=key in OPTIONAL_ROWS,
                              on_add=on_add)
        if kind == "choice":
            box = ChoiceBox(minimum)
            box.currentTextChanged.connect(
                lambda v, k=key: self._set_param(k, v))
            return box
        return None

    def _pick_color(self, key, button):
        from PyQt5.QtGui import QColor
        from PyQt5.QtWidgets import QColorDialog
        current = QColor(str(self.node.params.get(key, "#4a90d9")))
        chosen = QColorDialog.getColor(
            current if current.isValid() else QColor("#4a90d9"),
            self, language.tr("Colour"))
        if chosen.isValid():
            self._set_param(key, chosen.name())
            self._swatch(button, chosen.name())

    @staticmethod
    def _swatch(button, color):
        button.setText(color)
        button.setStyleSheet(
            f"QPushButton {{ background: {color}; }}")

    def _load_values(self):
        self._updating = True
        defaults = NODE_TYPES.get(self.node.type, {}).get("params", {})
        from . import slot2d
        sizes = slot2d.read(self.node) if slot2d.is_slot(self.node) \
            else {}
        for key, editor in self._editors.items():
            if key.startswith("slot:"):
                editor.set_value(sizes.get(key[5:], 0.0))
                continue
            # fall back to the type's default: a node saved before a
            # param existed has no value for it, and feeding None to a
            # spin box raises straight through a Qt slot (which PyQt
            # turns into abort())
            value = self.node.params.get(key, defaults.get(key))
            if value is None:
                continue
            if isinstance(editor, VarOrValueEdit):
                editor.set_value(value)
            elif isinstance(editor, QDoubleSpinBox):
                editor.setValue(float(value))
            elif isinstance(editor, QSpinBox):
                editor.setValue(int(value))
            elif isinstance(editor, QCheckBox):
                editor.setChecked(bool(value))
            elif isinstance(editor, RowsEditor):
                editor.set_rows(value)
            elif isinstance(editor, ChoiceBox):
                editor.set_value(value)
            elif isinstance(editor, QPushButton):
                self._swatch(editor, str(value))
            elif isinstance(editor, MultilineEdit):
                editor.setPlainText(str(value))
            elif isinstance(editor, QLineEdit):
                editor.setText(str(value))
        if getattr(self, "_construction", None) is not None:
            self._construction.setChecked(
                self.node.params.get("modifier") == "%")
        if getattr(self, "_origin", None):
            from . import sketch_tools2 as _s2
            group, boxes = self._origin
            if group.parent is not None and _s2.origin_parts(group):
                xl, yl = _s2.arm_lengths(group)
                boxes["x"].setValue(xl)
                boxes["y"].setValue(yl)
        if getattr(self, "_pattern", None):
            from . import pattern_props
            pattern_props.load(self)
        if getattr(self, "_extrude", None):
            from . import extrude_props
            extrude_props.load(self)
        if getattr(self, "_locked", None) is not None:
            from . import sketch_lock
            try:
                info = sketch_lock.of(self.model, self.node)
                self._locked.setText(sketch_lock.text(info) if info else "")
            except Exception:
                self._locked.setText("")
        self._updating = False

    # --------------------------------------------------------- events
    def _live(self):
        """False once the window is closing and the model is gone: an
        editor that finishes then (focus out as the window closes) must
        not touch it (2026-11-15: "DocumentModel has been deleted")."""
        try:
            from PyQt5 import sip
            return not sip.isdeleted(self.model)
        except Exception:
            return True

    def _set_param(self, key, value):
        if not self._updating and self.node is not None and self._live():
            self.model.set_param(self.node, key, value)

    def _set_construction(self, on):
        if not self._updating and self.node is not None and \
                self._live() and \
                (self.node.params.get("modifier") == "%") != bool(on):
            self.model.set_modifier(self.node, "%" if on else "")

    def _set_slot(self, key, value):
        if not self._updating and self.node is not None and self._live():
            from . import slot2d
            slot2d.write(self.model, self.node, key, value)

    def _rename(self, name):
        if not self._updating and self.node is not None and name and \
                self._live():
            self.model.rename(self.node, name)

    def _node_changed(self, node):
        # Param changed elsewhere (2D view drag): refresh the editors.
        if node is self.node and not self._updating:
            self._load_values()

    def _structure_changed(self):
        # The node may have been deleted from under us.
        if self.node is not None and \
                self.model.find(self.node.id) is None:
            self.set_node(None)

    @staticmethod
    def _clear_layout(layout):
        while layout.count():
            entry = layout.takeAt(0)
            widget = entry.widget()
            if widget is not None:
                widget.deleteLater()
            elif entry.layout() is not None:
                PropertiesPanel._clear_layout(entry.layout())
