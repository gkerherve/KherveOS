"""More sketch CREATE tools (2026-10-21, the user: "add them all" — what
SolidCraft's sketcher has and KherveCAD lacked). They plug into
sketch_tools' tables (TOOLS, CLICKS, PROMPTS, BUILD, outline) on import,
so the clicks, the rubber band, Enter / right-click and Backspace work
as for the others:

- **construction** — not a tool but a switch (`toggle_construction`):
  OpenSCAD's own `%` modifier on the selected shapes, so OpenSCAD leaves
  them out of the solid and the program stays exact; drawn dashed, and
  constraints and dimensions use them like any shape;
- **point** — a 0.25 mm construction circle: its centre is a point to
  constrain (a hole centre, a midpoint);
- **three-point rectangle** (a side, then the depth: drawn at an angle),
  **two-point / three-point circles**, **regular polygon** (centre, a
  corner, sides asked), **polyline** (lines end to end, each joined to
  the last by a coincident constraint; Enter / right-click ends),
  **control-point spline** (a closed B-spline the points pull on, which
  it does not pass through), **tangent arc** (from a line's end, on in
  its direction), **tangent circle** (inside three lines) and **conic**
  (start, end, shoulder; rho 0.5 = a parabola).

Arcs and conics are open curves: they are drawn as a band as wide as a
line (a `polygon`), like a sketch fillet between two lines.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import math

from . import sketch_tools as st

POINT, RECT_3PT, CIRCLE_2PT, CIRCLE_3PT, POLY_REG = (
    "point", "rect_3pt", "circle_2pt", "circle_3pt", "poly_reg")
POLYLINE, BSPLINE, ARC_TAN, CIRCLE_TAN, CONIC = (
    "polyline", "bspline", "arc_tangent", "circle_tangent", "conic")
CONSTRUCTION = "construction"
CONST_LINE = "construction_line"

TOOLS = [
    (CONST_LINE, "mdi.vector-line", "Construction line", ""),
    (POINT, "mdi.axis-arrow", "Origin", ""),
    (POLYLINE, "mdi.vector-polyline", "Polyline", ""),
    (RECT_3PT, "mdi.vector-rectangle", "3-point rectangle", ""),
    (CIRCLE_2PT, "mdi.circle-outline", "2-point circle", ""),
    (CIRCLE_3PT, "mdi.circle-double", "3-point circle", ""),
    (CIRCLE_TAN, "mdi.circle-slice-8", "Tangent circle", ""),
    (ARC_TAN, "mdi.vector-curve", "Tangent arc", ""),
    (POLY_REG, "mdi.hexagon-outline", "Regular polygon", ""),
    (BSPLINE, "mdi.chart-bell-curve", "Control-point spline", ""),
    (CONIC, "mdi.vector-bezier", "Conic", ""),
]
CLICKS = {CONST_LINE: 2, POINT: 1, RECT_3PT: 3, CIRCLE_2PT: 2, CIRCLE_3PT: 3,
          POLY_REG: 2, ARC_TAN: 2, CIRCLE_TAN: 3, CONIC: 3}
#: tools that take any number of clicks (Enter / right-click ends)
VARIABLE = {POLYLINE, BSPLINE}
PROMPTS = {
    CONST_LINE: ["Click where the construction line starts (a dashed "
                 "reference: constraints use it, the solid does not).",
                 "Click where it ends."],
    POINT: ["Click where the point goes."],
    POLYLINE: ["Click points: each makes a line from the last. Enter, "
               "right-click or double-click ends; Backspace takes one "
               "back."],
    RECT_3PT: ["Click one corner.", "Click the next corner (the first "
               "side, at any angle).", "Click to set the depth."],
    CIRCLE_2PT: ["Click one end of a diameter.", "Click the other end."],
    CIRCLE_3PT: ["Click a point on the circle.", "Click a second point.",
                 "Click a third point."],
    CIRCLE_TAN: ["Click the first of three lines the circle touches.",
                 "Click the second line.", "Click the third line."],
    ARC_TAN: ["Click near the end of a line to go on from.",
              "Click where the arc ends."],
    POLY_REG: ["Click the centre.", "Click a corner."],
    BSPLINE: ["Click control points (the curve is pulled towards them). "
              "Enter, right-click or double-click ends."],
    CONIC: ["Click where the conic starts.", "Click where it ends.",
            "Click its shoulder (where the two end tangents meet)."],
}
POINT_R = 0.25
CURVE_STEPS = 24
LINE_W = 2.0


def _r(v):
    return round(v, 4)


def _band(pts, width=LINE_W):
    from .sketch_modify import _band as band
    return band(pts, width)


def _curve(pts):
    """An OPEN curve as joined arcs through its points (sketch_arc): it
    was a line-wide band polygon — a filled shape that closed nothing
    with the other edges (the user)."""
    if len(pts) < 2:
        return None
    from . import sketch_arc
    if len(pts) > 5:                       # a few arcs, not dozens
        k = len(pts) - 1
        pts = [pts[round(i * k / 4)] for i in range(5)]
    return sketch_arc.through(list(pts))


# ------------------------------------------------------------ geometry
def const_line(a, b):
    if math.dist(a, b) < st.MIN:
        return None
    return [("line", dict(x1=_r(a[0]), y1=_r(a[1]), x2=_r(b[0]),
                          y2=_r(b[1]), width=0.5, modifier="%"), None)]


#: half the length of a point's two centerlines (mm)
POINT_ARM = 10.0


def point(p, arm=POINT_ARM):
    """A point like the sketch origin (2026-11-11, the user): the point
    and two construction centerlines through it along X and Y, to snap
    to and dimension from (`origin_relations` ties them to it)."""
    x, y = _r(p[0]), _r(p[1])
    a = _r(arm)
    return [("circle", dict(x=x, y=y, radius=POINT_R, modifier="%"), None),
            ("line", dict(x1=_r(x - a), y1=y, x2=_r(x + a), y2=y,
                          width=0.5, modifier="%"), None),
            ("line", dict(x1=x, y1=_r(y - a), x2=x, y2=_r(y + a),
                          width=0.5, modifier="%"), None)]


#: on an origin's three shapes: its name ("Origin 1"), so they are found
#: together. They sit loose in the sketch, NOT in a group of their own:
#: a relation ties only shapes of one container, and a circle snapped onto
#: an origin in a group could not be tied to it (2026-11-11, the user: "if
#: it changes position I expected it to follow"). A group made before is
#: still read (`origin_parts`).
ORIGIN_KEY = "origin_point"
#: a new point's centerlines reach this far on screen each way
ARM_PX = 50


def origin_parts(node):
    """(holder, dot, x line, y line) when *node* is one of an origin's
    shapes (or an older origin group), else None. *holder* is the dot."""
    if node is None:
        return None
    label = node.params.get(ORIGIN_KEY)
    if label is True and len(node.children) == 3:       # an older group
        dot, h, v = node.children
        if dot.type == "circle" and h.type == v.type == "line":
            return node, dot, h, v
        return None
    if label is None and node.parent is not None and \
            node.parent.params.get(ORIGIN_KEY) is True:
        return origin_parts(node.parent)
    if not isinstance(label, str) or node.parent is None:
        return None
    mine = [n for n in node.parent.children
            if n.params.get(ORIGIN_KEY) == label]
    dots = [n for n in mine if n.type == "circle"]
    lines = [n for n in mine if n.type == "line"]
    if len(dots) != 1 or len(lines) != 2:
        return None

    def level(n):
        return abs(float(n.params.get("y2", 0)) -
                   float(n.params.get("y1", 0))) < \
            abs(float(n.params.get("x2", 0)) - float(n.params.get("x1", 0)))
    h = next((n for n in lines if n.name.endswith(" X")), None) or \
        next((n for n in lines if level(n)), lines[0])
    v = next(n for n in lines if n is not h)
    return dots[0], dots[0], h, v


def tree_rows(children):
    """*children* in order, an origin's three shapes gathered into one
    entry where the first of them stands: ``node`` or ``(label,
    [point, x line, y line])`` — the tree shows them under one "Origin
    n" folder row (2026-11-11, the user) while they stay loose in the
    sketch, where relations can tie a shape snapped on them."""
    out, seen = [], set()
    for c in children:
        label = c.params.get(ORIGIN_KEY)
        if isinstance(label, str):
            if label in seen:
                continue
            parts = origin_parts(c)
            if parts is not None:
                seen.add(label)
                out.append((label, list(parts[1:])))
                continue
        out.append(c)
    return out


def arm_lengths(group):
    _g, _d, h, v = origin_parts(group)

    def length(n):
        p = n.params
        return math.hypot(float(p["x2"]) - float(p["x1"]),
                          float(p["y2"]) - float(p["y1"]))
    return length(h), length(v)


def set_arms(model, group, x_len=None, y_len=None, emit=True):
    """The X and Y centerlines made *x_len* / *y_len* long, still centred
    on the point (so their relations hold)."""
    _g, dot, h, v = origin_parts(group)
    cx, cy = float(dot.params.get("x", 0)), float(dot.params.get("y", 0))
    if x_len is not None and x_len > 0:
        a = x_len / 2
        h.params.update(x1=_r(cx - a), y1=_r(cy), x2=_r(cx + a), y2=_r(cy))
        if emit:
            model.node_changed.emit(h)
    if y_len is not None and y_len > 0:
        a = y_len / 2
        v.params.update(x1=_r(cx), y1=_r(cy - a), x2=_r(cx), y2=_r(cy + a))
        if emit:
            model.node_changed.emit(v)


def origin_relations(scene, made):
    """The point and its two centerlines named "Origin n", "Origin n X",
    "Origin n Y", loose in the sketch: each line centred on the point
    (Coincident with its middle), one Horizontal, one Vertical — drag the
    point and its axes come with it; a shape drawn on them is tied."""
    from . import sketch_constraints as sc
    dot, h, v = made
    model = scene.model
    taken = {n.name for n in model.root.walk()}
    k = 1
    while "Origin %d" % k in taken:
        k += 1
    label = "Origin %d" % k
    for node, name in ((dot, label), (h, label + " X"), (v, label + " Y")):
        node.params[ORIGIN_KEY] = label
        model.rename(node, name)        # the tree shows it at once
    # the centerlines a size that reads at this zoom, not always 10 mm
    try:
        from .polygon_draw import px_to_scene
        arm = px_to_scene(scene, ARM_PX)
        if arm and arm > 0:
            set_arms(model, dot, 2 * arm, 2 * arm, emit=False)
    except Exception:
        pass
    parent = dot.parent
    for kind, refs in (
            ("coincident", [sc.ref_of(parent, dot, "c"),
                            sc.ref_of(parent, h, "m")]),
            ("coincident", [sc.ref_of(parent, dot, "c"),
                            sc.ref_of(parent, v, "m")]),
            ("horizontal", [sc.ref_of(parent, h, "l")]),
            ("vertical", [sc.ref_of(parent, v, "l")])):
        try:
            sc.add(model, parent, kind, refs)
        except (ValueError, KeyError):
            pass
    # the tree drew the three shapes before they were marked as one
    # origin: draw it again now, so the "Origin n" folder shows at once
    # (it waited for the next shape — 2026-11-11, the user)
    model.structure_changed.emit()
    return dot


def rect_3pt_corners(a, b, c):
    ux, uy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(ux, uy)
    if L < st.MIN:
        return None
    nx, ny = -uy / L, ux / L
    d = (c[0] - b[0]) * nx + (c[1] - b[1]) * ny
    if abs(d) < st.MIN:
        return None
    return [a, b, (b[0] + nx * d, b[1] + ny * d),
            (a[0] + nx * d, a[1] + ny * d)]


def rect_3pt(a, b, c):
    pts = rect_3pt_corners(a, b, c)
    return st._polygon(pts) if pts else None


def circle_2pt(a, b):
    r = math.hypot(b[0] - a[0], b[1] - a[1]) / 2
    if r < st.MIN / 2:
        return None
    return [("circle", dict(x=_r((a[0] + b[0]) / 2), y=_r((a[1] + b[1]) / 2),
                            radius=_r(r)), None)]


def circle_3pt(a, b, c):
    o = st.circumcentre(a, b, c)
    if o is None:
        return None
    return [("circle", dict(x=_r(o[0]), y=_r(o[1]),
                            radius=_r(math.hypot(a[0] - o[0],
                                                 a[1] - o[1]))), None)]


def regular_points(c, corner, sides):
    r = math.hypot(corner[0] - c[0], corner[1] - c[1])
    a0 = math.atan2(corner[1] - c[1], corner[0] - c[0])
    return [(c[0] + r * math.cos(a0 + 2 * math.pi * i / sides),
             c[1] + r * math.sin(a0 + 2 * math.pi * i / sides))
            for i in range(sides)]


def poly_reg(c, corner, sides=6):
    if math.hypot(corner[0] - c[0], corner[1] - c[1]) < st.MIN:
        return None
    return st._polygon(regular_points(c, corner, max(3, int(sides))))


def polyline(*pts):
    pts = [p for i, p in enumerate(pts) if i == 0 or p != pts[i - 1]]
    if len(pts) < 2:
        return None
    return [("line", dict(x1=_r(a[0]), y1=_r(a[1]), x2=_r(b[0]),
                          y2=_r(b[1]), width=LINE_W), None)
            for a, b in zip(pts, pts[1:])]


def bspline_points(ctrl, steps=8):
    """A closed uniform cubic B-spline of the control points."""
    n = len(ctrl)
    out = []
    for i in range(n):
        p0, p1, p2, p3 = (ctrl[(i - 1) % n], ctrl[i], ctrl[(i + 1) % n],
                          ctrl[(i + 2) % n])
        for s in range(steps):
            t = s / steps
            b0 = (1 - t) ** 3 / 6
            b1 = (3 * t ** 3 - 6 * t ** 2 + 4) / 6
            b2 = (-3 * t ** 3 + 3 * t ** 2 + 3 * t + 1) / 6
            b3 = t ** 3 / 6
            out.append(tuple(b0 * p0[k] + b1 * p1[k] + b2 * p2[k]
                             + b3 * p3[k] for k in (0, 1)))
    return out


def bspline(*pts):
    """An OPEN B-spline of the control points, as joined arcs."""
    if len(pts) < 3:
        return None
    ctrl = [pts[0], pts[0]] + list(pts) + [pts[-1], pts[-1]]
    curve = bspline_points(ctrl, 2)[2 * 2:-(2 * 2 - 1)] or list(pts)
    curve[0], curve[-1] = tuple(pts[0]), tuple(pts[-1])
    from . import sketch_arc
    return sketch_arc.through(curve)


def conic_points(a, b, shoulder, rho=0.5, steps=CURVE_STEPS):
    """A rational quadratic Bezier from a to b pulled to the shoulder:
    weight w = rho / (1 - rho) (0.5 a parabola, below an ellipse arc,
    above a hyperbola)."""
    w = rho / (1.0 - rho)
    out = []
    for i in range(steps + 1):
        t = i / steps
        k0, k1, k2 = (1 - t) ** 2, 2 * t * (1 - t) * w, t * t
        den = k0 + k1 + k2
        out.append(tuple((k0 * a[j] + k1 * shoulder[j] + k2 * b[j]) / den
                         for j in (0, 1)))
    return out


def conic(a, b, shoulder):
    if math.hypot(b[0] - a[0], b[1] - a[1]) < st.MIN:
        return None
    return _curve(conic_points(a, b, shoulder))


def tangent_arc_points(start, direction, end, steps=CURVE_STEPS):
    """The arc leaving *start* along *direction* (unit) to *end*."""
    dx, dy = end[0] - start[0], end[1] - start[1]
    nx, ny = -direction[1], direction[0]           # left normal
    chord2 = dx * dx + dy * dy
    side = dx * nx + dy * ny
    if abs(side) < 1e-9:
        return [start, end]                         # straight on
    r = chord2 / (2 * side)                         # signed radius
    c = (start[0] + nx * r, start[1] + ny * r)
    a0 = math.atan2(start[1] - c[1], start[0] - c[0])
    a1 = math.atan2(end[1] - c[1], end[0] - c[0])
    sweep = (a1 - a0) % (2 * math.pi)
    if r < 0:
        sweep -= 2 * math.pi
    R = abs(r)
    return [(c[0] + R * math.cos(a0 + sweep * i / steps),
             c[1] + R * math.sin(a0 + sweep * i / steps))
            for i in range(steps + 1)]


def _intersect(l1, l2):
    (a, b), (c, d) = l1, l2
    r = (b[0] - a[0], b[1] - a[1])
    s = (d[0] - c[0], d[1] - c[1])
    den = r[0] * s[1] - r[1] * s[0]
    if abs(den) < 1e-9:
        return None
    t = ((c[0] - a[0]) * s[1] - (c[1] - a[1]) * s[0]) / den
    return (a[0] + r[0] * t, a[1] + r[1] * t)


def incircle(l1, l2, l3):
    """(centre, radius) of the circle inside the triangle three lines
    make, or None."""
    p = [_intersect(l1, l2), _intersect(l2, l3), _intersect(l3, l1)]
    if any(q is None for q in p):
        return None
    a = math.dist(p[1], p[2])
    b = math.dist(p[2], p[0])
    c = math.dist(p[0], p[1])
    s = a + b + c
    if s < 1e-9:
        return None
    centre = ((a * p[0][0] + b * p[1][0] + c * p[2][0]) / s,
              (a * p[0][1] + b * p[1][1] + c * p[2][1]) / s)
    area = abs((p[1][0] - p[0][0]) * (p[2][1] - p[0][1])
               - (p[2][0] - p[0][0]) * (p[1][1] - p[0][1])) / 2
    return centre, 2 * area / s


# --------------------------------------- tools that need the sketch
def _line_near(scene, xy):
    """(node, its two ends) of the line nearest a scene point, or None."""
    from PyQt5.QtCore import QPointF
    from . import sketch_constrain_ui as scu
    hit = scu.pick(scene, QPointF(*xy), "line")
    if hit is None or hit[0].type != "line":
        return None
    p = hit[0].params
    return hit[0], ((p["x1"], p["y1"]), (p["x2"], p["y2"]))


def _near_hook(scene, p):
    hook = getattr(scene, "line_near", None)
    return hook(p) if hook is not None else _line_near(scene, p)


def build_tangent_arc(scene, start_click, end):
    found = _near_hook(scene, start_click)
    if found is None:
        scene.status.emit("Tangent arc: start on a line's end.")
        return None
    node, (a, b) = found
    # go on from the end nearer the click, in the line's direction
    if math.dist(start_click, a) < math.dist(start_click, b):
        a, b = b, a
    L = math.dist(a, b) or 1.0
    d = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
    pts = tangent_arc_points(b, d, end)
    from . import sketch_arc               # ONE open arc, tangent at b
    return [sketch_arc.arc_spec(
        b, end, sketch_arc.bulge_through(b, end, pts[len(pts) // 2])
        if len(pts) > 2 else 0.0)]


def build_tangent_circle(scene, c1, c2, c3):
    lines = [_near_hook(scene, c) for c in (c1, c2, c3)]
    if any(x is None for x in lines):
        scene.status.emit("Tangent circle: click three lines.")
        return None
    got = incircle(*[x[1] for x in lines])
    if got is None:
        scene.status.emit("Tangent circle: those lines make no triangle.")
        return None
    (cx, cy), r = got
    return [("circle", dict(x=_r(cx), y=_r(cy), radius=_r(r)), None)]


def tangent_to_lines(lines, clicks):
    """(centre, radius) of the circle touching three lines on the side
    the clicks are on — the perimeter circle clicked on a rectangle's
    top, bottom and end (two parallel lines are fine), or None."""
    mx = sum(p[0] for p in clicks) / 3
    my = sum(p[1] for p in clicks) / 3
    rows = []
    for (a, b), click in zip(lines, clicks):
        L = math.dist(a, b)
        if L < 1e-9:
            return None
        n = (-(b[1] - a[1]) / L, (b[0] - a[0]) / L)
        d = n[0] * a[0] + n[1] * a[1]
        # the centre lies on the side of the line the other clicks are on
        side = n[0] * mx + n[1] * my - d
        if abs(side) < 1e-9:
            side = 1.0
        s = 1.0 if side > 0 else -1.0
        rows.append((s * n[0], s * n[1], -1.0, s * d))   # s(n.c - d) = r
    (a1, b1, c1, d1), (a2, b2, c2, d2), (a3, b3, c3, d3) = rows

    def det(m):
        return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))
    A = [[a1, b1, c1], [a2, b2, c2], [a3, b3, c3]]
    D = det(A)
    if abs(D) < 1e-12:
        return None
    rhs = [d1, d2, d3]
    sol = []
    for k in range(3):
        m = [row[:] for row in A]
        for i in range(3):
            m[i][k] = rhs[i]
        sol.append(det(m) / D)
    cx, cy, r = sol
    return ((cx, cy), r) if r > 1e-9 else None


def build_perimeter(scene, a, b, c):
    """SolidWorks' Perimeter Circle: three clicks on lines (a line, or a
    rectangle's / polygon's side) make the circle TANGENT to them, with
    Tangent relations; three clicks in the open, the circle through
    them."""
    from PyQt5.QtCore import QPointF
    from . import sketch_constraints as sc
    from . import sketch_constrain_ui as scu
    hook = getattr(scene, "pick_line", None)
    hits = [hook(p) if hook is not None else
            scu.pick(scene, QPointF(*p), "line") for p in (a, b, c)]
    scene._pending_tangents = []
    if all(hits):
        try:
            segs = [sc._line(h[0], h[1], {}) for h in hits]
        except (KeyError, ValueError, IndexError):
            segs = None
        got = tangent_to_lines(segs, (a, b, c)) if segs else None
        if got is not None:
            (cx, cy), r = got
            scene._pending_tangents = [(h[0], h[1]) for h in hits]
            return [("circle", dict(x=_r(cx), y=_r(cy), radius=_r(r)),
                     None)]
    return circle_3pt(a, b, c)


def build_poly_reg(scene, c, corner):
    hook = getattr(scene, "ask_value", None)
    if hook is not None:
        text = hook(POLY_REG, 6)
    else:
        from PyQt5.QtWidgets import QInputDialog
        views = scene.views()
        n, ok = QInputDialog.getInt(views[0] if views else None,
                                    "Regular polygon", "Sides:", 6, 3, 64)
        if not ok:
            return None
        text = n
    try:
        sides = int(float(text))
    except (TypeError, ValueError):
        sides = 6
    scene._pending_regular = (float(c[0]), float(c[1]))
    return poly_reg(c, corner, sides)


def regular_relations(scene, node, centre):
    """What keeps a regular polygon REGULAR, as SolidWorks' Polygon: a
    construction circle through its corners (each corner On it) and
    every side Equal — so one Smart Dimension (a side, or the circle's
    diameter) sizes all of it and its centre is a point to tie
    (2026-11-10: a side dimensioned 15 moved that one side alone and
    left nine freedoms). Returns the circle."""
    from . import sketch_constraints as sc
    parent = node.parent
    pts = node.params.get("points") or []
    if parent is None or len(pts) < 3:
        return None
    ox = float(node.params.get("x", 0) or 0)
    oy = float(node.params.get("y", 0) or 0)
    r = math.hypot(float(pts[0][0]) + ox - centre[0],
                   float(pts[0][1]) + oy - centre[1])
    circle = scene.model.add_node("circle", dict(
        x=_r(centre[0]), y=_r(centre[1]), radius=_r(r), modifier="%"),
        parent=parent, name="Polygon circle")
    made = getattr(scene, "made", None)
    if isinstance(made, list):
        made.append(circle)
    rows = [("point_on", [sc.ref_of(parent, node, "v%d" % i),
                          sc.ref_of(parent, circle, "o")])
            for i in range(len(pts))]
    rows += [("equal", [sc.ref_of(parent, node, "e%d" % i),
                        sc.ref_of(parent, node, "e%d" % (i + 1))])
             for i in range(len(pts) - 1)]
    for kind, refs in rows:
        try:
            sc.add(scene.model, parent, kind, refs)
        except (ValueError, KeyError):
            pass
    return circle


BUILD = {CONST_LINE: const_line, POINT: point, RECT_3PT: rect_3pt, CIRCLE_2PT: circle_2pt,
         CIRCLE_3PT: circle_3pt, POLYLINE: polyline, BSPLINE: bspline,
         CONIC: conic}
#: builders that need the scene (lines to pick, a value to ask)
BUILD_SCENE = {ARC_TAN: build_tangent_arc, CIRCLE_TAN: build_tangent_circle,
               POLY_REG: build_poly_reg, CIRCLE_3PT: build_perimeter}


def outline(tool, pts):
    """The rubber band while placing (None: not one of ours)."""
    if tool not in CLICKS and tool not in VARIABLE:
        return None
    if tool == BSPLINE:
        return bspline_points(pts) if len(pts) >= 3 else list(pts)
    if tool in (POLYLINE, CONST_LINE):
        return list(pts)
    if len(pts) < 2:
        return list(pts)
    if tool == RECT_3PT:
        return (rect_3pt_corners(*pts[:3]) if len(pts) >= 3 else None) \
            or list(pts)
    if tool == CIRCLE_2PT:
        a, b = pts[0], pts[1]
        c = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        r = math.dist(a, b) / 2
        return [(c[0] + r * math.cos(2 * math.pi * i / 48),
                 c[1] + r * math.sin(2 * math.pi * i / 48))
                for i in range(48)]
    if tool == CIRCLE_3PT:
        # no circle until the third click (the user): picked on lines it
        # is the TANGENT circle, which a through-the-points preview is not
        return []
    if tool == POLY_REG:
        return regular_points(pts[0], pts[1], 6)
    if tool == CONIC and len(pts) >= 3:
        return conic_points(pts[0], pts[1], pts[2])
    return list(pts)


# ------------------------------------------------------ construction
def toggle_construction(model, nodes):
    """Construction on / off for the selected 2D shapes (OpenSCAD's
    `%`: shown, never part of the solid). Returns how many changed."""
    from .model import SHAPE_2D
    shapes = [n for n in nodes if n.category == SHAPE_2D]
    if not shapes:
        return 0
    on = not all(n.params.get("modifier") == "%" for n in shapes)
    for n in shapes:
        model.set_modifier(n, "%" if on else "")
    return len(shapes)


def is_construction(node):
    return node.params.get("modifier") == "%"


# ------------------------------------------------- joining the tables
def register():
    st.TOOLS.extend(TOOLS)
    st.CLICKS.update(CLICKS)
    st.PROMPTS.update(PROMPTS)
    st.BUILD.update(BUILD)


register()


TIPS = {
    CONSTRUCTION: (
        "Construction",
        "Turns the selected sketch shapes into construction geometry and "
        "back: drawn dashed, used by constraints and dimensions, never "
        "part of the solid (OpenSCAD's % modifier).",
        ["Select sketch shapes.", "Click Construction."], None),
}


PICK_CONSTRUCTION = "sk_construction"


def construction_press(scene, event):
    """The click tool: the shape under the click switches construction
    on / off."""
    from PyQt5.QtCore import Qt
    from . import sketch_constrain_ui as scu
    event.accept()
    if event.button() != Qt.LeftButton:
        return
    hit = scu.pick(scene, event.scenePos())
    if hit is None:
        scene.status.emit("Construction: click a sketch shape.")
        return
    node = hit[0]
    toggle_construction(scene.model, [node])
    scene.status.emit("%s is %s." % (node.name, "construction now"
                                     if is_construction(node)
                                     else "solid again"))


def construction_action(win):
    act = getattr(win, "_construction_act", None)
    if act is not None:
        return act
    from PyQt5.QtWidgets import QAction
    from . import icons, language, toolbars, tooltips
    tooltips.TIPS.update(TIPS)
    act = QAction(icons.icon("mdi.vector-line", icons.family_color("draw")),
                  language.tr("Construction"), win)
    act.setData(CONSTRUCTION)
    toolbars.remember_glyph(act, "mdi.vector-line", "draw")
    tooltips.apply(act, CONSTRUCTION)

    def run():
        n = toggle_construction(
            win.model, win.builder.active_tree().selected_nodes())
        if n:
            win.statusBar().showMessage(language.tr(
                "Construction switched on {n} shape(s).").format(n=n), 5000)
            return
        # nothing selected: a click tool — each shape clicked switches
        # (the user: "when I click on it, nothing happened")
        win._set_tool(PICK_CONSTRUCTION)
        msg = language.tr("Construction: click the sketch shapes to "
                          "switch (dashed = construction, left out of the "
                          "solid). Esc when done.")
        win.statusBar().showMessage(msg, 8000)
        flash = getattr(win.view2d, "flash", None) or \
            getattr(win.view3d, "flash", None)
        if flash is not None:
            try:
                flash(msg)
            except Exception:
                pass
    act.triggered.connect(lambda _=False: run())
    win._construction_act = act
    return act


# ------------------------------------------- picking lines, seen
#: tools whose clicks land on lines: the line under the mouse lights up,
#: a clicked one stays lit until the shape is made (the user: "I should
#: be able to select the line itself")
LINE_PICKERS = (CIRCLE_3PT, CIRCLE_TAN, ARC_TAN)


def _line_item(scene, pos, width):
    from PyQt5.QtCore import QLineF, QPointF
    from PyQt5.QtGui import QColor, QPen
    from PyQt5.QtWidgets import QGraphicsLineItem
    from . import sketch_constraints as sc
    from . import sketch_constrain_ui as scu
    hit = scu.pick(scene, pos, "line")
    if hit is None:
        return None
    node, name, _kind = hit
    try:
        a, b = sc._line(node, name, {})
    except (KeyError, ValueError, IndexError):
        return None
    frame = next((it.parentItem() for it in scu._shape_items(scene)
                  if it.node is node), None)
    item = QGraphicsLineItem(QLineF(QPointF(*a), QPointF(*b)), frame)
    if frame is None:
        scene.addItem(item)
    pen = QPen(QColor(255, 140, 0))
    pen.setCosmetic(True)
    pen.setWidthF(width)
    item.setPen(pen)
    item.setZValue(60)
    return item


def _remove(item):
    if item is not None and item.scene() is not None:
        item.scene().removeItem(item)


def hover(scene, pos):
    """Light the line under the mouse."""
    _remove(getattr(scene, "_line_hover", None))
    scene._line_hover = _line_item(scene, pos, 3.0) \
        if scene.tool in LINE_PICKERS else None


def mark(scene, pos):
    """Keep a clicked line lit."""
    if scene.tool not in LINE_PICKERS:
        return
    item = _line_item(scene, pos, 4.0)
    if item is not None:
        scene.__dict__.setdefault("_line_marks", []).append(item)


def clear_marks(scene):
    _remove(getattr(scene, "_line_hover", None))
    scene._line_hover = None
    for item in getattr(scene, "_line_marks", []):
        _remove(item)
    scene._line_marks = []
