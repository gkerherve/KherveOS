# KherveCAD - easy CAD GUI on the OpenSCAD engine.
# Copyright (C) 2026 Gwilherm Kerherve. GPL-3.0-or-later; see LICENSE.
"""Feature dimensions on the 3D view, as SolidWorks shows a Boss-Extrude's
depth or a Revolve's angle beside the sketch's Smart Dimensions
(2026-11-10, the user: "a dimension that comes from a linear extrude ...
from a rotation extrude").

A selected Linear extrude shows its Distance (and Distance 2 when it goes
both ways) as a dimension along its axis at the profile's side; a
selected Rotate extrude shows its angle as an arc round its axis. A click
on the number types a new value (dim_link's editor: Enter keeps it, a
click on another dimension meanwhile links to it). While any dimension is
being typed, every feature in view shows its dimensions so they can be
clicked to link. A value driven by an expression reads "Σ 10", as
SolidWorks marks an equation.

`dimensions(window)` -> [(node, key, label, world points)] is what is
drawn; `paint` draws it and fills `window._feature_dim_hits` [(rect,
node, key)]; `press` / `release` open the editor."""

import math

FEATURES = ("linear_extrude", "rotate_extrude")
INK = "#6a1b9a"                 # set apart from the sketch's blue
#: the dimension line stands this far out from the profile, of its size
GAP = 0.18
#: params key: the depth was placed as a Smart Dimension and stays shown
PLACED = "depth_dim"
#: params key: where the depth's dimension line stands, [dx, dy] mm in
#: the extrude's own frame from the profile's corner (dragged there)
AT = "depth_dim_at"
#: pixels a press must move to be a drag, not a click
DRAG_PX = 4


def _env(window):
    from .anchors import doc_env
    return doc_env(window.model)


def _num(node, key, env, default):
    from . import expr
    try:
        return float(expr.resolve(node.params.get(key, default), env,
                                  default))
    except (TypeError, ValueError):
        return default


def _features_of(node):
    """The extrudes / revolves a selected node stands for: itself, or the
    ones a sketch Group or a wrapper holds directly."""
    if node.type in FEATURES:
        return [node]
    out = []
    stack = list(node.children)
    while stack:
        n = stack.pop()
        if n.type in FEATURES:
            out.append(n)
            continue
        if n.category != "2d" and n.children:
            stack.extend(n.children)
    return out


def shown_features(window):
    """The features whose dimensions are drawn now."""
    model = window.model
    scope = window._render_scope()[0]
    editing = getattr(window.view3d, "_dim3d_editor", None) is not None
    if editing:
        # typing a value: every feature in view can be clicked to link
        return [n for n in scope.walk() if n.type in FEATURES
                and n.visible]
    out = []
    for nid in getattr(window, "_selected_ids", ()) or ():
        node = model.find(nid)
        if node is None:
            continue
        for f in _features_of(node):
            if f not in out:
                out.append(f)
    # depths PLACED with Smart Dimension stay on the model like a
    # sketch's dimensions (the user: "I never can make it a smart
    # dimension"), until the Smart Dimensions switch hides them
    try:
        from . import sketch_dims3d
        main = sketch_dims3d.assembly_mode(window)
    except Exception:
        main = False
    if not main and getattr(window.scene, "show_sketch_dims", True):
        for n in scope.walk():
            if n.type == "linear_extrude" and n.params.get(PLACED) and \
                    n.visible and n not in out:
                out.append(n)
    # a Smart Dimension started from the Extrude window: that extrude's
    # depth is clickable beside the sketch's sizes
    drag = getattr(window, "_drag_paused", None)
    ext = drag.target() if drag is not None else None
    if ext is not None and ext.type in FEATURES and ext not in out:
        out.append(ext)
    return out[:12]


def extrude_of(cont):
    """The Linear extrude a sketch container belongs to: itself, or the
    nearest one above it (a Regions / a sketch Group sits inside it)."""
    node = cont
    while node is not None:
        if node.type == "linear_extrude":
            return node
        node = node.parent
    return None


def edit_depth(window, node, x, y):
    """Open the depth editor of *node* at screen point (x, y) — what a
    Smart Dimension click on a face lying flat to the sketch means."""
    from PyQt5.QtCore import QRectF
    window.view3d.flash(
        "That face is the extrude's end: its distance is the feature's "
        "depth. Type it here (Enter keeps it).", 6000)
    return edit(window, QRectF(x - 30, y - 10, 60, 20), node, "height")


def _depth_span(node, env):
    """(z0, z1) the extrude reaches along its own axis."""
    h = _num(node, "height", env, 10.0)
    if node.params.get("center"):
        return -h / 2.0, h / 2.0
    return -max(0.0, _num(node, "height2", env, 0.0)), h


def depth_at(window, desc):
    """The Linear extrude whose depth a 3D pick shows (2026-11-16, the
    user: Smart Dimension on a finished extrusion did nothing): a face
    that is one of its END caps, or an edge running along its axis
    within its profile. *desc* is View3D._pick_at's. None when none."""
    import numpy as np
    if not desc:
        return None
    env = _env(window)
    scope = window._render_scope()[0]
    found = None
    for node in scope.walk():
        if node.type != "linear_extrude" or not node.visible or \
                node.params.get("suppressed"):
            continue
        box = _box(node, env)
        if box is None:
            continue
        try:
            m = np.array(_frame(window, node, own=True), float)
            inv = np.linalg.inv(m)
        except Exception:
            continue
        x0, y0, x1, y1 = box
        z0, z1 = _depth_span(node, env)
        size = max(x1 - x0, y1 - y0, abs(z1 - z0), 1e-3)
        tol = max(0.02, 0.003 * size)

        def local(p):
            return inv[:3, :3] @ np.asarray(p, float) + inv[:3, 3]

        def inside(q):
            return (x0 - tol <= q[0] <= x1 + tol and
                    y0 - tol <= q[1] <= y1 + tol)
        if desc.get("kind") == "face" and desc.get("dir") is not None:
            q = local(desc["pos"])
            n = inv[:3, :3] @ np.asarray(desc["dir"], float)
            ln = np.linalg.norm(n)
            if ln < 1e-12 or abs(n[2]) / ln < 0.99 or not inside(q):
                continue
            if min(abs(q[2] - z0), abs(q[2] - z1)) <= tol:
                found = node                 # a later feature wins
        elif desc.get("kind") == "edge" and desc.get("seg"):
            a, b = (local(p) for p in desc["seg"])
            d = b - a
            L = np.linalg.norm(d)
            if L < 1e-9 or abs(d[2]) / L < 0.99:
                continue
            if inside(a) and inside(b) and \
                    min(a[2], b[2]) >= z0 - tol and \
                    max(a[2], b[2]) <= z1 + tol:
                found = node
    return found


def depth_ends(window, node):
    """World points (start, end) of *node*'s depth at its profile's side
    — what a Smart Dimension of it measures; None without a profile."""
    from . import mesh
    env = _env(window)
    box = _box(node, env)
    if box is None:
        return None
    m = _frame(window, node, own=True)
    z0, z1 = _depth_span(node, env)
    if not node.params.get("center"):
        z0 = 0.0                         # Distance, not Distance 2
    x1, y0 = box[2], box[1]
    return (mesh.mat_apply(m, (x1, y0, z0)), mesh.mat_apply(m, (x1, y0, z1)))


def on_sketch_plane(window, node, desc):
    """True when the picked face is the extrude's START cap, where its
    sketch lies (a click there may mean the sketch's own shapes)."""
    import numpy as np
    if not desc or desc.get("kind") != "face":
        return False
    try:
        inv = np.linalg.inv(np.array(_frame(window, node, own=True), float))
    except Exception:
        return False
    q = inv[:3, :3] @ np.asarray(desc["pos"], float) + inv[:3, 3]
    box = _box(node, _env(window)) or (0, 0, 1, 1)
    size = max(box[2] - box[0], box[3] - box[1], 1e-3)
    return abs(q[2]) <= max(0.02, 0.003 * size)


def double_click(window, pos):
    """A double-click on an extrusion's end face or height edge in 3D
    selects the feature and opens its depth box (SolidWorks shows a
    feature's dimensions on a double-click). True when used."""
    view = window.view3d
    try:
        desc, _key = view._pick_at(pos.x(), pos.y())
    except Exception:
        return False
    node = depth_at(window, desc)
    if node is None:
        return False
    try:
        window.builder.active_tree().select_nodes([node])
    except Exception:
        pass
    edit_depth(window, node, pos.x(), pos.y())
    return True


def _frame(window, node, own):
    """Matrix from *node*'s frame (with its own transform when *own*) to
    the world the view draws."""
    from . import mesh
    scope = window._render_scope()[0]
    iso = scope if scope is not window.model.root else None
    env = _env(window)
    with window._isolated_frame(iso):
        m = mesh.ancestor_matrix(node, env, stop=iso)
        if own:
            m = mesh.mat_mul(m, mesh.node_matrix(node, env))
    return m


def _box(node, env):
    from . import mesh
    pts = [p for loop in mesh.collect_outlines(node, env) for p in loop]
    if not pts:
        return None
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def text(node, key, value):
    from . import units
    raw = node.params.get(key)
    try:
        dec = units.DIM_DECIMALS
    except AttributeError:
        dec = 2
    shown = ("%.*f" % (dec, value)).rstrip("0").rstrip(".")
    if key == "angle":
        shown += "°"
    if isinstance(raw, str):
        try:
            float(raw)
        except ValueError:
            shown = "Σ " + shown         # driven by an expression
    return shown


def dimensions(window):
    """[(node, key, label, kind, points)]: *kind* "linear" with points
    (a0, a1, d0, d1) — the two ends on the part and on the dimension line
    — or "angle" with the arc's points."""
    from . import mesh
    env = _env(window)
    out = []
    for node in shown_features(window):
        box = _box(node, env)
        if box is None:
            continue
        x0, y0, x1, y1 = box
        size = max(x1 - x0, y1 - y0, 1e-3)
        if node.type == "linear_extrude":
            m = _frame(window, node, own=True)
            h = _num(node, "height", env, 10.0)
            h2 = _num(node, "height2", env, 0.0)
            centre = bool(node.params.get("center"))
            at = node.params.get(AT)
            try:
                dx, dy = float(at[0]), float(at[1])
            except (TypeError, ValueError, IndexError):
                dx, dy = GAP * size, 0.0      # beside the profile

            def run(za, zb):
                return [mesh.mat_apply(m, p) for p in (
                    (x1, y0, za), (x1, y0, zb), (x1 + dx, y0 + dy, za),
                    (x1 + dx, y0 + dy, zb))]
            if centre:
                out.append((node, "height", text(node, "height", h),
                            "linear", run(-h / 2.0, h / 2.0)))
            else:
                out.append((node, "height", text(node, "height", h),
                            "linear", run(0.0, h)))
                if h2 > 1e-9:
                    out.append((node, "height2", text(node, "height2", h2),
                                "linear", run(-h2, 0.0)))
        else:
            # the revolve turns its profile (x the radius, y along the
            # axis) about its parent's Z
            m = _frame(window, node, own=False)
            a = _num(node, "angle", env, 360.0)
            r = max(abs(x0), abs(x1)) * (1.0 + GAP)
            z = (y0 + y1) / 2.0
            steps = max(8, int(abs(a) / 6))
            arc = [mesh.mat_apply(m, (r * math.cos(math.radians(a * i / steps)),
                                      r * math.sin(math.radians(a * i / steps)),
                                      z)) for i in range(steps + 1)]
            out.append((node, "angle", text(node, "angle", a), "angle", arc))
    return out


def paint(window, painter, project):
    from PyQt5.QtCore import QPointF, QRectF, Qt
    from PyQt5.QtGui import QBrush, QColor, QFont, QPen, QPolygonF
    window._feature_dim_hits = []
    window._feature_dim_jac = {}
    if not getattr(window.scene, "show_sketch_dims", True):
        return
    try:
        dims = dimensions(window)
    except Exception:                         # never break the paint
        import traceback
        traceback.print_exc()
        return
    if not dims:
        return
    ink = QColor(INK)
    pen = QPen(ink, 1.4)
    pen.setCosmetic(True)
    thin = QPen(ink, 1.0, Qt.DashLine)
    thin.setCosmetic(True)
    font = QFont(painter.font())
    font.setBold(True)
    font.setPointSize(max(8, font.pointSize()))
    painter.save()
    painter.setRenderHint(painter.Antialiasing, True)
    painter.setFont(font)
    fm = painter.fontMetrics()

    def scr(p):
        q = project(p)
        return None if q is None else QPointF(q[0], q[1])

    def arrow(tip, frm):
        dx, dy = tip.x() - frm.x(), tip.y() - frm.y()
        L = math.hypot(dx, dy) or 1.0
        ux, uy = dx / L, dy / L
        base = QPointF(tip.x() - ux * 8, tip.y() - uy * 8)
        painter.setBrush(QBrush(ink))
        painter.drawPolygon(QPolygonF([
            tip, QPointF(base.x() - uy * 3.5, base.y() + ux * 3.5),
            QPointF(base.x() + uy * 3.5, base.y() - ux * 3.5)]))
        painter.setBrush(Qt.NoBrush)

    for node, key, label, kind, pts in dims:
        q = [scr(p) for p in pts]
        if kind == "linear" and any(p is None for p in q):
            continue
        if kind != "linear":
            q = [p for p in q if p is not None]   # the part in view
            if len(q) < 2:
                continue
        if kind == "linear":
            a0, a1, d0, d1 = q
            painter.setPen(thin)
            painter.drawLine(a0, d0)
            painter.drawLine(a1, d1)
            painter.setPen(pen)
            painter.drawLine(d0, d1)
            arrow(d0, d1)
            arrow(d1, d0)
            at = QPointF((d0.x() + d1.x()) / 2, (d0.y() + d1.y()) / 2)
        else:
            painter.setPen(pen)
            for p, r in zip(q, q[1:]):
                painter.drawLine(p, r)
            if len(q) > 1:
                arrow(q[-1], q[-2])
            at = q[len(q) // 2]
        tw = fm.horizontalAdvance(label)
        rect = QRectF(at.x() - tw / 2 - 5, at.y() - fm.height() / 2 - 2,
                      tw + 10, fm.height() + 4)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(255, 255, 255, 235)))
        painter.drawRoundedRect(rect, 4, 4)
        painter.setPen(QPen(ink, 1.0))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(rect, 4, 4)
        painter.drawText(rect, int(Qt.AlignCenter), label)
        window._feature_dim_hits.append((QRectF(rect), node, key))
        if kind == "linear" and node.type == "linear_extrude":
            try:
                window._feature_dim_jac[(id(node), key)] = _jacobian(
                    window, node, project)
            except Exception:
                pass
    painter.restore()


def hit(window, pos):
    for rect, node, key in getattr(window, "_feature_dim_hits", []):
        if rect.adjusted(-3, -3, 3, 3).contains(pos.x(), pos.y()):
            return rect, node, key
    return None


def _jacobian(window, node, project):
    """Screen pixels per mm of the extrude's own +x and +y, at its
    profile — how a drag on screen moves the dimension line."""
    from . import mesh
    m = _frame(window, node, own=True)
    o = project(mesh.mat_apply(m, (0.0, 0.0, 0.0)))
    ex = project(mesh.mat_apply(m, (1.0, 0.0, 0.0)))
    ey = project(mesh.mat_apply(m, (0.0, 1.0, 0.0)))
    if o is None or ex is None or ey is None:
        return None
    return ((ex[0] - o[0], ex[1] - o[1]), (ey[0] - o[0], ey[1] - o[1]))


def press(window, pos):
    got = hit(window, pos)
    if got is None:
        return False
    window._feature_dim_press = got
    window._feature_dim_drag = dict(start=pos, moved=False)
    return True


def _current_at(node, window):
    at = node.params.get(AT)
    try:
        return float(at[0]), float(at[1])
    except (TypeError, ValueError, IndexError):
        box = _box(node, _env(window)) or (0, 0, 1, 1)
        return GAP * max(box[2] - box[0], box[3] - box[1], 1e-3), 0.0


def move(window, pos):
    """A press on a depth's number that MOVES: the dimension line follows
    the cursor (the user: "move them just like a smart dimension")."""
    got = getattr(window, "_feature_dim_press", None)
    d = getattr(window, "_feature_dim_drag", None)
    if got is None or d is None:
        return False
    _rect, node, key = got
    if node.type != "linear_extrude":
        return True
    dx, dy = pos.x() - d["start"].x(), pos.y() - d["start"].y()
    if not d["moved"] and (dx * dx + dy * dy) ** 0.5 < DRAG_PX:
        return True
    jac = getattr(window, "_feature_dim_jac", {}).get((id(node), key))
    if not jac:
        return True
    from .sketch_dims3d import _to_local
    local = _to_local(jac, dx, dy)
    if local is None:
        return True
    if not d["moved"]:
        d["moved"] = True
        d["at"] = _current_at(node, window)
        d["orig"] = node.params.get(AT)
    node.params[AT] = [round(d["at"][0] + local[0], 3),
                       round(d["at"][1] + local[1], 3)]
    window.view3d.update()
    return True


def release(window, pos):
    got = getattr(window, "_feature_dim_press", None)
    if got is None:
        return False
    window._feature_dim_press = None
    d = getattr(window, "_feature_dim_drag", None)
    window._feature_dim_drag = None
    if d is not None and d.get("moved"):
        node = got[1]
        new = list(node.params[AT])
        if d.get("orig") is None:            # set_param sees the change
            node.params.pop(AT, None)
        else:
            node.params[AT] = d["orig"]
        window.model.set_param(node, AT, new)           # one undo step
        return True
    edit(window, *got)
    return True


def edit(window, rect, node, key):
    """Type a new depth / angle on the model."""
    from . import dim_link
    from .sketch_constrain_ui import _value
    raw = node.params.get(key, "")

    def commit(typed):
        value = _value(typed)
        window.model.set_param(node, key, value)
    return dim_link.open_editor(window, rect, str(raw), commit,
                                ("feature", node, key))
