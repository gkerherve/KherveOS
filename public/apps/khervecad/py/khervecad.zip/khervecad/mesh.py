"""Built-in tessellator — triangle meshes for the 3D preview.

OpenSCAD is the real engine: when its binary is available the 3D view
shows the exact mesh OpenSCAD renders. This module is the fallback
(and the instant preview): it turns the object tree into triangles in
pure Python, evaluating expressions and unrolling loops/conditionals
like OpenSCAD would. difference / intersection / minkowski are cut
exactly through Manifold (csg.py) when manifold3d is installed, else
they show their first operand and the OpenSCAD engine renders them.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import math
import re
from collections import OrderedDict
from pathlib import Path

from . import expr
from .model import SHAPE_2D, CadNode, keeps_segments
from . import organic

#: a mesh is a list of triangles; a triangle is 3 (x, y, z) tuples.

#: params that stay strings (never resolved to numbers).
_TEXT_PARAMS = {"text", "path", "variable", "condition", "update",
                "values", "value", "caps", "axis", "toward",
                "material", "bindings", "args", "message", "file",
                "layer", "id", "font", "halign", "valign", "direction",
                "modifier", "options", "description", "group",
                "collection", "library", "library_part", "cad_source"}

#: ops the fallback can only approximate (engine renders exactly).
APPROXIMATED = {"difference", "intersection", "minkowski", "hull",
                "offset", "fillet",     # a fillet cuts convex edges
                "intersection_for",     # drawn as its first iteration
                "scad_raw"}             # only OpenSCAD can draw it

_stl_cache = {}
#: how many parsed mesh files stl_mesh keeps
STL_CACHE_FILES = 8

#: when set (int), primitive/revolve segment counts and extrude slices
#: are capped to this — used for the fast, low-detail 2D silhouette.
_DETAIL = None


def _cap(n) -> int:
    return min(int(n), _DETAIL) if _DETAIL else int(n)


def rv(value, env=None, default=0.0) -> float:
    """Resolve a param that may be a number or an expression."""
    return expr.resolve(value, env, default)


#: round object types whose segment count the document-wide $fn
#: override replaces (linear_extrude's "segments" means slices, so it
#: is deliberately excluded).
_FN_TYPES = {"circle", "cylinder", "sphere", "rotate_extrude",
             "capsule", "ellipsoid", "rounded_box"}
_FN_OVERRIDE = None

#: {str(node id): node} for Linked-copy references + cycle-guard stack;
#: set by the tessellate entry points.
_REF_INDEX = None
_REF_STACK = set()


def rp(node: CadNode, env=None) -> dict:
    """Node params with every numeric/expression value resolved."""
    out = {}
    for key, value in node.params.items():
        if key in _TEXT_PARAMS:
            out[key] = value
        elif isinstance(value, bool):
            out[key] = value
        elif isinstance(value, list):
            # a list param is normally polygon points — but not always
            # (an Object's "anchors" is a list of dicts), and unpacking
            # one of those raised ValueError straight through a Qt slot,
            # which PyQt turns into abort(): the whole app died
            if all(isinstance(pt, (list, tuple)) and len(pt) == 2
                   for pt in value):
                out[key] = [[rv(x, env), rv(y, env)] for x, y in value]
            else:
                out[key] = value
        else:
            out[key] = rv(value, env)
    # the codegen's rule (model._fn): a hex prism stays a hex
    if _FN_OVERRIDE is not None and node.type in _FN_TYPES and \
            not keeps_segments(out.get("segments")):
        out["segments"] = _FN_OVERRIDE
    return out


# ------------------------------------------------------------- matrices

def mat_identity():
    return [[1.0 if i == j else 0.0 for j in range(4)] for i in range(4)]


def ancestor_matrix(node, env=None, stop=None):
    """The 4x4 transform mapping *node*'s own coordinates to the frame
    of *stop* (the document root when None): the product of its
    ancestors' translate / rotate / scale / mirror and Group / Object /
    instance placements, exactly as the tessellator applies them.
    Expressions resolve with *env*."""
    chain = []
    probe = node.parent
    while probe is not None and probe is not stop:
        chain.append(probe)
        probe = probe.parent
    m = mat_identity()
    for anc in reversed(chain):
        m = mat_mul(m, node_matrix(anc, env))
    return m


def node_matrix(node, env=None):
    """The transform *node* applies to what it holds: a translate /
    rotate / scale / mirror, or a Group / Object / instance placement
    (translate · rotate); the identity for anything else."""
    env = env or {}

    def num(key, default=0.0):
        return rv(node.params.get(key, default), env, default)
    t = node.type
    if t == "translate":
        return mat_translate(num("x"), num("y"), num("z"))
    if t == "rotate":
        return mat_rotate(num("x"), num("y"), num("z"))
    if t == "scale":
        return mat_scale(num("x", 1.0), num("y", 1.0), num("z", 1.0))
    if t == "mirror":
        return mat_mirror(num("x", 1.0), num("y"), num("z"))
    if t in ("union", "component", "reference"):
        return mat_mul(mat_translate(num("x"), num("y"), num("z")),
                       mat_rotate(num("rx"), num("ry"), num("rz")))
    if t == "joint":
        # kcad_joint: translate(pivot) rotate(a) translate(-pivot)
        px, py, pz = num("px"), num("py"), num("pz")
        return mat_mul(mat_translate(px, py, pz), mat_mul(
            mat_rotate(num("rx"), num("ry"), num("rz")),
            mat_translate(-px, -py, -pz)))
    return mat_identity()


def mat_apply(m, p):
    """*p* (x, y, z) through the 4x4 *m*."""
    return [m[i][0] * p[0] + m[i][1] * p[1] + m[i][2] * p[2] + m[i][3]
            for i in range(3)]


def mat_apply_dir(m, d):
    return [m[i][0] * d[0] + m[i][1] * d[1] + m[i][2] * d[2]
            for i in range(3)]


def mat_mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(4)) for j in range(4)]
            for i in range(4)]


def mat_translate(x, y, z):
    m = mat_identity()
    m[0][3], m[1][3], m[2][3] = x, y, z
    return m


def mat_scale(x, y, z):
    m = mat_identity()
    m[0][0], m[1][1], m[2][2] = x, y, z
    return m


def mat_rotate(ax, ay, az):
    """Rotation like OpenSCAD rotate([ax, ay, az]) — X then Y then Z."""
    rx, ry, rz = (math.radians(v) for v in (ax, ay, az))
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    mx = [[1, 0, 0, 0], [0, cx, -sx, 0], [0, sx, cx, 0], [0, 0, 0, 1]]
    my = [[cy, 0, sy, 0], [0, 1, 0, 0], [-sy, 0, cy, 0], [0, 0, 0, 1]]
    mz = [[cz, -sz, 0, 0], [sz, cz, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
    return mat_mul(mz, mat_mul(my, mx))


def mat_mirror(nx, ny, nz):
    length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    nx, ny, nz = nx / length, ny / length, nz / length
    m = mat_identity()
    axes = (nx, ny, nz)
    for i in range(3):
        for j in range(3):
            m[i][j] = (1.0 if i == j else 0.0) - 2 * axes[i] * axes[j]
    return m


def transform_point(m, p):
    x, y, z = p
    return (m[0][0] * x + m[0][1] * y + m[0][2] * z + m[0][3],
            m[1][0] * x + m[1][1] * y + m[1][2] * z + m[1][3],
            m[2][0] * x + m[2][1] * y + m[2][2] * z + m[2][3])


def flips_winding(m) -> bool:
    """True when *m* mirrors: its triangles come out wound the other
    way and have to be turned back, or normals would point inward."""
    return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
            - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
            + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])) < 0


def transform_mesh(m, mesh):
    """*mesh* through *m*. The arithmetic is spelled out over the whole
    list rather than called per point: this is the hot loop of every
    redraw (a moving assembly transforms its entire mesh each frame),
    and a call plus twelve index chains per vertex cost more than the
    nine multiplications they carry."""
    (a, b, c, d), (e, f, g, h), (i, j, k, n) = m[0], m[1], m[2]
    if flips_winding(m):
        return [((a * x2 + b * y2 + c * z2 + d, e * x2 + f * y2 + g * z2 + h,
                  i * x2 + j * y2 + k * z2 + n),
                 (a * x1 + b * y1 + c * z1 + d, e * x1 + f * y1 + g * z1 + h,
                  i * x1 + j * y1 + k * z1 + n),
                 (a * x0 + b * y0 + c * z0 + d, e * x0 + f * y0 + g * z0 + h,
                  i * x0 + j * y0 + k * z0 + n))
                for (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) in mesh]
    return [((a * x0 + b * y0 + c * z0 + d, e * x0 + f * y0 + g * z0 + h,
              i * x0 + j * y0 + k * z0 + n),
             (a * x1 + b * y1 + c * z1 + d, e * x1 + f * y1 + g * z1 + h,
              i * x1 + j * y1 + k * z1 + n),
             (a * x2 + b * y2 + c * z2 + d, e * x2 + f * y2 + g * z2 + h,
              i * x2 + j * y2 + k * z2 + n))
            for (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) in mesh]


# --------------------------------------------------------- 2D outlines

def polygon_area(points) -> float:
    total = 0.0
    for i, (x1, y1) in enumerate(points):
        x2, y2 = points[(i + 1) % len(points)]
        total += x1 * y2 - x2 * y1
    return total / 2.0


def ensure_ccw(points):
    return points if polygon_area(points) >= 0 else points[::-1]


def triangulate(points):
    """Ear-clipping triangulation of a simple polygon (2D)."""
    pts = ensure_ccw([tuple(p) for p in points])
    if len(pts) < 3:
        return []
    indices = list(range(len(pts)))
    triangles = []
    guard = 0
    while len(indices) > 3 and guard < 10000:
        guard += 1
        ear_found = False
        for k in range(len(indices)):
            i0 = indices[k - 1]
            i1 = indices[k]
            i2 = indices[(k + 1) % len(indices)]
            a, b, c = pts[i0], pts[i1], pts[i2]
            cross = ((b[0] - a[0]) * (c[1] - a[1])
                     - (b[1] - a[1]) * (c[0] - a[0]))
            if cross <= 1e-12:
                continue                     # reflex corner
            # a bridged hole visits its cut's two ends twice: those
            # copies sit on the ear's corners, not inside it
            if any(_point_in_tri(pts[j], a, b, c)
                   for j in indices
                   if j not in (i0, i1, i2)
                   and pts[j] not in (a, b, c)):
                continue
            triangles.append((i0, i1, i2))
            del indices[k]
            ear_found = True
            break
        if not ear_found:                    # degenerate: fan fallback
            break
    if len(indices) == 3:
        triangles.append(tuple(indices))
    elif len(indices) > 3:                   # non-simple polygon: fan
        for k in range(1, len(indices) - 1):
            triangles.append((indices[0], indices[k], indices[k + 1]))
    return [(pts[i], pts[j], pts[k]) for i, j, k in triangles]


def _point_in_tri(p, a, b, c):
    def sign(p1, p2, p3):
        return ((p1[0] - p3[0]) * (p2[1] - p3[1])
                - (p2[0] - p3[0]) * (p1[1] - p3[1]))
    d1, d2, d3 = sign(p, a, b), sign(p, b, c), sign(p, c, a)
    has_neg = min(d1, d2, d3) < -1e-12
    has_pos = max(d1, d2, d3) > 1e-12
    return not (has_neg and has_pos)


def convex_hull_2d(points):
    """Andrew's monotone chain — hull of 2D points, CCW."""
    pts = sorted(set((round(x, 9), round(y, 9)) for x, y in points))
    if len(pts) <= 2:
        return list(pts)

    def cross(o, a, b):
        return ((a[0] - o[0]) * (b[1] - o[1])
                - (a[1] - o[1]) * (b[0] - o[0]))
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def offset_outline(points, r):
    """Naive polygon offset for the preview: push each vertex along
    its angle-bisector normal. OpenSCAD's offset() is exact."""
    pts = ensure_ccw(points)
    n = len(pts)
    if n < 3 or not r:
        return list(pts)
    out = []
    for i in range(n):
        px, py = pts[i - 1]
        cx, cy = pts[i]
        nx_, ny_ = pts[(i + 1) % n]
        # edge normals (outward for CCW)
        e1 = (cy - py, px - cx)
        e2 = (ny_ - cy, cx - nx_)
        l1 = math.hypot(*e1) or 1.0
        l2 = math.hypot(*e2) or 1.0
        bx = e1[0] / l1 + e2[0] / l2
        by = e1[1] / l1 + e2[1] / l2
        lb = math.hypot(bx, by)
        if lb < 1e-9:
            out.append((cx, cy))
            continue
        # scale so edges shift by exactly r
        dot = (e1[0] / l1 * bx + e1[1] / l1 * by) / lb
        scale = r / max(dot, 0.1)
        out.append((cx + bx / lb * scale, cy + by / lb * scale))
    return out


def node_outlines(node: CadNode, env=None):
    """Closed CCW outlines (lists of (x, y)) for a 2D shape node."""
    p = rp(node, env)
    if node.type == "rect":
        x, y, w, h = p["x"], p["y"], p["width"], p["height"]
        return [[(x, y), (x + w, y), (x + w, y + h), (x, y + h)]]
    if node.type == "circle":
        angle = p.get("angle", 360.0)
        arc = [(p["x"] + ax, p["y"] + ay)
               for ax, ay in node.arc_points(env)]
        if angle >= 360.0:
            return [arc[:-1]]                # closed ring, drop repeat
        return [[(p["x"], p["y"])] + arc]    # pie slice with centre
    if node.type == "polygon":
        pts = [(p["x"] + x, p["y"] + y) for x, y in p["points"]]
        paths = polygon_paths(node)
        if paths:
            return [[pts[i] for i in path if 0 <= i < len(pts)]
                    for path in paths]
        return [pts]
    if node.type == "line":
        return [_capsule(p["x1"], p["y1"], p["x2"], p["y2"],
                         p["width"] / 2.0)]
    if node.type == "text":
        return _text_outlines(p)
    if node.type == "import_2d":
        from . import scadfiles
        return scadfiles.drawing_outlines(node, env)
    if node.type in organic.features.SHAPES_2D:
        return organic.features.outlines(node, env)
    return []


def polygon_paths(node):
    """A polygon's OpenSCAD paths as lists of whole point indices, or []
    when it has none (all points, in order)."""
    out = []
    for row in node.params.get("paths") or []:
        if not isinstance(row, (list, tuple)):
            continue
        indices = []
        for value in row:
            try:
                indices.append(int(float(value)))
            except (TypeError, ValueError):
                pass
        if len(indices) >= 3:
            out.append(indices)
    return out


def _capsule(x1, y1, x2, y2, r):
    """Rounded-cap stroke outline, matching the hull-of-circles codegen."""
    angle = math.atan2(y2 - y1, x2 - x1)
    steps = 12
    points = []
    for i in range(steps + 1):               # cap around p2
        a = angle - math.pi / 2 + math.pi * i / steps
        points.append((x2 + r * math.cos(a), y2 + r * math.sin(a)))
    for i in range(steps + 1):               # cap around p1
        a = angle + math.pi / 2 + math.pi * i / steps
        points.append((x1 + r * math.cos(a), y1 + r * math.sin(a)))
    return points


def _text_outlines(p):
    """Glyph outlines via Qt (preview only; OpenSCAD renders exactly).

    Rendered at a fixed, generously large reference point size and
    scaled down geometrically — at the sub-millimetre sizes a molecule
    label or a "+" between reaction terms uses, `QFont` clamps/hints
    the glyph outline at tiny point sizes and distorts it.

    `path.simplified()` is deliberately NOT used: some glyphs ("+",
    "=", ...) are built from several separate SAME-winding, OVERLAPPING
    strokes (e.g. a horizontal bar and a vertical bar) rather than one
    outer contour with nested holes. `simplified()` resolves overlaps
    with the path's fill rule, which treats a doubly-covered region as
    OUTSIDE (even crossing count) — it does not union them, so a "+"
    came back as four separate arms with the centre square missing.
    The raw (un-simplified) subpaths are each simple, well-formed
    glyph-component contours by construction; `_oriented()`'s own
    nesting-depth test already tells a real hole (a contour's first
    point lies inside another, like the counter of an "O") from a
    same-depth overlapping stroke (a "+"'s bars, neither containing
    the other's corner points) and extrudes/unions them accordingly.
    """
    try:
        path, scale = text_path(p)
    except ImportError:                      # pragma: no cover
        return []
    outlines = []
    for poly in path.toSubpathPolygons():
        pts = [(p["x"] + pt.x() * scale, p["y"] - pt.y() * scale)
               for pt in poly]
        if len(pts) >= 3:
            outlines.append(pts)
    return outlines


#: the font a text uses when it names none (Qt's metrics stand in for
#: OpenSCAD's Liberation Sans)
DEFAULT_FONT = "DejaVu Sans"
#: glyphs are laid out at this point size and scaled (see _text_outlines)
TEXT_REF_SIZE = 100.0


def text_font(p):
    """The QFont for a text node's params at TEXT_REF_SIZE: OpenSCAD's
    ``"Family:style=Bold Italic"`` read into family, weight and slant,
    and ``spacing`` as letter spacing."""
    from PyQt5.QtGui import QFont
    spec = str(p.get("font") or "").strip()
    family, _, style = spec.partition(":")
    style = style.lower()
    font = QFont(family.strip() or DEFAULT_FONT)
    font.setPointSizeF(TEXT_REF_SIZE)
    if "bold" in style or "black" in style or "heavy" in style:
        font.setBold(True)
    if "italic" in style or "oblique" in style:
        font.setItalic(True)
    try:
        spacing = float(p.get("spacing", 1.0) or 1.0)
    except (TypeError, ValueError):
        spacing = 1.0
    if abs(spacing - 1.0) > 1e-9:
        font.setLetterSpacing(QFont.PercentageSpacing, spacing * 100.0)
    return font


def text_path(p):
    """(QPainterPath at TEXT_REF_SIZE in Qt's y-down frame, scale to the
    node's size) with OpenSCAD's halign / valign / direction applied:
    the path's origin is where the text node's x, y sits."""
    from PyQt5.QtGui import QFontMetricsF, QPainterPath
    size = max(float(p["size"]), 1e-6)
    font = text_font(p)
    metrics = QFontMetricsF(font)
    text = str(p["text"])
    direction = str(p.get("direction") or "ltr")
    path = QPainterPath()
    if direction in ("ttb", "btt"):
        chars = list(text) if direction == "ttb" else list(reversed(text))
        line = metrics.height()
        widest = max((metrics.horizontalAdvance(c) for c in chars),
                     default=0.0)
        for k, ch in enumerate(chars):
            path.addText(-metrics.horizontalAdvance(ch) / 2, k * line,
                         font, ch)
        left, advance = -widest / 2, widest
    else:
        if direction == "rtl":
            text = text[::-1]
        path.addText(0, 0, font, text)
        left, advance = 0.0, metrics.horizontalAdvance(text)
    halign = str(p.get("halign") or "left")
    dx = {"center": -(left + advance / 2),
          "right": -(left + advance)}.get(halign, -left if left else 0.0)
    box = path.boundingRect()               # ink, y down
    valign = str(p.get("valign") or "baseline")
    if valign == "top":
        dy = -box.top()
    elif valign == "bottom":
        dy = -box.bottom()
    elif valign == "center":
        dy = -box.center().y()
    else:
        dy = 0.0
    if dx or dy:
        path.translate(dx, dy)
    return path, size / TEXT_REF_SIZE


def collect_outlines(node: CadNode, env=None):
    """All outlines of the visible 2D content in *node*'s subtree,
    with loops unrolled, conditionals evaluated and offset/hull
    applied (approximately)."""
    env = dict(env or {})
    outlines = []
    if not node.visible:
        return outlines
    if node.category == SHAPE_2D:
        outlines.extend(_oriented(node, node_outlines(node, env)))
    if node.type == "offset":
        child_outlines = _children_outlines(node, env)
        r = rv(node.params["radius"], env)
        return [_offset_keeping(o, r) for o in child_outlines]
    if node.type == "difference":
        return _difference_outlines(node, env)
    if node.type == "hull":
        pts = [pt for o in _children_outlines(node, env) for pt in o]
        hull = convex_hull_2d(pts)
        return [hull] if len(hull) >= 3 else []
    if node.type in ("for_loop", "while_loop"):
        var = str(node.params.get("variable", "i")) or "i"
        for value in node.loop_values(env):
            scoped = dict(env)
            scoped[var] = value
            outlines.extend(_children_outlines(node, scoped))
        return outlines
    if node.type == "if_else":
        branch = _if_branch(node, env)
        for child in branch:
            outlines.extend(collect_outlines(child, env))
        return outlines
    if node.type == "pattern":
        from . import pattern
        return pattern.outlines(node, env)
    if node.type in _SCADLANG_OUTLINES:
        from . import scadlang
        return scadlang.outlines(node, env)
    if node.type in _TRANSFORMS_2D:
        return _transformed_outlines(node, env)
    outlines.extend(_children_outlines(node, env))
    return outlines


#: OpenSCAD statements whose 2D outlines scadlang works out
_SCADLANG_OUTLINES = {"resize", "multmatrix", "render", "intersection_for",
                      "let", "echo", "assert", "scad_use"}

#: transforms a 2D outline passes through on its way into an extrusion
_TRANSFORMS_2D = ("translate", "rotate", "scale", "mirror")
#: 3D transform node -> the matrix it applies (x, y, z)
_TRANSFORM_MATS = dict(translate=mat_translate, rotate=mat_rotate,
                       scale=mat_scale, mirror=mat_mirror)


def _transformed_outlines(node, env):
    """The children's outlines mapped through the transform's 2D part.

    Without it every translate, rotate, scale and mirror between an
    extrude and its 2D shapes was dropped in the preview: a card's index
    turned half round for the opposite corner was drawn back on top of
    the first one, a scaled pip stayed a dot, and a translate only
    survived where the importer had folded it into the shape's own x/y.
    Inner transforms apply first, as the recursion returns; a mirror (or
    a negative scale) reverses each outline so its winding holds."""
    def val(key, default):
        try:
            return float(rv(node.params.get(key, default), env, default))
        except (TypeError, ValueError):
            return default
    if node.type == "translate":
        m = mat_translate(val("x", 0.0), val("y", 0.0), val("z", 0.0))
    elif node.type == "rotate":
        m = mat_rotate(val("x", 0.0), val("y", 0.0), val("z", 0.0))
    elif node.type == "scale":
        m = mat_scale(val("x", 1.0), val("y", 1.0), val("z", 1.0))
    else:
        m = mat_mirror(val("x", 1.0), val("y", 0.0), val("z", 0.0))
    out = [[(m[0][0] * x + m[0][1] * y + m[0][3],
             m[1][0] * x + m[1][1] * y + m[1][3]) for x, y in outline]
           for outline in _children_outlines(node, env)]
    if m[0][0] * m[1][1] - m[0][1] * m[1][0] < 0:
        out = [list(reversed(outline)) for outline in out]
    return out


# 2D content reaches an extrusion as SOLIDS (counter-clockwise outlines)
# and HOLES (clockwise), the way OpenSCAD's own polygons carry holes: a
# glyph's counter (the inside of an O) and the shapes a 2D difference
# takes away are holes, which the extruders cut out of the solid around
# them. Before, every outline was extruded as a solid of its own: an O
# came out filled and a pot drawn as outline-minus-inset was a block.

def _inside(pt, loop):
    """Even-odd point-in-polygon."""
    x, y = pt
    inside = False
    for (x1, y1), (x2, y2) in zip(loop, loop[1:] + loop[:1]):
        if (y1 > y) != (y2 > y) and \
                x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
            inside = not inside
    return inside


def _centroid2d(loop):
    return (sum(x for x, _ in loop) / len(loop),
            sum(y for _, y in loop) / len(loop))


def _oriented(node, outlines):
    """A 2D shape's outlines as solids (counter-clockwise) — and, for
    text, the loops nested inside a glyph as holes (clockwise)."""
    loops = [o for o in (_distinct(o) for o in outlines) if len(o) >= 3]
    if node.type not in ("text", "import_2d") and \
            node.type not in organic.features.NESTED_2D and not (
            node.type == "polygon" and polygon_paths(node)):
        return [ensure_ccw(o) for o in loops]
    out = []
    for i, loop in enumerate(loops):
        depth = sum(1 for j, other in enumerate(loops)
                    if j != i and _inside(loop[0], other))
        ccw = ensure_ccw(loop)
        out.append(ccw if depth % 2 == 0 else ccw[::-1])
    return out


def _distinct(outline):
    """The loop without repeated points: a glyph's outline closes by
    repeating its first point, and that zero-length edge stalled the
    ear clipper on a bridged hole, whose fan fallback then covered the
    counter of an O."""
    out = []
    for p in outline:
        p = tuple(p)
        if not out or abs(p[0] - out[-1][0]) > 1e-9 or \
                abs(p[1] - out[-1][1]) > 1e-9:
            out.append(p)
    while len(out) > 1 and abs(out[0][0] - out[-1][0]) <= 1e-9 and \
            abs(out[0][1] - out[-1][1]) <= 1e-9:
        out.pop()
    return out


def _offset_keeping(outline, r):
    """Offset that grows a solid and shrinks a hole alike."""
    if polygon_area(outline) >= 0:
        return offset_outline(outline, r)
    return offset_outline(ensure_ccw(outline), -r)[::-1]


def _difference_outlines(node, env):
    """A 2D difference: the first shape's outlines, then every other
    shape's turned round, so its solids become holes. A hole inside a
    solid is cut out of it exactly (a pot wall, a washer, a frame); a
    subtraction across an edge is approximated."""
    env = dict(env)
    out, first = [], True
    for child in node.children:
        if child.type == "assign":
            _apply_assign(child, env)
            continue
        loops = collect_outlines(child, env)
        if first:
            out.extend(loops)
            first = False
        else:
            out.extend(list(reversed(o)) for o in loops)
    return out


def outline_regions(loops):
    """[(solid, [holes inside it])]: each hole goes to the smallest solid
    that holds it; a hole inside no solid takes nothing away."""
    regions = [(o, []) for o in loops if polygon_area(o) >= 0]
    for hole in (o for o in loops if polygon_area(o) < 0):
        probe = _centroid2d(hole)
        best, best_area = None, None
        for index, (solid, _holes) in enumerate(regions):
            if _inside(probe, solid) or _inside(hole[0], solid):
                area = polygon_area(solid)
                if best is None or area < best_area:
                    best, best_area = index, area
        if best is not None:
            regions[best][1].append(hole)
    return regions


def _caps(solid, holes):
    """Cap triangles (counter-clockwise) of a solid less its holes. Each
    hole is bridged into the outline and the result ear-clipped, so the
    cap uses only the outline's own vertices and meets the walls edge
    for edge (a trapezoid sweep split the edges and left the solid
    unsealed for the print check); the sweep remains the fallback."""
    if not holes:
        return triangulate(solid)
    merged = _bridge_holes(solid, holes)
    if merged is None:
        from .cutaway import fill
        return fill([solid] + holes)
    return triangulate(merged)


def _bridge_holes(solid, holes):
    """One polygon walking *solid* (CCW) and every hole (CW), each hole
    joined by a two-way cut from its rightmost vertex to the nearest
    outline vertex it can see, rightmost holes first (Eberly's order);
    None when a hole sees nothing."""
    outer = [tuple(p) for p in solid]
    rest = sorted(([tuple(p) for p in h] for h in holes),
                  key=lambda h: -max(p[0] for p in h))
    while rest:
        hole = rest.pop(0)
        j = max(range(len(hole)), key=lambda k: hole[k][0])
        m = hole[j]
        walls = _loop_edges(outer) + [e for h in rest
                                      for e in _loop_edges(h)] \
            + _loop_edges(hole)
        best = None
        for i, v in enumerate(outer):
            if v[0] < m[0] - 1e-9 or v == m:
                continue
            d = (v[0] - m[0]) ** 2 + (v[1] - m[1]) ** 2
            if best is not None and d >= best[0]:
                continue
            if not _sees(m, v, walls):
                continue
            mid = ((m[0] + v[0]) / 2, (m[1] + v[1]) / 2)
            if not _inside(mid, outer) or \
                    any(_inside(mid, h) for h in rest):
                continue
            best = (d, i)
        if best is None:
            return None
        i = best[1]
        outer = outer[:i + 1] + hole[j:] + hole[:j + 1] + outer[i:]
    return outer


def _loop_edges(loop):
    return list(zip(loop, loop[1:] + loop[:1]))


def _sees(m, v, walls):
    """True when the segment m-v crosses no wall (touching at m or v is
    allowed: those are the bridge's own ends)."""
    for a, b in walls:
        if a in (m, v) or b in (m, v):
            continue
        if _segments_cross(m, v, a, b):
            return False
    return True


def _segments_cross(p, q, a, b):
    def side(o, s, t):
        return (s[0] - o[0]) * (t[1] - o[1]) - (s[1] - o[1]) * (t[0] - o[0])
    d1, d2 = side(a, b, p), side(a, b, q)
    d3, d4 = side(p, q, a), side(p, q, b)
    eps = 1e-12
    if ((d1 > eps and d2 < -eps) or (d1 < -eps and d2 > eps)) and \
            ((d3 > eps and d4 < -eps) or (d3 < -eps and d4 > eps)):
        return True
    # a wall vertex lying on the bridge blocks it too
    for o, s, t, d in ((p, q, a, d3), (p, q, b, d4)):
        if abs(d) <= eps and min(o[0], s[0]) - eps <= t[0] <= \
                max(o[0], s[0]) + eps and min(o[1], s[1]) - eps <= t[1] \
                <= max(o[1], s[1]) + eps:
            return True
    return False


def _children_outlines(node, env):
    outlines = []
    env = dict(env)
    for child in node.children:
        if child.type == "assign":
            _apply_assign(child, env)
        else:
            outlines.extend(collect_outlines(child, env))
    return outlines


def _apply_assign(node, env):
    var = str(node.params.get("variable", "")).strip()
    if var:
        try:
            env[var] = expr.evaluate(node.params.get("value", 0), env)
        except expr.ExprError:
            pass


def _if_branch(node, env):
    """Children of the branch an if/else takes under *env*."""
    else_node = next((c for c in node.children
                      if c.type == "union"
                      and c.name.lower().startswith("else")), None)
    then_nodes = [c for c in node.children if c is not else_node]
    try:
        take_then = bool(expr.evaluate(node.params["condition"], env))
    except expr.ExprError:
        take_then = True
    if take_then:
        return then_nodes
    return list(else_node.children) if else_node is not None else []


# ----------------------------------------------------------- primitives

def cube_mesh(p):
    w, d, h = p["width"], p["depth"], p["height"]
    ox = -w / 2 if p["center"] else 0.0
    oy = -d / 2 if p["center"] else 0.0
    oz = -h / 2 if p["center"] else 0.0
    x0, y0, z0 = p["x"] + ox, p["y"] + oy, p["z"] + oz
    x1, y1, z1 = x0 + w, y0 + d, z0 + h
    v = [(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
         (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]
    quads = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
             (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    mesh = []
    for a, b, c, d_ in quads:
        mesh.append((v[a], v[b], v[c]))
        mesh.append((v[a], v[c], v[d_]))
    return mesh


def sphere_mesh(p):
    r = p["radius"]
    n = max(_cap(p["segments"]), 4)
    rings = max(n // 2, 3)
    cx, cy, cz = p["x"], p["y"], p["z"]

    def vert(i, j):
        theta = math.pi * i / rings
        phi = 2 * math.pi * j / n
        return (cx + r * math.sin(theta) * math.cos(phi),
                cy + r * math.sin(theta) * math.sin(phi),
                cz + r * math.cos(theta))
    mesh = []
    for i in range(rings):
        for j in range(n):
            a = vert(i, j)
            b = vert(i + 1, j)
            c = vert(i + 1, j + 1)
            d = vert(i, j + 1)
            if i > 0:
                mesh.append((a, b, d))
            if i < rings - 1:
                mesh.append((b, c, d))
    return mesh


def cylinder_mesh(p):
    n = max(_cap(p["segments"]), 3)
    h = p["height"]
    r1, r2 = p["radius_bottom"], p["radius_top"]
    cx, cy = p["x"], p["y"]
    z0 = p["z"] - (h / 2 if p["center"] else 0.0)
    z1 = z0 + h
    bottom = [(cx + r1 * math.cos(2 * math.pi * i / n),
               cy + r1 * math.sin(2 * math.pi * i / n), z0)
              for i in range(n)]
    top = [(cx + r2 * math.cos(2 * math.pi * i / n),
            cy + r2 * math.sin(2 * math.pi * i / n), z1)
           for i in range(n)]
    mesh = []
    for i in range(n):
        j = (i + 1) % n
        mesh.append((bottom[i], bottom[j], top[j]))
        mesh.append((bottom[i], top[j], top[i]))
    center_b = (cx, cy, z0)
    center_t = (cx, cy, z1)
    for i in range(n):
        j = (i + 1) % n
        if r1 > 0:
            mesh.append((center_b, bottom[j], bottom[i]))
        if r2 > 0:
            mesh.append((center_t, top[i], top[j]))
    return mesh


def stl_mesh(p):
    """Triangles of an imported mesh (STL/OBJ/OFF/3MF) placed like
    OpenSCAD's translate() rotate() scale() import(). The parsed files
    are cached by path + mtime — several of them: with a one-file cache
    a document holding two imports re-read both on every redraw."""
    path = str(p.get("path", "")).strip()
    if not path or not Path(path).exists():
        return []
    try:
        key = (path, Path(path).stat().st_mtime)
        mesh = _stl_cache.pop(key, None)
        if mesh is None:
            from .engine import parse_mesh
            mesh = parse_mesh(path)
        _stl_cache[key] = mesh               # most recently used last
        while len(_stl_cache) > STL_CACHE_FILES:
            del _stl_cache[next(iter(_stl_cache))]
    except Exception:
        return []
    s = p.get("scale", 1.0)
    m = mat_mul(mat_translate(p["x"], p["y"], p["z"]),
                mat_mul(mat_rotate(p.get("rx", 0.0), p.get("ry", 0.0),
                                   p.get("rz", 0.0)),
                        mat_scale(s, s, s)))
    return transform_mesh(m, mesh)


# ----------------------------------------------------------- extrusions

def linear_extrude_mesh(node: CadNode, env=None):
    p = rp(node, env)
    height = p["height"]
    twist = p.get("twist", 0.0)
    scale_top = p.get("scale", 1.0)
    z0 = -height / 2 if p.get("center") else 0.0
    slices = max(int(p.get("segments") or 0), 1)
    if twist and slices == 1:
        slices = max(int(abs(twist) / 6), 8)
    # keep the instant preview light for heavy twists (threads);
    # the OpenSCAD engine renders the exact slice count.
    slices = min(slices, 120)
    if _DETAIL:
        slices = min(slices, _DETAIL)
    mesh = []
    loops = [o for o in collect_outlines(node, env) if len(o) >= 3]
    for solid, holes in outline_regions(loops):
        # a hole twists and scales with its solid (about the same centre)
        cx, cy = _centroid2d(solid)

        def ring(loop, f):
            """A loop at fraction f of the height (twist about origin,
            scale about the solid's centroid, like OpenSCAD)."""
            angle = -math.radians(twist) * f
            s = 1.0 + (scale_top - 1.0) * f
            cos_a, sin_a = math.cos(angle), math.sin(angle)
            pts = []
            for x, y in loop:
                sx = cx + (x - cx) * s
                sy = cy + (y - cy) * s
                pts.append((sx * cos_a - sy * sin_a,
                            sx * sin_a + sy * cos_a,
                            z0 + height * f))
            return pts
        tops = []
        for loop in [solid] + holes:
            # walls follow the loop's own direction: a hole's face inward
            rings = [ring(loop, i / slices) for i in range(slices + 1)]
            tops.append([(x, y) for x, y, _ in rings[-1]])
            n = len(loop)
            for k in range(slices):
                lower, upper = rings[k], rings[k + 1]
                for i in range(n):
                    j = (i + 1) % n
                    mesh.append((lower[i], lower[j], upper[j]))
                    mesh.append((lower[i], upper[j], upper[i]))
        for a, b, c in _caps(solid, holes):  # bottom cap faces down
            mesh.append(((a[0], a[1], z0), (c[0], c[1], z0),
                         (b[0], b[1], z0)))
        if scale_top > 0:
            z = z0 + height
            for a, b, c in _caps(tops[0], tops[1:]):
                mesh.append(((a[0], a[1], z), (b[0], b[1], z),
                             (c[0], c[1], z)))
    return mesh


def rotate_extrude_mesh(node: CadNode, env=None):
    p = rp(node, env)
    angle = min(max(p.get("angle", 360.0), 0.01), 360.0)
    n = max(_cap(p.get("segments", 96)), 3)
    steps = max(int(n * angle / 360.0), 2)
    full = angle >= 360.0
    mesh = []
    loops = [o for o in collect_outlines(node, env) if len(o) >= 3]
    for solid, holes in outline_regions(loops):
        profiles = [[(max(x, 0.0), y) for x, y in loop]
                    for loop in [solid] + holes]
        for profile in profiles:
            # a hole's loop runs the other way round: its surface faces in
            def ring(step, profile=profile):
                a = math.radians(angle) * step / steps
                cos_a, sin_a = math.cos(a), math.sin(a)
                return [(x * cos_a, x * sin_a, y) for x, y in profile]
            rings = [ring(s) for s in range(steps + 1)]
            if full:
                # sin(2π) is -2.4e-16, not 0: the last ring must BE the
                # first, or the seam stays open by a hair and the edge
                # lines draw it across every flat floor
                rings[-1] = rings[0]
            m = len(profile)
            for s in range(steps):
                r0, r1 = rings[s], rings[s + 1]
                for i in range(m):
                    j = (i + 1) % m
                    mesh.append((r0[i], r1[i], r1[j]))
                    mesh.append((r0[i], r1[j], r0[j]))
        if not full:                          # end caps
            caps = _caps(profiles[0], profiles[1:])
            for a, b, c in caps:
                mesh.append(((a[0], 0.0, a[1]), (c[0], 0.0, c[1]),
                             (b[0], 0.0, b[1])))
            last = math.radians(angle)
            cos_a, sin_a = math.cos(last), math.sin(last)
            for a, b, c in caps:
                mesh.append(((a[0] * cos_a, a[0] * sin_a, a[1]),
                             (b[0] * cos_a, b[0] * sin_a, b[1]),
                             (c[0] * cos_a, c[0] * sin_a, c[1])))
    return mesh


def flat_mesh(node: CadNode, env=None):
    """Un-extruded 2D shape shown as a flat face at z = 0."""
    mesh = []
    for outline in node_outlines(node, env):
        mesh.extend((
            (a[0], a[1], 0.0), (b[0], b[1], 0.0), (c[0], c[1], 0.0))
            for a, b, c in triangulate(outline))
    return mesh


# ------------------------------------------------- per-Object mesh cache

#: {component node id: (content key, local [(tri, color, False)])} —
#: an Object's tessellation in its LOCAL frame, reused as long as its
#: contents are unchanged. Moving/rotating/recolouring an Object (or
#: anything else in the assembly) then costs one matrix transform
#: instead of a full re-tessellation, which is what keeps assembly
#: drags snappy.
_COMP_CACHE = {}
_COMP_CACHE_MAX = 128

#: cache hit/miss counters (tests and profiling).
CACHE_STATS = {"hits": 0, "misses": 0}

#: the Object's own params that do NOT affect its local mesh.
_PLACEMENT_KEYS = ("x", "y", "z", "rx", "ry", "rz", "color", "alpha",
                   "mate", "anchors")


#: {content key: triangles} — OpenSCAD's EXACT local mesh for a part,
#: rendered one part at a time in the background. An assembly is parts
#: placed next to each other, not booleaned together, so each part can
#: be rendered on its own and the assembly assembled from the results:
#: booleans are really cut (bolt holes appear), per-part colours
#: survive (an STL of the whole document could only carry one), and a
#: part is re-rendered only when its own contents change — moving,
#: snapping or colouring it costs nothing.
#: Least-recently-used, bounded by triangles rather than by parts: it
#: used to hold 64 parts and CLEAR ITSELF on the 65th, so a document of
#: more than 64 exact parts re-rendered them one by one for ever (each
#: arrival wiped the others, which were then queued again).
_EXACT = OrderedDict()
_EXACT_MAX_TRIS = 8_000_000
_exact_tris = 0


def clear_component_cache():
    _COMP_CACHE.clear()


def exact_key(node, env=None, fn=None):
    """The content key an exact mesh for *node* would be stored under,
    or None when the subtree cannot be keyed (it pulls in a Linked copy
    whose master lives outside it).

    *fn* must be the same segment count the preview tessellates with —
    it is part of the key, so computing it outside a tessellation
    (where the global override is unset) would produce a key the
    lookup never matches, and every part would render for nothing."""
    global _DETAIL
    saved_detail = _DETAIL
    _DETAIL = None
    _set_fn(fn)
    try:
        return _component_key(node, dict(env or {}))
    finally:
        _set_fn(None)
        _DETAIL = saved_detail


def set_exact_mesh(key, tris):
    """Store OpenSCAD's exact mesh for one part. A late result is
    harmless: the key is the part's *content*, so a mesh for an old
    version simply lands under a key nothing asks for."""
    global _exact_tris
    if not key:
        return
    old = _EXACT.pop(key, None)
    if old is not None:
        _exact_tris -= len(old)
    # evict the least recently used parts, never the whole cache
    while _EXACT and _exact_tris + len(tris) > _EXACT_MAX_TRIS:
        _k, dropped = _EXACT.popitem(last=False)
        _exact_tris -= len(dropped)
    _EXACT[key] = tris
    _exact_tris += len(tris)
    # the local (approximate) tessellation of that part is now stale
    for node_id, cached in list(_COMP_CACHE.items()):
        if cached[0] == key:
            del _COMP_CACHE[node_id]


def has_exact_mesh(key) -> bool:
    if not key or key not in _EXACT:
        return False
    _EXACT.move_to_end(key)          # still on screen: evict it last
    return True


def clear_exact_meshes():
    global _exact_tris
    _EXACT.clear()
    _exact_tris = 0
    _COMP_CACHE.clear()


def _expr_strings(value, out):
    """Append every string inside *value* to *out*: only a string can
    name a variable (a number, or a row of numbers, cannot). Iterative
    and on exact types: a polyhedron's points are hundreds of thousands
    of numbers to step over, and a call apiece cost more than the walk."""
    stack = [value]
    while stack:
        item = stack.pop()
        kind = type(item)
        if kind is str:
            out.append(item)
        elif kind is list or kind is tuple:
            stack.extend(item)


def _component_key(node, env):
    """Content key of an Object's subtree: anything that could change
    the local mesh — child types/params/visibility, the environment,
    the $fn override, the detail cap, mesh-file mtimes. Returns None
    when the subtree cannot be cached (it pulls in a Linked copy whose
    master lives outside the subtree)."""
    parts = []
    exprs = []                  # only what can hold a variable's name
    walk = [node]
    while walk:
        n = walk.pop()
        if n.type == "reference":
            return None                     # master may change unseen
        parts.append(n.type)
        # the Object's own visibility is not content: _tess gates on it
        # before the cache, and the isolated view force-shows hidden
        # Objects — either way the local mesh is the same
        parts.append("1" if (n.visible or n is node) else "0")
        for key in sorted(n.params):
            if n is node and key in _PLACEMENT_KEYS:
                continue
            parts.append(f"{key}={n.params[key]!r}")
            _expr_strings(n.params[key], exprs)
        if n.type == "stl_import":
            from pathlib import Path
            try:
                parts.append(str(Path(str(n.params.get(
                    "path", ""))).stat().st_mtime_ns))
            except OSError:
                parts.append("?")
        parts.append(";")
        walk.extend(n.children)
    if any("$t" in p for p in parts):
        # an animated part is a different mesh at every moment
        parts.append(f"$t={expr.SPECIAL_DEFAULTS.get('$t', 0)!r}")
    if env:
        # only the variables the part READS: a slider moving one variable
        # (a motor angle) must not rebuild — or re-render in OpenSCAD —
        # every part of the document. Scan the EXPRESSIONS only, never
        # the whole key: param names and node types are words too, and
        # a circle's `angle=` made every part inside a loop over a
        # variable called `angle` depend on it (an orrery's moons then
        # re-tessellated on every tick). It is also far less text — a
        # polyhedron's points are numbers, and they are most of the key.
        used = set(re.findall(r"\$?[A-Za-z_]\w*", "\x00".join(exprs)))
        parts.append(repr(sorted(
            (k, float(v) if isinstance(v, (int, float))
             and not isinstance(v, bool) else v)
            for k, v in env.items() if k in used)))
    parts.append(str(_FN_OVERRIDE))
    parts.append(str(_DETAIL))
    return "\x00".join(parts)


def part_colours(node, env=None) -> set:
    """The colours painted inside a part (its visible `color` nodes, as
    the preview's colour tuples) — what decides whether OpenSCAD's
    colourless STL can stand in for it: with one it is tinted, with
    several it would paint them all one colour."""
    out = set()
    for n in node.walk():
        if n is node or not n.visible:
            continue
        if n.type in ("component", "reference"):
            # a nested Object or instance may wear its own colour: an
            # assembly of a red base and a white lid, each one scad_raw,
            # was rendered as ONE colourless STL that hid both
            own = str(n.params.get("color", "")).strip()
            if own:
                out.add((own, rv(n.params.get("alpha", 1.0), env, 1.0)))
            continue
        if n.type != "color":
            continue
        colour = (str(n.params.get("color", "#4a90d9")),
                  rv(n.params.get("alpha", 1.0), env, 1.0))
        material = str(n.params.get("material") or "Default")
        if material != "Default":
            colour += (material,)
        out.add(colour)
    return out


def needs_exact(node, env=None) -> bool:
    """Whether an exact OpenSCAD render of this part is worth asking
    for: only when the preview cannot show it right (a boolean, hull,
    offset, fillet...) and the part is of one colour at most. A part of
    plain solids is already exact in the preview, and swapping in a
    second triangulation of the same surface is what caused the
    preview's glitches."""
    return approximates(node) and len(part_colours(node, env)) <= 1


def _component_mesh(node, env, color, sel, selected):
    """The component branch of _tess with a two-level cache:

    1. the LOCAL mesh, invalidated only when the Object's contents
       change (placement and colour are excluded from the key);
    2. the PLACED mesh (local × placement, colours applied), reused
       while the placement/colour stay put — so re-tessellating the
       assembly after a drag re-transforms only the dragged Object
       and every other one is a dictionary lookup.

    Selection passes bypass the cache (per-triangle flags)."""
    group_color = color
    col = str(node.params.get("color", "")).strip()
    if col:
        group_color = (col, rv(node.params.get("alpha", 1.0), env, 1.0))
    rx = rv(node.params.get("rx", 0), env, 0.0)
    ry = rv(node.params.get("ry", 0), env, 0.0)
    rz = rv(node.params.get("rz", 0), env, 0.0)
    tx = rv(node.params.get("x", 0), env, 0.0)
    ty = rv(node.params.get("y", 0), env, 0.0)
    tz = rv(node.params.get("z", 0), env, 0.0)
    moved = any((rx, ry, rz, tx, ty, tz))

    if sel:
        # highlight pass: rare, needs true per-triangle selection flags
        out = _children_mesh(node, env, group_color, sel, selected)
        if moved:
            out = _transform_colored(
                mat_mul(mat_translate(tx, ty, tz),
                        mat_rotate(rx, ry, rz)), out)
        return out

    key = _component_key(node, env)
    placed_key = (key, (tx, ty, tz, rx, ry, rz), group_color)
    # one slot per Object AND per pass kind: the 2D view tessellates at
    # a detail cap, the 3D view without, and with one slot a part's two
    # meshes evicted each other on every change (a Lego build's 96 x 96
    # baseplate was re-tessellated twice a click)
    slot = (node.id, _FN_OVERRIDE, _DETAIL)
    cached = _COMP_CACHE.get(slot) if key is not None else None
    if cached is not None and cached[0] == key:
        CACHE_STATS["hits"] += 1
        local = cached[1]
        if cached[2] == placed_key:            # nothing moved: free
            return cached[3]
    elif key is not None and key in _EXACT:
        CACHE_STATS["misses"] += 1
        # OpenSCAD has rendered this exact part: use its mesh (holes
        # really cut) instead of the approximate tessellation. An STL
        # has no colour, so it wears the one colour inside the part (a
        # red library brick used to turn grey here); a part of several
        # colours is never sent for an exact render (part_colours)
        inside = part_colours(node, env)
        tint = next(iter(inside)) if len(inside) == 1 else None
        local = [(tri, tint, False) for tri in _EXACT[key]]
    else:
        CACHE_STATS["misses"] += 1
        # children tessellated colour-neutral, so the Object's own
        # colour can change without invalidating the local cache
        local = _children_mesh(node, env, None, frozenset(), False)
    out = [(tri, c if c is not None else group_color, False)
           for tri, c, _s in local]
    if moved:
        out = _transform_colored(
            mat_mul(mat_translate(tx, ty, tz),
                    mat_rotate(rx, ry, rz)), out)
    if key is not None:
        if len(_COMP_CACHE) >= _COMP_CACHE_MAX:
            _COMP_CACHE.clear()
        _COMP_CACHE[slot] = (key, local, placed_key, out)
    return out


# ----------------------------------------------------------- tree walk

def _set_fn(fn):
    global _FN_OVERRIDE
    _FN_OVERRIDE = int(fn) if fn else None


def _set_refs(node):
    """Index nodes by name so Linked copies can resolve their master.
    The index is built from the *document* root (the top of the node's
    parent chain), so tessellating one instance alone — the Snap
    tool's per-part pick meshes, a part outline in the 2D assembly —
    still resolves the Object definition it references."""
    global _REF_INDEX
    _REF_INDEX = {}
    top = node
    while top.parent is not None:
        top = top.parent
    for n in top.walk():
        _REF_INDEX.setdefault(n.name, n)
    _REF_STACK.clear()


def _clear_refs():
    global _REF_INDEX
    _REF_INDEX = None
    _REF_STACK.clear()


def tessellate(node: CadNode, env=None, fn=None, detail=None):
    """Triangle mesh for *node*'s subtree (fallback semantics). *fn*
    overrides the segment count of every round object when given;
    *detail* caps it, for the low-resolution 2D outlines."""
    global _DETAIL
    _DETAIL = detail
    _set_fn(fn)
    _set_refs(node)
    try:
        return [tri for tri, _c, _s in
                _tess(node, dict(env or {}), None, frozenset(), False)]
    finally:
        _DETAIL = None
        _set_fn(None)
        _clear_refs()


def tessellate_colored(node: CadNode, env=None, fn=None, detail=None):
    """Like tessellate but returns [(triangle, (color, alpha) | None)]
    with per-face colours from color() nodes — the built-in preview
    shows them (STL from the engine is geometry-only). *detail* caps
    segment counts, for the 2D views' coloured plans."""
    global _DETAIL
    _DETAIL = detail
    _set_fn(fn)
    _set_refs(node)
    try:
        return [(t, c) for t, c, _s in
                _tess(node, dict(env or {}), None, frozenset(), False)]
    finally:
        _DETAIL = None
        _set_fn(None)
        _clear_refs()


def selected_world_tris(node: CadNode, sel_ids, env=None, detail=None,
                        fn=None):
    """World-space triangles belonging to any node whose id is in
    *sel_ids* — used to highlight the selected object in both views.
    Ancestor transforms are already applied, so the triangles land
    where the object actually sits in the assembly. *detail* caps
    segment counts for the fast, low-resolution 2D silhouette."""
    global _DETAIL
    sel = frozenset(sel_ids)
    if not sel:
        return []
    _DETAIL = detail
    _set_fn(fn)
    _set_refs(node)
    try:
        out = [t for t, _c, s in
               _tess(node, dict(env or {}), None, sel, False) if s]
        if not out:
            # the selection may live in a non-rendering store (a master),
            # which _tess skips — so it never appears in the scene walk.
            # Tessellate each selected node's own subtree directly so it
            # can still be highlighted in both views.
            by_id = {n.id: n for n in node.walk()}
            for nid in sel:
                target = by_id.get(nid)
                if target is not None and target is not node:
                    out += [t for t, _c, _s in
                            _tess(target, dict(env or {}), None,
                                  frozenset({nid}), True)]
        return out
    finally:
        _DETAIL = None
        _set_fn(None)
        _clear_refs()


def _emit(tris, color, selected):
    return [(tri, color, selected) for tri in tris]


#: how the preview tints OpenSCAD's # (highlight) and % (background)
MODIFIER_TINT = {"#": ("#ff5151", 0.5), "%": ("#b4b4b4", 0.3)}
_MODIFIER_ACTIVE = set()


def show_only(root):
    """The first visible node carrying OpenSCAD's ``!`` modifier under
    *root* (the whole program then renders that alone), or None."""
    for n in root.walk():
        if n is not root and n.params.get("modifier") == "!" and n.visible:
            probe, shown = n.parent, True
            while probe is not None and probe is not root:
                shown = shown and probe.visible
                probe = probe.parent
            if shown:
                return n
    return None


def _tess(node, env, color, sel, selected):
    if not node.visible:
        return []
    mod = node.params.get("modifier")
    if mod in MODIFIER_TINT and node.id not in _MODIFIER_ACTIVE:
        _MODIFIER_ACTIVE.add(node.id)
        try:
            out = _tess(node, env, color, sel, selected)
        finally:
            _MODIFIER_ACTIVE.discard(node.id)
        tint = MODIFIER_TINT[mod]
        return [(tri, tint, s) for tri, _c, s in out]
    if node.type == "root" and node.id not in _MODIFIER_ACTIVE:
        only = show_only(node)
        if only is not None:
            _MODIFIER_ACTIVE.add(node.id)
            try:
                return _transform_colored(
                    ancestor_matrix(only, env),
                    _tess(only, env, color, sel, selected))
            finally:
                _MODIFIER_ACTIVE.discard(node.id)
    selected = selected or (node.id in sel)
    t = node.type
    if t == "color":
        color = (str(node.params.get("color", "#4a90d9")),
                 rv(node.params.get("alpha", 1.0), env, 1.0))
        material = str(node.params.get("material") or "Default")
        if material != "Default":
            color += (material,)        # (colour, alpha, material)
        return _children_mesh(node, env, color, sel, selected)
    if t == "masters":
        # definitions store: masters render only through Linked copies,
        # so the group contributes no geometry of its own.
        return []
    if t == "scad_raw":
        # verbatim OpenSCAD — only the OpenSCAD engine can render it;
        # the built-in tessellator has no model for it.
        return []
    if t == "projection":
        # flattens 3D to a 2D outline — a 2D result the mesh preview
        # can't represent; the OpenSCAD engine renders it.
        return []
    if t in ("root", "variables"):
        # "variables" only holds assignments, so it adds no geometry.
        return _children_mesh(node, env, color, sel, selected)
    if t == "hull":
        return _hull_mesh(node, env, color, sel, selected)
    if t == "reference":
        # a Linked copy renders its master's geometry, moved/rotated.
        # When the master is an **Object**, this is an assembly
        # instance: it renders the Object's LOCAL geometry (the module
        # body — placement zeroed, definition visibility ignored, as a
        # hidden Object is a pure definition) under its own placement.
        target = (_REF_INDEX or {}).get(
            str(node.params.get("ref", "")).strip())
        if target is None or node.id in _REF_STACK:
            return []
        col = str(node.params.get("color", "")).strip()
        if col:
            # the instance's own colour: two copies of one Object can
            # wear different colours (a colour inside the master still
            # wins, as OpenSCAD's innermost color() does)
            color = (col, rv(node.params.get("alpha", 1.0), env, 1.0))
        _REF_STACK.add(node.id)
        try:
            if target.type == "component":
                saved = {k: target.params.get(k, 0.0)
                         for k in ("x", "y", "z", "rx", "ry", "rz")}
                saved_visible = target.visible
                try:
                    for k in saved:
                        target.params[k] = 0.0
                    target.visible = True
                    out = _tess(target, env, color, sel, selected)
                finally:
                    target.params.update(saved)
                    target.visible = saved_visible
            else:
                out = _tess(target, env, color, sel, selected)
        finally:
            _REF_STACK.discard(node.id)
        rx = rv(node.params.get("rx", 0), env, 0.0)
        ry = rv(node.params.get("ry", 0), env, 0.0)
        rz = rv(node.params.get("rz", 0), env, 0.0)
        tx = rv(node.params.get("x", 0), env, 0.0)
        ty = rv(node.params.get("y", 0), env, 0.0)
        tz = rv(node.params.get("z", 0), env, 0.0)
        if any((rx, ry, rz, tx, ty, tz)):
            matrix = mat_mul(mat_translate(tx, ty, tz),
                             mat_rotate(rx, ry, rz))
            out = _transform_colored(matrix, out)
        return out
    if t == "component":
        # like a group, but the local mesh is cached (see
        # _component_mesh) so assembly edits stay snappy
        return _component_mesh(node, env, color, sel, selected)
    if t == "union":
        # a group is a part: apply its own colour, then its rotate and
        # translate (matching the color()/translate()/rotate() codegen)
        group_color = color
        col = str(node.params.get("color", "")).strip()
        if col:
            group_color = (col, rv(node.params.get("alpha", 1.0), env,
                                   1.0))
        out = _children_mesh(node, env, group_color, sel, selected)
        rx = rv(node.params.get("rx", 0), env, 0.0)
        ry = rv(node.params.get("ry", 0), env, 0.0)
        rz = rv(node.params.get("rz", 0), env, 0.0)
        tx = rv(node.params.get("x", 0), env, 0.0)
        ty = rv(node.params.get("y", 0), env, 0.0)
        tz = rv(node.params.get("z", 0), env, 0.0)
        if any((rx, ry, rz, tx, ty, tz)):
            matrix = mat_mul(mat_translate(tx, ty, tz),
                             mat_rotate(rx, ry, rz))
            out = _transform_colored(matrix, out)
        return out
    if t in ("difference", "intersection", "minkowski"):
        # Exact through Manifold (csg.py) when it can; else show the
        # first operand and leave the true result to OpenSCAD.
        from . import csg
        ops = _operands(node, env)
        if not ops:
            return []
        if csg.available():
            meshes = [_tess(c, scope, color, sel, selected)
                      for c, scope in ops]
            cut = csg.boolean(t, meshes)
            if cut is not None:
                csg.FAILED.discard(node.id)
                if sel:
                    # a selected tool (a bore) glows whole, as before
                    for (child, _s), rows in zip(ops[1:], meshes[1:]):
                        if any(n.id in sel for n in child.walk()):
                            cut.extend(rows)
                return cut
            csg.FAILED.add(node.id)
            mesh = meshes[0]
        else:
            mesh = _tess(ops[0][0], ops[0][1], color, sel, selected)
        ops = [c for c, _s in ops]
        # a selected object hiding in a subtracted / later operand (e.g.
        # a bore removed from a body) still needs its own geometry so it
        # can be shown when *it* is picked — but selecting the whole
        # difference must not draw the removed tools as solid, so only
        # pull in an operand that actually contains a selected node.
        if sel:
            for child in ops[1:]:
                if any(n.id in sel for n in child.walk()):
                    mesh.extend(_tess(child, env, color, sel, selected))
        return mesh
    if t in ("for_loop", "while_loop"):
        var = str(node.params.get("variable", "i")) or "i"
        mesh = []
        for value in node.loop_values(env):
            scoped = dict(env)
            scoped[var] = value
            mesh.extend(_children_mesh(node, scoped, color, sel,
                                       selected))
        return mesh
    if t == "if_else":
        mesh = []
        for child in _if_branch(node, env):
            mesh.extend(_tess(child, env, color, sel, selected))
        return mesh
    if t == "assign":
        return []
    if t == "linear_extrude":
        return _emit(linear_extrude_mesh(node, env), color, selected)
    if t == "rotate_extrude":
        return _emit(rotate_extrude_mesh(node, env), color, selected)
    if t in _TRANSFORM_MATS:
        # A chain of single-child transforms is ONE matrix. Applied one
        # at a time, every triangle went through a separate Python loop
        # per link — an orrery's planet is translate · rotate · scale
        # over a spinning globe, so each frame transformed the whole
        # model four times over. Stop at anything `_tess` has to see
        # for itself: several children, a hidden node or a modifier.
        matrix = None
        while True:
            p = rp(node, env)
            step = _TRANSFORM_MATS[node.type](p["x"], p["y"], p["z"])
            matrix = step if matrix is None else mat_mul(matrix, step)
            kids = node.children
            if (len(kids) == 1 and kids[0].type in _TRANSFORM_MATS
                    and kids[0].visible
                    and not kids[0].params.get("modifier")):
                node = kids[0]
                selected = selected or (node.id in sel)
                continue
            break
        return _transform_colored(
            matrix, _children_mesh(node, env, color, sel, selected))
    if t == "offset":
        # 2D-only op: preview its (offset) outlines flat at z = 0.
        mesh = []
        for outline in collect_outlines(node, env):
            mesh.extend((
                (a[0], a[1], 0.0), (b[0], b[1], 0.0),
                (c[0], c[1], 0.0)) for a, b, c in triangulate(outline))
        return _emit(mesh, color, selected)
    if t == "cube":
        return _emit(cube_mesh(rp(node, env)), color, selected)
    if t == "sphere":
        return _emit(sphere_mesh(rp(node, env)), color, selected)
    if t == "cylinder":
        return _emit(cylinder_mesh(rp(node, env)), color, selected)
    if t == "stl_import":
        return _emit(stl_mesh(rp(node, env)), color, selected)
    if t in organic.TYPES:
        return organic.tess(node, env, color, sel, selected)
    if node.category == SHAPE_2D:
        return _emit(flat_mesh(node, env), color, selected)
    return []                                 # pragma: no cover


#: past this many points a hull previews as the union of its children
#: rather than stall the GUI thread (the exact render is still exact)
HULL_POINT_LIMIT = 60000


def _hull_mesh(node, env, color, sel, selected):
    """A 3D hull is the convex hull of its children (geom3d) — a chain
    of hulled spheres previews as the capsule it is, not as a string of
    beads. A flat (2D) hull has no volume to hull and keeps the union
    of its children, as before."""
    from . import geom3d
    parts = _children_mesh(node, env, color, sel, selected)
    pts = [v for tri, _c, _s in parts for v in tri]
    if not 4 <= len(pts) <= HULL_POINT_LIMIT:
        return parts
    tris = geom3d.convex_hull(pts)
    if not tris:
        return parts                            # coplanar: a 2D hull
    own = color if color is not None else next(
        (c for _t, c, _s in parts if c is not None), None)
    out = _emit(tris, own, selected)
    if sel and not selected:
        # a selected operand still needs its own triangles to glow
        out.extend(item for item in parts if item[2])
    return out


def _transform_colored(m, marked):
    """(triangle, colour, selected) rows through *m*, in ONE pass: the
    obvious spelling — strip the triangles, transform them, zip the
    rows back together — walks the list three times and builds two
    throwaway lists of it, on the hot path of every redraw."""
    (a, b, c, d), (e, f, g, h), (i, j, k, n) = m[0], m[1], m[2]
    if flips_winding(m):
        return [(((a * x2 + b * y2 + c * z2 + d,
                   e * x2 + f * y2 + g * z2 + h,
                   i * x2 + j * y2 + k * z2 + n),
                  (a * x1 + b * y1 + c * z1 + d,
                   e * x1 + f * y1 + g * z1 + h,
                   i * x1 + j * y1 + k * z1 + n),
                  (a * x0 + b * y0 + c * z0 + d,
                   e * x0 + f * y0 + g * z0 + h,
                   i * x0 + j * y0 + k * z0 + n)), col, sel)
                for ((x0, y0, z0), (x1, y1, z1), (x2, y2, z2)), col, sel
                in marked]
    return [(((a * x0 + b * y0 + c * z0 + d,
               e * x0 + f * y0 + g * z0 + h,
               i * x0 + j * y0 + k * z0 + n),
              (a * x1 + b * y1 + c * z1 + d,
               e * x1 + f * y1 + g * z1 + h,
               i * x1 + j * y1 + k * z1 + n),
              (a * x2 + b * y2 + c * z2 + d,
               e * x2 + f * y2 + g * z2 + h,
               i * x2 + j * y2 + k * z2 + n)), col, sel)
            for ((x0, y0, z0), (x1, y1, z1), (x2, y2, z2)), col, sel
            in marked]


def _operands(node, env):
    """A boolean's operands with the scope each is tessellated in: an
    assign among them binds for the ones after it, and a transparent
    `variables` group's geometry counts one operand per child."""
    env = dict(env)
    out = []
    for child in node.children:
        if not child.visible:
            continue
        if child.type == "assign":
            _apply_assign(child, env)
        elif child.type == "variables":
            for grandchild in child.children:
                if grandchild.type == "assign":
                    _apply_assign(grandchild, env)
                elif grandchild.visible:
                    out.append((grandchild, dict(env)))
        else:
            out.append((child, dict(env)))
    return out


def _children_mesh(node, env, color, sel, selected):
    mesh = []
    env = dict(env)
    for child in node.children:
        if child.type == "assign":
            _apply_assign(child, env)
        elif child.type == "variables":
            # transparent group: its assignments belong to this scope so
            # sibling geometry can use them
            for grandchild in child.children:
                if grandchild.type == "assign":
                    _apply_assign(grandchild, env)
                else:
                    mesh.extend(_tess(grandchild, env, color, sel,
                                      selected))
        else:
            mesh.extend(_tess(child, env, color, sel, selected))
    return mesh


def uses_booleans(node: CadNode) -> bool:
    """True if the subtree contains ops the fallback preview can only
    approximate (booleans, minkowski, hull, offset)."""
    return any(n.type in APPROXIMATED
               for n in node.walk() if n.visible)


def approximates(node: CadNode) -> bool:
    """True if the preview of this subtree is NOT the true shape: an
    approximated op other than the booleans Manifold cuts exactly
    (csg.py), or one of those whose last cut failed (an operand that is
    not a closed solid). What the "booleans approximated" warnings and
    the exact-render queue ask."""
    from . import csg
    exact = csg.HANDLED if csg.available() else frozenset()
    return any(n.type in APPROXIMATED
               and (n.type not in exact or n.id in csg.FAILED)
               for n in node.walk() if n.visible)
