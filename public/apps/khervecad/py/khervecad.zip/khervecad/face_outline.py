"""The face you sketch on, shown in the sketch (2026-10-25, the user: "when
we select the face we should see that face in the 2D view … the centre
of the circle, this is where we would like the cut to start").

`outline(tris, point, normal)` (Qt-free): the triangles lying in the
clicked face's plane and facing its way, their boundary edges (an edge
used by one of them only) — the face's outline, holes included.
`for_group(group, tris)` maps it into the face sketch's own frame
(`face_sketch.to_local`), which is the 2D view's frame while that
sketch is open; `snap_points` gives its corners, the middle of each
straight side and the centre of each round run (`drawing.find_circles`)
— SolidWorks' snaps on the face's edges.

The 2D view draws the outline grey under the sketch and snaps to those
points (`SketchScene.face_outline`); nothing is stored in the document.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import math

PLANE_TOL = 1e-3          # mm off the plane still on it
FACING = 0.999            # cos of the angle a triangle may tilt
SNAP_PX = 10


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def _unit(v):
    n = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
    return (v[0] / n, v[1] / n, v[2] / n)


def outline(tris, point, normal):
    """[((x, y, z), (x, y, z))] boundary edges of the face of *tris* in
    the plane through *point* square to *normal*."""
    n = _unit(normal)
    d0 = n[0] * point[0] + n[1] * point[1] + n[2] * point[2]
    size = 1.0
    for t in tris[:2000]:
        for v in t:
            size = max(size, abs(v[0]), abs(v[1]), abs(v[2]))
    tol = PLANE_TOL * size
    count = {}
    for t in tris:
        tn = _unit(_cross(_sub(t[1], t[0]), _sub(t[2], t[0])))
        if tn[0] * n[0] + tn[1] * n[1] + tn[2] * n[2] < FACING:
            continue
        if any(abs(v[0] * n[0] + v[1] * n[1] + v[2] * n[2] - d0) > tol
               for v in t):
            continue
        for a, b in ((t[0], t[1]), (t[1], t[2]), (t[2], t[0])):
            ka = tuple(round(c, 4) for c in a)
            kb = tuple(round(c, 4) for c in b)
            key = (ka, kb) if ka <= kb else (kb, ka)
            count[key] = count.get(key, 0) + 1
    return [k for k, c in count.items() if c == 1]


def for_group(group, tris):
    """The clicked face's outline in *group*'s own 2D frame."""
    from . import face_sketch
    point = face_sketch.to_world(group, 0.0, 0.0)
    normal = face_sketch._normal_of(group)
    segs = []
    for a, b in outline(tris, point, normal):
        segs.append((face_sketch.to_local(group, a),
                     face_sketch.to_local(group, b)))
    return segs


def arcs(segs):
    """[((cx, cy), r)] of the round runs in the outline: along each loop,
    vertices that turn a little (a tessellated arc, between 0.3 and 40
    degrees) in a row; sharp corners and straight sides end a run."""
    from . import drawing
    out = []
    for points, _s, closed in drawing._chains(list(segs)):
        n = len(points)
        if n < 3:
            continue

        def signed(i):
            a, b, c = points[i - 1], points[i], points[(i + 1) % n]
            u = (b[0] - a[0], b[1] - a[1])
            v = (c[0] - b[0], c[1] - b[1])
            return math.degrees(math.atan2(u[0] * v[1] - u[1] * v[0],
                                           u[0] * v[0] + u[1] * v[1]))

        def turn(i):
            return abs(signed(i))

        def radius(i):
            # the local radius: half the two pieces' length over the turn
            a, b, c = points[i - 1], points[i], points[(i + 1) % n]
            ln = (math.hypot(b[0] - a[0], b[1] - a[1])
                  + math.hypot(c[0] - b[0], c[1] - b[1])) / 2
            return ln / max(math.radians(turn(i)), 1e-9)

        def same_arc(i, j):
            # tangent arcs of other radii (Exercise 50: an R25 end running
            # into an R100) are two arcs, not one fitted between them
            if (signed(i) > 0) != (signed(j) > 0):
                return False
            ri, rj = radius(i), radius(j)
            return max(ri, rj) / max(min(ri, rj), 1e-9) < 1.6
        def even(i):
            # a tessellated arc's pieces are alike; a vertex between an
            # arc and a long straight side is where the arc ENDS (it
            # turned a little too, and a run through two of them made a
            # huge circle of a straight side — Exercise 50's plate)
            a, b, c = points[i - 1], points[i], points[(i + 1) % n]
            la = math.hypot(b[0] - a[0], b[1] - a[1])
            lc = math.hypot(c[0] - b[0], c[1] - b[1])
            return max(la, lc) <= 4.0 * max(min(la, lc), 1e-9)
        rng = range(n) if closed else range(1, n - 1)
        bent = {i: 0.3 < turn(i) < 40.0 and even(i) for i in rng}
        if closed and all(bent.values()):
            got = drawing.fit_circle(points)
            if got:
                out.append(got)
            continue
        # walk from a vertex that is not bent so runs never wrap halfway
        start = next((i for i in rng if not bent[i]), None)
        if start is None:
            continue
        order = [(start + k) % n for k in range(n)] if closed else list(rng)
        run = []
        for i in order + [start]:
            if bent.get(i) and (not run or same_arc(run[-1], i)):
                run.append(i)
                continue
            if len(run) >= 2:
                pts = [points[(run[0] - 1) % n]] + [points[j] for j in run] \
                    + [points[(run[-1] + 1) % n]]
                got = drawing.fit_circle(pts)
                if got and got[1] > 1e-6:
                    out.append(got)
            run = [i] if bent.get(i) else []
    return out


def snap_points(segs):
    """[(x, y, label)]: corners, side middles, arc centres."""
    pts = {}
    for a, b in segs:
        for p in (a, b):
            pts[(round(p[0], 3), round(p[1], 3))] = "corner"
    out = [(x, y, k) for (x, y), k in pts.items()]
    for (cx, cy), _r in arcs(segs):
        out.append((cx, cy, "centre"))
    for a, b in segs:
        if math.hypot(b[0] - a[0], b[1] - a[1]) > 5.0:   # a real side
            out.append(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, "middle"))
    return out


def centre_of(segs):
    """Area centre of the largest closed loop of the outline, or None."""
    from . import drawing
    best = None
    for points, _s, closed in drawing._chains(list(segs)):
        if not closed or len(points) < 3:
            continue
        a = cx = cy = 0.0
        for i, p in enumerate(points):
            q = points[(i + 1) % len(points)]
            c = p[0] * q[1] - q[0] * p[1]
            a += c
            cx += (p[0] + q[0]) * c
            cy += (p[1] + q[1]) * c
        if abs(a) > 1e-9 and (best is None or abs(a) > best[0]):
            best = (abs(a), cx / (3 * a), cy / (3 * a))
    return (round(best[1], 6), round(best[2], 6)) if best else None


# =================================================================== Qt
def _face_triangles(group, tris):
    """The triangles of *tris* lying on *group*'s face, in its 2D frame,
    each counter-clockwise."""
    from . import face_sketch
    point = face_sketch.to_world(group, 0.0, 0.0)
    n = _unit(face_sketch._normal_of(group))
    d0 = n[0] * point[0] + n[1] * point[1] + n[2] * point[2]
    size = 1.0
    for t in tris[:2000]:
        for v in t:
            size = max(size, abs(v[0]), abs(v[1]), abs(v[2]))
    tol = PLANE_TOL * size
    out = []
    for t in tris:
        tn = _unit(_cross(_sub(t[1], t[0]), _sub(t[2], t[0])))
        if tn[0] * n[0] + tn[1] * n[1] + tn[2] * n[2] < FACING:
            continue
        if any(abs(v[0] * n[0] + v[1] * n[1] + v[2] * n[2] - d0) > tol
               for v in t):
            continue
        q = [face_sketch.to_local(group, v) for v in t]
        area = (q[1][0] - q[0][0]) * (q[2][1] - q[0][1]) - \
            (q[1][1] - q[0][1]) * (q[2][0] - q[0][0])
        if abs(area) < 1e-12:
            continue
        out.append(q if area > 0 else q[::-1])
    return out


def to_local_point(group, p):
    from . import face_sketch
    return face_sketch.to_local(group, p)


def _contains(polys, at):
    """Is *at* inside the polygons (even-odd, holes included)?"""
    x, y = at
    n = 0
    for poly in polys:
        pts = [(float(a), float(b)) for a, b in poly]
        for i, a in enumerate(pts):
            b = pts[(i + 1) % len(pts)]
            if (a[1] > y) != (b[1] > y) and \
                    a[0] + (y - a[1]) / (b[1] - a[1]) * (b[0] - a[0]) > x:
                n += 1
    return n % 2 == 1


def whole_face(group, own, others):
    """The face as SolidWorks sees it (2026-10-31, the user: the face of
    one part showed alone, not the part beside it on the same face): the
    clicked part's face (*own* triangles) joined with every other part's
    triangles in that plane touching it — one region, outline segments
    in the sketch's frame. None without Manifold."""
    try:
        import manifold3d as m
    except ImportError:                              # pragma: no cover
        return None
    mine = _face_triangles(group, own)
    if not mine:
        return None
    rest = _face_triangles(group, others) if others else []
    try:
        cs = m.CrossSection([[tuple(p) for p in t] for t in mine + rest],
                            m.FillRule.Positive).simplify(1e-4)
        seed = m.CrossSection([[tuple(p) for p in t] for t in mine],
                              m.FillRule.Positive).simplify(1e-4)
        keep = [c for c in cs.decompose()
                if not (c ^ seed).is_empty()]
        click = getattr(group, "_face_click", None)
        if click and len(keep) > 1:
            # a face is the connected region under the click, not every
            # coplanar piece of the part (Exercise 59: the floor inside
            # the curved wall, not the plate's far side of it)
            at = to_local_point(group, click[0])
            under = [c for c in keep
                     if _contains(c.to_polygons(), at)]
            keep = under or keep
        polys = [p for c in keep for p in c.to_polygons()]
    except Exception:
        return None
    segs = []
    for poly in polys:
        pts = [(round(float(x), 4) + 0.0, round(float(y), 4) + 0.0)
               for x, y in poly]
        for i, a in enumerate(pts):
            b = pts[(i + 1) % len(pts)]
            if a != b:
                segs.append((a, b))
    return segs or None


def feature_points(window, group):
    """[(x, y, kind)] the centre, corners and edge middles of every
    earlier FEATURE's own face lying in *group*'s plane (2026-11-10, the
    user: sketching on a boss's end, flush with the base under it, "I
    cannot access the centre of that plane ... somehow it is focused on
    another centre"). The face a sketch stands on is the whole flat
    region — base and boss together — and its one centre is the middle
    of the two; SolidWorks offers each face's own. A face in several
    islands gives each island's centre."""
    try:
        import manifold3d as m
    except ImportError:                              # pragma: no cover
        return []
    from . import face_owner
    out = []
    for node in face_owner._before(window, group):
        try:
            tris = _face_triangles(group, face_owner._world(window, node))
        except Exception:
            continue
        if not tris:
            continue
        try:
            cs = m.CrossSection([[tuple(p) for p in t] for t in tris],
                                m.FillRule.Positive).simplify(1e-4)
            islands = cs.decompose()
        except Exception:
            continue
        for island in islands:
            a = cx = cy = 0.0
            segs = []
            for poly in island.to_polygons():      # holes run clockwise
                pts = [(round(float(x), 4) + 0.0, round(float(y), 4) + 0.0)
                       for x, y in poly]
                for i, p in enumerate(pts):
                    q = pts[(i + 1) % len(pts)]
                    c = p[0] * q[1] - q[0] * p[1]
                    a += c
                    cx += (p[0] + q[0]) * c
                    cy += (p[1] + q[1]) * c
                    if p != q:
                        segs.append((p, q))
            if abs(a) < 1e-9:
                continue
            out.append((round(cx / (3 * a), 6) + 0.0,
                        round(cy / (3 * a), 6) + 0.0, "face centre"))
            out += snap_points(segs)
    return out


def show(window, group, part):
    """Hand the face's outline to the 2D view for *group*'s sketch: the
    whole face, every part lying in it (`whole_face`)."""
    from . import meshedit_ui
    tris, others = None, []
    for node, t in meshedit_ui._parts(window):
        if _inside(node, group):
            continue      # the sketch's own shapes are not the face
        if tris is None and (node is part or _inside(part, node)):
            tris = t
        else:
            others.extend(t)
    scene = window.view2d.scene()
    if not tris:
        # a plane through the part, no face under it: still the other
        # sketches' points and edges lying in it (Plane1 through A, B, C)
        scene.face_outline = None
        try:
            gp, gs = plane_features(window, group)
            if gp or gs:
                scene.face_outline = {"segments": [], "points": gp,
                                      "guides": gs}
        except Exception:
            import traceback
            traceback.print_exc()
        return []
    segs = None
    try:
        segs = whole_face(group, tris, others)
    except Exception:                        # never stop the sketch
        import traceback
        traceback.print_exc()
    if not segs:
        segs = for_group(group, tris)
    points = snap_points(segs) + anchor_points(group, segs)
    middle = centre_of(segs)
    if middle is not None:
        points.append((middle[0], middle[1], "face centre"))
    try:
        # ... and of each FEATURE's own face in this plane (the user: a
        # boss flush with the base — only the middle of the two together
        # was offered, never the boss's own)
        have = {(round(x, 3), round(y, 3), k) for x, y, k in points}
        for q in feature_points(window, group):
            if (round(q[0], 3), round(q[1], 3), q[2]) not in have:
                have.add((round(q[0], 3), round(q[1], 3), q[2]))
                points.append(q)
    except Exception:                        # never stop the sketch
        import traceback
        traceback.print_exc()
    try:
        points += sketch_points(group, part)
    except Exception:                        # never stop the sketch
        import traceback
        traceback.print_exc()
    info = {"segments": segs, "points": points}
    try:
        gp, gs = plane_features(window, group)
        have = {(round(x, 3), round(y, 3)) for x, y, _k in points}
        points += [q for q in gp if (round(q[0], 3), round(q[1], 3)) not in have]
        info["guides"] = gs
    except Exception:                        # never stop the sketch
        import traceback
        traceback.print_exc()
    try:
        # the whole part cut just behind the face (the user: "a cut of
        # the whole part through that face"), hatched under the contour
        cut = cut_behind(window, group)
        if cut:
            info["cut"] = cut
            have = {(round(x, 3), round(y, 3)) for x, y, _k in points}
            info["points"] = points + [
                q for q in snap_points(cut)
                if (round(q[0], 3), round(q[1], 3)) not in have]
    except Exception:                        # never stop the sketch
        import traceback
        traceback.print_exc()
    scene.face_outline = info
    return segs


#: how far behind the face the part is cut for its section (mm)
CUT_DEPTH = 0.05


def cut_behind(window, group):
    """The parts' section a hair behind *group*'s face, in its frame."""
    from . import face_sketch, meshedit_ui, section_outline
    n = face_sketch._normal_of(group)
    o = face_sketch.to_world(group, 0.0, 0.0)
    ex = face_sketch.to_world(group, 1.0, 0.0)
    ey = face_sketch.to_world(group, 0.0, 1.0)
    r = [ex[i] - o[i] for i in range(3)]
    u = [ey[i] - o[i] for i in range(3)]
    o = [o[i] - n[i] * CUT_DEPTH for i in range(3)]
    tris = [t for node, ts in meshedit_ui._parts(window)
            if node is not group for t in ts]
    if not tris or len(tris) > section_outline.MAX_TRIS:
        return []
    return section_outline.plane_segments(tris, o, n, r, u)


def anchor_points(group, segs):
    """The part's ORIGIN seen on the face (where the scope's 0, 0, 0
    lands in the sketch's frame, square to it) and the middle of the
    face — what "the centre of the part" means to a dimension (the
    user: dimension the hole's centre to the part's centre, 50 mm). The
    sketch's own (0, 0) is only where the face was clicked."""
    from . import face_sketch
    out = []
    try:
        ox, oy = face_sketch.to_local(group, (0.0, 0.0, 0.0))
        out.append((round(ox, 6) + 0.0, round(oy, 6) + 0.0, "part origin"))
    except Exception:
        pass
    if segs:
        xs = [p[0] for s in segs for p in s]
        ys = [p[1] for s in segs for p in s]
        out.append((round((min(xs) + max(xs)) / 2, 6) + 0.0,
                    round((min(ys) + max(ys)) / 2, 6) + 0.0, "face centre"))
    return out


def _shape_local_points(node):
    """(x, y, kind) of a 2D shape in its own frame, or []."""
    p = node.params
    try:
        if node.type == "rect":
            x, y = float(p.get("x", 0)), float(p.get("y", 0))
            w, h = float(p.get("width", 0)), float(p.get("height", 0))
            return [(x + w / 2, y + h / 2, "centre"), (x, y, "corner"),
                    (x + w, y, "corner"), (x + w, y + h, "corner"),
                    (x, y + h, "corner")]
        if node.type == "circle":
            return [(float(p.get("x", 0)), float(p.get("y", 0)), "centre")]
        if node.type == "line":
            a = (float(p["x1"]), float(p["y1"]))
            b = (float(p["x2"]), float(p["y2"]))
            return [(a[0], a[1], "corner"), (b[0], b[1], "corner"),
                    ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, "middle")]
        if node.type == "polygon":
            ox, oy = float(p.get("x", 0)), float(p.get("y", 0))
            pts = [(ox + float(q[0]), oy + float(q[1]))
                   for q in p.get("points") or []]
            out = [(x, y, "corner") for x, y in pts]
            if pts:
                out.append((sum(q[0] for q in pts) / len(pts),
                            sum(q[1] for q in pts) / len(pts), "centre"))
            return out
    except (TypeError, ValueError, KeyError):
        pass
    return []


def scope_points(scene):
    """Every sketch shape's centre / corners / ends in the scope the 2D
    view shows — HIDDEN ones too (a Regions' rectangle and circle), in
    the view's frame: what a new shape snaps and is pinned to."""
    from . import mesh
    from .model import SHAPE_2D
    if getattr(scene, "plane", "Top (XY)") not in ("Top (XY)", None):
        return []
    resolver = getattr(scene, "isolation_resolver", None)
    scope = (resolver() if resolver else None) or scene.model.root
    out = []
    for node in scope.walk():
        if node.category != SHAPE_2D:
            continue
        local = _shape_local_points(node)
        if not local:
            continue
        stop = None if scope is scene.model.root else scope
        try:
            m = mesh.mat_mul(mesh.ancestor_matrix(node, {}, stop=stop),
                             mesh.node_matrix(node, {}))
        except Exception:
            continue
        for x, y, kind in local:
            out.append((m[0][0] * x + m[0][1] * y + m[0][3],
                        m[1][0] * x + m[1][1] * y + m[1][3], kind, node))
    return out


def sketch_points(group, part):
    """The part's own sketch, seen on the face: the centres, corners
    and ends of the 2D shapes it was made from (a Regions' rectangle and
    circle, hidden or not) — "the centre of that rectangle"."""
    from . import face_sketch, mesh
    from .model import SHAPE_2D
    out = []
    normal = _unit(face_sketch._normal_of(group))
    for node in part.walk() if part is not None else ():
        if node.category != SHAPE_2D:
            continue
        p = node.params
        try:
            if node.type == "rect":
                x, y = float(p.get("x", 0)), float(p.get("y", 0))
                w, h = float(p.get("width", 0)), float(p.get("height", 0))
                local = [(x + w / 2, y + h / 2, "centre"),
                         (x, y, "corner"), (x + w, y, "corner"),
                         (x + w, y + h, "corner"), (x, y + h, "corner")]
            elif node.type == "circle":
                local = [(float(p.get("x", 0)), float(p.get("y", 0)),
                          "centre")]
            elif node.type == "line":
                a = (float(p["x1"]), float(p["y1"]))
                b = (float(p["x2"]), float(p["y2"]))
                local = [(a[0], a[1], "corner"), (b[0], b[1], "corner"),
                         ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, "middle")]
            else:
                continue
        except (TypeError, ValueError, KeyError):
            continue                          # expressions: skip
        m = mesh.mat_mul(mesh.ancestor_matrix(node, {}, stop=group.parent),
                         mesh.node_matrix(node, {}))
        # only a sketch lying PARALLEL to this face: the centre of a
        # circle drawn on another side of the part, dropped onto this
        # face, is a point of nothing (the user's "random" marks)
        nz = [m[r][2] for r in range(3)]
        length = math.sqrt(sum(c * c for c in nz)) or 1.0
        if abs(sum(a * b for a, b in zip(nz, normal))) / length < 0.999:
            continue
        for x, y, kind in local:
            w = [m[r][0] * x + m[r][1] * y + m[r][3] for r in range(3)]
            lx, ly = face_sketch.to_local(group, w)
            out.append((lx, ly, kind))
    return out


def plane_features(window, group):
    """([(x, y, kind)], [(a, b)]): the points and EDGES of the other
    sketches' shapes (a rectangle's corners and sides, a line) that lie IN
    *group*'s plane — SolidWorks' Point2@Sketch4 on Sketch3's edge, A B C
    on a sloping plane. Exact, so a line drawn to them lands on them."""
    from . import face_sketch, mesh
    from .model import SHAPE_2D
    normal = _unit(face_sketch._normal_of(group))
    o = [float(group.params.get(k, 0.0)) for k in ("x", "y", "z")]
    pts, segs = [], []
    for node in window.model.root.walk():
        if node.category != SHAPE_2D or _inside(node, group):
            continue
        p = node.params
        try:
            if node.type == "rect":
                x, y = float(p["x"]), float(p["y"])
                w, h = float(p["width"]), float(p["height"])
                loc = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
                edges = [(loc[i], loc[(i + 1) % 4]) for i in range(4)]
            elif node.type == "line":
                loc = [(float(p["x1"]), float(p["y1"])),
                       (float(p["x2"]), float(p["y2"]))]
                edges = [(loc[0], loc[1])]
            else:
                continue
            m = mesh.mat_mul(mesh.ancestor_matrix(node, {}),
                             mesh.node_matrix(node, {}))
        except (TypeError, ValueError, KeyError):
            continue

        def world(q):
            return [m[r][0] * q[0] + m[r][1] * q[1] + m[r][3]
                    for r in range(3)]

        def on_plane(w_):
            return abs(sum((w_[i] - o[i]) * normal[i]
                           for i in range(3))) < 1e-3
        for q in loc:
            w_ = world(q)
            if on_plane(w_):
                lx, ly = face_sketch.to_local(group, w_)
                pts.append((round(lx, 6) + 0.0, round(ly, 6) + 0.0, "corner"))
        for a, b in edges:
            wa, wb = world(a), world(b)
            if on_plane(wa) and on_plane(wb):
                segs.append((tuple(round(c, 6) + 0.0 for c in
                                   face_sketch.to_local(group, wa)),
                             tuple(round(c, 6) + 0.0 for c in
                                   face_sketch.to_local(group, wb))))
    return pts, segs


def add_guides(window, group):
    """Merge the other sketches' in-plane points and edges into whatever
    outline the 2D view holds for *group* (a reference plane's section)."""
    scene = window.view2d.scene()
    gp, gs = plane_features(window, group)
    if not (gp or gs):
        return
    info = getattr(scene, "face_outline", None)
    if info is None:
        scene.face_outline = {"segments": [], "points": list(gp),
                              "guides": list(gs)}
        return
    have = {(round(x, 3), round(y, 3)) for x, y, _k in info["points"]}
    info["points"] = list(info["points"]) + [
        q for q in gp if (round(q[0], 3), round(q[1], 3)) not in have]
    info["guides"] = list(info.get("guides") or []) + list(gs)


def pin(scene, model, node):
    """A shape just drawn on the face: each of its points sitting on a
    snap point of the face is fixed there (SolidWorks makes it
    coincident: the slot stays on the arc's centre)."""
    info = getattr(scene, "face_outline", None)
    if node is None or node.parent is None:
        return 0
    from . import sketch_constraints as sc
    from .sketch_constrain_ui import _entities
    targets = [(x, y) for x, y, _k in info["points"]] if info else []
    middles = {(round(x, 6), round(y, 6)) for x, y, k in
               (info["points"] if info else []) if k == "middle"}
    mine = set(id(n) for n in node.walk())
    try:
        # the sketch's own centres and corners too, hidden or not (not
        # the shape just drawn: it would pin to itself)
        # ... but never a shape of THIS sketch: that is a Coincident
        # (sketch_touch.relate), which moves with it. Pinned in place,
        # a circle drawn on an origin froze the origin and every
        # dimension to it (2026-11-11, the user's 70 that would not
        # change)
        targets += [(x, y) for x, y, kind, owner in scope_points(scene)
                    if id(owner) not in mine and kind == "centre"
                    and getattr(owner, "parent", None) is not node.parent]
    except Exception:
        pass
    if not targets and not (info or {}).get("segments"):
        return 0
    n = 0
    for shape in [node] + list(node.children):
        if shape.parent is None:
            continue
        try:
            ents = _entities(shape)
        except Exception:
            continue
        for name, kind in ents:
            if kind != "point":
                continue
            try:
                pt = sc._point(shape, name, {})
            except (KeyError, ValueError, IndexError):
                continue
            if any(abs(pt[0] - x) < 1e-6 and abs(pt[1] - y) < 1e-6
                   for x, y in targets):
                try:
                    sc.add(model, shape.parent, "fix",
                           [sc.ref_of(shape.parent, shape, name)])
                    n += 1
                except (ValueError, KeyError):
                    pass
                else:
                    # a corner OF THE MODEL: it follows the model
                    # (model_refs), found again by its edges' directions
                    from . import model_refs
                    segs = (info or {}).get("segments", ())
                    row = sc.rows(shape.parent)[-1]
                    dirs = model_refs._corner_dirs(segs, pt)
                    mid = next(((a, b) for a, b in segs if
                                abs((a[0] + b[0]) / 2 - pt[0]) < 1e-6 and
                                abs((a[1] + b[1]) / 2 - pt[1]) < 1e-6),
                               None) if (round(pt[0], 6), round(pt[1], 6)) \
                        in middles or not dirs else None
                    centre = centre_of(segs) if segs else None
                    if centre is not None and \
                            abs(centre[0] - pt[0]) < 1e-5 and \
                            abs(centre[1] - pt[1]) < 1e-5:
                        row["model"] = "centre"
                    elif mid is not None:
                        # the MIDDLE of a model edge: stays its middle
                        row["model"] = "mid"
                        row["edge"] = [round(v, 6) for v in
                                       (*mid[0], *mid[1])]
                    elif dirs:
                        row["model"] = True
                        row["dirs"] = [round(d, 6) for d in dirs]
                continue
            # ON an edge of the part (not at a corner): it stays on that
            # edge, free to slide along it (SolidWorks' On Edge)
            for a, b in list((info or {}).get("segments", ())) + \
                    list((info or {}).get("guides") or []):
                ex_, ey_ = _on_segment(pt[0], pt[1], a, b)
                if abs(ex_ - pt[0]) < 1e-6 and abs(ey_ - pt[1]) < 1e-6:
                    try:
                        sc.add(model, shape.parent, "on_edge",
                               [sc.ref_of(shape.parent, shape, name)],
                               edge=[a[0], a[1], b[0], b[1]])
                        n += 1
                    except (ValueError, KeyError):
                        pass
                    break
    return n


def _inside(node, outer):
    while node is not None:
        if node is outer:
            return True
        node = node.parent
    return False


def clear(window):
    scene = window.view2d.scene()
    scene.face_outline = None


def paint(scene, painter):
    """Grey outline + small marks on the centres (scene coordinates)."""
    from PyQt5.QtCore import QLineF, QPointF
    from PyQt5.QtGui import QColor, QPen
    info = getattr(scene, "face_outline", None)
    if not info:
        return
    # the model itself is painted behind the sketch (sketch_backdrop):
    # no hatch over it then — the FACE sketched on is tinted and outlined
    backdrop = bool(getattr(scene, "_backdrop_on", False))
    if info.get("section"):
        _paint_section(scene, painter, info["segments"], hatch=not backdrop)
        return
    if info.get("cut") and not backdrop:
        # the whole part cut just behind the face, under its contour
        _paint_section(scene, painter, info["cut"], edges=False)
    painter.save()
    if backdrop:
        _paint_face(painter, info["segments"])
    pen = QPen(QColor(40, 120, 225) if backdrop
               else QColor(110, 120, 135), 0)
    pen.setCosmetic(True)
    pen.setWidthF(2.0 if backdrop else 1.6)
    painter.setPen(pen)
    for a, b in info["segments"]:
        painter.drawLine(QLineF(QPointF(*a), QPointF(*b)))
    mark = QPen(QColor(200, 60, 40), 0)
    mark.setCosmetic(True)
    mark.setWidthF(1.4)
    painter.setPen(mark)
    views = scene.views()
    k = 1.0 / (abs(views[0].transform().m11()) or 1.0) if views else 1.0
    for x, y, kind in info["points"]:
        if kind in ("part origin", "face centre"):
            s = 7 * k                       # a target: ⊕
            painter.drawEllipse(QPointF(x, y), s * 0.6, s * 0.6)
            painter.drawLine(QLineF(x - s, y, x + s, y))
            painter.drawLine(QLineF(x, y - s, x, y + s))
        elif kind == "centre":
            s = 5 * k
            painter.drawLine(QLineF(x - s, y, x + s, y))
            painter.drawLine(QLineF(x, y - s, x, y + s))
    painter.restore()


def _on_segment(px, py, a, b):
    ax, ay = a
    dx, dy = b[0] - ax, b[1] - ay
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 < 1e-12 else max(0.0, min(1.0, ((px - ax) * dx +
                                                  (py - ay) * dy) / L2))
    return ax + dx * t, ay + dy * t


def snap(scene, pos):
    """(point, kind) of the face's snap point nearest *pos* within
    SNAP_PX — a centre, corner, middle or the sketch's origin — else the
    nearest point ON one of its edges; or None."""
    info = getattr(scene, "face_outline", None)
    if not info:
        return None
    views = scene.views()
    k = abs(views[0].transform().m11()) if views else 1.0
    best = None
    for x, y, kind in info["points"] + [(0.0, 0.0, "origin")]:
        d = math.hypot(pos.x() - x, pos.y() - y) * k
        # the part origin / face centre give way to a real point there
        rank = d + (0.5 if kind in ("part origin", "face centre") else 0)
        if d <= SNAP_PX and (best is None or rank < best[0]):
            best = (rank, x, y, kind)
    from PyQt5.QtCore import QPointF
    if best is not None:
        return QPointF(best[1], best[2]), best[3]
    for a, b in list(info["segments"]) + list(info.get("guides") or []):
        x, y = _on_segment(pos.x(), pos.y(), a, b)
        d = math.hypot(pos.x() - x, pos.y() - y) * k
        if d <= SNAP_PX / 2 and (best is None or d < best[0]):
            best = (d, x, y, "edge")
    if best is not None:
        return QPointF(best[1], best[2]), best[3]
    return None


#: what a snap marker says
LABELS = {"part origin": "Part origin", "face centre": "Face centre",
          "centre": "Centre", "corner": "Corner", "middle": "Midpoint",
          "origin": "Origin", "edge": "On edge", "point": "Point",
          "on_line": "On centerline"}


def paint_hint(view, painter):
    """The point the cursor snaps to: an orange ring with its name, as
    SolidWorks shows it (the user did not see the snapping)."""
    from PyQt5.QtCore import QPointF, QRectF, Qt
    from PyQt5.QtGui import QColor, QPen
    scene = view.scene()
    hint = getattr(scene, "_snap_hint", None)
    if not hint or (getattr(scene, "tool", "select") == "select" and
                    not getattr(scene, "_handle_drag", False) and
                    getattr(scene, "_shape_drag", None) is None):
        return
    p, kind = hint
    k = abs(view.transform().m11()) or 1.0
    r = 6.0 / k
    painter.save()
    pen = QPen(QColor("#ff8c00"), 2.0)
    pen.setCosmetic(True)
    painter.setPen(pen)
    painter.setBrush(Qt.NoBrush)
    painter.drawEllipse(QPointF(p), r, r)
    if kind == "centre":
        painter.drawLine(QPointF(p.x() - r, p.y()), QPointF(p.x() + r, p.y()))
        painter.drawLine(QPointF(p.x(), p.y() - r), QPointF(p.x(), p.y() + r))
    # the name, upright on screen
    painter.resetTransform()
    sp = view.mapFromScene(p)
    painter.setPen(QColor("#c26a00"))
    font = painter.font()
    font.setBold(True)
    painter.setFont(font)
    painter.drawText(QRectF(sp.x() + 9, sp.y() - 22, 120, 16),
                     int(Qt.AlignLeft | Qt.AlignVCenter),
                     LABELS.get(kind, "Point"))
    painter.restore()


def reference(scene, pos, want=None, parent=None):
    """The face under a constraint / dimension click when no sketch shape
    is: SolidWorks lets you dimension to the model's edges. A fixed
    CONSTRUCTION copy is added to the sketch — a line along the edge, or
    a point on a corner / centre — and returned as a pick
    (node, entity, kind). None when the click is on nothing."""
    from . import sketch_constraints as sc
    # the sketch ORIGIN is offered even with no part under the sketch
    # (the user: the middle of a line to the origin, on an empty plane)
    info = getattr(scene, "face_outline", None) or {"points": [],
                                                     "segments": []}
    resolver = getattr(scene, "isolation_resolver", None)
    group = resolver() if resolver else None
    if group is None:
        group = parent
    if group is None:
        return None
    # into the container of the shape it is dimensioned to (a cut's
    # circle lives inside its extrude, not in the sketch Group): a
    # dimension joins shapes of ONE container, else it was refused
    if parent is not None:
        group = parent
    views = scene.views()
    k = abs(views[0].transform().m11()) if views else 1.0
    model = scene.model
    best = None
    if want in (None, "point"):
        for x, y, kind in info["points"] + [(0.0, 0.0, "origin")]:
            if kind == "middle":
                continue               # mid-edge: the EDGE is meant
            d = math.hypot(pos.x() - x, pos.y() - y) * k
            if d <= SNAP_PX and (best is None or d < best[0]):
                best = (d, "point", (x, y))
    if best is None and want in (None, "line", "curve"):
        for a, b in info["segments"]:
            x, y = _on_segment(pos.x(), pos.y(), a, b)
            d = math.hypot(pos.x() - x, pos.y() - y) * k
            if d <= SNAP_PX and math.hypot(b[0] - a[0], b[1] - a[1]) > 1e-6 \
                    and (best is None or d < best[0]):
                best = (d, "line", (a, b))
    if best is None:
        return None
    if best[1] == "point":
        x, y = best[2]
        node = model.add_node("circle", dict(x=round(x, 6), y=round(y, 6),
                                             radius=0.25), parent=group,
                              name="Reference point")
        model.set_modifier(node, "%")
        sc.add(model, group, "fix", [sc.ref_of(group, node, "c")])
        return node, "c", "point"
    (a, b) = best[2]
    # the whole straight edge: join collinear outline pieces into one
    a, b = _whole_edge(info["segments"], a, b)
    node = model.add_node("line", dict(x1=round(a[0], 6), y1=round(a[1], 6),
                                       x2=round(b[0], 6), y2=round(b[1], 6),
                                       width=0.2), parent=group,
                          name="Reference edge")
    model.set_modifier(node, "%")
    for end in ("p1", "p2"):
        sc.add(model, group, "fix", [sc.ref_of(group, node, end)])
    return node, "l", "line"


def _whole_edge(segs, a, b):
    """*a*-*b* grown along every outline piece lying on the same line."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy) or 1.0
    ux, uy = dx / L, dy / L
    lo, hi = 0.0, L
    for p, q in segs:
        ok = True
        for r in (p, q):
            # on the line through a along u?
            if abs((r[0] - a[0]) * uy - (r[1] - a[1]) * ux) > 1e-4:
                ok = False
        if not ok:
            continue
        for r in (p, q):
            t = (r[0] - a[0]) * ux + (r[1] - a[1]) * uy
            lo, hi = min(lo, t), max(hi, t)
    return ((a[0] + ux * lo, a[1] + uy * lo),
            (a[0] + ux * hi, a[1] + uy * hi))


def _paint_face(painter, segments):
    """The face sketched on, tinted: this is where the sketch lies (the
    rest of the picture is the part round it and behind it)."""
    from PyQt5.QtCore import QPointF, Qt
    from PyQt5.QtGui import QColor, QPainterPath
    from . import section as _section
    fill = QPainterPath()
    fill.setFillRule(Qt.OddEvenFill)
    for pts, closed in _section.chain(
            [((a[0], a[1]), (b[0], b[1])) for a, b in segments]):
        if closed and len(pts) >= 3:
            fill.moveTo(QPointF(*pts[0]))
            for q in pts[1:]:
                fill.lineTo(QPointF(*q))
            fill.closeSubpath()
    painter.setPen(Qt.NoPen)
    painter.setBrush(QColor(90, 165, 255, 70))
    painter.drawPath(fill)
    painter.setBrush(Qt.NoBrush)


def _paint_section(scene, painter, segments, edges=True, hatch=True):
    """The part CUT by the sketch plane (section_outline): a light
    section fill, drawn UNDER the sketch shapes (drawBackground)."""
    from PyQt5.QtCore import QPointF, Qt
    from PyQt5.QtGui import QBrush, QColor, QPainterPath, QPen
    painter.save()
    path = QPainterPath()
    path.setFillRule(Qt.OddEvenFill)
    for a, b in segments:
        path.moveTo(QPointF(*a))
        path.lineTo(QPointF(*b))
    from . import section as _section
    fill = QPainterPath()
    fill.setFillRule(Qt.OddEvenFill)
    for pts, closed in _section.chain(
            [((a[0], a[1]), (b[0], b[1])) for a, b in segments]):
        if closed and len(pts) >= 3:
            fill.moveTo(QPointF(*pts[0]))
            for q in pts[1:]:
                fill.lineTo(QPointF(*q))
            fill.closeSubpath()
    # blue like the sketch's own shapes, the holes left empty (the
    # user expected blue where a white veil and brown hatch were)
    painter.setPen(Qt.NoPen)
    painter.setBrush(QColor(33, 118, 199, 55))
    painter.drawPath(fill)
    # black hatch lines (2026-11-01, the user: darker, black) — not over
    # the model's own picture
    lines = QBrush(QColor(0, 0, 0, 170), Qt.BDiagPattern)
    views = scene.views()
    if views:                 # hatch at screen size, not model size
        from PyQt5.QtGui import QTransform
        m = views[0].transform()
        lines.setTransform(QTransform.fromScale(
            1 / (abs(m.m11()) or 1), 1 / (abs(m.m22()) or 1)))
    if hatch:
        painter.setBrush(lines)
        painter.drawPath(fill)
    edge = QPen(QColor(30, 60, 120), 0)
    edge.setCosmetic(True)
    edge.setWidthF(2.2 if edges else 1.2)
    painter.setPen(edge)
    painter.setBrush(Qt.NoBrush)
    painter.drawPath(path)
    painter.restore()
