"""Import OpenSCAD programs back into a KherveCAD object tree.

Parses the OpenSCAD subset KherveCAD generates — primitives,
transforms, extrusions, booleans, offset/hull/minkowski, `for`
loops, `if/else`, assignments, `import()` and the `*` disable
modifier — plus common variations (named or positional arguments,
`d=` diameters, scalar `rotate`/`scale`, bare `{}` blocks).

User `module` definitions are inlined at each call site and user
`function` definitions are evaluated (recursion and cross-calls
included), so list comprehensions `[for (i = r) let (..) if (c) expr]`,
`concat`, vector variables and `.x/.y/.z` all resolve to real numbers at
import — a `polygon(points)` whose points come from a variable, a
comprehension or a function (e.g. a NACA airfoil) imports as concrete
coordinates. Assignments that evaluate to a vector are stored as a
self-contained literal so the tree never depends on a function that
codegen can't emit.

Parsing never crashes a whole file: a statement that can't be parsed is
skipped with a warning and import resumes at the next boundary. `use` /
`include`, `children()` and calls nothing defines are handled by
scadinclude.py (a call that cannot become objects is kept as its own
OpenSCAD code); resize / multmatrix / let / echo / assert / render /
intersection_for by scadlang.py; surface and 2D import() by scadfiles.py.
Non-constant expressions are kept verbatim as expression strings, which
KherveCAD params support.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import re

from . import expr
from .model import CadNode

_TOKEN_RE = re.compile(r"""
    (?P<space>\s+)
  | (?P<comment>//[^\n]*|/\*.*?\*/)
  | (?P<directive>\b(?:use|include)\s*<[^>\n]*>)
  | (?P<number>\d+\.?\d*(?:[eE][-+]?\d+)?|\.\d+(?:[eE][-+]?\d+)?)
  | (?P<string>"(?:\\.|[^"\\])*")
  | (?P<ident>\$?[A-Za-z_]\w*)
  | (?P<op><=|>=|==|!=|&&|\|\||[-+*/%^<>=!?:,;(){}\[\]#.])
""", re.VERBOSE | re.DOTALL)


class ScadParseError(ValueError):
    pass


def _tokenize(text, comments=None):
    """Tokens of *text*; comments are dropped from the stream but, when
    a *comments* list is given, collected there as (start, text)."""
    tokens = []
    pos = 0
    while pos < len(text):
        match = _TOKEN_RE.match(text, pos)
        if match is None:
            raise ScadParseError(
                f"unexpected character {text[pos]!r} at offset {pos}")
        kind = match.lastgroup
        if kind == "comment":
            if comments is not None:
                comments.append((match.start(), match.group()))
        elif kind != "space":
            tokens.append((kind, match.group(), match.start(),
                           match.end()))
        pos = match.end()
    return tokens


#: a comment label longer than this is prose, not a name
_LABEL_MAX = 48


#: commented-out code: a call glued to its bracket (`cube([1, 2, 3])`)
#: or an assignment (`wall = 2`) — a label reads "Body (12 x 18)"
_CODE_LIKE = re.compile(r"^[A-Za-z_$][\w$.]*(\(|\s*=[^=])")


def _comment_label(text):
    """The label a `// Body` comment gives, or "" — block comments,
    long prose and commented-out code name nothing. Banner dressing
    (`// ---- Legs ----`, `// === Body ===`) is stripped, so the tree
    reads "For i [Legs]", not "For i [---- Legs ----]"."""
    if not text.startswith("//"):
        return ""
    label = " ".join(text[2:].split()).strip(" -=*#~_/+|")
    if not label or len(label) > _LABEL_MAX \
            or any(c in label for c in ";{}") or _CODE_LIKE.match(label):
        return ""
    return label


class Parser:
    def __init__(self, text: str, base_dir=None):
        self.text = text
        #: folder `use <...>` / `include <...>` resolve against first
        self.base_dir = base_dir
        #: > 0 while re-parsing a module body that lives in another file
        #: (its token offsets are not this text's, so no comment labels)
        self._foreign = 0
        #: the children of each module call being inlined, innermost last
        #: — what a children() in its body stands for
        self._children_stack = []
        #: library files being read (a cycle guard)
        self._loading = set()
        #: [(offset, "// text")] — read back as node labels
        self.comments = []
        self.tokens = _tokenize(text, self.comments)
        #: [(offset of a statement's first token, node it produced)]
        self._heads = []
        self.i = 0
        self.warnings = []
        #: name -> scadinclude.Module for user modules (their tokens,
        #: and for a library module its file's scope), inlined at each
        #: call site.
        self.modules = {}
        #: zero-param module names already materialised as a component —
        #: any further call becomes an *instance* (reference) of it.
        self.instanced = set()
        #: concrete values of top-level/bound assignments, so later
        #: expressions (polygon points, vector variables, list
        #: comprehensions) can be resolved to real numbers at import.
        self.scope = {}
        #: the names the TREE will define where the parser stands (a
        #: variable node, a module argument, a let binding, a loop
        #: variable): an expression over them is kept as written, so
        #: the imported model stays parametric (`_keeps_link`)
        self.bound = set()

    # ------------------------------------------------------- helpers
    def peek(self, offset=0):
        j = self.i + offset
        return self.tokens[j] if j < len(self.tokens) else None

    def next(self):
        token = self.peek()
        if token is None:
            raise ScadParseError("unexpected end of input")
        self.i += 1
        return token

    def accept(self, value):
        token = self.peek()
        if token is not None and token[1] == value:
            self.i += 1
            return True
        return False

    def expect(self, value):
        token = self.next()
        if token[1] != value:
            raise ScadParseError(
                f"expected {value!r}, got {token[1]!r}")
        return token

    def warn(self, message):
        self.warnings.append(message)

    def resolve_points(self, raw):
        """Turn a polygon ``points`` argument into a concrete list of
        ``[x, y]`` pairs. Accepts an inline list, a variable name, a list
        of variable names, or a list comprehension — anything that
        evaluates against the current scope. Returns None if it can't."""
        value = raw
        if isinstance(value, str):
            try:
                value = expr.evaluate(value, self.scope)
            except Exception:
                return None
        if not isinstance(value, (list, tuple)):
            return None
        pts = []
        for element in value:
            if isinstance(element, str) and \
                    re.match(r"(for|let|each|if)\b", element.strip()):
                # a list literal holding a comprehension arrives as
                # [ "for (i = ...) ..." ]: it yields many points
                try:
                    produced = expr.evaluate(f"[{element}]", self.scope)
                except Exception:
                    return None
                for item in produced:
                    if not (isinstance(item, (list, tuple))
                            and len(item) >= 2):
                        return None
                    pts.append([float(item[0]), float(item[1])])
                continue
            if isinstance(element, str):
                try:
                    element = expr.evaluate(element, self.scope)
                except Exception:
                    return None
            if isinstance(element, (list, tuple)) and len(element) >= 2:
                try:
                    pts.append([float(element[0]), float(element[1])])
                except (TypeError, ValueError):
                    return None
            else:
                return None
        return pts if len(pts) >= 3 else None

    # ------------------------------------------- expression scanning
    def _scan_expr(self, stop=(",", ")", "]", ";", ":")):
        """Consume one expression; return (numeric_or_None, source). A
        ternary `c ? a : b` is kept whole — its `:` is the ternary
        separator, not a stop (that would otherwise cut the expression)."""
        depth = 0
        ternary = 0
        start = self.peek()
        if start is None:
            raise ScadParseError("expected expression")
        begin = start[2]
        end = begin
        while True:
            token = self.peek()
            if token is None:
                break
            t = token[1]
            if depth == 0:
                if t == "?":
                    ternary += 1
                elif t == ":" and ternary > 0:
                    ternary -= 1               # ternary colon, keep going
                elif t in stop:
                    break
            if t in "([{":
                depth += 1
            elif t in ")]}":
                if depth == 0:
                    break
                depth -= 1
            end = token[3]
            self.i += 1
        source = self.text[begin:end].strip()
        if not source:
            raise ScadParseError("empty expression")
        try:
            value = expr.evaluate(source, self.scope)
        except (expr.ExprError, Exception):
            return None, source
        return value, source

    def _keeps_link(self, source):
        """True when *source* reads a variable the tree defines (and
        nothing only the parser knows — a user function, a library's
        own variable), so it must stay an expression: `cube(w)` keeps
        following `w` instead of freezing at its value."""
        linked = False
        for match in _NAME_RE.finditer(source):
            name = match.group(1)
            if name is None:                          # a "string"
                continue
            if match.group(2):                        # a call
                if name in expr.FUNCTIONS or name in _WORDS:
                    continue
                return False
            if name in _WORDS or name in expr.CONSTANTS:
                continue
            if name in self.bound or name in _LIVE:
                linked = True
            elif name in self.scope:
                return False
        return linked

    def _expr_param(self):
        """Expression as a param value: float when constant, else the
        source string — which it also stays when it reads a variable the
        tree defines (`_keeps_link`)."""
        value, source = self._scan_expr()
        if isinstance(value, bool) and not self._keeps_link(source):
            return value
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return source if self._keeps_link(source) else float(value)
        return source

    def scoped(self, names=(), values=None):
        """A context in which *names* are tree-defined (bound) and, when
        *values* has them, known — or unknown (a loop variable, shadowing
        any outer value). Restores both on exit."""
        import contextlib

        @contextlib.contextmanager
        def ctx():
            scope, bound = self.scope, self.bound
            self.scope, self.bound = dict(scope), set(bound) | set(names)
            for name in names:
                if values is not None and name in values:
                    self.scope[name] = values[name]
                else:
                    self.scope.pop(name, None)
            try:
                yield
            finally:
                self.scope, self.bound = scope, bound
        return ctx()

    def _vector(self):
        """[a, b, ...] as a list of param values; assumes next is [."""
        self.expect("[")
        items = []
        if not self.accept("]"):
            while True:
                items.append(self._expr_param())
                if self.accept("]"):
                    break
                self.expect(",")
                if self.accept("]"):             # trailing comma
                    break
        return items

    def _arguments(self):
        """Parse (...) into (positional list, named dict)."""
        self.expect("(")
        positional, named = [], {}
        if self.accept(")"):
            return positional, named
        while True:
            token = self.peek()
            nxt = self.peek(1)
            if token and token[0] == "ident" and nxt and nxt[1] == "=" \
                    and (self.peek(2) is None or self.peek(2)[1] != "="):
                name = self.next()[1]
                self.expect("=")
                named[name] = self._argument_value()
            else:
                positional.append(self._argument_value())
            if self.accept(")"):
                return positional, named
            self.expect(",")
            if self.accept(")"):                 # trailing comma
                return positional, named

    def _argument_value(self):
        token = self.peek()
        if token is not None and token[1] == "[":
            # vector of vectors (polygon points) or plain vector
            if self.peek(1) is not None and self.peek(1)[1] == "[":
                start = self.i
                try:
                    self.expect("[")
                    points = []
                    while True:
                        points.append(self._vector())
                        if self.accept("]"):
                            break
                        self.expect(",")
                    return points
                except ScadParseError:
                    # vectors mixed with variables or a comprehension
                    # (`[[0, 0], p1, p2]`): keep the expression, which
                    # resolve_points evaluates in scope
                    self.i = start
                    return self._expr_param()
            return self._vector()
        if token is not None and token[0] == "string":
            self.next()
            return _unquote(token[1])
        return self._expr_param()

    # ----------------------------------------------------- statements
    def parse_program(self) -> CadNode:
        root = CadNode("root")
        while self.peek() is not None:
            start = self.i
            try:
                node = self.parse_statement()
            except ScadParseError as exc:
                self.warn(f"skipped unparseable statement: {exc}")
                self._recover(start)
                continue
            except Exception as exc:             # never crash a whole file
                self.warn(f"skipped statement ({type(exc).__name__})")
                self._recover(start)
                continue
            if node is not None:
                root.add(node)
        self._apply_comment_labels()
        from . import customizer
        customizer.annotate(self, root)
        return root

    def _apply_comment_labels(self):
        """Name nodes after their comments: "Cube" becomes "Cube [Body]".

        A trailing ``// Body`` after a statement that ends on its line
        labels the innermost one (``color("red") cube(10);  // Body``
        names the cube, which is what codegen writes back). On a block
        header whose body runs on below (``for (..) for (..) {  //
        Legs``) it labels the outermost — the whole block. A lone
        comment line directly above a statement labels that statement —
        unless it is part of a comment block (the program header,
        prose)."""
        import bisect
        from collections import defaultdict
        from .model import UNTAGGED_TYPES, with_tag
        text = self.text
        starts = [0] + [k + 1 for k, c in enumerate(text) if c == "\n"]

        def line_of(offset):
            return bisect.bisect_right(starts, offset) - 1

        # line -> start offset -> [(node, end offset)]
        heads = defaultdict(lambda: defaultdict(list))
        for offset, end, node in self._heads:
            if node.type == "component" or node.type not in UNTAGGED_TYPES:
                heads[line_of(offset)][offset].append((node, end))

        def label_node(node, label):
            # an Object is NAMED by the label on its placed call
            # (`Throat_and_belly();  // Throat and belly`, which is how
            # codegen carries a name its identifier cannot), where any
            # other node is tagged ("Cube [Body]")
            if node.type == "component":
                node.name = label
            else:
                node.name = with_tag(node.name, label)
        comment_lines = set()
        for offset, body in self.comments:
            if not text[starts[line_of(offset)]:offset].strip():
                comment_lines.add(line_of(offset))
        labelled = set()
        standalone = []
        for offset, body in self.comments:
            label = _comment_label(body)
            if not label:
                continue
            line = line_of(offset)
            if line not in comment_lines:          # trailing comment
                before = [o for o in heads.get(line, {}) if o < offset]
                if before:
                    complete = [o for o in before
                                if any(line_of(end) == line
                                       for _n, end in heads[line][o])]
                    pick = max(complete) if complete else min(before)
                    for node, _end in heads[line][pick]:
                        label_node(node, label)
                        labelled.add(id(node))
            elif line - 1 not in comment_lines:
                standalone.append((line, label))
        for line, label in standalone:
            below = heads.get(line + 1)
            if not below:
                continue
            # same rule as a trailing comment: a one-line statement is
            # named by its shape (`color() cube();` -> the Cube), a
            # block by its header
            complete = [o for o in below
                        if any(line_of(end) == line + 1
                               for _n, end in below[o])]
            pick = max(complete) if complete else min(below)
            for node, _end in below[pick]:
                if id(node) not in labelled:
                    label_node(node, label)

    def _recover(self, start):
        """After a failed statement, advance to the next top-level ';' or
        '}' so the rest of the file still imports (and we never loop)."""
        if self.i <= start:
            self.i = start + 1
        depth = 0
        while self.peek() is not None:
            token = self.next()
            if token[1] in "([{":
                depth += 1
            elif token[1] in ")]}":
                if depth == 0:
                    break
                depth -= 1
            elif token[1] == ";" and depth == 0:
                break

    def parse_statement(self):
        token = self.peek()
        node = self._parse_statement()
        if node is not None and token is not None and not self._foreign:
            end = self.tokens[self.i - 1][3] if self.i else token[3]
            self._heads.append((token[2], end, node))
        return node

    def _parse_statement(self):
        token = self.peek()
        if token is None:
            return None
        value = token[1]
        if token[0] == "directive":
            return _scadinclude.parse_directive(self)
        if value == ";":
            self.next()
            return None
        if value == "{":
            return self._block_as_union()
        if value in ("*", "!", "#", "%"):
            self.next()
            node = self.parse_statement()
            if node is not None and value == "*":
                node.visible = False
            elif node is not None:
                node.params["modifier"] = value       # # highlight, % bg, !
            return node
        if token[0] != "ident":
            raise ScadParseError(f"unexpected token {value!r}")
        if value == "for":
            return self._parse_for()
        if value in _scadlang.STATEMENTS and self.peek(1) is not None \
                and self.peek(1)[1] == "(":
            return _scadlang.parse_statement(self, value)
        if value == "if":
            return self._parse_if()
        if value == "module":
            self._capture_module()
            return None
        if value == "function":
            self._capture_function()
            return None
        nxt = self.peek(1)
        if nxt is not None and nxt[1] == "=":
            return self._parse_assign()
        if nxt is not None and nxt[1] == "(":
            return self._parse_call()
        raise ScadParseError(f"unexpected identifier {value!r}")

    def _block_as_union(self):
        self.expect("{")
        node = CadNode("union", "Group")
        while not self.accept("}"):
            child = self.parse_statement()
            if child is not None:
                node.add(child)
        return node

    def _children_into(self, node):
        """Attach the following statement / block as children."""
        if self.accept(";"):
            return node
        token = self.peek()
        if token is not None and token[1] == "{":
            self.expect("{")
            while not self.accept("}"):
                child = self.parse_statement()
                if child is not None:
                    node.add(child)
            return node
        child = self.parse_statement()
        if child is not None:
            node.add(child)
        return node

    def _parse_assign(self):
        name = self.next()[1]
        self.expect("=")
        value, source = self._scan_expr()
        self.accept(";")
        # remember the concrete value so later expressions (points that
        # reference this, list comprehensions using it, ...) can resolve.
        linked = self._keeps_link(source)
        if value is not None:
            self.scope[name] = value
        self.bound.add(name)
        if linked:
            param = source                   # h = w * 2 follows w
        elif isinstance(value, bool):
            param = value
        elif isinstance(value, (int, float)):
            param = float(value)
        elif isinstance(value, (list, tuple)):
            # store the resolved vector/list as a self-contained literal —
            # its source may call user functions that are not tree nodes
            # (so validate() and codegen would otherwise choke on them).
            param = _literal(value)
        else:                                    # unresolved expression
            param = source
        return CadNode("assign", f"{name} =",
                       dict(variable=name, value=param))

    def _parse_for(self):
        self.next()                              # for
        self.expect("(")
        loops = []
        while True:
            var = self.next()[1]
            self.expect("=")
            loops.append((var, self._parse_range()))
            if self.accept(")"):
                break
            self.expect(",")
        outer = current = None
        for var, params in loops:
            loop = params.pop("while", None)
            if loop is not None:
                node = CadNode("while_loop", f"While {var}",
                               dict(variable=var, **loop))
            else:
                params["variable"] = var
                node = CadNode("for_loop", f"For {var}", params)
            if current is not None:
                current.add(node)
            current = node
            outer = outer or node
        with self.scoped([var for var, _p in loops]):
            self._children_into(current)
        return outer

    def _parse_loop_header(self):
        """`(var = range)` of a single-variable loop -> (var, params)."""
        self.expect("(")
        var = self.next()[1]
        self.expect("=")
        params = self._parse_range()
        self.expect(")")
        return var, params

    def _parse_c_for(self):
        """`[for (x = s, _w = 0; (cond) && _w < N; x = upd, _w = _w + 1)
        x]` -> {"while": params}: how codegen writes a while loop (OpenSCAD
        has no while statement). A hand-written C-style loop without the
        `_w` guard reads the same. Anything else raises ScadParseError, so
        the caller falls back to an ordinary list comprehension."""
        import re
        self.expect("[")
        self.expect("for")
        self.expect("(")
        var = self.next()[1]
        self.expect("=")
        start = self._expr_param()
        if self.accept(","):
            self._c_for_guard()
        self.expect(";")
        condition = self._scan_expr(stop=(";",))[1]
        guard = re.fullmatch(r"\((.*)\)\s*&&\s*_w\s*<\s*\d+", condition,
                             re.S)
        if guard:
            condition = guard.group(1).strip()
        self.expect(";")
        if self.next()[1] != var:
            raise ScadParseError("C-style for updates another variable")
        self.expect("=")
        update = self._scan_expr(stop=(",", ")"))[1]
        if self.accept(","):
            self._c_for_guard()
        self.expect(")")
        if self.next()[1] != var:
            raise ScadParseError("C-style for yields an expression")
        self.expect("]")
        return {"while": dict(start=start, condition=condition,
                              update=update)}

    def _c_for_guard(self):
        """Skip the `_w = ...` iteration guard of a C-style for."""
        if self.next()[1] != "_w":
            raise ScadParseError("C-style for with several variables")
        self.expect("=")
        self._scan_expr(stop=(",", ";", ")"))

    def _parse_range(self):
        """[a:b], [a:s:b], [v1, v2, ...], a C-style `[for (..; ..; ..) x]`
        (a while loop) or a single expression."""
        token = self.peek()
        if token is not None and token[1] == "[" and \
                (self.peek(1) or ("", ""))[1] == "for":
            start = self.i
            try:
                return self._parse_c_for()
            except ScadParseError:
                self.i = start                   # an ordinary comprehension
        if token is not None and token[1] == "[":
            self.expect("[")
            first = self._expr_param()
            if self.accept(":"):
                second = self._expr_param()
                if self.accept(":"):
                    third = self._expr_param()
                    self.expect("]")
                    return dict(start=first, step=second, end=third,
                                values="")
                self.expect("]")
                return dict(start=first, step=1.0, end=second,
                            values="")
            values = [first]
            while self.accept(","):
                values.append(self._expr_param())
            self.expect("]")
            from .model import fmt
            text = ", ".join(fmt(v) for v in values)
            if len(values) == 1 and text.strip().startswith("["):
                # one vector: keep the outer list, or the loop would
                # iterate the vector's numbers instead of the vector
                text = f"[{text}]"
            return dict(values=text)
        value = self._expr_param()
        from .model import fmt
        return dict(values=fmt(value))

    def _parse_if(self):
        self.next()                              # if
        self.expect("(")
        _value, condition = self._scan_expr(stop=(")",))
        self.expect(")")
        node = CadNode("if_else", f"If {condition}",
                       dict(condition=condition))
        self._children_into(node)
        if self.peek() is not None and self.peek()[1] == "else":
            self.next()
            else_branch = CadNode("union", "Else")
            self._children_into(else_branch)
            node.add(else_branch)
        return node

    def _skip_definition(self, kind):
        name = "?"
        self.next()
        if self.peek() is not None and self.peek()[0] == "ident":
            name = self.next()[1]
        depth = 0
        started = False
        while self.peek() is not None:
            token = self.next()
            if token[1] in "({[":
                depth += 1
                started = True
            elif token[1] in ")}]":
                depth -= 1
            elif token[1] == ";" and depth == 0:
                break
            if started and depth == 0 and token[1] == "}":
                break
        self.warn(f"{kind} '{name}' skipped (not supported)")

    def _capture_function(self):
        """Record `function name(params) = expr;` as a callable in the
        scope, so expressions (and polygon points) that call it resolve
        at import. Supports defaults and recursion / cross-calls via a
        live closure over the parser scope."""
        self.next()                                   # 'function'
        if self.peek() is None or self.peek()[0] != "ident":
            return self._skip_definition("function")
        name = self.next()[1]
        self.expect("(")
        params = []
        while not self.accept(")"):
            pname = self.next()[1]
            default = None
            if self.accept("="):
                default = self._scan_expr(stop=(",", ")"))[1]
            params.append((pname, default))
            if self.accept(")"):
                break
            self.expect(",")
        self.expect("=")
        body = self._scan_expr(stop=(";",))[1]
        self.accept(";")
        scope = self.scope

        def call(*args, **kwargs):
            local = dict(scope)
            for idx, (pname, default) in enumerate(params):
                if idx < len(args):
                    local[pname] = args[idx]
                elif pname in kwargs:
                    local[pname] = kwargs[pname]
                elif default is not None:
                    local[pname] = expr.evaluate(default, local)
            return expr.evaluate(body, local)

        self.scope[name] = call

    # ------------------------------------------------------- modules
    def _capture_module(self):
        """Record a `module name(params) { body }` definition so each
        call can be inlined (its body re-parsed with the arguments bound
        as local variables)."""
        self.next()                                   # 'module'
        name = "?"
        if self.peek() is not None and self.peek()[0] == "ident":
            name = self.next()[1]
        self.expect("(")
        params = []
        while not self.accept(")"):
            pname = self.next()[1]
            default = None
            if self.accept("="):
                default = self._scan_expr(stop=(",", ")"))[1]
            params.append((pname, default))
            if self.accept(")"):
                break
            self.expect(",")                     # trailing comma tolerated
        self.expect("{")
        body_start = self.i
        depth = 1
        while depth > 0 and self.peek() is not None:
            tok = self.next()
            if tok[1] == "{":
                depth += 1
            elif tok[1] == "}":
                depth -= 1
        body_end = self.i - 1                          # the closing '}'
        self.modules[name] = _scadinclude.Module(
            params, body_start, body_end, self.tokens, self.text,
            getattr(self, "library_scope", None))

    def _inline_module(self, name):
        """Expand a call to a user module: a union holding one assign per
        bound parameter, then the module body re-parsed as its children.
        A zero-parameter module is what KherveCAD emits for an Object
        (component), so those come back as component nodes — the
        export -> import round trip keeps the assembly structure."""
        module = self.modules[name]
        params, body_start, body_end = module.params, module.start, \
            module.end
        positional, named = self._arguments()
        # the call's own children, parsed in the caller's scope: what a
        # children() in the body stands for
        kids = _scadinclude.call_children(self)
        if not params and not positional and not named and not kids:
            if name in self.instanced:
                # the first call materialised the Object; every further
                # call is one placed instance of it
                self.accept(";")
                return CadNode("reference", f"{name} instance",
                               dict(ref=name))
            self.instanced.add(name)
            inst = CadNode("component", name)
        else:
            inst = CadNode("union", name)
        outer_scope = self.scope                      # bound params shadow
        outer_bound = self.bound
        self.bound = set(outer_bound) | {pname for pname, _d in params}
        self.scope = dict(outer_scope)                # the enclosing scope
        if module.scope is not None:
            # a library module sees its own file's variables and
            # functions; the caller's stay visible under them
            self.scope.update(module.scope)
        self.scope["$children"] = len(kids)
        for idx, (pname, default) in enumerate(params):
            if idx < len(positional):
                value = positional[idx]
            elif pname in named:
                value = named[pname]
            else:
                value = default
            source = _arg_source(value)
            inst.add(CadNode("assign", f"{pname} =",
                             dict(variable=pname, value=source)))
            try:                                      # so the body can use
                self.scope[pname] = expr.evaluate(source, outer_scope)
            except Exception:
                pass
        saved = (self.i, self.tokens, self.text)      # re-parse the body
        foreign = module.tokens is not self.tokens
        self.tokens, self.text, self.i = module.tokens, module.text, \
            body_start
        self._foreign += foreign
        self._children_stack.append(kids)
        try:
            while self.i < body_end:
                child = self.parse_statement()
                if child is not None:
                    inst.add(child)
        finally:
            self._children_stack.pop()
            self._foreign -= foreign
            self.i, self.tokens, self.text = saved
            self.scope = outer_scope                  # restore
            self.bound = outer_bound
        return inst

    def _skip_call_statement(self):
        """Skip the arg list + attached statement of an unknown call."""
        self._arguments()
        token = self.peek()
        if token is None or self.accept(";"):
            return
        if token[1] == "{":
            depth = 0
            while self.peek() is not None:
                tok = self.next()
                if tok[1] == "{":
                    depth += 1
                elif tok[1] == "}":
                    depth -= 1
                    if depth == 0:
                        return
        else:
            self.parse_statement()

    # ----------------------------------------------------------- calls
    def _parse_call(self):
        start = self.i
        name = self.next()[1]
        if name == "children":
            return _scadinclude.parse_children(self)
        if name in self.modules and name not in _BUILDERS:
            return _scadinclude.inline_or_raw(self, name, start)
        builder = _BUILDERS.get(name)
        if builder is None:
            self._skip_call_statement()
            return _scadinclude.raw_statement(
                self, start, f"unsupported call '{name}' kept as "
                             "OpenSCAD code")
        positional, named = self._arguments()
        node = builder(self, positional, named)
        if node is None:
            # builder consumed the call but produced nothing
            if not self.accept(";"):
                pass
            return None
        if node.is_container():
            self._children_into(node)
            node = _fold_container(node) or node
        else:
            self.accept(";")
        return node


def _literal(value) -> str:
    """Serialise a concrete number/bool/vector as an OpenSCAD literal
    expression string (so an assign carries no reference to user
    functions or other variables)."""
    from .model import fmt
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return fmt(float(value))
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_literal(v) for v in value) + "]"
    return str(value)


def _arg_source(value) -> str:
    """A module argument (float, expression string, or vector list) as an
    expression source string for the bound-parameter assign node."""
    from .model import fmt
    if value is None:
        return "0"
    if isinstance(value, list):
        return "[" + ", ".join(_arg_source(v) for v in value) + "]"
    if isinstance(value, str):
        return value
    return fmt(value)


def _unquote(literal: str) -> str:
    return literal[1:-1].replace('\\"', '"').replace("\\\\", "\\")


def _num(value, default=0.0):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    return value if isinstance(value, str) else default


def _get(positional, named, index, *names, default=None):
    for name in names:
        if name in named:
            return named[name]
    if index is not None and index < len(positional):
        return positional[index]
    return default


def _radius(positional, named, default):
    d = _get(positional, named, None, "d")
    if d is not None:
        if isinstance(d, (int, float)):
            return float(d) / 2.0
        return f"({d}) / 2"
    r = _get(positional, named, 0, "r", default=default)
    return _num(r, default)


def _segments(parser, named, radius, default):
    """A round shape's segment count the way OpenSCAD picks it: its own
    $fn, else a $fn set in scope, else — when $fa or $fs is given there
    or on the call — the fragments for the radius
    (``ceil(max(min(360 / $fa, 2 pi r / $fs), 5))``), else *default*.
    A $fn written as an expression stays one."""
    import math
    scope = parser.scope

    def pick(name):
        return named[name] if name in named else scope.get(name)
    fn = pick("$fn")
    if isinstance(fn, str) and fn.strip():
        return fn
    if isinstance(fn, (int, float)) and not isinstance(fn, bool) and fn > 0:
        return max(int(fn), 3)
    fa, fs = pick("$fa"), pick("$fs")
    if (fa is not None or fs is not None) and \
            isinstance(radius, (int, float)):
        try:
            fa = float(fa) if fa is not None else 12.0
            fs = float(fs) if fs is not None else 2.0
        except (TypeError, ValueError):
            return default
        if radius < 1e-6 or fa <= 0 or fs <= 0:
            return 3
        return int(math.ceil(max(min(360.0 / fa,
                                     radius * 2 * math.pi / fs), 5)))
    return default


# builder(parser, positional, named) -> CadNode | None

def _b_circle(parser, positional, named):
    radius = _radius(positional, named, 10.0)
    params = dict(x=0.0, y=0.0, radius=radius,
                  segments=_segments(parser, named, radius, 64))
    return CadNode("circle", "Circle", params)


def _b_square(parser, positional, named):
    size = _get(positional, named, 0, "size", default=10.0)
    if isinstance(size, list):
        width, height = (size + [10.0])[:2]
    elif isinstance(size, str) and _components(parser, size, 2):
        width, height = _components(parser, size, 2)
    else:
        width = height = size
    params = dict(x=0.0, y=0.0, width=_num(width, 10.0),
                  height=_num(height, 10.0))
    if named.get("center"):
        if isinstance(width, (int, float)) and \
                isinstance(height, (int, float)):
            params["x"], params["y"] = -width / 2.0, -height / 2.0
        else:
            params["x"] = f"-({width}) / 2" if isinstance(width, str) \
                else -float(width) / 2.0
            params["y"] = f"-({height}) / 2" if isinstance(height, str) \
                else -float(height) / 2.0
    return CadNode("rect", "Rectangle", params)


def _b_polygon(parser, positional, named):
    raw = _get(positional, named, 0, "points", default=None)
    paths = _get(positional, named, 1, "paths", default=None)
    if isinstance(paths, str):
        try:
            paths = expr.evaluate(paths, parser.scope)
        except Exception:
            parser.warn("polygon paths could not be resolved — all points "
                        "used as one outline")
            paths = None
    rows = []
    if isinstance(paths, list):
        flat = paths and all(not isinstance(v, list) for v in paths)
        for row in ([paths] if flat else paths):
            if isinstance(row, list):
                try:
                    rows.append([int(float(v)) for v in row])
                except (TypeError, ValueError):
                    pass
    pts = parser.resolve_points(raw)
    if pts is None:
        parser.warn("polygon points could not be resolved — "
                    "placeholder triangle used")
        pts = [[0.0, 0.0], [10.0, 0.0], [0.0, 10.0]]
    params = dict(x=0.0, y=0.0, points=pts)
    if rows:
        params["paths"] = rows
    return CadNode("polygon", "Polygon", params)


def _b_text(parser, positional, named):
    from .model import TEXT_DIRECTIONS, TEXT_HALIGN, TEXT_VALIGN
    params = dict(
        x=0.0, y=0.0,
        text=str(_get(positional, named, 0, "text", default="text")),
        size=_num(_get(positional, named, 1, "size", default=10.0),
                  10.0))
    font = _get(positional, named, 2, "font", default="")
    if font:
        params["font"] = str(font)
    for key, allowed in (("halign", TEXT_HALIGN), ("valign", TEXT_VALIGN),
                         ("direction", TEXT_DIRECTIONS)):
        value = named.get(key)
        if value is None:
            continue
        if str(value) in allowed:
            params[key] = str(value)
        else:
            parser.warn(f"text {key} {value!r} not understood — ignored")
    if "spacing" in named:
        params["spacing"] = _num(named["spacing"], 1.0)
    return CadNode("text", "Text", params)


def _b_cube(parser, positional, named):
    size = _get(positional, named, 0, "size", default=10.0)
    if isinstance(size, list):
        w, d, h = (size + [10.0, 10.0])[:3]
        w, d, h = _num(w, 10.0), _num(d, 10.0), _num(h, 10.0)
    elif isinstance(size, str):
        # a variable/expression — a vector reads by index, a scalar is
        # all three; unknown here, the graceful .x/.y/.z accessors
        parts = _components(parser, size, 3)
        try:
            scalar = isinstance(expr.evaluate(size, parser.scope),
                                (int, float))
        except Exception:
            scalar = False
        if parts is not None:
            w, d, h = (p if p is not None else 10.0 for p in parts)
        elif scalar:
            w = d = h = size
        else:
            w, d, h = f"({size}).x", f"({size}).y", f"({size}).z"
    else:
        w = d = h = _num(size, 10.0)
    return CadNode("cube", "Cube", dict(
        x=0.0, y=0.0, z=0.0, width=w, depth=d, height=h,
        center=bool(named.get("center", False))))


def _b_sphere(parser, positional, named):
    radius = _radius(positional, named, 10.0)
    return CadNode("sphere", "Sphere", dict(
        x=0.0, y=0.0, z=0.0, radius=radius,
        segments=_segments(parser, named, radius, 48)))


def _b_cylinder(parser, positional, named):
    r = _get(positional, named, None, "r")
    d = _get(positional, named, None, "d")
    r1 = _get(positional, named, None, "r1")
    r2 = _get(positional, named, None, "r2")
    d1 = _get(positional, named, None, "d1")
    d2 = _get(positional, named, None, "d2")

    def half(v):
        if isinstance(v, (int, float)):
            return float(v) / 2.0
        return f"({v}) / 2"
    if r1 is None and len(positional) > 1:
        r1 = positional[1]                       # cylinder(h, r1, r2)
    if r2 is None and len(positional) > 2:
        r2 = positional[2]
    bottom = r1 if r1 is not None else (
        half(d1) if d1 is not None else (
            r if r is not None else (half(d) if d is not None else 5.0)))
    top = r2 if r2 is not None else (
        half(d2) if d2 is not None else (
            r if r is not None else (half(d) if d is not None else 5.0)))
    return CadNode("cylinder", "Cylinder", dict(
        x=0.0, y=0.0, z=0.0,
        height=_num(_get(positional, named, 0, "h", default=10.0), 10.0),
        radius_bottom=_num(bottom, 5.0), radius_top=_num(top, 5.0),
        segments=_segments(parser, named,
                           max(bottom, top) if isinstance(bottom, (int, float))
                           and isinstance(top, (int, float)) else bottom, 64),
        center=bool(named.get("center", False))))


def _components(parser, source, count):
    """An expression standing for a vector or a scalar, split into
    *count* component expressions: `v[0]`, `v[1]`… when it evaluates to
    a list, else the scalar repeated."""
    try:
        value = expr.evaluate(source, parser.scope)
    except Exception:
        value = None
    if isinstance(value, (list, tuple)):
        return [f"{source}[{i}]" if i < len(value) else None
                for i in range(count)]
    return None


def _vector3(positional, named, default=0.0, parser=None):
    v = _get(positional, named, 0, "v", default=[default] * 3)
    if isinstance(v, str) and parser is not None:
        parts = _components(parser, v, 3)
        if parts is not None:
            return [p if p is not None else default for p in parts], False
    if not isinstance(v, list):
        return [v, v, v], True                  # scalar
    v = list(v) + [default] * (3 - len(v))
    return v[:3], False


def _b_translate(parser, positional, named):
    v, _scalar = _vector3(positional, named, parser=parser)
    return CadNode("translate", "Translate",
                   dict(x=_num(v[0]), y=_num(v[1]), z=_num(v[2])))


def _b_rotate(parser, positional, named):
    v = _get(positional, named, 0, "a", default=[0.0, 0.0, 0.0])
    if isinstance(v, str) and _components(parser, v, 3):
        v = [p if p is not None else 0.0 for p in _components(parser, v, 3)]
    if not isinstance(v, list):
        v = [0.0, 0.0, v]                       # rotate(45) is about Z
    v = list(v) + [0.0] * (3 - len(v))
    return CadNode("rotate", "Rotate",
                   dict(x=_num(v[0]), y=_num(v[1]), z=_num(v[2])))


def _b_scale(parser, positional, named):
    v, _ = _vector3(positional, named, 1.0, parser=parser)
    return CadNode("scale", "Scale",
                   dict(x=_num(v[0], 1.0), y=_num(v[1], 1.0),
                        z=_num(v[2], 1.0)))


def _b_mirror(parser, positional, named):
    v, _ = _vector3(positional, named, parser=parser)
    return CadNode("mirror", "Mirror",
                   dict(x=_num(v[0]), y=_num(v[1]), z=_num(v[2])))


def _b_linear_extrude(parser, positional, named):
    return CadNode("linear_extrude", "Linear extrude", dict(
        height=_num(_get(positional, named, 0, "height", default=10.0),
                    10.0),
        twist=_num(named.get("twist", 0.0)),
        scale=_num(named.get("scale", 1.0), 1.0),
        center=bool(named.get("center", False)),
        segments=int(_num(named.get("slices", 0), 0) or 0)))


def _b_rotate_extrude(parser, positional, named):
    return CadNode("rotate_extrude", "Rotate extrude", dict(
        angle=_num(named.get("angle", 360.0), 360.0),
        segments=_segments(parser, named, None, 96)))


def _b_offset(parser, positional, named):
    if "delta" in named:
        return CadNode("offset", "Offset", dict(
            radius=_num(named["delta"]),
            chamfer=bool(named.get("chamfer", False))))
    return CadNode("offset", "Offset", dict(
        radius=_num(_get(positional, named, 0, "r", default=1.0), 1.0),
        chamfer=False))


def _b_projection(parser, positional, named):
    return CadNode("projection", "Projection",
                   dict(cut=bool(named.get("cut", False))))


def _b_import(parser, positional, named):
    path = _get(positional, named, 0, "file", default="")
    if str(path).lower().endswith(_scadfiles.DRAWING_EXTS):
        return _scadfiles.build_import_2d(parser, positional, named,
                                          str(path))
    return CadNode("stl_import", "Import STL",
                   dict(path=str(path), x=0.0, y=0.0, z=0.0))


def _b_color(parser, positional, named):
    value = _get(positional, named, 0, "c", default="#4a90d9")
    alpha = _num(_get(positional, named, 1, "alpha", default=1.0), 1.0)
    if isinstance(value, list):
        rgb = [max(0.0, min(1.0, _num(v, 0.0))) for v in value[:3]]
        while len(rgb) < 3:
            rgb.append(0.0)
        if len(value) > 3:
            alpha = _num(value[3], 1.0)
        value = "#%02x%02x%02x" % tuple(int(round(c * 255))
                                        for c in rgb)
    return CadNode("color", "Color",
                   dict(color=str(value), alpha=alpha))


def _simple(type_, label):
    return lambda parser, positional, named: CadNode(type_, label)


_BUILDERS = {
    "circle": _b_circle, "square": _b_square, "polygon": _b_polygon,
    "text": _b_text, "cube": _b_cube, "sphere": _b_sphere,
    "cylinder": _b_cylinder,
    "translate": _b_translate, "rotate": _b_rotate,
    "scale": _b_scale, "mirror": _b_mirror,
    "linear_extrude": _b_linear_extrude,
    "rotate_extrude": _b_rotate_extrude,
    "offset": _b_offset, "projection": _b_projection,
    "import": _b_import, "color": _b_color,
    "union": _simple("union", "Group"),
    # a .csg file (OpenSCAD's own flattened export) groups with group()
    "group": _simple("union", "Group"),
    "difference": _simple("difference", "Difference"),
    "intersection": _simple("intersection", "Intersection"),
    "hull": _simple("hull", "Hull"),
    "minkowski": _simple("minkowski", "Minkowski"),
}
# kcad_* helper-module calls rebuild the organic nodes they came from
from . import organic as _organic  # noqa: E402
from . import scadlang as _scadlang  # noqa: E402
from . import scadinclude as _scadinclude  # noqa: E402
from . import scadfiles as _scadfiles  # noqa: E402

_BUILDERS.update(_organic.BUILDERS)

#: a name in an expression (group 1; a "string" matches with no group)
#: and whether it is called (group 2)
_NAME_RE = re.compile(r'"(?:\\.|[^"\\])*"|(?<![\w.$])(\$?[A-Za-z_]\w*)(\s*\()?')
#: special variables that change while the program runs ($t animates):
#: an expression reading one is never frozen
_LIVE = {"$t", "$preview", "$vpr", "$vpt", "$vpd", "$vpf", "$children"}
#: words of the expression language that are not variables
_WORDS = {"for", "if", "else", "let", "each", "function", "assert", "echo",
          "true", "false", "undef"}

#: shape types whose x/y(/z) a wrapping translate can be folded into.
_FOLDABLE = {"circle", "rect", "polygon", "text", "cube", "sphere",
             "cylinder", "stl_import", "import_2d"}


def _fold_container(node: CadNode):
    """Simplify freshly-parsed containers:

    - translate wrapping one plain shape -> shape with x/y/z set;
    - hull of exactly two equal circles -> a line node (that is how
      KherveCAD compiles lines).
    """
    folded = _organic.fold_material(node)
    if folded is not None:
        return folded
    if node.type == "translate" and len(node.children) == 1:
        child = node.children[0]
        if child.type in _FOLDABLE and \
                _is_zero(child.params.get("x")) and \
                _is_zero(child.params.get("y")) and \
                _is_zero(child.params.get("z", 0.0)):
            child.params["x"] = node.params["x"]
            child.params["y"] = node.params["y"]
            if "z" in child.params:
                child.params["z"] = node.params["z"]
            elif not _is_zero(node.params.get("z", 0.0)):
                return None                     # 2D shape lifted in z
            node.remove(child)
            child.visible = node.visible and child.visible
            return child
    if node.type in ("rotate", "scale") and len(node.children) == 1 \
            and node.children[0].type == "stl_import":
        # an import is emitted as `translate() rotate() scale() import()`
        # — fold them back in innermost first, and only while what is
        # already folded sits inside (a rotate of a translated mesh is
        # not the same part)
        child = node.children[0]
        p, q = child.params, node.params
        bare = all(_is_zero(p.get(k, 0.0))
                   for k in ("x", "y", "z", "rx", "ry", "rz"))
        folded = False
        if bare and node.type == "rotate":
            p["rx"], p["ry"], p["rz"] = (q.get(k, 0.0)
                                         for k in ("x", "y", "z"))
            folded = True
        elif bare and p.get("scale", 1.0) == 1 and \
                q.get("x") == q.get("y") == q.get("z"):
            p["scale"] = q.get("x", 1.0)
            folded = True
        if folded:
            node.remove(child)
            child.visible = node.visible and child.visible
            return child
    if len(node.children) == 1 and \
            node.children[0].type in ("component", "reference"):
        # a component's / instance's call is emitted as `color(...)
        # translate(...) rotate(...) Name();` — fold those wrappers
        # back into its own placement/colour params (innermost first,
        # as the parse recursion unwinds).
        child = node.children[0]
        p = child.params
        folded = False
        if node.type == "translate" and all(
                _is_zero(p.get(k, 0.0)) for k in ("x", "y", "z")):
            for k in ("x", "y", "z"):
                p[k] = node.params.get(k, 0.0)
            folded = True
        elif node.type == "rotate" and all(
                _is_zero(p.get(k, 0.0)) for k in ("rx", "ry", "rz")):
            for k, src in (("rx", "x"), ("ry", "y"), ("rz", "z")):
                p[k] = node.params.get(src, 0.0)
            folded = True
        elif node.type == "color" and child.type == "component" and \
                not str(p.get("color", "")).strip():
            p["color"] = node.params.get("color", "")
            p["alpha"] = node.params.get("alpha", 1.0)
            folded = True
        if folded:
            node.remove(child)
            child.visible = node.visible and child.visible
            return child
    if node.type == "hull" and len(node.children) == 2 and \
            all(c.type == "circle" for c in node.children):
        a, b = node.children
        ra, rb = a.params.get("radius"), b.params.get("radius")
        if ra == rb and isinstance(ra, (int, float)):
            line = CadNode("line", "Line", dict(
                x1=a.params["x"], y1=a.params["y"],
                x2=b.params["x"], y2=b.params["y"],
                width=2.0 * ra))
            line.visible = node.visible
            return line
    return None


def _is_zero(value):
    return isinstance(value, (int, float)) and abs(value) < 1e-12


# ------------------------------------------------------------- API

#: Leaf node types that actually emit geometry. A container built only
#: from other things (assignments, empty operations) produces nothing.
_GEOMETRY_LEAVES = {
    "cube", "sphere", "cylinder", "stl_import", "circle", "rect",
    "polygon", "text", "line", "scad_raw", "reference",
} | _organic.LEAVES
#: Container/operation types that are meaningless when they wrap no
#: geometry — pruned on import so a skipped ``children()`` does not leave
#: an empty red node behind.
_PRUNE_WHEN_DEAD = {
    "translate", "rotate", "scale", "mirror", "offset", "color",
    "linear_extrude", "rotate_extrude", "projection",
    "union", "difference", "intersection", "hull", "minkowski",
    "if_else",
} | _organic.WRAPPERS


def _has_geometry(node) -> bool:
    if node.type in _GEOMETRY_LEAVES:
        return True
    return any(_has_geometry(child) for child in node.children)


def _prune_dead(root) -> None:
    """Drop operation/boolean nodes that end up wrapping no geometry —
    e.g. a module whose body was a bare ``children()`` we could not
    inline. Cascades bottom-up so a whole dead branch disappears rather
    than surfacing as empty red nodes."""
    changed = True
    while changed:
        changed = False
        for node in list(root.walk()):
            parent = node.parent
            if parent is None or node.type not in _PRUNE_WHEN_DEAD:
                continue
            if not _has_geometry(node):
                parent.remove(node)
                changed = True


def parse_scad(text: str, base_dir=None):
    """Parse *text* into (root CadNode, warnings list). *base_dir* is
    the folder `use <...>` / `include <...>` resolve against first."""
    parser = Parser(text, base_dir)
    root = parser.parse_program()
    _prune_dead(root)
    return root, parser.warnings


def import_scad(model, path: str):
    """Load a .scad file into *model*, replacing the document.
    Returns the list of warnings."""
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    root, warnings = parse_scad(text, os.path.dirname(os.path.abspath(path)))
    # OpenSCAD reads import("part.stl") beside the .scad, not beside
    # wherever the app was started
    from .meshimport import resolve_paths
    resolve_paths(root, os.path.dirname(os.path.abspath(path)))
    model.root = root
    model.group_variables()               # gather loose top-level vars
    model.structure_changed.emit()
    return warnings
