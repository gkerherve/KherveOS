"""Extrude extents (Qt-free), 2026-10-21 — SolidWorks' end conditions
Through All and Up To Surface, from the user's "do them all".

A `linear_extrude` may carry schema-only params:

- ``extent`` "" (blind: its own height, as before), "through_all" or
  "up_to";
- ``up_to``  the NAME of the node it extrudes up to, ``up_to_side``
  "far" / "near" (that node's far or near face along the extrude) and
  ``up_to_offset`` mm beyond it.

`refresh` (called from MainWindow._model_edited, like the sketch
constraints) works the height out from the geometry and WRITES it into
``height`` (and ``center``), so codegen and the preview are untouched
and the program stays plain OpenSCAD; editing the target moves the depth
with it. Through All cuts through the body it is subtracted from (the
first child of the nearest `difference` holding it), else through the
whole scope, centred so it reaches both ways.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

EXTENTS = ("", "through_all_one", "through_all", "up_to_next",
           "up_to_vertex", "up_to_face", "offset_face", "up_to",
           "mid_plane")
#: SolidWorks' names, in its order (2026-10-31, the user's picture of
#: the Extruded Cut's Direction 1 list). "through_all" was here first
#: and reaches BOTH ways, so it keeps that meaning; "through_all_one"
#: is SolidWorks' plain Through All, one way.
LABELS = {"": "Blind", "through_all_one": "Through All",
          "through_all": "Through All - Both", "up_to_next": "Up To Next",
          "up_to_vertex": "Up To Vertex", "up_to_face": "Up To Surface",
          "offset_face": "Offset From Surface", "up_to": "Up To Body",
          "mid_plane": "Mid Plane"}
#: the ones waiting for a click in 3D: what to click
PICKS = {"up_to_vertex": "vertex", "up_to_face": "face",
         "offset_face": "face", "up_to": "body"}
#: the ones that keep the Distance the user typed
KEEPS_HEIGHT = ("mid_plane",)
SIDES = ("far", "near", "contact")
MARGIN = 1.0

SCHEMA = [("extent", "End condition", "choice", EXTENTS, None),
          ("up_to", "Up to (object name)", "str", None, None),
          ("up_to_side", "Up to its", "choice", SIDES, None),
          ("up_to_offset", "Offset beyond (mm)", "float", -1e6, 1e6)]
TEXT = {"extent", "up_to", "up_to_side"}
# "up_to_vertex": ``up_to_point`` [x, y, z] world, the depth is where it
# lies along the extrude. "up_to_next": the first surface every ray from
# the profile meets. "mid_plane": the Distance as typed, centred.
# "up_to_face" (2026-10-27, SolidWorks' Up To Surface by a CLICK): the
# picked face as ``up_to_face`` [x, y, z, nx, ny, nz] in world
# coordinates; the depth is where the extrude's axis, through its
# sketch's centre, meets that face's plane (+ ``up_to_offset``).


def _np():
    import numpy as np
    return np


def _world_points(node, env):
    from . import mesh
    tris = mesh.tessellate(node, env)
    if not tris:
        return None
    np = _np()
    pts = np.array([p for t in tris for p in t], float)
    m = np.array(mesh.ancestor_matrix(node, env), float)
    return pts @ m[:3, :3].T + m[:3, 3]


def _frame(extrude, env):
    """4x4 of the extrude's own frame, +Z the way it GOES: its Reverse
    direction param (every cut's) flips it — the end conditions looked
    out of the part, away from the cut (2026-11-01, the user)."""
    from . import mesh
    np = _np()
    m = np.array(mesh.ancestor_matrix(extrude, env), float)
    if extrude.params.get("reverse"):
        m = m @ np.diag([1.0, 1.0, -1.0, 1.0])
    return m


def _local_z(extrude, pts, env):
    """z of world points along the way the extrude goes."""
    np = _np()
    inv = np.linalg.inv(_frame(extrude, env))
    return pts @ inv[2, :3] + inv[2, 3]


def _before(model, extrude):
    """What the extrude meets when it cuts nothing: what was built before
    it in its Object (or the document), visible; else what comes after.
    The whole document's top level left out its own Object and took the
    other Objects, hidden ones too."""
    earlier, later = [], []
    probe = extrude
    while probe.parent is not None:
        kids = probe.parent.children
        i = kids.index(probe)
        earlier += kids[:i]
        later += kids[i + 1:]
        if probe.parent.type == "component":
            break
        probe = probe.parent
    keep = [n for n in earlier if n.visible]
    return keep or [n for n in later if n.visible]


def _body_for(extrude):
    """What Through All cuts: the first child of the nearest difference
    the extrude is a cutter of, else None (the whole scope)."""
    child, probe = extrude, extrude.parent
    while probe is not None:
        if probe.type == "difference" and probe.children and \
                probe.children[0] is not child:
            return probe.children[0]
        child, probe = probe, probe.parent
    return None


def _find(model, name, extrude):
    hits = [n for n in model.root.walk()
            if n.name == name and n is not extrude
            and not _is_inside(extrude, n)]
    return hits[0] if hits else None


def _is_inside(node, ancestor):
    p = node
    while p is not None:
        if p is ancestor:
            return True
        p = p.parent
    return False


def height_for(model, extrude, env=None):
    """(height, center) the extent asks for, or raise ValueError."""
    from .anchors import doc_env
    env = doc_env(model) if env is None else env
    kind = extrude.params.get("extent") or ""
    if kind == "mid_plane":
        return float(extrude.params.get("height") or 10.0), True
    if kind == "through_all_one":
        pts = _cut_points(model, extrude, env)
        z = _local_z(extrude, pts, env)
        if float(z.max()) <= 0.01:
            raise ValueError("Through all: the part is behind the sketch "
                             "(try Reverse direction).")
        return round(float(z.max()) + MARGIN, 4), False
    if kind == "up_to_vertex":
        row = extrude.params.get("up_to_point") or []
        if len(row) < 3:
            raise ValueError("Up to vertex: no vertex picked.")
        z = _local_z(extrude, _np().array([row[:3]], float), env)
        h = float(z[0]) + float(extrude.params.get("up_to_offset") or 0.0)
        if h <= 0.01:
            raise ValueError("Up to vertex: the vertex is behind the "
                             "sketch (try Reverse direction).")
        return round(h, 4), False
    if kind == "up_to_next":
        return _to_next(model, extrude, env), False
    if kind == "through_all":
        body = _body_for(extrude)
        if body is None:
            pts = [_world_points(c, env) for c in _before(model, extrude)]
            pts = [p for p in pts if p is not None]
            if not pts:
                raise ValueError("Through all: nothing to cut through.")
            pts = _np().concatenate(pts)
        else:
            pts = _world_points(body, env)
            if pts is None:
                raise ValueError("Through all: the body is empty.")
        z = _local_z(extrude, pts, env)
        reach = max(abs(float(z.min())), abs(float(z.max()))) + MARGIN
        return round(2 * reach, 4), True
    if kind == "up_to":
        name = str(extrude.params.get("up_to") or "").strip()
        target = _find(model, name, extrude) if name else None
        side = extrude.params.get("up_to_side") or "far"
        if target is None and side == "contact" and name and any(
                n.name == name and _is_inside(extrude, n)
                for n in model.root.walk()):
            # the body the click found is the part the extrude itself is
            # being built in: what stands BEFORE it is the body
            h = _to_next(model, extrude, env, anything=True)
            return round(h + float(extrude.params.get("up_to_offset")
                                    or 0.0), 4), False
        if target is None:
            raise ValueError("Up to: no object named %r." % name)
        pts = _world_points(target, env)
        if pts is None:
            raise ValueError("Up to: %r has no geometry." % name)
        if side == "contact":
            # SolidWorks' Up To Body: the profile lands on the body's
            # surface everywhere (2026-11-15, Exercise 58's Ø44 boss on a
            # fork: a plane through the body's near face would stop it in
            # the air over the hub)
            h = _to_contact(extrude, target, env)
            return round(h + float(extrude.params.get("up_to_offset")
                                    or 0.0), 4), False
        z = _local_z(extrude, pts, env)
        h = float(z.max() if side == "far" else z.min())
        h += float(extrude.params.get("up_to_offset") or 0.0)
        if h <= 0.01:
            raise ValueError("Up to: %r's %s face is not above the "
                             "sketch." % (name, side))
        return round(h, 4), False
    if kind in ("up_to_face", "offset_face"):
        return _to_face(extrude, env)
    raise ValueError("Blind extrude: no extent to work out.")


def _cut_points(model, extrude, env):
    """World points of what the extrude goes through: the body it is cut
    from, else everything else in the document."""
    body = _body_for(extrude)
    if body is not None:
        pts = _world_points(body, env)
        if pts is not None:
            return pts
    pts = [_world_points(c, env) for c in _before(model, extrude)]
    pts = [p for p in pts if p is not None]
    if not pts:
        raise ValueError("Through all: nothing to go through.")
    return _np().concatenate(pts)


def _world_tris(model, extrude, env):
    from . import mesh
    np = _np()
    body = _body_for(extrude)
    nodes = [body] if body is not None else _before(model, extrude)
    out = []
    for n in nodes:
        tris = mesh.tessellate(n, env)
        if not tris:
            continue
        t = np.array(tris, float).reshape(-1, 3)
        m = np.array(mesh.ancestor_matrix(n, env), float)
        out.append((t @ m[:3, :3].T + m[:3, 3]).reshape(-1, 3, 3))
    if not out:
        raise ValueError("Up to next: nothing in front of the sketch.")
    return np.concatenate(out)


def _first_hit(tris, o, d, leaving=False):
    """The smallest t > 0 where o + t d meets a triangle, or None;
    *leaving*: only a surface the ray comes OUT of."""
    np = _np()
    v0 = tris[:, 0]
    e1, e2 = tris[:, 1] - v0, tris[:, 2] - v0
    h = np.cross(d, e2)
    a = np.einsum("ij,ij->i", e1, h)
    ok = np.abs(a) > 1e-12
    f = np.where(ok, 1.0 / np.where(ok, a, 1.0), 0.0)
    s = o - v0
    u = f * np.einsum("ij,ij->i", s, h)
    q = np.cross(s, e1)
    v = f * (q @ d)
    t = f * np.einsum("ij,ij->i", e2, q)
    hit = ok & (u >= -1e-9) & (v >= -1e-9) & (u + v <= 1 + 1e-9) & \
        (t > 1e-4)
    if leaving:
        hit = hit & (a < 0)         # a = -(normal . d): it faces along d
    return float(t[hit].min()) if hit.any() else None


def _profile_depth(extrude, env, tris, leaving):
    """The depth where the LAST ray from the profile (its points drawn a
    little in, and its centre) meets its first surface, or None."""
    from . import mesh
    np = _np()
    m = _frame(extrude, env)
    try:
        loops = [o for o in mesh.collect_outlines(extrude, env) if o]
    except Exception:
        loops = []
    cx, cy = _sketch_centre(extrude, env)
    starts = [(cx, cy)]
    for loop in loops:
        step = max(1, len(loop) // 12)
        for x, y in loop[::step]:
            starts.append((x + (cx - x) * 0.02, y + (cy - y) * 0.02))
    d = m[:3, 2]                       # one local z, in world
    depth = None
    for x, y in starts:
        o = m[:3, :3] @ np.array([x, y, 0.0]) + m[:3, 3]
        # a cut goes on to where the solid ENDS. Stopping at the first
        # surface met, a sketch standing a hair off its face cut nothing
        # (the user's Circle 13: 0.02 mm of air, a depth of 0.02)
        t = _first_hit(tris, o, d, leaving=leaving)
        if t is not None:
            depth = t if depth is None else max(depth, t)
    return depth


def _to_next(model, extrude, env, anything=False):
    """Up To Next: rays along the extrude from the profile (its points
    drawn a little in, and its centre); the depth is where the LAST of
    them meets its first surface, so the whole profile gets there."""
    tris = _world_tris(model, extrude, env)
    depth = _profile_depth(extrude, env, tris,
                           _body_for(extrude) is not None)
    if depth is None:
        raise ValueError("Up to next: no surface in front of the sketch "
                         "(try Reverse direction).")
    if anything:
        return depth
    return round(depth + float(extrude.params.get("up_to_offset") or 0.0),
                 4)


def _to_contact(extrude, target, env):
    """Rays along the extrude from the profile to the body's first
    surface: the depth is where the LAST of them lands."""
    from . import mesh
    np = _np()
    raw = mesh.tessellate(target, env)
    if not raw:
        raise ValueError("Up to: %r has no geometry." % target.name)
    t = np.array(raw, float).reshape(-1, 3)
    m = np.array(mesh.ancestor_matrix(target, env), float)
    tris = (t @ m[:3, :3].T + m[:3, 3]).reshape(-1, 3, 3)
    depth = _profile_depth(extrude, env, tris, False)
    if depth is None:
        raise ValueError("Up to: %r is not in front of the sketch (try "
                         "Reverse direction)." % target.name)
    return depth


def _sketch_centre(extrude, env):
    from . import mesh
    try:
        loops = [o for o in mesh.collect_outlines(extrude, env) if o]
    except Exception:
        loops = []
    pts = [p for o in loops for p in o]
    if not pts:
        return 0.0, 0.0
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2


def _to_face(extrude, env):
    """Depth from the sketch to the picked face's plane along +Z."""
    from . import mesh
    np = _np()
    row = extrude.params.get("up_to_face") or []
    if len(row) < 6:
        raise ValueError("Up to face: no face picked.")
    q, n = np.array(row[:3], float), np.array(row[3:6], float)
    m = _frame(extrude, env)
    cx, cy = _sketch_centre(extrude, env)
    o = m[:3, :3] @ np.array([cx, cy, 0.0]) + m[:3, 3]
    a = m[:3, 2]                       # world step for one local z
    den = float(n @ a)
    if abs(den) < 1e-9:
        raise ValueError("Up to face: the face runs along the extrude, "
                         "it never meets it.")
    h = float(n @ (q - o)) / den
    h += float(extrude.params.get("up_to_offset") or 0.0)
    if h <= 0.01:
        raise ValueError("Up to face: the face is behind the sketch "
                         "(try Reverse direction).")
    return round(h, 4), False


def _track(model, extrude, env):
    """The picked vertex or surface as the model is NOW: they were kept
    as fixed coordinates, so a changed dimension left the extrude going
    to where the surface used to be (2026-11-01, the user)."""
    np = _np()
    p = extrude.params
    kind = p.get("extent")
    if kind == "up_to_vertex" and len(p.get("up_to_point") or []) >= 3:
        tris = _world_tris(model, extrude, env).reshape(-1, 3)
        q = np.array(p["up_to_point"][:3], float)
        best = tris[np.argmin(((tris - q) ** 2).sum(axis=1))]
        p["up_to_point"] = [round(float(v), 6) for v in best]
    elif kind in ("up_to_face", "offset_face") and \
            len(p.get("up_to_face") or []) >= 6:
        tris = _world_tris(model, extrude, env)
        q = np.array(p["up_to_face"][:3], float)
        n0 = np.array(p["up_to_face"][3:6], float)
        c = np.cross(tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0])
        size = np.linalg.norm(c, axis=1)
        big = size > 1e-12
        if not big.any():
            return
        tris, n = tris[big], c[big] / size[big][:, None]
        ok = n @ n0 > 0.7
        if not ok.any():
            return               # the surface has gone: said by the depth
        tris, n = tris[ok], n[ok]
        # nearest: its plane first, then along it
        off = np.abs(((q - tris[:, 0]) * n).sum(axis=1))
        along = np.linalg.norm(tris.mean(axis=1) - q, axis=1)
        i = int(np.argmin(off * 5.0 + along))
        # the same point, carried onto that plane
        moved = q + n[i] * float(n[i] @ (tris[i, 0] - q))
        p["up_to_face"] = [round(float(v), 6) for v in (*moved, *n[i])]


_BUSY = False


def refresh(model):
    """Write the height of every extent-driven extrude. Returns
    {node id: error} for the ones that could not be worked out."""
    global _BUSY
    if _BUSY:
        return {}
    _BUSY = True
    errors = {}
    try:
        from .anchors import doc_env
        env = doc_env(model)
        for node in list(model.root.walk()):
            if node.type != "linear_extrude" or \
                    not node.params.get("extent"):
                continue
            try:
                _track(model, node, env)
                h, centre = height_for(model, node, env)
            except (ValueError, ImportError) as exc:
                errors[node.id] = str(exc)
                continue
            p = node.params
            if p.get("height") != h or bool(p.get("center")) != centre:
                p["height"], p["center"] = h, centre
                model.node_changed.emit(node)
    finally:
        _BUSY = False
    return errors


def set_extent(model, extrude, kind, up_to="", side="far", offset=0.0,
               face=None, point=None):
    if kind not in EXTENTS:
        raise ValueError("extent is one of %s." % ", ".join(
            repr(k) for k in EXTENTS))
    p = extrude.params
    height = p.get("height")
    for k in ("extent", "up_to", "up_to_side", "up_to_offset",
              "up_to_face", "up_to_point"):
        p.pop(k, None)
    if kind:
        p["extent"] = kind
    if kind == "up_to":
        p["up_to"], p["up_to_side"] = up_to, side
        if offset:
            p["up_to_offset"] = float(offset)
    if kind == "up_to_vertex":
        if point is None or len(point) < 3:
            raise ValueError("Up to vertex needs the point: [x, y, z].")
        p["up_to_point"] = [round(float(v), 6) for v in point[:3]]
    if kind in ("up_to_face", "offset_face"):
        if face is None or len(face) < 6:
            raise ValueError("Up to face needs the face: [x, y, z, nx, "
                             "ny, nz].")
        p["up_to_face"] = [round(float(v), 6) for v in face[:6]]
        if offset:
            p["up_to_offset"] = float(offset)
    if kind and offset:
        p["up_to_offset"] = float(offset)
    if kind == "offset_face" and not offset:
        p["up_to_offset"] = 0.0
    if kind:
        if height is not None:
            p["height"] = height
        try:
            p["height"], p["center"] = height_for(model, extrude)
        except ValueError:
            # kept, as the user chose it (red in the tree, like a refresh
            # that fails); the windows still hear of it
            model.node_changed.emit(extrude)
            raise
    model.node_changed.emit(extrude)
    return p["height"]
