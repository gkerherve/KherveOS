"""The tool table KherveCAD offers MCP clients — schemas only.

Deliberately Qt-free and import-free: this is the contract, and
`mcp_tools.py` is the implementation.  Keeping them apart means the
tool list can be inspected (and tested) without a running window, and
the stdio server never drags PyQt5 into the host's subprocess.

Every tool answers with JSON.  ``render_view`` additionally returns a
PNG under `mcp_server.IMAGE_KEY`, which the stdio/HTTP servers turn
into a real MCP image block.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from __future__ import annotations

#: Camera presets `render_view` accepts (View3D.VIEWS).
ORIENTATIONS = ["Isometric", "Top", "Bottom", "Front", "Back", "Right",
                "Left"]

#: colour materials (model.MATERIALS — repeated for the same reason).
MATERIALS = ["Default", "Plastic", "Metal", "Matte", "Clay", "Glass",
             "Rubber", "Skin", "Gold", "Copper", "Emissive",
             "Brick", "Concrete", "Render", "Roof tiles", "Slate", "Stone",
             "Bark", "Leaves",
             "Wall tiles", "Metro tiles", "Mosaic", "Hex tiles", "Marble",
             "Floor tiles", "Checker tiles", "Terrazzo", "Zellige",
             "Floorboards", "Parquet", "Carpet", "Plaster", "Cladding",
             "Shingles", "Thatch", "Standing seam", "Solar panels",
             "Panelling", "Fabric", "Velvet", "Leather", "Bouclé",
             "Wood", "Grass",
             # creature skins (glrender.creature)
             "Scales", "Reptile", "Fur", "Feathers", "Chitin", "Slime"]

#: 3D projections (view3d.PROJECTIONS — repeated here because this
#: module must not import Qt).
PROJECTIONS = ["Perspective", "Orthographic"]

#: `publish_to_printables` choices.  They live here rather than in
#: `printables.py` because that module imports PyQt5 and this one must
#: not — the stdio server reads this table in a bare interpreter.
LICENSES = [
    "CC BY-SA 4.0", "CC BY 4.0", "CC0 1.0", "CC BY-NC 4.0",
    "CC BY-NC-SA 4.0", "CC BY-ND 4.0", "CC BY-NC-ND 4.0",
    "GPL-3.0", "Standard Digital File License",
]
DEFAULT_LICENSE = "CC BY-SA 4.0"

#: Printables' add-a-model form asks for a main category, a one-line
#: summary and where the design came from, and none of those are in the
#: geometry — so the bundle answers them and the tool takes them.
CATEGORIES = [
    "3D Printing", "Art & Design", "Costumes & Accessories", "Fashion",
    "Gadgets", "Healthcare", "Hobby & Makers", "Household", "Learning",
    "Models", "Seasonal Designs", "Sports & Outdoor", "Tools",
    "Toys & Games", "World & Scans",
]
DEFAULT_CATEGORY = "Hobby & Makers"
ORIGINS = ["My own design", "A remix", "A scan",
           "Someone else's design"]
DEFAULT_ORIGIN = ORIGINS[0]

#: Printables caps the summary field.
SUMMARY_LIMIT = 120

#: What the bundle can contain, by extension.
FORMATS = ("stl", "3mf", "scad", "kcad")

#: The three-quarter stills: every corner from above, the classic
#: product angles and the underside — pictures of a solid, where a face
#: seen square-on reads as a flat 2D drawing.  The front-right
#: isometric leads, as the cover.
ISO_VIEWS = ("Isometric", "Isometric front-left", "Isometric back-right",
             "Isometric back", "Three-quarter front", "Bird's-eye",
             "Low angle", "Underside")

#: The square-on faces, still on offer when a listing wants them.
ORTHO_VIEWS = ("Front", "Back", "Left", "Right", "Top", "Bottom")

#: Every standard still a Printables bundle or File > Export PNG can
#: render; `engine.CAMERA_ROTATIONS` holds the camera for each.
STILL_VIEWS = ISO_VIEWS + ORTHO_VIEWS

#: Camera angles rendered unless the caller says otherwise: the
#: three-quarter set.  The upload page keeps the files in order, so the
#: front-right isometric still gets the cover.
DEFAULT_VIEWS = ISO_VIEWS

#: A PNG of a named view, when no size is given (File > Export PNG,
#: export_document).
PNG_DEFAULT_SIZE = (1920, 1080)


#: Operations `wrap_nodes` can apply.  Every one of them wraps the
#: nodes it is given — that is how an extrude, a transform or a
#: boolean is applied in this app.
WRAP_TYPES = [
    "union", "difference", "intersection", "hull", "minkowski",
    "linear_extrude", "rotate_extrude", "translate", "rotate", "scale",
    "mirror", "offset", "projection", "color", "for_loop",
    "while_loop", "if_else", "component", "symmetry", "joint", "sweep",
    "section_loft", "blend", "bend", "twist", "taper", "lattice", "subdivide",
    "pattern", "shell", "sculpt", "decimate", "shrinkwrap", "bevel",
    "remesh", "wireframe", "cloth", "push_pull", "bisect", "weathering",
    "scatter", "displace", "armature", "shape_keys", "hair_strands",
    "vertex_paint", "bone",
]


def _obj(properties: dict, required=()) -> dict:
    return {"type": "object", "properties": properties,
            "required": list(required)}


_IDS = {
    "type": "array",
    "items": {"type": "integer"},
    "description": "Node ids from list_tree.",
}

_ID = {"type": "integer", "description": "A node id from list_tree."}


def _vec3(description: str) -> dict:
    return {"type": "array", "items": {"type": "number"},
            "minItems": 3, "maxItems": 3, "description": description}

#: Parameter values are numbers, booleans, strings — or expression
#: strings, which is the point of the app.
_PARAMS = {
    "type": "object",
    "description": (
        "Parameter values by name, from list_node_types. A numeric "
        "parameter also accepts an EXPRESSION STRING — \"wall * 2\", "
        "\"i * 10\", \"cos(a) * r\" — which is how a loop variable or a "
        "document variable reaches it, and what makes the model "
        "parametric."
    ),
}


TOOLS = [
    # ── Inspection ─────────────────────────────────────────────────
    {
        "name": "get_document_info",
        "description": (
            "The document as a whole: file path and unsaved state, the "
            "document UNIT (`unit`: nm, um, mm, cm, m or in — what one "
            "model unit means; every size and coordinate in every tool "
            "is in it, and keys ending _mm are true millimetres), node "
            "and Object counts, the global segment count, whether the "
            "OpenSCAD engine was found (without it booleans are only "
            "approximated in the preview), which Object the user is "
            "editing, the model's bounding box, and any validation "
            "errors. Call this first."
        ),
        "input_schema": _obj({}),
    },
    {
        "name": "list_node_types",
        "description": (
            "Every node type this app can build, with its category, its "
            "parameters and their ranges. Call it once at the start — "
            "add_node, set_params and wrap_nodes all speak these names, "
            "and guessing one wastes a call."
        ),
        "input_schema": _obj({
            "category": {
                "type": "string",
                "enum": ["2d", "3d", "op", "bool", "ctl"],
                "description": "Filter: 2D shapes, 3D primitives, "
                               "operations, booleans, control flow.",
            },
        }),
    },
    {
        "name": "list_tree",
        "description": (
            "The object tree: id, type, name, visibility, parameters and "
            "children. Ids are stable while a node lives, but undo and "
            "open rebuild the tree — re-read them afterwards."
        ),
        "input_schema": _obj({
            "node_id": dict(_ID, description=(
                "Start from this node instead of the document root.")),
            "depth": {
                "type": "integer",
                "description": "How deep to go (default 4; -1 for the "
                               "whole tree).",
            },
            "params": {
                "type": "boolean",
                "description": "Include each node's parameters "
                               "(default true).",
            },
        }),
    },
    {
        "name": "get_node",
        "description": (
            "One node in full: every parameter with its label and "
            "range, its path from the root, its children, its mate if "
            "it has one, and its error if it has one."
        ),
        "input_schema": _obj({"node_id": _ID}, ["node_id"]),
    },
    {
        "name": "get_code",
        "description": (
            "The generated OpenSCAD program. The whole document by "
            "default, or one Object/subtree standalone with node_id — "
            "which is what an Object's own view renders, in its own "
            "local frame. Read this before apply_code."
        ),
        "input_schema": _obj({
            "full": {"type": "boolean",
                     "description": "Write baked meshes (a blend's points and faces) out in full. Off by default: they are summarised, since only the node's parameters matter to read or re-apply it."},
            "node_id": dict(_ID, description=(
                "Emit just this Object/subtree as a standalone "
                "program.")),
        }),
    },
    {
        "name": "render_view",
        "description": (
            "A PNG of the 3D preview, returned as an image you can look "
            "at. Do this after building anything non-trivial — a part "
            "that is wrong is obvious in the picture and invisible in "
            "the tree. By default it first WAITS for OpenSCAD to finish "
            "the exact render, so booleans are really cut in what you "
            "see; `render_complete` says whether it finished in time. "
            "Camera parameters (azimuth, elevation, distance, zoom, "
            "target, target_node, projection, region, orientations) "
            "render from an offscreen camera and leave the user's view "
            "alone — `orientation` and `fit` alone move the user's own "
            "camera, as before. Pass the returned `camera` back to "
            "reproduce or adjust a view."
        ),
        "input_schema": _obj({
            "orientation": {
                "type": "string",
                "enum": ORIENTATIONS,
                "description": "Camera preset. On its own (or with "
                               "fit) it moves the USER'S camera; with "
                               "any camera parameter it only aims the "
                               "offscreen one. Omit to leave their view "
                               "alone.",
            },
            "view": {
                "type": "string",
                "enum": ["3d", "2d"],
                "description": "'2d' grabs the sketch/assembly view "
                               "instead. Default '3d'.",
            },
            "fit": {
                "type": "boolean",
                "description": "Frame the whole model first.",
            },
            "max_width": {
                "type": "integer",
                "description": "Scale the picture down to at most this "
                               "many pixels wide (default 900).",
            },
            "wait_for_exact": {
                "type": "boolean",
                "description": "Wait for OpenSCAD's exact render before "
                               "taking the picture (default true). "
                               "False takes whatever is on screen now.",
            },
            "timeout": {
                "type": "number",
                "description": "Seconds to wait for the exact render "
                               "(default 30, max 300). On timeout you "
                               "still get the picture, with "
                               "render_complete false.",
            },
            "azimuth": {
                "type": "number",
                "description": "Camera angle around Z, degrees: 0 looks "
                               "from +X, -90 from the front (-Y), 90 "
                               "from the back, 180 from -X.",
            },
            "elevation": {
                "type": "number",
                "description": "Camera height above the XY plane, "
                               "degrees: 90 looks straight down, "
                               "negative looks up from below.",
            },
            "distance": {
                "type": "number",
                "description": "Camera distance from the target in mm "
                               "(the scale, in orthographic). Usually "
                               "leave it to target_node/fit and use "
                               "zoom.",
            },
            "zoom": {
                "type": "number",
                "description": "After framing, move in (2 = twice as "
                               "close) or out (0.5).",
            },
            "target": {
                "type": "array",
                "items": {"type": "number"},
                "minItems": 3, "maxItems": 3,
                "description": "World point [x, y, z] in mm the camera "
                               "looks at.",
            },
            "target_node": {
                "type": "integer",
                "description": "Frame this node from list_tree: aim at "
                               "it and fit it to the picture — a "
                               "close-up of one part.",
            },
            "projection": {
                "type": "string",
                "enum": PROJECTIONS,
                "description": "Orthographic shows true proportions (no "
                               "perspective shrink) — best for checking "
                               "alignment and symmetry.",
            },
            "region": {
                "type": "array",
                "items": {"type": "number"},
                "minItems": 4, "maxItems": 4,
                "description": "Crop to [x0, y0, x1, y1] as fractions "
                               "of the picture (0-1, origin top-left). "
                               "Rendered at a higher resolution, so a "
                               "small detail comes back sharp.",
            },
            "orientations": {
                "type": "array",
                "items": {"type": "string", "enum": ORIENTATIONS},
                "description": "Several presets in ONE picture: a "
                               "labelled contact sheet, each view "
                               "framed on its own. One call instead of "
                               "one per angle.",
            },
            "overlay_reference": {
                "type": "boolean",
                "description": "Compare with the photo: the reference "
                               "image is drawn OVER the model (onion "
                               "skin), square on to its plane and "
                               "orthographic unless you aim the camera "
                               "yourself, picture and model both framed. "
                               "Where the model's outline leaves the "
                               "photo is where to sculpt next.",
            },
        }),
    },
    {
        "name": "list_parts",
        "description": (
            "The parametric part library: vacuum components (CF/KF "
            "flanges, fittings, valves, pumps, analysers, "
            "manipulators), ISO-threaded fasteners, chemistry glassware, "
            "room furniture, home furniture for every room (kitchen, "
            "bathroom, bedroom, living and dining room), ready-made cars "
            "and hand tools, LEGO-compatible bricks, plates, tiles, "
            "slopes and baseplates, and the City sections: Buildings "
            "(houses, blocks, towers, church), Trees (13 grown species, "
            "seasons), Park & sport (pitches, courts, lake, playground, "
            "complete park), Sport ('Sport: stadiums' — whole grounds "
            "for football, rugby, athletics, tennis and indoor sports in "
            "six shapes: rounded bowl one or two tiers, oval, circular, "
            "horseshoe, four straight stands, indoor arena; with roof, "
            "changing rooms, tunnel, dugouts, scoreboards — plus "
            "'Sport: pitches & courts' (rugby, badminton, volleyball, "
            "handball, 400 m track, tennis show court), 'Sport: "
            "equipment' and 'Sport: seating' incl. the players' bucket "
            "seat and dugout), Lighting & signals (street lamps, traffic "
            "lights), Landscape (hills, mountain, cliff, canyon...), "
            "Landmarks (Eiffel Tower, Big Ben...), Skyscrapers and "
            "Bridges (Golden Gate...), true size with model scales; "
            "and science in NANOMETRES: crystal unit cells and "
            "supercells, crystal SURFACES (every library crystal's usual "
            "faces, 'Surfaces: Metals' ...), graphene sheets / stacks / "
            "twisted bilayers / nanoribbons and the graphite (0001) "
            "surface ('Surfaces: Graphene & graphite'), carbon NANOTUBES "
            "of any (n, m) ('Crystals (nanotubes)'), fullerenes and ~490 "
            "molecules ('Molecules: ...'), and MY LIBRARY ('My "
            "library: <section>' — Objects the user or an assistant "
            "designed and saved with save_to_library, each with a "
            "description; search finds words in it) — "
            "with each part's standard sizes, "
            "the dimensions you may override and, where it has them, "
            "its colours. ALWAYS check it before modelling anything: "
            "call list_parts with `search` (words from the request, "
            "e.g. 'gate valve', 'sofa', 'M6 bolt'). Use a library part "
            "rather than modelling a CF flange or a brick from scratch."
        ),
        "input_schema": _obj({
            "category": {"type": "string",
                         "description": "Filter to one category."},
            "search": {"type": "string",
                       "description": "Words to look for in part "
                                      "labels, ids, categories and — for "
                                      "My library parts — descriptions "
                                      "and tags "
                                      "(every word must match; "
                                      "case-insensitive). The cheap way "
                                      "to check the library first."},
            "part_id": {"type": "string",
                        "description": "Full detail for one part, "
                                       "including its size table."},
        }),
    },
    {
        "name": "save_to_library",
        "description": (
            "Save an Object (or any node) you designed to the user's own "
            "library on disk (~/Documents/KherveCAD Library), so it is "
            "found by list_parts and reused next time instead of being "
            "modelled again. Do this for every reusable Object you "
            "design — a bracket, a piece of furniture, a character, a "
            "building — once it looks right. The TITLE says what it is "
            "and its key size ('Wall-mounted bike hook, 120 mm, two "
            "screw holes'); the DESCRIPTION says what it is for, its "
            "overall dimensions, its parameters / variables and what "
            "they change, how it is built and anything to know before "
            "reusing it — it is what a later search reads. Instances "
            "save as the Object they place, with the Objects it uses. "
            "Saving the same title in the same section again updates it."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "title": {"type": "string",
                      "description": "What it is, specific and short, "
                                     "with its key size."},
            "description": {"type": "string",
                            "description": "Several sentences: purpose, "
                                           "dimensions, parameters, "
                                           "construction, how to reuse."},
            "section": {"type": "string",
                        "description": "The AREA of work it belongs to — "
                                       "its folder: Sport, House & home, "
                                       "Buildings, Trees & plants, "
                                       "Molecules, Unit cells & crystals, "
                                       "Mechanical, Fasteners & brackets, "
                                       "Electronics, Vacuum & UHV, "
                                       "Vehicles, Characters & animals, "
                                       "3D printing, Tools, Toys & games, "
                                       "Kitchen & tableware, Music, "
                                       "Science & space — or a new area's "
                                       "name, which makes a new folder. "
                                       "Matched whatever the case, plural "
                                       "or synonym ('football' -> Sport); "
                                       "list_parts reports the areas "
                                       "that already exist."},
            "tags": {"type": "array", "items": {"type": "string"},
                     "description": "Search words: synonyms, materials, "
                                    "uses, other languages."},
        }, required=("node_id", "title", "description", "section")),
    },
    {
        "name": "list_examples",
        "description": (
            "The built-in example models, by category — a graded Learn "
            "series, mechanical parts, procedural flowers and trees, "
            "and the course projects. load_example replaces the "
            "document with one, fully editable."
        ),
        "input_schema": _obj({}),
    },
    {
        "name": "split_part",
        "description": (
            "Split a part that is too big for the print bed: two new "
            "Objects, each the part cut by the plane axis = position (in "
            "the part's own frame; omit position for the middle), joined "
            "by dowel holes placed where the section is solid, plus a "
            "dowel pin Object. The original is hidden, not deleted."
        ),
        "input_schema": _obj({
            "node_id": {"type": "integer"},
            "axis": {"type": "string", "enum": ["x", "y", "z"]},
            "position": {"type": "number"},
            "dowels": {"type": "integer", "description": "0-4 (default 2)."},
            "dowel_diameter": {"type": "number"},
            "dowel_depth": {"type": "number",
                            "description": "Total pin length, mm."},
            "clearance": {"type": "number"},
            "gap": {"type": "number",
                    "description": "How far the second half is moved "
                                   "along the axis to show both."},
        }, ["node_id"]),
    },
    {
        "name": "list_scad_libraries",
        "description": (
            "The OpenSCAD community libraries (BOSL2, MCAD, NopSCADlib, "
            "Round-Anything, dotSCAD, threads.scad, Catch'n'Hole, "
            "Gridfinity): which are installed, the include line each "
            "program starts with, and the folders use <...> / include "
            "<...> search. A program using an installed library can be "
            "sent to apply_code: its calls become objects where they "
            "import cleanly and stay OpenSCAD code (rendered exactly by "
            "the engine) where they do not."
        ),
        "input_schema": _obj({}),
    },
    {
        "name": "install_scad_library",
        "description": (
            "Download one library from list_scad_libraries (its GitHub "
            "project) into the user's OpenSCAD library folder, shared "
            "with OpenSCAD. Ask the user before installing."
        ),
        "input_schema": _obj({
            "key": {"type": "string",
                    "description": "The library key, e.g. 'BOSL2'."},
        }, ["key"]),
    },
    {
        "name": "list_anchors",
        "description": (
            "The parts that can be mated at a given scope, and the "
            "anchors of one of them. Every part has automatic "
            "bounding-box anchors — Origin, 6 face centres, 12 edge "
            "midpoints, 8 corners — plus any the user picked. These are "
            "the names attach_parts takes."
        ),
        "input_schema": _obj({
            "node_id": dict(_ID, description=(
                "The part whose anchors you want. Omit to just list the "
                "mateable parts.")),
            "scope_id": dict(_ID, description=(
                "List the parts inside this Object instead of the Main "
                "assembly.")),
        }),
    },

    # ── Building ───────────────────────────────────────────────────
    {
        "name": "get_node_bounds",
        "description": (
            "World-space bounding box of one or more nodes — min, max, "
            "size and centre in the document's unit (`unit`), where the "
            "object really sits in "
            "the assembly (every ancestor transform applied). Use it to "
            "check a part's size or position without reading the tree "
            "by hand. `approximate` flags a subtree whose booleans the "
            "built-in tessellator only approximates."
        ),
        "input_schema": _obj({"node_ids": _IDS}, ["node_ids"]),
    },
    {
        "name": "measure",
        "description": (
            "Distance between two points — explicit coordinates, a "
            "node's centre / min / max corner, or a named anchor on an "
            "Object. Between two nodes it also gives the per-axis `gap` "
            "between their boxes (> 0 clearance, < 0 overlap), "
            "`overlap` and `clearance`: is this pin clear of that wall?"
        ),
        "input_schema": _obj({"a": {
                "type": "object",
                "description": "{\"point\": [x, y, z]} or {\"node\": "
                               "id, \"at\": \"center\" | \"min\" | "
                               "\"max\" | <anchor name>}. Anchor names "
                               "(Objects/instances) come from "
                               "list_anchors.",
                "properties": {
                    "point": {"type": "array",
                              "items": {"type": "number"},
                              "minItems": 3, "maxItems": 3},
                    "node": {"type": "integer"},
                    "at": {"type": "string"},
                },
            }, "b": {
                "type": "object",
                "description": "{\"point\": [x, y, z]} or {\"node\": "
                               "id, \"at\": \"center\" | \"min\" | "
                               "\"max\" | <anchor name>}. Anchor names "
                               "(Objects/instances) come from "
                               "list_anchors.",
                "properties": {
                    "point": {"type": "array",
                              "items": {"type": "number"},
                              "minItems": 3, "maxItems": 3},
                    "node": {"type": "integer"},
                    "at": {"type": "string"},
                },
            }}, ["a", "b"]),
    },
    {
        "name": "probe_surface",
        "description": (
            "Cast a ray at the model and read the surface it hits: the "
            "world point, the outward unit normal there, the distance "
            "and which part it is. This is how to put an eye, a knob, a "
            "boss or a label ON a curved surface (a loft, a blend, a "
            "sphere) without deriving the geometry by hand: place it at "
            "point + normal * inset, orient it along the normal. The "
            "ray runs from `from` along `direction` (or through `to`); "
            "`hits` lists every crossing nearest first, each marked "
            "entering (into the solid) or leaving, so the far side of a "
            "part is one call away too. Probes the visible parts of the "
            "scope, or only `node_ids`. Uses the built-in tessellation "
            "(booleans approximated: a difference reads as its first "
            "operand)."
        ),
        "input_schema": _obj({
            "from": _vec3("Ray origin [x, y, z] in mm."),
            "direction": _vec3("Ray direction [dx, dy, dz] (any length)."),
            "to": _vec3("A point the ray passes through, instead of "
                        "`direction`."),
            "node_ids": _IDS,
            "max_hits": {"type": "integer",
                         "description": "Keep only the nearest N hits "
                                        "(default: all)."},
        }, ["from"]),
    },
    {
        "name": "sample_surface",
        "description": (
            "Scatter N points over a part's surface, each with its "
            "outward normal — for the details that come in numbers: "
            "curls of hair over a head, tubercles along a whale, rivets "
            "on a hull, pebbles on a base. Evenly spread (random darts "
            "kept `spacing` mm apart, repeatable with `seed`), limited "
            "to faces looking within `max_angle` of `facing` (the top "
            "of a head: [0, 0, 1]) and/or to a `within` box, so the "
            "face or the front stays clear. Then add one sphere or "
            "part per point, sunk `inset` mm along the normal. Fewer "
            "points come back when the surface is full at that "
            "spacing. Built-in tessellation (booleans approximated)."
        ),
        "input_schema": _obj({
            "node_ids": _IDS,
            "count": {"type": "integer",
                      "description": "Points wanted (default 20)."},
            "spacing": {"type": "number",
                        "description": "Minimum distance between points "
                                       "in mm (default: an even spread "
                                       "of `count`)."},
            "facing": _vec3("Keep faces looking this way, e.g. [0, 0, 1] "
                            "for the top."),
            "max_angle": {"type": "number",
                          "description": "Degrees off `facing` still "
                                         "kept (default 90)."},
            "within": {"type": "object",
                       "description": "World box keeping faces whose "
                                      "centre lies inside: {\"min\": "
                                      "[x, y, z], \"max\": [x, y, z]}.",
                       "properties": {"min": _vec3("Low corner."),
                                      "max": _vec3("High corner.")}},
            "seed": {"type": "integer",
                     "description": "Random seed (default 1): the same "
                                    "seed gives the same points."},
        }, ["node_ids"]),
    },
    {
        "name": "sculpt_stroke",
        "description": (
            "Sculpt a surface with brush strokes — Blender's sculpt "
            "mode, kept as parameters: grab drags the surface along "
            "`direction` by `strength` mm, inflate pushes it out along "
            "its normals (negative pulls in), smooth relaxes it, flatten "
            "presses it onto a plane, pinch draws it to the centre; each "
            "falls off to nothing at `radius`. crease carves a groove "
            "`strength` mm deep from `at` to `to`, `radius` mm either "
            "side (a wrinkle, a frown, a knuckle fold); ridge raises one "
            "(a vein, a tendon, a scar) — both taper at their ends, so "
            "short strokes in a row read as one line. `noise` (mm) with "
            "`noise_scale` (mm) roughens the whole surface — pores, old "
            "lumpy skin. CREATURE brushes: snake_hook pulls a horn, "
            "tentacle, spike or tail straight out — from `at` to `to` "
            "(the skin it stretches is refined by itself); draw raises "
            "along the patch's own normal; clay_strips lays square slabs "
            "of clay `strength` mm thick (muscle masses, folds); layer "
            "raises an even plate (a scale, a scute); elastic_grab drags "
            "with a soft falloff the whole body follows (a jaw, a belly); "
            "pose turns a limb about the joint `at` by `strength` degrees "
            "round `direction`, `tip` being any point on the limb that "
            "moves (the rest stays, `radius` blends the joint); mask "
            "freezes where it lands (strength 0-1, negative unfreezes) "
            "so later strokes leave it alone. Give one stroke, or "
            "several in `strokes` (one undo step). `node_id` is a "
            "sculpt node, or any solid — a blend, a subdivided cage, an "
            "imported scan — which is wrapped in one. Points are WORLD "
            "coordinates from probe_surface; `mirror` repeats every "
            "stroke across the part's x, y or z plane (a face from one "
            "side). This is what turns a blob of primitives into a "
            "likeness: probe the surface, push it where the photo says, "
            "render_view, repeat."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "kind": {"type": "string",
                     "enum": ["grab", "inflate", "smooth", "flatten",
                              "pinch", "crease", "ridge", "snake_hook",
                              "draw", "clay_strips", "layer",
                              "elastic_grab", "pose", "mask"]},
            "at": _vec3("Brush centre [x, y, z] in world mm (a crease / "
                        "ridge: where it starts)."),
            "to": _vec3("crease / ridge: where the line ends; snake_hook: "
                        "where the pull ends; grab / elastic_grab: where "
                        "the surface is dragged to — world mm."),
            "tip": _vec3("pose: a point on the limb that moves, world mm."),
            "radius": {"type": "number", "description": "mm."},
            "strength": {"type": "number",
                         "description": "mm for grab/inflate; 0-1 for "
                                        "smooth (more = passes), flatten "
                                        "and pinch."},
            "direction": _vec3("grab: which way to drag; pose: the "
                               "rotation axis."),
            "strokes": {"type": "array",
                        "description": "Several strokes at once: "
                                       "[{kind, at, radius, strength, "
                                       "direction, to, tip}].",
                        "items": {"type": "object"}},
            "noise": {"type": "number",
                      "description": "Skin roughness over the whole "
                                     "surface, mm along the normals "
                                     "(set on the node; 0 = smooth)."},
            "noise_scale": {"type": "number",
                            "description": "Size of the roughness, mm "
                                           "(pores ~1, lumps ~6)."},
            "seed": {"type": "integer",
                     "description": "Roughness seed."},
            "mirror": {"type": "string", "enum": ["none", "x", "y", "z"],
                       "description": "Repeat strokes across this plane "
                                      "of the part (set on the node)."},
            "detail": {"type": "number",
                       "description": "Refine the surface to this max "
                                      "edge length in mm before "
                                      "sculpting (default 0: as it is — "
                                      "a blend or a scan is dense "
                                      "already; a cube needs it)."},
        }, ["node_id"]),
    },
    {
        "name": "scatter_on_surface",
        "description": (
            "Scatter copies of one piece over a surface — Blender's "
            "particle instancing: spikes down a spine, warts, scales, "
            "barnacles, rows of teeth, eye clusters, rivets, studs. "
            "Model the piece FIRST at the origin standing up along +Z "
            "with its base at z = 0 (a cone for a spike, a flattened "
            "sphere for a wart, a small ellipsoid tilted for a scale); "
            "then give `piece_id` and `surface_id` (the body: a sculpt, "
            "a blend, a mesh) and they are wrapped in one scatter node "
            "— the piece first, the surface after it, drawn too. "
            "`count` copies darted over the surface at least `spacing` "
            "mm apart (0 = even), `seed`; `facing` + `max_angle` keep "
            "faces looking one way (the top of a back: +z, 60) and "
            "`within` {min, max} (world mm) a region. Or `path` (world "
            "points: a spine, a jaw line, a brow ridge) puts `count` "
            "copies evenly along it, each dropped onto the surface — "
            "`taper` makes them smaller towards its ends. Each copy "
            "stands along the surface normal (`align` normal / up / "
            "blend), `sink` mm into it, `scale` × (1 ± `scale_jitter`), "
            "`spin_jitter` / `tilt_jitter` degrees of randomness. "
            "`scatter_id` changes an existing one. The piece stays "
            "editable: change it and every copy follows. OpenSCAD "
            "renders the real piece at every spot (the placements are "
            "baked into kcad_scatter)."
        ),
        "input_schema": _obj({
            "piece_id": _ID,
            "surface_id": _ID,
            "scatter_id": _ID,
            "name": {"type": "string"},
            "mode": {"type": "string", "enum": ["surface", "path"]},
            "count": {"type": "integer"},
            "spacing": {"type": "number", "description": "mm."},
            "seed": {"type": "integer"},
            "scale": {"type": "number"},
            "scale_jitter": {"type": "number", "description": "0-1."},
            "spin_jitter": {"type": "number", "description": "degrees."},
            "tilt_jitter": {"type": "number", "description": "degrees."},
            "align": {"type": "string", "enum": ["normal", "up", "blend"]},
            "align_blend": {"type": "number"},
            "sink": {"type": "number", "description": "mm into the "
                                                      "surface."},
            "facing": {"type": "string",
                       "enum": ["any", "+z", "-z", "+x", "-x", "+y", "-y"]},
            "max_angle": {"type": "number"},
            "within": {"type": "object",
                       "description": "{min: [x, y, z], max: [x, y, z]} "
                                      "world mm."},
            "path": {"type": "array", "items": {"type": "array"},
                     "description": "World points [[x, y, z], ...]."},
            "taper": {"type": "number", "description": "0-1."},
            "show_target": {"type": "boolean"},
        }),
    },
    {
        "name": "rig_armature",
        "description": (
            "Give ANY body bones so it bends — Blender's armature with "
            "automatic weights. A sculpted or blended monster is one skin: "
            "joints only turn rigid pieces, an armature bends it at the "
            "elbow. `node_id` is the body (it is wrapped in an armature) "
            "or an armature to change. `bones`: [{name, parent, head: [x, "
            "y, z], tail: [x, y, z]}] in WORLD mm — a chain down each "
            "limb, the spine, the neck, the tail, heads at the joints; "
            "every vertex is bound to the bones nearest it and the "
            "weights are smoothed so joints bend as sleeves (`falloff` "
            "higher = stiffer, `smooth` passes, `detail` mm refines a "
            "coarse mesh first). `pose`: {bone: {rx, ry, rz}} degrees "
            "about the bone's head in the part's axes, carried to every "
            "bone below it. `from_skin` takes the bones from a skin "
            "node's skeleton. Afterwards set_pose (node_id + bones) poses "
            "it and reach (IK) moves a bone's tip to a point. Name bones "
            "Head, Tail, Left wing, Front left leg … and "
            "send_to_planetcraft cuts the body into the game's walking "
            "parts by bone."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "name": {"type": "string"},
            "bones": {"type": "array", "items": {"type": "object"},
                      "description": "[{name, parent, head, tail}] world "
                                     "mm."},
            "pose": {"type": "object",
                     "description": "{bone: {rx, ry, rz}} degrees."},
            "from_skin": dict(_ID, description="A skin node: one bone per "
                                               "skeleton edge."),
            "falloff": {"type": "number"},
            "smooth": {"type": "integer"},
            "detail": {"type": "number"},
        }, ["node_id"]),
    },
    {
        "name": "shape_key",
        "description": (
            "Shape keys (morph targets) — Blender's: a blink, an open "
            "jaw, a snarl, a breath, blended by a 0-1 value. `node_id` is "
            "the face/body (wrapped in a shape_keys node) or one to "
            "change. `key` names a key and `strokes` sculpts it: the same "
            "brushes as sculpt_stroke ({kind, at, radius, strength, "
            "direction, to, tip}, WORLD mm — grab an eyelid down, pinch "
            "the lips, grab the jaw open), applied once to the base "
            "(`replace` true: the key's old strokes go). `value` sets its "
            "weight now; `slider` true makes a document variable with a "
            "0-1 Customizer slider (group 'Shape keys') drive it, so "
            "play_motion animates it; `values` {key: value} sets several. "
            "A key keeps the vertices (no snake_hook). Put shape keys "
            "OUTSIDE the sculpt, inside the armature: the face morphs, "
            "then the body poses."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "key": {"type": "string"},
            "strokes": {"type": "array", "items": {"type": "object"}},
            "replace": {"type": "boolean"},
            "value": {"type": ["number", "string"]},
            "slider": {"type": "boolean"},
            "values": {"type": "object"},
            "mirror": {"type": "string", "enum": ["none", "x", "y", "z"]},
            "detail": {"type": "number"},
        }, ["node_id"]),
    },
    {
        "name": "grow_hair",
        "description": (
            "Grow real STRANDS of hair or fur from a surface — Blender's "
            "hair particles: a troll's mane, a beard, fur tufts, a ruff, "
            "whiskers (the hair cap only makes a bumpy shell). `node_id` "
            "is the head/body (wrapped in hair_strands, drawn as it is) "
            "or one to change. `count` strands of `length` mm (± "
            "`length_jitter`), `root_radius` → `tip_radius`; `gravity` "
            "0-1 droops them, `curl` mm + `curl_turns` corkscrews them, "
            "`clumps` locks with `clump_strength` 0-1 gathers them (a "
            "mane reads as locks), `comb_x/y/z` + `comb_strength` combs "
            "them one way (fur lying back: comb_x -1, strength 2). "
            "`within` {min, max} world mm keeps them to the scalp / chin "
            "/ back; `clear` (default -y) + `clear_angle` keeps them off "
            "the face. `color` and `material` (Fur, Matte…) colour the "
            "strands. Keep count × segments modest: each strand is ~50 "
            "triangles."
        ),
        "input_schema": _obj({
            "node_id": _ID, "name": {"type": "string"},
            "count": {"type": "integer"}, "length": {"type": "number"},
            "length_jitter": {"type": "number"},
            "root_radius": {"type": "number"},
            "tip_radius": {"type": "number"},
            "segments": {"type": "integer"}, "sides": {"type": "integer"},
            "gravity": {"type": "number"}, "curl": {"type": "number"},
            "curl_turns": {"type": "number"},
            "clumps": {"type": "integer"},
            "clump_strength": {"type": "number"},
            "comb_x": {"type": "number"}, "comb_y": {"type": "number"},
            "comb_z": {"type": "number"},
            "comb_strength": {"type": "number"},
            "within": {"type": "object",
                       "description": "{min: [x, y, z], max: [x, y, z]} "
                                      "world mm."},
            "clear": {"type": "string",
                      "enum": ["none", "-y", "+y", "-x", "+x", "+z", "-z"]},
            "clear_angle": {"type": "number"},
            "seed": {"type": "integer"},
            "color": {"type": "string"}, "material": {"type": "string"},
        }, ["node_id"]),
    },
    {
        "name": "paint_stroke",
        "description": (
            "Brush colour onto a part by hand — Blender's Vertex Paint: "
            "stripes, war paint, blood, scars, a pale belly, the dark "
            "tip of a tail, spots placed where you want them (weathering "
            "colours by shape; this is your own brush). `node_id` is the "
            "part (wrapped in vertex_paint, keeping its own colour "
            "underneath) or a vertex_paint node. A stroke is {at, to, "
            "radius, color, strength 0-1, hardness 0-1} in WORLD mm — "
            "`to` makes it a line (a stripe, a scar), without it a dab; "
            "points from probe_surface or sample_surface. Several in "
            "`strokes` land as one undo step; later strokes paint over "
            "earlier ones; `clear` wipes the old ones first. Put "
            "weathering OUTSIDE it to dirty the paint too."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "at": _vec3("Dab centre / line start, world mm."),
            "to": _vec3("Line end, world mm."),
            "radius": {"type": "number"},
            "color": {"type": "string"},
            "strength": {"type": "number"},
            "hardness": {"type": "number"},
            "strokes": {"type": "array", "items": {"type": "object"}},
            "clear": {"type": "boolean"},
        }, ["node_id"]),
    },
    {
        "name": "edit_mesh",
        "description": (
            "Edit a part vertex by vertex — Blender's Edit Mode (the user "
            "has it too: Tab over the 3D view). `operation` open turns "
            "the part into an editable polyhedron if it is not one (a "
            "cube becomes 8 vertices and 6 quads; an Object keeps its "
            "name, placement and colour) and lists its vertices in WORLD "
            "mm with the faces; then move (`delta`, with `proportional` "
            "mm to drag the neighbourhood smoothly and `mirror` x/y/z to "
            "edit both halves), set (one vertex to `to`), subdivide "
            "(the faces whose every corner is chosen; `cuts`), extrude "
            "(those faces pushed out `distance` mm, joined by side walls), "
            "merge (to the centre or `to`), dissolve, smooth (`factor`, "
            "`passes`), split_edge (`edge` [a, b] at `t`: a new vertex), "
            "poke (a new vertex inside `face`, at `at`). Box-modelling a "
            "creature from a cube: inset (the chosen faces get a border "
            "`thickness` mm wide, the inner part pushed `depth` mm — a "
            "horn's base, an eye socket; `individual` per face), "
            "loop_cut (`edge` [a, b] of a ring of quads: a new edge loop "
            "round a limb, `cuts` evenly), knife (split every face the "
            "plane through `at` with `normal` crosses — or only the "
            "chosen faces), bridge (two chosen face regions with equal "
            "rims removed and joined by a tube: a handle, a tunnel, a "
            "limb joined to a body), spin (the chosen faces extruded "
            "`steps` times, turned `angle`° about the axis through "
            "`origin` along `axis`, scaled to `taper` by the end — a "
            "curving horn, a tusk, a coiled tail). Choose vertices "
            "by `vertices` (indices), `within` (a world box) or `all`. "
            "The solid always stays closed — an edit that would break "
            "it is refused and nothing changes. Each call is one undo "
            "step and returns the new `selection` (e.g. the extruded "
            "copy, ready to move). Use it for shapes no primitive gives "
            "— a hull, a nose cone, a wedge, a low-poly figure — then "
            "render_view."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "operation": {"type": "string",
                          "enum": ["open", "move", "set", "subdivide",
                                   "extrude", "merge", "dissolve",
                                   "smooth", "split_edge", "poke",
                                   "inset", "loop_cut", "knife", "bridge",
                                   "spin"]},
            "vertices": {"type": "array", "items": {"type": "integer"},
                         "description": "Vertex indices (from open)."},
            "within": {"type": "object",
                       "description": "Choose every vertex in this world "
                                      "box: {\"min\": [x, y, z], "
                                      "\"max\": [x, y, z]}.",
                       "properties": {"min": _vec3("Low corner."),
                                      "max": _vec3("High corner.")}},
            "all": {"type": "boolean", "description": "Every vertex."},
            "delta": _vec3("move: world mm."),
            "to": _vec3("set / merge: world position."),
            "proportional": {"type": "number",
                             "description": "move / set: radius (mm) "
                                            "round the chosen vertices "
                                            "that follows with a smooth "
                                            "falloff (0: off)."},
            "falloff": {"type": "string",
                        "enum": ["smooth", "linear", "sharp", "root",
                                 "sphere", "constant"]},
            "mirror": {"type": "string", "enum": ["none", "x", "y", "z"],
                       "description": "move / set: also move each "
                                      "vertex's mirror image across the "
                                      "part's own x, y or z = 0 plane."},
            "distance": {"type": "number",
                         "description": "extrude: mm along the normal."},
            "cuts": {"type": "integer",
                     "description": "subdivide: how many times."},
            "factor": {"type": "number",
                       "description": "smooth: 0-1 (default 0.5)."},
            "passes": {"type": "integer"},
            "edge": {"type": "array", "items": {"type": "integer"},
                     "description": "split_edge: [a, b]."},
            "t": {"type": "number",
                  "description": "split_edge: 0-1 from a (default 0.5)."},
            "face": {"type": "integer",
                     "description": "poke: face index."},
            "thickness": {"type": "number",
                          "description": "inset: border width, mm."},
            "depth": {"type": "number",
                      "description": "inset: push the inner part, mm."},
            "individual": {"type": "boolean"},
            "normal": _vec3("knife: the cutting plane's normal."),
            "origin": _vec3("spin: a point on the axis, world mm."),
            "axis": _vec3("spin: the axis direction."),
            "angle": {"type": "number", "description": "spin: degrees."},
            "steps": {"type": "integer"},
            "taper": {"type": "number",
                      "description": "spin: end size / start size."},
            "at": _vec3("poke: world point on the face (default its "
                        "centre)."),
            "include_points": {"type": "boolean",
                               "description": "List every vertex's world "
                                              "position in the result."},
            "include_faces": {"type": "boolean"},
        }, ["node_id"]),
    },
    {
        "name": "mesh_from_photo",
        "description": (
            "Turn ONE picture into a 3D surface with an image-to-3D "
            "model and import it as a mesh part: `backend` tripo "
            "(api.tripo3d.ai) or meshy (api.meshy.ai) with the user's "
            "API key (kept in the app's settings or TRIPO_API_KEY / "
            "MESHY_API_KEY), or local — a command the user configured "
            "that takes {image} and writes {output}. The result is "
            "scaled to `size_mm` on its longest side, stood on Z = 0, "
            "and is a plausible surface (the far side is guessed): "
            "sculpt it against the photo afterwards. Takes minutes; "
            "the file access needs the full level."
        ),
        "input_schema": _obj({
            "image_path": {"type": "string",
                           "description": "Absolute path of the picture."},
            "backend": {"type": "string", "enum": ["tripo", "meshy",
                                                  "local"]},
            "size_mm": {"type": "number",
                        "description": "Longest side after import "
                                       "(default 100)."},
            "name": {"type": "string",
                     "description": "Name of the imported part."},
            "api_key": {"type": "string",
                        "description": "Only when the app has none "
                                       "stored for that backend."},
            "command": {"type": "string",
                        "description": "local only: the command template "
                                       "with {image} and {output}."},
        }, ["image_path"]),
    },
    {
        "name": "face_landmarks",
        "description": (
            "Where a human figure's face landmarks are: eye_l/r, brow_l/r, "
            "cheek_l/r, mouth_l/r, jaw_l/r, ear_l/r, nose_tip, "
            "nose_bridge, forehead, lip_top, lip_bottom, chin, head_top — "
            "in the node's own frame, in world mm, and as PIXEL positions "
            "on each reference image (so they can be compared with where "
            "the photo has them). Read this, look at the photo, then "
            "fit_face."
        ),
        "input_schema": _obj({"node_id": _ID}, ["node_id"]),
    },
    {
        "name": "fit_face",
        "description": (
            "Make a human figure's face match photographs: give where "
            "its landmarks are in a reference image (pixel positions, "
            "the names from face_landmarks) and the face sliders are "
            "solved so the model's landmarks project onto them, then a "
            "smooth warp carries each landmark the rest of the way. One "
            "photo pins the two axes of its plane; a front and a side "
            "photo pin all three. The figure may be turned (the fit "
            "reads its placement) and the head's own turn, tilt and nod "
            "are solved with it. Sets the node's `targets`, `pose` and `warp` "
            "— this is what turns the generic head into a likeness; "
            "sculpt afterwards for what landmarks cannot say."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "landmarks": {
                "type": "array",
                "description": "[{name, image, px, py}] — landmark name, "
                               "reference image index (default 0), pixel "
                               "x/y in that picture (y down). Or {name, "
                               "plane, u, v} in mm on a plane.",
                "items": {"type": "object"}},
            "sliders": {"type": "array", "items": {"type": "string"},
                        "description": "Sliders to adjust (default: the "
                                       "proportions a photo pins down)."},
            "warp": {"type": "boolean",
                     "description": "Carry the residual with a warp "
                                    "(default true)."},
            "stiffness": {"type": "number",
                          "description": "Regularisation, 0.05 loose .. 2 "
                                         "stiff (default 0.3)."},
            "fit_head": {"type": "boolean",
                         "description": "Also solve the head's turn, tilt "
                                        "and nod (the head bone's pose), "
                                        "default true — a photo is rarely "
                                        "square on."},
        }, ["node_id", "landmarks"]),
    },
    {
        "name": "section",
        "description": (
            "Cut the model with a plane and get the cross-section: a "
            "hatched PNG with a grid, plus the outlines — each "
            "closed or not, its area (holes negative; `area` in the "
            "document's unit², `area_mm2` true mm²) and extent. Shows "
            "what a shaded render cannot: wall thickness, whether a "
            "bore goes through, what is inside a closed shell. Also "
            "the SECTION PROPERTIES of the cut face (`properties`: "
            "centroid, perimeter, moments of inertia about the "
            "centroid — I_<u> resists bending about the u axis — "
            "principal I1 / I2 and their angle, polar J, radii of "
            "gyration, section moduli) for beam stiffness and "
            "strength. By "
            "default it cuts what the 3D view shows after waiting for "
            "the exact render; with node_id it cuts that node's "
            "built-in tessellation. An outline that does not close "
            "means the mesh leaks on that plane."
        ),
        "input_schema": _obj({
            "axis": {"type": "string", "enum": ["x", "y", "z"],
                     "description": "The plane's normal: 'z' cuts "
                                    "horizontally (a plan), 'y' a "
                                    "front section, 'x' a side one."},
            "offset": {"type": "number",
                       "description": "Where along the axis, in the "
                                      "document's unit. Defaults to "
                                      "the model's middle."},
            "node_id": {"type": "integer",
                        "description": "Cut just this node instead of "
                                       "the whole view."},
            "include_points": {"type": "boolean",
                               "description": "Also return each "
                                              "outline's (u, v) points."},
            "max_width": {"type": "integer",
                          "description": "Picture width (default 700)."},
            "wait_for_exact": {"type": "boolean",
                               "description": "Wait for OpenSCAD's "
                                              "exact render first "
                                              "(default true)."},
            "timeout": {"type": "number",
                        "description": "Seconds to wait (default 30)."},
        }, ["axis"]),
    },
    {
        "name": "check_code",
        "description": (
            "Dry-run an OpenSCAD program: parse and validate it exactly "
            "as apply_code would, WITHOUT touching the model. Returns "
            "what it would create (node types and counts), every "
            "statement the importer skipped (`warnings`) and every "
            "node that would turn red (`problems`). Use it before a "
            "big apply_code, or to learn whether a construct is in the "
            "importable subset."
        ),
        "input_schema": _obj({
            "code": {"type": "string",
                     "description": "The OpenSCAD program."},
        }, ["code"]),
    },
    {
        "name": "add_node",
        "description": (
            "Create a node. Without a parent it lands in the scope the "
            "user is working in — inside the Object they have open, "
            "else at the assembly root. Returns the new node's id. A "
            "sketch's Straight Slot is a line with width = the slot's "
            "width and slot: true (a closed slot, cut out of an outline "
            "round it when extruded)."
        ),
        "input_schema": _obj({
            "type": {"type": "string",
                     "description": "A type from list_node_types."},
            "params": _PARAMS,
            "name": {"type": "string",
                     "description": "Shown in the tree; auto-named if "
                                    "omitted. Say what it is, in the "
                                    "form \"Cube [Body]\"."},
            "parent_id": dict(_ID, description="Where to put it."),
            "index": {"type": "integer",
                      "description": "Position among the parent's "
                                     "children."},
        }, ["type"]),
    },
    {
        "name": "set_params",
        "description": (
            "Change parameters, name or visibility on existing nodes. "
            "Only the keys you pass are touched. Typing a placement "
            "(x/y/z/rx/ry/rz) onto a mated part releases the mate — "
            "the mate would otherwise overwrite what you set."
        ),
        "input_schema": _obj({
            "changes": {
                "type": "array",
                "description": "One entry per node.",
                "items": _obj({
                    "id": {"type": "integer"},
                    "params": _PARAMS,
                    "name": {"type": "string"},
                    "visible": {"type": "boolean"},
                }, ["id"]),
            },
        }, ["changes"]),
    },
    {
        "name": "play_motion",
        "description": (
            "Set the model MOVING in front of the user: press the "
            "Customizer's play on a slider variable, sweeping it back "
            "and forth so every part it drives moves — gears turn, a "
            "piston runs, a planet spins and its moons orbit. CALL THIS "
            "whenever the user asks to make it move, rotate, spin, "
            "turn, run, animate, play or 'show it in action' — once the "
            "motion is built, as the last step, so they SEE it. With no "
            "arguments it plays the model's motion slider (one in a "
            "Motion or Time group, or named angle / days / time / spin "
            "…). `spin` with a part's id makes a still part turn: it "
            "adds a <part>_spin slider (0-360°) to that part's rz and "
            "plays it — 'make the Earth rotate' on a plain globe. "
            "play: false stops it. Playing goes on until stopped or a "
            "structural edit; it changes nothing you have to undo."
        ),
        "input_schema": _obj({
            "variable": {"type": "string",
                         "description": "The slider to play, by name "
                                        "(earth_days, or just days). "
                                        "Omit for the motion slider."},
            "id": dict(_ID, description="Or the slider variable's "
                                        "assign node id."),
            "spin": dict(_ID, description=(
                "Make this part (an Object, instance or group) turn "
                "about its own Z, then play it.")),
            "play": {"type": "boolean",
                     "description": "False stops whatever is playing. "
                                    "Default true."},
        }),
    },
    {
        "name": "set_pose",
        "description": (
            "Pose a character in one call: set the bend angles of any "
            "number of `joint` nodes, by name or id — or, with node_id "
            "and `bones`, pose a human figure's own rig (MakeHuman's "
            "163 bones with skin weights). A joint rotates "
            "everything inside it about its pivot, and joints nest — a "
            "hand in a forearm in an upper arm — so the tree IS the "
            "armature and a pose is a handful of angles. Angles past a "
            "joint's min/max limits are clamped (and reported). The "
            "result lists every joint with its pivot and angles; pass "
            "{} to just list them."
        ),
        "input_schema": _obj({
            "joints": {
                "type": "object",
                "description": "{\"<joint name or id>\": {\"rx\": deg, "
                               "\"ry\": deg, \"rz\": deg}, ...}. An "
                               "axis left out keeps its angle.",
            },
            "node_id": dict(_ID, description=(
                "A human figure or an armature (or the Object holding "
                "it): pose its rig with `bones` instead of joint "
                "nodes.")),
            "bones": {
                "type": "object",
                "description": "For a human figure: {\"<bone>\": {\"rx\": "
                               "deg, \"ry\": deg, \"rz\": deg}} — "
                               "MakeHuman's rig (upperarm01/02.L/R, "
                               "lowerarm01/02, wrist, upperleg01/02, "
                               "lowerleg01/02, foot, spine01-05, "
                               "neck01-03, head, jaw, clavicle, ...); "
                               "pass {} to list the bones. Angles turn "
                               "the bone about its head in the body's "
                               "axes and carry everything below it.",
            },
        }),
    },
    {
        "name": "render_photo",
        "description": (
            "A PHOTOREAL picture of the model (Blender Cycles in the "
            "background: real light and shadow, metal that reflects, "
            "glass you see through, emissive parts that glow) — for a "
            "listing, a presentation or the user's approval, not for "
            "checking geometry (render_view is instant). Uses the "
            "user's own camera, or a preset framed. Needs Blender "
            "installed (free); get_document_info says whether it was "
            "found. Takes 10-120 s. Returns the image; `path` also "
            "saves it."
        ),
        "input_schema": _obj({
            "view": {"type": "string",
                     "description": "'current' (default: the user's "
                                    "camera) or a preset: Isometric, "
                                    "Three-quarter front, Bird's-eye, "
                                    "Low angle, Front, Right, Top..."},
            "width": {"type": "integer",
                      "description": "Pixels (default 1200)."},
            "height": {"type": "integer",
                       "description": "Pixels (default 900)."},
            "samples": {"type": "integer",
                        "description": "Cycles samples (default 64; "
                                       "more = less noise, slower)."},
            "engine": {"type": "string", "enum": ["cycles", "eevee"],
                       "description": "cycles (default, path traced) "
                                      "or eevee (fast raster)."},
            "ground": {"type": "boolean",
                       "description": "A studio floor with the part's "
                                      "shadow (default true)."},
            "transparent": {"type": "boolean",
                            "description": "Transparent background, "
                                           "shadow kept."},
            "path": {"type": "string",
                     "description": "Also save the PNG here."},
            "max_width": {"type": "integer",
                          "description": "Scale the returned image to "
                                         "at most this wide (default "
                                         "900)."},
        }),
    },
    {
        "name": "push_pull_face",
        "description": (
            "Direct editing: push a FLAT face of a part straight out "
            "(distance > 0: a boss, a taller wall) or cut it in "
            "(distance < 0: a pocket, a recess, a thinner plate), with "
            "an optional inset that leaves a rim. `point` is any point "
            "on the face in world coordinates — take it from "
            "probe_surface. The first call wraps the part in a "
            "push_pull node; later calls on that node (or the part) add "
            "faces, applied in order, so the top of a boss just raised "
            "can be raised again. Exact (Manifold)."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "point": {"type": "array", "items": {"type": "number"},
                      "minItems": 3, "maxItems": 3,
                      "description": "A point on the flat face (world)."},
            "distance": {"type": "number",
                         "description": "mm out along the face's normal; "
                                        "negative cuts in."},
            "inset": {"type": "number",
                      "description": "Shrink the face by this much first "
                                     "(a rim). Default 0."},
        }, ["node_id", "point", "distance"]),
    },
    {
        "name": "drop_parts",
        "description": (
            "Gravity: parts fall onto the floor (z = floor) or onto the "
            "parts below them, and with settle (default) TIP OVER like "
            "real objects until they rest stably — a cone rolls onto "
            "its side, a leaning post falls, a box stays. Use it to put "
            "things on a table, stack bricks, lay parts on a print bed "
            "or check whether a design stands up. Lowest part first; "
            "writes each part's placement (x y z rx ry rz), one undo "
            "step. Returns per part how far it fell and how far it "
            "tipped."
        ),
        "input_schema": _obj({
            "node_ids": dict(_IDS, description=(
                "Parts to drop (default: every visible part in the "
                "assembly / the open Object).")),
            "floor": {"type": "number",
                      "description": "Floor height (default 0)."},
            "settle": {"type": "boolean",
                       "description": "Let parts tip over onto a stable "
                                      "face (default true). False only "
                                      "slides them straight down."},
            "gap": {"type": "number",
                    "description": "Clearance to leave under each part "
                                   "(default 0)."},
        }),
    },
    {
        "name": "reach",
        "description": (
            "Inverse kinematics: move a hand, foot, head or tool TIP to a "
            "point and let the joints work out the angles — 'left hand "
            "on the table', 'gripper on the bolt', 'foot on the step'. "
            "node_id is a human figure (effector left_hand / right_hand /"
            " left_foot / right_foot / head, or a bone name) or a part "
            "inside nested `joint` nodes (a robot arm, crane, lamp: the "
            "part itself is the effector, the joints above it the "
            "chain, within their min/max angles). Aim with `target` "
            "(world xyz, e.g. a probe_surface hit point) or `target_node`"
            " (the centre of another part's box). Writes ordinary pose "
            "angles (human pose rows / joint rx ry rz), one undo step. "
            "Returns `miss` (distance left) and, if unreachable, why."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "target": {"type": "array", "items": {"type": "number"},
                       "minItems": 3, "maxItems": 3,
                       "description": "World point [x, y, z] (document "
                                      "units) to reach."},
            "target_node": dict(_ID, description=(
                "Reach the centre of this part's bounding box instead.")),
            "offset": {"type": "array", "items": {"type": "number"},
                       "minItems": 3, "maxItems": 3,
                       "description": "Added to the target (e.g. [0, 0, "
                                      "30] to hover above it)."},
            "effector": {"type": "string",
                         "description": "Human figure: left_hand, "
                                        "right_hand, left_foot, "
                                        "right_foot, head or a bone. "
                                        "Default left_hand."},
            "chain": {"type": "integer",
                      "description": "Joint chains: how many joints up "
                                     "from the part may move (default "
                                     "all)."},
            "point": {"type": "array", "items": {"type": "number"},
                      "minItems": 3, "maxItems": 3,
                      "description": "Joint chains: the effector point in "
                                     "the part's own frame (default its "
                                     "box centre) — e.g. a gripper's "
                                     "tip."},
        }, ["node_id"]),
    },
    {
        "name": "wrap_nodes",
        "description": (
            "Apply an operation to existing nodes by wrapping them in "
            "it — this is how an extrude, a transform or a boolean is "
            "applied here. For a difference, the FIRST node stays the "
            "solid and the rest are subtracted, so order matters. The "
            "nodes must share a parent. Returns the wrapper's id."
        ),
        "input_schema": _obj({
            "ids": _IDS,
            "operation": {"type": "string", "enum": WRAP_TYPES},
            "params": _PARAMS,
            "name": {"type": "string"},
        }, ["ids", "operation"]),
    },
    {
        "name": "move_node",
        "description": (
            "Reparent or reorder a node — how you put a shape inside an "
            "extrude, or a part into a group."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "parent_id": dict(_ID, description="The new parent."),
            "index": {"type": "integer",
                      "description": "Position among its children "
                                     "(default last)."},
        }, ["node_id", "parent_id"]),
    },
    {
        "name": "duplicate_node",
        "description": "Copy a node and its subtree next to itself.",
        "input_schema": _obj({"node_id": _ID}, ["node_id"]),
    },
    {
        "name": "delete_nodes",
        "description": "Remove nodes and their subtrees.",
        "input_schema": _obj({"ids": _IDS}, ["ids"]),
    },
    {
        "name": "ungroup_node",
        "description": (
            "Replace a container by its children — the inverse of "
            "wrap_nodes."
        ),
        "input_schema": _obj({"node_id": _ID}, ["node_id"]),
    },
    {
        "name": "set_color",
        "description": (
            "Colour nodes. Reuses an existing colour wrapper rather "
            "than stacking a new one. A colour makes the whole-document "
            "exact render pause (an STL carries no colour), but each "
            "part is still rendered exactly on its own."
        ),
        "input_schema": _obj({
            "ids": _IDS,
            "color": {"type": "string",
                      "description": "#rrggbb, or an OpenSCAD colour "
                                     "name."},
            "alpha": {"type": "number",
                      "description": "0 (clear) to 1 (opaque)."},
            "material": {"type": "string", "enum": MATERIALS,
                         "description": "How the surface shades in the "
                                        "3D view: Metal, Glass, Rubber, "
                                        "Skin... (OpenSCAD itself has no "
                                        "materials; the choice is kept "
                                        "in the file)."},
        }, ["ids", "color"]),
    },
    {
        "name": "round_edges",
        "description": (
            "Round the edges of nodes after extrusion — wraps them in "
            "minkowski() with a small sphere, the OpenSCAD idiom. "
            "Expensive to render; keep the radius small."
        ),
        "input_schema": _obj({
            "ids": _IDS,
            "radius": {"type": "number", "description": "mm."},
        }, ["ids"]),
    },
    {
        "name": "apply_code",
        "description": (
            "Parse an OpenSCAD program and apply it as REAL NODES — not "
            "pasted text. For anything with structure this beats a "
            "dozen add_node calls, and the result is an ordinary "
            "editable tree. It lands in the scope the user is working "
            "in unless you name one. Constructs outside the importable "
            "subset come back as warnings; for a library the parser "
            "cannot read (BOSL2…), add a scad_raw node instead. End "
            "each statement with a `// Label` comment (`cube(10);  // "
            "Body`): the node is named \"Cube [Body]\" in the tree, and "
            "the label on a module's placed call (`Part();  // Left "
            "flipper`) names that Object."
        ),
        "input_schema": _obj({
            "code": {"type": "string",
                     "description": "The OpenSCAD program."},
            "mode": {
                "type": "string",
                "enum": ["append", "replace"],
                "description": "'append' (default) adds it alongside "
                               "what is there; 'replace' swaps the "
                               "scope's contents for it.",
            },
            "into_id": dict(_ID, description=(
                "Apply inside this Object/container instead of the "
                "scope the user is in.")),
        }, ["code"]),
    },

    {
        "name": "make_equal",
        "description": (
            "EQUAL SIZES between parts (tree right-click > Make Sizes "
            "Equal): node_b's param_b always equals node_a's param_a, the "
            "parametric way — one document variable (name, or made from "
            "node_a's name + param, value = its current size) drives "
            "both, so editing it resizes both and it survives export. "
            "Size params only (radius, width, height, thickness...; not "
            "x/y/z/rotation). action: link (default), unlink (node_a, "
            "param_a: back to a plain number), list (every shared size "
            "variable and the params it drives)."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["link", "unlink", "list"]},
            "node_a": {"type": "integer"},
            "param_a": {"type": "string"},
            "node_b": {"type": "integer"},
            "param_b": {"type": "string"},
            "name": {"type": "string"},
        }),
    },
    {
        "name": "configurations",
        "description": (
            "CONFIGURATIONS (Edit > Configurations): named sets of the "
            "document's global variable values — 'M6' / 'M8', 'Long' / "
            "'Short' — switched in one call. action: list (default: "
            "active, every configuration, current values, which differ "
            "from the active one), save (name; values {variable: value} "
            "or, omitted, every variable as it stands), apply (name: "
            "writes its values into the variables), remove (name). Make "
            "the design parametric with assign variables first."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["list", "save", "apply", "remove"]},
            "name": {"type": "string"},
            "values": {"type": "object"},
        }),
    },
    {
        "name": "suppress",
        "description": (
            "FEATURE HISTORY, SolidWorks style: switch features off "
            "without deleting them, or roll the history back. action: "
            "suppress / unsuppress (node_ids — a wrapper passes its "
            "children through, a difference keeps only its body, a "
            "leaf draws nothing; Objects, instances, ifs and raw code "
            "cannot be suppressed — hide them instead), rollback "
            "(node_id: everything AFTER it among its siblings is off), "
            "roll_forward (node_id = the container, or none for all), "
            "list (default). history: the feature list of the tree's "
            "History view — one entry a feature in the order they were "
            "MADE (not the order they nest), each with its sketch. "
            "rollback_history (node_id of a feature): every feature made "
            "AFTER it is off, wherever it stands in the tree — "
            "SolidWorks' rollback bar; roll_forward brings them back. "
            "Written to the program as kcad_off(...) so it survives "
            "export and import."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["list", "suppress", "unsuppress",
                                "rollback", "roll_forward", "history",
                                "rollback_history"]},
            "node_ids": {"type": "array", "items": {"type": "integer"}},
            "node_id": {"type": "integer"},
        }),
    },
    {
        "name": "reference_geometry",
        "description": (
            "REFERENCE GEOMETRY, SolidWorks style: planes, axes and "
            "points that stay in the tree, are drawn in the 3D view and "
            "render nothing (kcad_ref_* in the program). action: plane "
            "(origin + normal, or offset_from: 'Front' / 'Top' / "
            "'Right' + distance, or points: three [x, y, z], or faces: "
            "two [x, y, z, nx, ny, nz] — the mid-plane of two parallel "
            "faces, the bisector of two at an angle), axis "
            "(point + direction, or points: two, or planes: two "
            "ref_plane node ids — where they meet), point (at), sketch "
            "(node_id of a plane, or origin + normal: makes the Group "
            "'Sketch on …' lying on it; add rect / circle / line nodes "
            "inside it with add_node and extrude it), up_to_face "
            "(node_id of a linear_extrude + face: [x, y, z, nx, ny, nz] "
            "from probe_surface — the depth then follows that face), "
            "two_way (node_id of a linear_extrude + depth: also extrude "
            "this far down -Z), end_condition (node_id of a "
            "linear_extrude + condition, SolidWorks' list: blind, "
            "through_all_one (Through All), through_all (Through All - "
            "Both), up_to_next, up_to_vertex (+ point), up_to_face (Up To "
            "Surface, + face), offset_face (+ face + distance), up_to (Up "
            "To Body, + body: a node name — the profile lands on its surface everywhere), mid_plane), list (default)."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["list", "plane", "axis", "point",
                                "sketch", "up_to_face", "two_way",
                                "end_condition"]},
            "condition": {"type": "string",
                          "enum": ["blind", "through_all_one",
                                   "through_all", "up_to_next",
                                   "up_to_vertex", "up_to_face",
                                   "offset_face", "up_to", "mid_plane"]},
            "body": {"type": "string"},
            "origin": {"type": "array", "items": {"type": "number"}},
            "normal": {"type": "array", "items": {"type": "number"}},
            "point": {"type": "array", "items": {"type": "number"}},
            "direction": {"type": "array", "items": {"type": "number"}},
            "at": {"type": "array", "items": {"type": "number"}},
            "points": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"}}},
            "faces": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"}}},
            "planes": {"type": "array", "items": {"type": "integer"}},
            "offset_from": {"type": "string",
                            "enum": ["Front", "Top", "Right"]},
            "distance": {"type": "number"},
            "size": {"type": "number"},
            "node_id": {"type": "integer"},
            "face": {"type": "array", "items": {"type": "number"}},
            "depth": {"type": "number"},
        }),
    },
    {
        "name": "sketch_constraint",
        "description": (
            "SKETCH CONSTRAINTS and driven dimensions on 2D shapes "
            "(line, rect, circle, polygon) — the ribbon's SKETCH > "
            "Constraints panel. Constraints live on the CONTAINER holding "
            "the shapes (node_id; default the scope's root) and the "
            "solver writes the shapes' own params, so the program stays "
            "plain OpenSCAD. refs are '<child index>.<entity>': line p1 "
            "p2 l, rect v0-v3 (corners CCW from lower left) e0-e3 "
            "(bottom, right, top, left) c, circle c (centre) o (the "
            "circle), polygon v<i> e<i>. Kinds: coincident, horizontal "
            "/ vertical (a line or two points), parallel, perpendicular, "
            "tangent, equal, concentric, collinear, midpoint (point, "
            "line), symmetric (point, point, line), fix, point_on, diagonal (one line at 45°); "
            "dimensions with value (number or expression of variables, "
            "measured when omitted): distance, hdistance, vdistance, "
            "length, point_line, radius, diameter, angle (degrees), "
            "arc_length (an arc: a line with a bulge). Options on add: "
            "double true (point_line across a centerline: the value is "
            "the DIAMETER, twice the distance — a revolve's profile), "
            "rim {'0': 'min' | 'max'} (that ref is a circle's centre: "
            "measure to its near / far side), driven true (it only "
            "measures, shown in brackets, never conflicts). set_driven "
            "(index, driven) switches one. "
            "action: list (default: rows, shapes with their entities, "
            "status + degrees of freedom, held_by = what ties the sketch "
            "to the part, free_to = how it can still move, e.g. slide "
            "left / right), add, remove (index), "
            "set_value (index, value), auto (add the H / V / coincident "
            "constraints the drawing already looks like), solve. A "
            "constraint that cannot hold with the others is refused. "
            "face_reference: a flat FACE of the part (world point on it, "
            "from probe_surface; optional normal) becomes a fixed "
            "construction line of this sketch where the face meets the "
            "sketch plane — the reply's `reference` is its ref; use it "
            "in point_line / parallel / angle to dimension a sketch "
            "shape to that face. The line follows the face when the "
            "part changes. "
            "link: make a dimension FOLLOW another, as SolidWorks' "
            "= D1@Boss-Extrude1 — the target is this sketch's row "
            "`index`, or a feature's size (`feature_id` + `key`: an "
            "extrude's height / height2, a revolve's angle); the source "
            "is `source_index` (+ `source_id`, the sketch holding it; "
            "default this one) or `source_feature_id` + `source_key`. "
            "Both then read one document variable (made from the "
            "source's value when it was a plain number); the reply "
            "names it. The user sees an extrude's depth and a revolve's "
            "angle on the model when the feature is selected."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["list", "add", "remove", "set_value",
                                "auto", "solve", "face_reference",
                                "set_driven", "link"]},
            "feature_id": {"type": "integer"},
            "key": {"type": "string",
                    "enum": ["height", "height2", "angle"]},
            "source_index": {"type": "integer", "minimum": 0},
            "source_id": {"type": "integer"},
            "source_feature_id": {"type": "integer"},
            "source_key": {"type": "string",
                           "enum": ["height", "height2", "angle"]},
            "double": {"type": "boolean"},
            "driven": {"type": "boolean"},
            "rim": {"type": "object"},
            "node_id": {"type": "integer"},
            "point": {"type": "array", "items": {"type": "number"}},
            "normal": {"type": "array", "items": {"type": "number"}},
            "kind": {"type": "string"},
            "refs": {"type": "array", "items": {"type": "string"}},
            "value": {"type": ["number", "string"]},
            "index": {"type": "integer", "minimum": 0},
            "scale_sketch": {"type": "boolean", "description": (
                "add: false keeps the sketch's size when this is its "
                "first dimension (default follows the user's 'scale on "
                "first dimension' option; the reply says scaled)")},
        }),
    },
    {
        "name": "hole_wizard",
        "description": (
            "SolidWorks' HOLE WIZARD: drill standard holes into a part. "
            "node_id = the part (a solid, an Object or an instance — an "
            "Object is drilled inside, every instance follows), points = "
            "world [x, y, z] ON one face (probe_surface gives point + "
            "normal), normal = that face's outward normal. type "
            "Clearance / Tapped (drill) / Counterbore / Countersink / Nut "
            "trap, size (ISO 'M1'..'M64', inch '1/4-20 UNC', '#8-32 UNC', '1/4-28 UNF' ...), fit Close / Normal / Loose (ISO 273), end "
            "Through all (default) or Blind + depth mm. The holes are ONE "
            "feature (a Group 'M6 Clearance Hole' cut by a Difference); a "
            "later call with the same settings adds to it. action update "
            "+ node_id inside a feature re-sizes all its holes."
        ),
        "input_schema": _obj({
            "action": {"type": "string", "enum": ["drill", "update"]},
            "node_id": {"type": "integer"},
            "points": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 3, "maxItems": 3}},
            "normal": {"type": "array", "items": {"type": "number"},
                       "minItems": 3, "maxItems": 3},
            "type": {"type": "string"},
            "size": {"type": "string"},
            "fit": {"type": "string"},
            "end": {"type": "string"},
            "depth": {"type": "number", "exclusiveMinimum": 0},
            "hole_diameter": {"type": "number", "exclusiveMinimum": 0,
                              "description": "Custom sizing: hole Ø mm."},
            "head_diameter": {"type": "number", "exclusiveMinimum": 0,
                              "description": "Custom sizing: counterbore "
                              "/ countersink Ø mm."},
            "head_depth": {"type": "number", "exclusiveMinimum": 0,
                           "description": "Custom sizing: counterbore "
                           "depth mm."},
        }, ["node_id"]),
    },
    {
        "name": "fill_pattern",
        "description": (
            "SolidWorks' FILL PATTERN: fill a flat FACE with copies of a "
            "seed cut. node_id = the part (a solid, an Object or an "
            "instance), point = world [x, y, z] ON the face and normal = "
            "its outward normal (probe_surface gives both). layout "
            "circular (a centre instance then loops every loop_spacing mm "
            "holding the next even count with at most `spacing` mm of arc "
            "between neighbours), square (a grid) or perforation "
            "(staggered rows); margin mm kept clear of the face's edge; "
            "direction = a unit vector in the part's frame (a sketch "
            "line's direction) or angle degrees in the face, reverse "
            "turns it round; shape square / circle / diamond / polygon "
            "(+ sides), size mm, rotation degrees; end Through all "
            "(default) or Blind + depth. ONE feature: a Group 'Fill "
            "Pattern' cut by a Difference, one polygon with a path per "
            "instance; the reply gives the instance count. action count "
            "only counts; action update + node_id inside a fill changes "
            "its settings and fills again."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["fill", "update", "count"]},
            "node_id": {"type": "integer"},
            "point": {"type": "array", "items": {"type": "number"},
                      "minItems": 3, "maxItems": 3},
            "normal": {"type": "array", "items": {"type": "number"},
                       "minItems": 3, "maxItems": 3},
            "layout": {"type": "string",
                       "enum": ["circular", "square", "perforation"]},
            "loop_spacing": {"type": "number", "exclusiveMinimum": 0},
            "spacing": {"type": "number", "exclusiveMinimum": 0},
            "margin": {"type": "number", "minimum": 0},
            "shape": {"type": "string",
                      "enum": ["square", "circle", "diamond", "polygon"]},
            "size": {"type": "number", "exclusiveMinimum": 0},
            "rotation": {"type": "number"},
            "sides": {"type": "integer", "minimum": 3},
            "angle": {"type": "number"},
            "direction": {"type": "array", "items": {"type": "number"},
                          "minItems": 3, "maxItems": 3},
            "reverse": {"type": "boolean"},
            "end": {"type": "string", "enum": ["Through all", "Blind"]},
            "depth": {"type": "number", "exclusiveMinimum": 0},
        }, ["node_id"]),
    },
    {
        "name": "mirror_feature",
        "description": (
            "MIRROR (SolidWorks' Mirror of features / bodies): node_ids "
            "(features, parts) copied about plane Front / Top / Right — "
            "the PART's planes, carried into each node's own frame, so a "
            "rib or boss made in a turned sketch mirrors where it should "
            "(wrap_nodes symmetry mirrors in the node's own frame) — or "
            "about point + normal (scope frame). The original stays."
        ),
        "input_schema": _obj({
            "node_ids": {"type": "array", "items": {"type": "integer"}},
            "plane": {"type": "string"},
            "point": {"type": "array", "items": {"type": "number"}},
            "normal": {"type": "array", "items": {"type": "number"}},
        }, ["node_ids"]),
    },
    {
        "name": "deform_point",
        "description": (
            "SolidWorks' DEFORM, Point type: every vertex of the bodies "
            "within `radius` mm of `point` moves along `direction` by "
            "`distance` mm times a smooth falloff (shape minimum = a "
            "peak, medium = a bell, maximum = a broad flat hill) — a "
            "flat grille pushed into a dome. body_ids = nodes sharing "
            "one parent; point = world [x, y, z] (the origin by "
            "default), direction a vector (default +Z), reverse flips "
            "it. The reply gives the Deform node; call it again on the "
            "result for a second push (the video's central dimple)."
        ),
        "input_schema": _obj({
            "body_ids": {"type": "array", "items": {"type": "integer"}},
            "point": {"type": "array", "items": {"type": "number"},
                      "minItems": 3, "maxItems": 3},
            "direction": {"type": "array", "items": {"type": "number"},
                          "minItems": 3, "maxItems": 3},
            "distance": {"type": "number"},
            "radius": {"type": "number", "exclusiveMinimum": 0},
            "shape": {"type": "string",
                      "enum": ["minimum", "medium", "maximum"]},
            "reverse": {"type": "boolean"},
        }, ["body_ids"]),
    },
    {
        "name": "deform_curve",
        "description": (
            "DEFORM, CURVE TO CURVE (SolidWorks' Deform): bend `body_ids` "
            "(parts / feature groups, one parent) from `initial_id` — a "
            "sketch or line holding the initial curve (a sketch with "
            "construction lines uses only those, e.g. the rod's centre "
            "line) — onto `target_id`, a sketch of lines and arcs chained "
            "end to end. The initial curve's ends land on the target's "
            "ends; the result is a Deform node (curves in Properties)."
        ),
        "input_schema": _obj({
            "initial_id": {"type": "integer"},
            "target_id": {"type": "integer"},
            "body_ids": {"type": "array", "items": {"type": "integer"}},
        }, ["initial_id", "target_id", "body_ids"]),
    },
    {
        "name": "pattern_feature",
        "description": (
            "CIRCULAR / LINEAR PATTERN of features or bodies (SolidWorks' "
            "Circular Pattern, Linear Pattern — the Features tab's "
            "windows): node_ids (an extrude, a cut's feature, a part). "
            "kind circular: copies about `axis` [x, y, z] through "
            "`centre` (world, default origin; a cylinder's axis is its "
            "centre line), `count` instances over `angle` (default 360, "
            "equal spacing; equal false = `angle` between copies), "
            "reverse. kind linear: `direction` [x, y, z], `spacing` mm, "
            "`count`, reverse; optional direction2 / spacing2 / count2 "
            "for a grid. One pattern per parent; copies follow every "
            "edit of the original."
        ),
        "input_schema": _obj({
            "kind": {"type": "string", "enum": ["circular", "linear"]},
            "node_ids": {"type": "array", "items": {"type": "integer"}},
            "count": {"type": "integer", "minimum": 1},
            "axis": {"type": "array", "items": {"type": "number"}},
            "centre": {"type": "array", "items": {"type": "number"}},
            "angle": {"type": "number"},
            "equal": {"type": "boolean"},
            "reverse": {"type": "boolean"},
            "direction": {"type": "array", "items": {"type": "number"}},
            "spacing": {"type": "number"},
            "direction2": {"type": "array", "items": {"type": "number"}},
            "spacing2": {"type": "number"},
            "count2": {"type": "integer", "minimum": 1},
        }, ["node_ids"]),
    },
    {
        "name": "sketch_feature",
        "description": (
            "FEATURE FROM A SKETCH — the ribbon's Extruded Boss / Cut and "
            "the other Bosses and Cuts, made exactly as on leaving their "
            "sketch: node_id = the sketch (a face / plane sketch Group, "
            "reference_geometry sketch_on). The AREA its lines, arcs and "
            "shapes close is the profile (a circle inside a closed outline "
            "is a hole), kept as a Regions with the sketch's dimensions. "
            "kind extruded_boss (default, joined to the part) / "
            "extruded_cut / revolved_boss / revolved_cut (about the "
            "sketch's Y axis) / swept_* / lofted_*; depth (mm, default "
            "10), mid_plane (both ways, centred on the sketch), "
            "through_all (cuts), reverse; part_id = the part a cut cuts "
            "(default: the part the sketch stands on). Lines that close "
            "nothing alone (ONE line across a face) close areas WITH the "
            "part's edges at the sketch plane, as SolidWorks: region = "
            "[x, y] in the sketch picks the area (default the smallest). "
            "regions = "
            "SolidWorks' Selected Contours: [[x, y], ...] points in the "
            "sketch's own x, y, one inside each area to extrude (extruded "
            "kinds); the same sketch may be given again later with other "
            "regions — one sketch, several features (a cut then cuts "
            "everything built before it). from_offset = SolidWorks' "
            "From: Offset — the extrude starts that many mm along its own "
            "direction (after reverse) instead of on the sketch plane; "
            "the end condition (reference_geometry end_condition, e.g. "
            "up_to_face) then measures from there. flip = SolidWorks' "
            "\"Flip side to cut\" (cuts): the cut removes everything "
            "AROUND the picked regions, the part keeps their inside."
        ),
        "input_schema": _obj({
            "node_id": {"type": "integer"},
            "kind": {"type": "string"},
            "flip": {"type": "boolean"},
            "depth": {"type": "number", "exclusiveMinimum": 0},
            "from_offset": {"type": "number"},
            "mid_plane": {"type": "boolean"},
            "through_all": {"type": "boolean"},
            "reverse": {"type": "boolean"},
            "part_id": {"type": "integer"},
            "region": {"type": "array", "items": {"type": "number"},
                       "minItems": 2, "maxItems": 2},
            "regions": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 2, "maxItems": 2}},
        }, ["node_id"]),
    },
    {
        "name": "rib",
        "description": (
            "RIB (SolidWorks' Rib): node_id = a sketch on a plane THROUGH "
            "the part (reference_geometry sketch_on, or a face sketch) "
            "holding one or more OPEN lines that start and end on the "
            "part's edges on that plane. The area each line closes with "
            "the part's outline there is filled and extruded `thickness` "
            "mm (default 10) about the plane, both sides, joined to the "
            "part — a brace between a wall and a base. Change the "
            "thickness later with set_params height on the returned rib."
        ),
        "input_schema": _obj({
            "node_id": {"type": "integer"},
            "thickness": {"type": "number", "exclusiveMinimum": 0},
        }, ["node_id"]),
    },
    {
        "name": "sketch_modify",
        "description": (
            "SKETCH MODIFY — the ribbon's Trim / Extend / Sketch fillet / "
            "Sketch chamfer. Points are in the shape's own sketch "
            "coordinates (its params' frame). trim: node_id (a line, "
            "circle, arc, or a rectangle / polygon — its side nearest the "
            "point) + point on the piece to remove — it is cut where other "
            "lines / circles of its group cross it (shortened, split in "
            "two, deleted; a circle becomes an open arc). construction: "
            "node_id (+ point to pick a rectangle / polygon side, which "
            "becomes lines) switches it to construction and back. extend: node_id (a line) + point near the end to "
            "run on to the first line / circle it meets. fillet / "
            "chamfer: node_id of a polygon or rect + vertex index (a rect "
            "becomes a polygon; the corner is kept and a corners row "
            "draws the arc), or node_ids [two lines meeting at an end] "
            "(both trimmed, an arc / chamfer piece added); size = radius "
            "or distance. mirror (Mirror Entities): node_ids = the shapes, "
            "mirror_line = the line (usually a centerline, a construction "
            "line) in the same sketch — each copy is the same kind of "
            "shape tied by Symmetric relations (Equal for circles) unless "
            "relate is false; a rect about a slanted line becomes a "
            "polygon. offset (SolidWorks' Offset Entities): node_ids = "
            "lines / arcs joined end to end (any order), size = the "
            "distance, reverse = the other side (the side is the left of "
            "the FIRST id as drawn), cap = close both ends with lines (a "
            "wall of even thickness, ready to extrude). The PART's edges "
            "instead (as SolidWorks, no Convert first): node_id = the "
            "sketch + point (or points) = [x, y] on an edge where the "
            "sketch's plane meets the part; chain (default true, Select "
            "chain) runs on through tangent edges; the copy goes INTO the "
            "part, reverse = out of it. convert "
            "(Convert Entities): node_id = the sketch, point = [x, y] in "
            "its frame on an edge of the part where the sketch's plane "
            "meets it (the whole edge comes in as a line, arc or circle), "
            "or inside it (the whole outline)."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["trim", "extend", "fillet", "chamfer",
                                 "mirror", "offset", "construction",
                                 "convert"]},
            "reverse": {"type": "boolean"},
            "cap": {"type": "boolean"},
            "node_id": {"type": "integer"},
            "node_ids": {"type": "array", "items": {"type": "integer"},
                         "minItems": 1},
            "mirror_line": {"type": "integer"},
            "relate": {"type": "boolean"},
            "point": {"type": "array", "items": {"type": "number"},
                      "minItems": 2, "maxItems": 2},
            "points": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 2, "maxItems": 2}},
            "chain": {"type": "boolean"},
            "vertex": {"type": "integer", "minimum": 0},
            "size": {"type": "number", "exclusiveMinimum": 0},
        }, ["action"]),
    },
    {
        "name": "sheet_metal",
        "description": (
            "SHEET METAL (the ribbon's SHEET METAL tab, after SolidCraft / "
            "SolidWorks). A body = a flat base OUTLINE (mm, XY, the sheet "
            "from z = 0 up by the thickness) or a CONTOUR (open X, Z "
            "chain, width along Y), plus flanges / hems / folds; one "
            "thickness, inside bend radius, K-factor and hem gap (or a "
            "named RULE = document variables smr_<rule>_t/_r/_k/_hem). "
            "Panels: 0 = the base, then the contour's segments, then each "
            "flange in order. Edges: base outline edge i runs from point i "
            "to i + 1 (a rectangle from (0,0): 0 front -Y, 1 right +X, 2 "
            "back +Y, 3 left -X); on a flange 0 = bend, 1 and 3 sides, 2 "
            "the far edge. Flange height is to the OUTSIDE (virtual "
            "sharp), so a 100 x 60 outline with four 20 mm flanges is a "
            "100 x 60 x 20 box. angle > 0 bends up (toward +Z of the "
            "panel), < 0 down. action: create (outline | contour + width, "
            "thickness, bend_radius, k_factor, rule), convert (node_id: a "
            "thin cube / extruded rect, polygon, circle / old sheet metal "
            "part), flange (panel, edge, height, angle, bend_radius 0 = "
            "the body's, inset_start/end, then [[height, angle], ...] "
            "chained on the far edge; ear true = Edge Flange with an edited "
            "profile, a strip of width centred `center` mm along the edge "
            "with a full round end, hole_diameter = the hole at its "
            "centre), hem (panel, edge, length, flip), "
            "path_flange (panel, edge, segments [[length, angle], ...]), fold "
            "(line [[x1,y1],[x2,y2]] across the base, angle — the outline "
            "is the flat blank), perforate (diameter, pitch, margin, "
            "pattern staggered|square: holes in the flat pattern), panel_hole "
            "(a hole through ANY panel, the base's opening or a flange's: panel, diameter and u, v in the panel's own "
            "frame — or edge + along + across mm inward from that edge; "
            "cut in the folded part AND the flat pattern, a base flange's "
            "opening is one too), corner (Break Corner: panel, size and "
            "u, v near the convex corner; chamfer true = a cut instead of "
            "a round), tab (Base Flange/Tab merged into a panel: u, v = "
            "centre of its round end, width, length toward angle degrees, "
            "hole_diameter; it may stand in an opening the panel already "
            "has), tab_jog (a jog of a merged tab, not of the whole plate: two bends along `line` [[x1,y1],[x2,y2]] in the "
            "panel's frame step what lies beyond it `offset` mm — up for "
            "angle > 0, down for < 0, bend_radius, fixed [x, y] = a point "
            "on the piece that stays, extend true = stretch the line "
            "across the material it crosses), gusset (a stamped rib across the "
            "inside of bend number `bend` from the bend table, `offset` "
            "mm along it, d1 / d2 depths up each face, width, draft "
            "degrees), mirror / linear_pattern / circular_pattern (features "
            "[{kind, index}] — kind pholes|tabs|tabjogs|gussets|corners|ears, "
            "index from 0 as `state` lists them under features: mirror "
            "about plane x|y at coordinate `at`; linear_pattern count, dx, "
            "dy (a gusset's dx is the spacing along its bend); "
            "circular_pattern count, pivot [u, v], total degrees — "
            "copies written as ordinary rows), unfold "
            "/ refold (show flat / folded), flat_pattern (a flat copy "
            "beside it), remove (what flanges|hems|folds|perforate|holes|corners|tabs, "
            "index), state (panels, bends, bend table, every edge with its "
            "label, flat size, errors), rules, set_rule (rule + "
            "thickness, bend_radius, k_factor, hem_gap; node_id applies "
            "it), apply_rule, delete_rule, export_dxf (path: CUT, "
            "BEND_UP/DOWN, ETCH layers), export_bend_table (path, else "
            "the CSV text). Every edit answers the state: read 'errors'."
        ),
        "input_schema": _obj({
            "action": {"type": "string", "enum": [
                "create", "convert", "flange", "hem", "path_flange", "fold",
                "jog", "hole", "slot", "perforate", "panel_hole", "corner", "tab",
                "tab_jog", "gusset", "mirror", "linear_pattern",
                "circular_pattern", "unfold", "refold", "flat_pattern",
                "remove",
                "state", "rules", "set_rule", "apply_rule", "delete_rule",
                "export_dxf", "export_bend_table"]},
            "node_id": {"type": "integer"},
            "parent_id": {"type": "integer"},
            "name": {"type": "string"},
            "outline": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 2, "maxItems": 2}},
            "contour": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 2, "maxItems": 2}},
            "width": {"type": "number", "exclusiveMinimum": 0},
            "thickness": {"type": "number", "exclusiveMinimum": 0},
            "bend_radius": {"type": "number", "minimum": 0},
            "k_factor": {"type": "number", "minimum": 0, "maximum": 1},
            "hem_gap": {"type": "number", "minimum": 0},
            "rule": {"type": "string"},
            "panel": {"type": "integer", "minimum": 0},
            "edge": {"type": "integer", "minimum": 0},
            "height": {"type": "number", "exclusiveMinimum": 0},
            "angle": {"type": "number"},
            "inset_start": {"type": "number", "minimum": 0},
            "inset_end": {"type": "number", "minimum": 0},
            "then": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 2, "maxItems": 2}},
            "segments": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 2, "maxItems": 2}},
            "path": {"type": "string"},
            "length": {"type": "number", "exclusiveMinimum": 0},
            "flip": {"type": "boolean"},
            "line": {"type": "array", "items": {
                "type": "array", "items": {"type": "number"},
                "minItems": 2, "maxItems": 2}},
            "diameter": {"type": "number", "exclusiveMinimum": 0},
            "pitch": {"type": "number", "exclusiveMinimum": 0},
            "margin": {"type": "number", "minimum": 0},
            "pattern": {"type": "string", "enum": ["staggered", "square"]},
            "what": {"type": "string",
                     "enum": ["flanges", "hems", "folds", "jogs", "holes",
                              "slots", "perforate", "pholes", "corners",
                              "tabs", "tabjogs", "gussets"]},
            "index": {"type": "integer", "minimum": 0},
            "u": {"type": "number"}, "v": {"type": "number"},
            "ear": {"type": "boolean"},
            "features": {"type": "array", "items": {
                "type": "object", "properties": {
                    "kind": {"type": "string", "enum": [
                        "pholes", "tabs", "tabjogs", "gussets", "corners",
                        "ears"]},
                    "index": {"type": "integer", "minimum": 0}},
                "required": ["kind", "index"]}},
            "plane": {"type": "string", "enum": ["x", "y"]},
            "pivot": {"type": "array", "items": {"type": "number"},
                      "minItems": 2, "maxItems": 2},
            "at": {"type": "number"},
            "count": {"type": "integer", "minimum": 2},
            "dx": {"type": "number"}, "dy": {"type": "number"},
            "total": {"type": "number"},
            "bend": {"type": "integer", "minimum": 1},
            "d1": {"type": "number", "exclusiveMinimum": 0},
            "d2": {"type": "number", "exclusiveMinimum": 0},
            "draft": {"type": "number", "minimum": 0, "maximum": 80},
            "offset": {"type": "number"},
            "extend": {"type": "boolean"},
            "fixed": {"type": "array", "items": {"type": "number"},
                      "minItems": 2, "maxItems": 2},
            "center": {"type": "number", "minimum": 0},
            "hole_diameter": {"type": "number", "minimum": 0},
            "size": {"type": "number", "exclusiveMinimum": 0},
            "chamfer": {"type": "boolean"},
            "along": {"type": "number", "minimum": 0},
            "across": {"type": "number", "minimum": 0},
            "bend_notes": {"type": "boolean"},
            "offset": {"type": "number", "exclusiveMinimum": 0},
            "dimension": {"type": "string",
                          "enum": ["outside", "inside", "total"]},
            "position": {"type": "integer", "minimum": 0, "maximum": 3},
            "fixed_side": {"type": "string", "enum": ["right", "left"]},
            "direction": {"type": "string", "enum": ["up", "down"]},
            "x": {"type": "number"}, "y": {"type": "number"},
        }, ["action"]),
    },
    # ── Parts and assemblies ───────────────────────────────────────
    {
        "name": "bill_of_materials",
        "description": (
            "The document's BILL OF MATERIALS (File > Bill of Materials). "
            "Objects are assemblies/parts, and every LABELLED node inside "
            "a part ('// Copper tube' comment, 'Cube [Copper tube]') is a "
            "component line, grouped by label with loop iterations "
            "counted. Each line: item ('1.3.2'), part_no, name, "
            "description (from what the node is: tube OD and length, "
            "cylinder Ø × h, plate thickness), qty + unit (pc, or m for "
            "pipe / tube / cable / rail), material (label word or colour, "
            "'(est.)' when guessed), finish, size L×W×H mm, mass each / "
            "total kg (solid estimate), cost, supplier, source. action: "
            "get (default; detail components | parts | assemblies, "
            "max_level, columns), set (item or ids + fields: part_no, "
            "description, material, finish, supplier, cost, mass, unit, "
            "notes, exclude — saved on the nodes, one undo step), export "
            "(path .csv .xlsx .html .json), place (parts list + numbered "
            "balloons on the Blueprint), parts (the Objects that have a "
            "BOM of their own), export_parts (every Object's own BOM: "
            ".xlsx = a sheet each after a Summary, else a folder of CSV). "
            "object = one Object's own BOM for get / export (same item "
            "and part numbers as the whole). LABEL every piece you build "
            "so the BOM can list it."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["get", "set", "export", "place", "parts",
                                "export_parts"]},
            "object": {"type": "string"},
            "detail": {"type": "string",
                       "enum": ["components", "parts", "assemblies"]},
            "max_level": {"type": "integer", "minimum": 0},
            "columns": {"type": "array", "items": {"type": "string"}},
            "item": {"type": "string"},
            "ids": _IDS,
            "fields": {"type": "object"},
            "path": {"type": "string"},
            "balloons": {"type": "boolean"},
        }),
    },
    {
        "name": "drawing_set",
        "description": (
            "The DRAWING SET: the Blueprint's assembly sheet plus one "
            "part drawing per Object (its own views and dimensions, its "
            "own parts list with balloons, title block with its part "
            "number, material, mass and sheet n / N), saved in the "
            ".kcad. action: list (default; every sheet and whether it is "
            "made), make (names, or all missing), show (name; '' = the "
            "assembly) — opens the Blueprint on it, export (path: .pdf = "
            "ONE multi-page PDF of the whole set, else a folder with a "
            "PDF, DXF, SVG and PNG per sheet), render (name: a PNG of "
            "that sheet to look at)."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["list", "make", "show", "export",
                                "render"]},
            "names": {"type": "array", "items": {"type": "string"}},
            "name": {"type": "string"},
            "path": {"type": "string"},
        }),
    },
    {
        "name": "blueprint",
        "description": (
            "EDIT the Blueprint (File > Blueprint) sheet live: views, "
            "dimensions, notes and title block, one undo step per call. "
            "action state (default): views with id, plane (Front = (x, "
            "z), Top = (x, y), Right = (y, z)), model bounds, round edges "
            "(centres, r) and edge points; notes by index with what each "
            "dimension shows. add (notes: [{type 'dim' (default), view "
            "(id or name), kind horizontal | vertical | aligned (a, b "
            "model points in the view plane; side above / below / left / "
            "right + gap sheet mm, or offset) | diameter | radius (centre, "
            "r, angle, offset, count) | angle (vertex, p1, p2); text, "
            "prefix, suffix, tol_plus, tol_minus, decimals}, {type "
            "'text', x, y sheet mm y DOWN, text, size, bold}, leader "
            "{view, tip, at, text}, centre_mark, centre_line, datum, fcf, "
            "finish, balloon, sketch]), set (index or indices, changes), "
            "remove (indices, or auto true), auto_dimension, arrange "
            "(scale), new_sheet, add_view (kind projected name | section "
            "axis offset | detail parent centre radius factor | shaded; "
            "x, y), set_view (view + x, y, label, show_label...), "
            "remove_view, sheet (sheet, scale 0.5 or '1:2', style, "
            "hidden_lines, merge_parts, fields {title, number, material, drawn, "
            "company, revision, finish...}), update_from_model, undo, "
            "redo, render (PNG to look at), export (path .pdf .svg .png "
            ".dxf), revision (text, by: a row in the revision table, "
            "next letter, today), baseline / chain (view, points [[u, "
            "v]...] the first the base, kind horizontal | vertical). "
            "Note types also 'ordinate' {view, axis, origin, points} and "
            "'revisions' {x, y, rows}. drawing = which sheet first (a "
            "part name; '' = assembly)."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["state", "add", "set", "remove",
                                "auto_dimension", "arrange", "new_sheet",
                                "revision", "baseline", "chain",
                                "add_view", "set_view", "remove_view",
                                "sheet", "update_from_model", "undo",
                                "redo", "render", "export"]},
            "drawing": {"type": "string"},
            "points": {"type": "array",
                       "items": {"type": "array",
                                 "items": {"type": "number"}}},
            "text": {"type": "string"}, "by": {"type": "string"},
            "notes": {"type": "array", "items": {"type": "object"}},
            "index": {"type": "integer"},
            "indices": {"type": "array", "items": {"type": "integer"}},
            "changes": {"type": "object"},
            "auto": {"type": "boolean"},
            "view": {"type": "string"},
            "kind": {"type": "string"},
            "name": {"type": "string"},
            "axis": {"type": "string", "enum": ["x", "y", "z"]},
            "parent": {"type": "string"},
            "centre": {"type": "array", "items": {"type": "number"}},
            "radius": {"type": "number"},
            "factor": {"type": "number"},
            "offset": {"type": "number"},
            "x": {"type": "number"}, "y": {"type": "number"},
            "label": {"type": "string"},
            "show_label": {"type": "boolean"},
            "sheet": {"type": "string"},
            "scale": {"type": ["number", "string"]},
            "style": {"type": "string"},
            "hidden_lines": {"type": "boolean"},
            "merge_parts": {"type": "boolean", "description": (
                "sheet: draw parts that pass through each other (a port "
                "welded into a wall) as ONE solid, so their meeting curve "
                "is drawn — default true; the model is never changed.")},
            "fields": {"type": "object"},
            "px_per_mm": {"type": "number"},
            "path": {"type": "string"},
        }),
    },
    {
        "name": "pid",
        "description": (
            "The document's P&ID — piping and instrumentation diagram "
            "(File > P&ID), saved in the .kcad. action: symbols (the "
            "~55 ISO 10628 / ISA-5.1 symbols: kind, ports with the way a "
            "pipe leaves each, tag prefix), state (default; symbols, "
            "lines, notes, problems, usable sheet area), add (symbols: "
            "[{kind, x, y, tag?, label, rot 0/90/180/270, mirror, data, "
            "node = the 3D part's name}] in sheet mm, y DOWN; tags "
            "number themselves, P-101, V-102), set (id or tag + x, y, "
            "rot, mirror, tag, label, node, data, kind), connect (lines: "
            "[{from: 'TAG.port', to: 'TAG.port' or {x, y} on another "
            "line (a tee), kind process | secondary | signal | pneumatic "
            "| capillary | data, service HWF HWR DHW CW RHG RL RS R2P "
            "GLY AIR DR, size, material CU SS CS PEX..., insulated, "
            "arrow, points?}] — routed square round the symbols, process "
            "lines numbered 28-HWF-001-CU), set_line (id or number + "
            "fields, new_number, reroute), remove (ids or tags), note "
            "(text, x, y, size), sheet (sheet A4-A1, fields title / "
            "number / revision / project / company / drawn / checked, "
            "colour_lines), from_model (a symbol per recognised 3D "
            "part, to arrange and connect), schedules (equipment, "
            "valves, instrument index, line list), export (path: .pdf "
            ".svg .png .dxf the sheet, .xlsx .csv the schedules), "
            "render (a PNG to look at), clear."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["state", "symbols", "add", "set",
                                "connect", "set_line", "remove", "note",
                                "sheet", "from_model", "schedules",
                                "export", "render", "clear"]},
            "symbols": {"type": "array", "items": {"type": "object"}},
            "lines": {"type": "array", "items": {"type": "object"}},
            "id": {"type": "string"},
            "tag": {"type": "string"},
            "number": {"type": "string"},
            "new_number": {"type": "string"},
            "ids": {"type": "array", "items": {"type": "string"}},
            "x": {"type": "number"}, "y": {"type": "number"},
            "rot": {"type": "integer"}, "mirror": {"type": "boolean"},
            "label": {"type": "string"}, "node": {"type": "string"},
            "kind": {"type": "string"}, "data": {"type": "object"},
            "service": {"type": "string"}, "size": {"type": "string"},
            "material": {"type": "string"},
            "insulated": {"type": "boolean"},
            "arrow": {"type": "boolean"}, "reroute": {"type": "boolean"},
            "points": {"type": "array", "items": {"type": "array", "items": {"type": "number"}}},
            "text": {"type": "string"}, "sheet": {"type": "string"},
            "fields": {"type": "object"},
            "colour_lines": {"type": "boolean"},
            "replace": {"type": "boolean"},
            "path": {"type": "string"},
            "px_per_mm": {"type": "number"},
        }),
    },
    {
        "name": "collections",
        "description": (
            "Blender-style COLLECTIONS: named sets of parts shown, "
            "hidden or locked together (Walls, Roof, Furniture, Moving "
            "parts), whatever the tree structure — the Collections tab. "
            "Hiding is a VIEW setting: the 3D/2D views and render_view "
            "leave the parts out, the program and every export keep "
            "them. action: list (default), create (name, ids), assign "
            "(ids into name; name '' takes them out), show / hide / "
            "solo (show only this one; again = all) / lock / unlock "
            "(name), rename (name, new_name), delete (name; its parts "
            "stay). Every action returns the collections with members."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["list", "create", "assign", "show",
                                "hide", "solo", "lock", "unlock",
                                "rename", "delete"]},
            "name": {"type": "string"},
            "new_name": {"type": "string"},
            "ids": _IDS,
        }),
    },
    {
        "name": "make_object",
        "description": (
            "Promote nodes into an Object — a part definition that "
            "compiles to its own OpenSCAD module, so the program reads "
            "as an assembly of named parts. A Group converts in place; "
            "anything else is wrapped."
        ),
        "input_schema": _obj({
            "ids": _IDS,
            "name": {"type": "string"},
        }, ["ids"]),
    },
    {
        "name": "add_instance",
        "description": (
            "Place another instance of an Object into the assembly: one "
            "placed call of its module, with its own position, rotation "
            "and colour. Build a part once and instance it rather than "
            "duplicating its geometry."
        ),
        "input_schema": _obj({
            "node_id": dict(_ID, description="The Object to instance."),
            "params": _PARAMS,
        }, ["node_id"]),
    },
    {
        "name": "make_master",
        "description": (
            "Define a node once and place it by reference: it becomes a "
            "hidden Object (the Object tab) and a Linked copy of it takes "
            "its place — even inside a loop. Editing the Object then "
            "updates every copy. (The Masters tab was retired; this now "
            "makes an Object.)"
        ),
        "input_schema": _obj({"node_id": _ID}, ["node_id"]),
    },
    {
        "name": "add_linked_copy",
        "description": (
            "Add another Linked copy of a named node or Object, with its "
            "own placement."
        ),
        "input_schema": _obj({
            "node_id": dict(_ID, description="The node or Object to "
                            "copy."),
            "params": _PARAMS,
        }, ["node_id"]),
    },
    {
        "name": "attach_parts",
        "description": (
            "Mate one part to another, anchor to anchor: the two "
            "anchors coincide and their directions oppose (the BOSL2 "
            "attach() model — no constraint solver). The mate is live, "
            "so moving the parent moves the child. The parent must be a "
            "SIBLING of the child. Pass detach:true to release one."
        ),
        "input_schema": _obj({
            "node_id": dict(_ID, description="The part that moves."),
            "parent": {"type": "string",
                       "description": "Name of the part to attach to."},
            "anchor": {"type": "string",
                       "description": "Anchor on the moving part "
                                      "(list_anchors)."},
            "parent_anchor": {"type": "string",
                              "description": "Anchor on the parent."},
            "offset": {"type": "number",
                       "description": "mm along the mate axis."},
            "spin": {"type": "number",
                     "description": "Degrees about the mate axis."},
            "kind": {"type": "string",
                     "enum": ["coincident", "concentric", "angle"],
                     "description": "coincident (default): the anchors "
                                    "touch. concentric: axes aligned, "
                                    "the part slides along the axis "
                                    "(offset = the slide; a drag keeps "
                                    "the mate). angle: a hinge, the "
                                    "child turned by `angle` degrees "
                                    "about the anchor's edge."},
            "align": {"type": "string", "enum": ["opposed", "same"],
                      "description": "opposed (default): face to face. "
                                     "same: flush, both anchors "
                                     "pointing the same way."},
            "angle": {"type": "number",
                      "description": "Hinge angle in degrees (kind "
                                     "angle)."},
            "ratio": {"type": "number",
                      "description": "Gear mate: the child's spin "
                                     "follows the parent's spin times "
                                     "this ratio, the opposite way."},
            "min_offset": {"type": "number",
                           "description": "Limit mate: the offset / "
                                          "slide never goes below this."},
            "max_offset": {"type": "number",
                           "description": "...nor above this."},
            "detach": {"type": "boolean",
                       "description": "Release the mate instead."},
        }, ["node_id"]),
    },
    {
        "name": "insert_part",
        "description": (
            "Insert a parametric part from the library as one finished "
            "Object. Dimensions default to the chosen standard size; "
            "override only what the user asked to change."
        ),
        "input_schema": _obj({
            "part_id": {"type": "string",
                        "description": "From list_parts."},
            "size": {"type": "string",
                     "description": "A size name from that part's "
                                    "table, e.g. 'CF40' or 'M6'."},
            "dims": {"type": "object",
                     "description": "Dimension overrides, by the names "
                                    "list_parts gives, in the part's "
                                    "`unit` (mm; nm for crystals, "
                                    "surfaces, graphene and nanotubes — "
                                    "e.g. {\"tube_n\": 10, \"length\": "
                                    "4})."},
            "color": {"type": "string",
                      "description": "For parts that come in colours "
                                     "(Lego bricks, tree seasons, wall "
                                     "materials, lit signal): one of the "
                                     "names list_parts gives, e.g. "
                                     "'Red', 'Autumn', 'Brick'."},
            "name": {"type": "string"},
            "x": {"type": "number", "description": "Placement, mm."},
            "y": {"type": "number"},
            "z": {"type": "number"},
            "rz": {"type": "number",
                   "description": "Turn about Z, degrees."},
        }, ["part_id"]),
    },
    {
        "name": "list_crystals",
        "description": (
            "The crystal library: 32 standard structures — FCC, BCC, "
            "HCP and simple-cubic metals, diamond and zinc-blende "
            "semiconductors, wurtzite, rock salt, CsCl, fluorite, "
            "rutile, anatase, perovskite, alpha-quartz, graphite, h-BN — "
            "each with its space group, lattice (nm, degrees), atoms per "
            "cell, density and coordination polyhedra. Pass `crystal` "
            "for one in full (every atom's fractional coordinates, the "
            "nearest distances). Use it before build_crystal; never type "
            "a crystal's atoms yourself."
        ),
        "input_schema": _obj({
            "category": {"type": "string",
                         "description": "Filter to one family."},
            "crystal": {"type": "string",
                        "description": "A key, e.g. 'quartz', 'cu', "
                                       "'rutile'."},
        }),
    },
    {
        "name": "build_crystal",
        "description": (
            "Build a crystal in nanometres as Objects: its UNIT CELL "
            "(atoms at covalent radii, lattice box, coordination "
            "polyhedra such as SiO4 tetrahedra), a SUPERCELL (for loops "
            "over na x nb x nc cells) and/or a PARTICLE — a shape filled "
            "with every cell whose centre is inside, or with blocks of "
            "N x N x N cells. build 'hierarchy' makes all three side by "
            "side. The build is counted first (cells, atoms, polyhedra, "
            "triangles) and refused past what the 3D view can draw, with "
            "what to change; dry_run returns the counts only. An empty "
            "document is switched to nm. Tunables become prefixed "
            "document variables (quartz_r, quartz_N) the user can edit."
        ),
        "input_schema": _obj({
            "crystal": {"type": "string",
                        "description": "Library key from list_crystals."},
            "custom": {"type": "object",
                       "description": "A crystal the library lacks: {name, "
                                      "a, b, c, alpha, beta, gamma, atoms: "
                                      "[[element, fx, fy, fz], ...], "
                                      "polyhedra: {centre, ligand, "
                                      "cutoff}, units: 'angstrom' | "
                                      "'nm'} — every atom of the "
                                      "conventional cell, fractional. "
                                      "Or give only the asymmetric unit as "
                                      "atoms plus symops: ['x,y,z', "
                                      "'-x+1/2,y,-z', ...] and every atom "
                                      "is generated; or cif: the text of a "
                                      "CIF file."},
            "path": {"type": "string",
                     "description": "A CIF file to build (ICSD, COD, "
                                    "Materials Project, a paper's SI): its "
                                    "symmetry operators expand the "
                                    "asymmetric unit to every atom."},
            "build": {"type": "string",
                      "enum": ["hierarchy", "unit_cell", "supercell",
                               "particle", "scatter"],
                      "description": "'scatter' spreads `count` copies "
                                     "of the particle over an area, each "
                                     "sitting on the plane and turned at "
                                     "random — a dispersion on a "
                                     "substrate. One particle is built "
                                     "and instanced, so the copies are "
                                     "nearly free."},
            "count": {"type": "integer",
                      "description": "scatter: how many particles "
                                     "(default 12)."},
            "area_nm": {"type": "array", "items": {"type": "number"},
                        "description": "scatter: the patch [x, y] they "
                                       "are spread over, nm."},
            "seed": {"type": "integer",
                     "description": "scatter: the same seed gives the "
                                    "same arrangement."},
            "min_gap_nm": {"type": "number",
                           "description": "scatter: smallest gap between "
                                          "two particles (default 1)."},
            "substrate": {"type": "boolean",
                          "description": "scatter: draw a thin slab under "
                                         "the patch (default true)."},
            "random_turn": {"type": "boolean",
                            "description": "scatter: turn each particle "
                                           "at random about z (default "
                                           "true)."},
            "representation": {"type": "string",
                               "enum": ["auto", "vesta",
                                        "ball_and_stick", "atoms",
                                        "polyhedra", "both"],
                               "description": "How a cell is drawn, in "
                                              "VESTA's colours. vesta: "
                                              "small balls + bonds + "
                                              "translucent polyhedra; "
                                              "ball_and_stick: balls + "
                                              "bonds; atoms: full-size "
                                              "spheres. auto: vesta in "
                                              "the unit cell, polyhedra "
                                              "(else atoms) in supercells."},
            "supercell": {"type": "array", "items": {"type": "integer"},
                          "description": "[na, nb, nc], default [4, 4, 4]."},
            "shape": {"type": "string",
                      "enum": ["sphere", "hemisphere", "cube", "box",
                               "cylinder", "hexagonal_prism",
                               "octahedron"]},
            "size_nm": {"type": "number",
                        "description": "Diameter (sphere, hemisphere, "
                                       "cylinder), edge (cube), across "
                                       "corners (hexagonal prism), tip to "
                                       "tip (octahedron). Default 10."},
            "height_nm": {"type": "number",
                          "description": "Cylinder / hexagonal prism."},
            "box_nm": {"type": "array", "items": {"type": "number"},
                       "description": "Box edges [x, y, z]."},
            "fill": {"type": "string",
                     "enum": ["auto", "atoms", "polyhedra", "blocks"],
                     "description": "What fills the particle; auto keeps "
                                    "cells while light, blocks beyond."},
            "block_cells": {"type": "integer",
                            "description": "Cells per block edge (10: a "
                                           "block is 1000 cells)."},
            "gap": {"type": "number",
                    "description": "Gap between blocks, fraction of a "
                                   "block (0 = solid). Default 0.03."},
            "atom_scale": {"type": "number",
                           "description": "x the covalent radius, default "
                                          "1."},
            "cell_box": {"type": "boolean",
                         "description": "Draw the lattice boxes (default "
                                        "true)."},
            "segments": {"type": "integer",
                         "description": "Sphere segments for atoms "
                                        "(default 12)."},
            "dry_run": {"type": "boolean",
                        "description": "Count only; build nothing."},
        }),
    },
    {
        "name": "build_surface",
        "description": (
            "Build a crystal SURFACE in nanometres: a slab of a library "
            "(or custom) crystal cut along any (hkl) plane — Si(111), "
            "SiO2 quartz (0001), rutile (110), Cu(100), GaN (10-10). The "
            "primitive surface cell is found for any crystal system "
            "(centring included), turned so the surface normal is +z with "
            "the top at z = 0, repeated nx x ny with a for loop and "
            "`layers` interplanar spacings deep. Bulk-terminated (no "
            "relaxation or reconstruction). The cut falls in the widest "
            "gap between planes unless `termination` says where. Returns "
            "the surface cell, angle, spacing and atom count; dry_run "
            "builds nothing. The usual faces of every library crystal "
            "are also ready parts (insert_part 'surface_<key>_<hkl>'); "
            "graphene and graphite, with their bonds, are the parts in "
            "'Surfaces: Graphene & graphite', not this tool."
        ),
        "input_schema": _obj({
            "crystal": {"type": "string",
                        "description": "Library key from list_crystals."},
            "custom": {"type": "object",
                       "description": "A crystal the library lacks, as in "
                                      "build_crystal."},
            "miller": {"type": "string",
                       "description": "'111', '1 1 0', '1-10', or four "
                                      "hexagonal indices '0001', '10-10'."},
            "repeat": {"type": "array", "items": {"type": "integer"},
                       "description": "Surface cells [nu, nv], default "
                                      "[6, 6]."},
            "layers": {"type": "integer",
                       "description": "Interplanar spacings deep "
                                      "(default 3)."},
            "termination": {"type": "number",
                            "description": "0..1 of a layer: where the cut "
                                           "falls (omit for automatic)."},
            "atom_scale": {"type": "number"},
            "segments": {"type": "integer"},
            "cell_box": {"type": "boolean",
                         "description": "Thin base plate under the slab."},
            "dry_run": {"type": "boolean"},
        }),
    },
    {
        "name": "build_house",
        "description": (
            "The House Builder in one call: floors of rectangular rooms "
            "(x, y, w, d in mm — wall centre-lines, so rooms sharing an "
            "edge share ONE wall), doors and windows on each room's N/S/"
            "E/W side (see-through glass panes, openings built from solid "
            "wall pieces so the preview shows them), and furniture from "
            "the Part Library. Each floor is an Object stacked in Z; every "
            "piece of furniture is its own Object inside it. Place a piece "
            "with `wall` ('N'/'S'/'E'/'W': back flush against that wall, "
            "turned to face the room, `along` = its centre's distance "
            "from the room's W or S corner, default the middle) or with "
            "x/y from the room's corner and rz; `z` lifts it (wall and "
            "ceiling pieces default to their own height) and `on_top: "
            "true` sets it down on the furniture under it (a TV on its "
            "unit, a microwave on the worktop). A room's `surface` "
            "'garden' or 'paving' is an outdoor area (porch, patio, "
            "driveway, lawn) with no walls or roof. `roof` picks the top "
            "floor's roof (flat by default). Never assemble walls or "
            "furniture by hand."
        ),
        "input_schema": _obj({
            "template": {"type": "string",
                         "enum": ["Chemistry lab", "Physics lab",
                                  "Electronics lab", "Company office",
                                  "Bungalow — 1 bedroom",
                                  "Bungalow — 2 bedrooms",
                                  "Bungalow — 3 bedrooms",
                                  "Two-storey house — 1 bedroom",
                                  "Two-storey house — 2 bedrooms",
                                  "Two-storey house — 3 bedrooms",
                                  "Block of flats — 10 storeys",
                                  "Arab courtyard house",
                                  "Modern house with pool"],
                         "description": "Start from a whole furnished "
                                        "building (fume hoods, benches, "
                                        "optical tables, UHV chambers, "
                                        "bench desks, meeting and server "
                                        "rooms…). Its floors are used "
                                        "unless you pass your own; other "
                                        "keys (roof, walls) override it. "
                                        "Lab and office pieces are "
                                        "lab_* / office_* part ids. 'Arab "
                                        "courtyard house': rooms round a "
                                        "courtyard with a fountain, a "
                                        "first-floor gallery, arched "
                                        "openings and a crenellated "
                                        "terrace roof."},
            "floors": {
                "type": "array",
                "description": "Bottom to top.",
                "items": {"type": "object", "properties": {
                    "name": {"type": "string"},
                    "wall_height": {"type": "number"},
                    "wall_thickness": {
                        "type": "number",
                        "description": "Outside walls, mm (200)."},
                    "inner_wall_thickness": {
                        "type": "number",
                        "description": "Walls between rooms, mm (100)."},
                    "slab_thickness": {"type": "number"},
                    "rooms": {"type": "array", "items": {
                        "type": "object", "properties": {
                            "name": {"type": "string"},
                            "x": {"type": "number"},
                            "y": {"type": "number"},
                            "w": {"type": "number"},
                            "d": {"type": "number"},
                            "surface": {"type": "string",
                                        "enum": ["indoor", "garden",
                                                 "paving", "void"],
                                        "description": "void: a "
                                        "stairwell with no floor, open "
                                        "(a balustrade) towards a hall "
                                        "or landing. Rooms with the same "
                                        "name are one open space, no "
                                        "wall between them."},
                            "finish": {
                                "type": "string",
                                "description": (
                                    "Tiles or panelling on this room's "
                                    "walls: White tiles, White metro "
                                    "tiles, Green metro tiles, Black "
                                    "metro tiles, Blue tiles, Blue "
                                    "mosaic, Green zellige, Pink "
                                    "zellige, Hexagon tiles, Marble, "
                                    "Grey porcelain, Terracotta tiles, "
                                    "Wood panelling, or None. Omit and "
                                    "a bathroom, shower room, toilet, "
                                    "kitchen or utility is tiled "
                                    "automatically (bathroom: half "
                                    "height, full height behind the "
                                    "bath and shower; kitchen: a "
                                    "splashback behind worktops and "
                                    "sinks) and other rooms stay "
                                    "painted."),
                            },
                            "flooring": {
                                "type": "string",
                                "description": (
                                    "Floor covering: Oak floorboards, "
                                    "Walnut floorboards, Grey oak, Oak "
                                    "parquet, Grey carpet, Beige "
                                    "carpet, Blue carpet, Grey "
                                    "porcelain, Stone tiles, Slate "
                                    "tiles, Terracotta, Checkerboard, "
                                    "Hexagon tiles, Terrazzo, Marble, "
                                    "Polished concrete, Vinyl. Omit to "
                                    "choose from the room's name "
                                    "(carpet in bedrooms, boards in "
                                    "living rooms, tiles in kitchens "
                                    "and bathrooms)."),
                            },
                            "openings": {"type": "array", "items": {
                                "type": "object", "properties": {
                                    "kind": {"type": "string",
                                             "enum": ["door", "window",
                                                      "garage door",
                                                      "arch window",
                                                      "arch door"],
                                             "description": "arch window "
                                             "and arch door are "
                                             "round-headed (an Arab, "
                                             "Moorish or Mediterranean "
                                             "house): arch door 1100 x "
                                             "2500 with a studded timber "
                                             "leaf, arch window 900 x "
                                             "1600 on a 950 sill, each "
                                             "with a stone ring."},
                                    "side": {"type": "string",
                                             "enum": ["N", "S", "E", "W"]},
                                    "offset": {
                                        "type": "number",
                                        "description": "From the side's "
                                        "W (N/S sides) or S (E/W sides) "
                                        "corner."},
                                    "width": {"type": "number"},
                                    "height": {"type": "number"},
                                    "sill": {"type": "number"}}}},
                            "furniture": {"type": "array", "items": {
                                "type": "object", "properties": {
                                    "part_id": {"type": "string"},
                                    "size": {"type": "string"},
                                    "color": {"type": "string"},
                                    "dims": {"type": "object"},
                                    "name": {"type": "string"},
                                    "wall": {"type": "string",
                                             "enum": ["N", "S", "E", "W"]},
                                    "along": {"type": "number"},
                                    "gap": {"type": "number"},
                                    "x": {"type": "number"},
                                    "y": {"type": "number"},
                                    "z": {"type": "number"},
                                    "rz": {"type": "number"},
                                    "on_top": {"type": "boolean"}},
                                "required": ["part_id"]}}},
                        "required": ["w", "d"]}}}},
            },
            "roof": {"type": "object",
                     "description": "The top floor's roof; omit for flat.",
                     "properties": {
                         "style": {"type": "string",
                                   "enum": ["Flat", "Gable", "Hip",
                                            "Pyramid", "Lean-to"]},
                         "pitch": {"type": "number",
                                   "description": "Degrees, 5-60."},
                         "overhang": {"type": "number"},
                         "parapet": {
                             "type": "number",
                             "description": "A FLAT roof's parapet: its "
                             "height in mm round every outside wall "
                             "(courtyard-facing ones too), 0 for none. "
                             "With a parapet the roof is a slab over "
                             "each indoor room of the top floor, so a "
                             "courtyard (a paving room) stays open."},
                         "crenellated": {
                             "type": "boolean",
                             "description": "The parapet as merlons and "
                             "gaps, as on an Arab house."},
                         "ridge": {"type": "string",
                                   "enum": ["auto", "x", "y"]},
                         "color": {
                             "type": "string",
                             "description": (
                                 "Covering: Brown tiles, Red clay, "
                                 "Terracotta pantiles, Grey tiles, "
                                 "Black pantiles, Slate, Dark slate, "
                                 "Cedar shingles, Thatch, Green, Green "
                                 "roof, Zinc, Copper (verdigris), Solar "
                                 "panels, Flat terrace (light concrete "
                                 "for a flat roof).")},
                         "wings": {
                             "type": "string",
                             "enum": ["Lean-to", "Gable", "Hip", "Flat",
                                      "Same as main"],
                             "description": "The roof over a side wing — "
                             "a part of a floor with nothing above it, "
                             "like a garage, which would stand open "
                             "otherwise. Default a lean-to on the taller "
                             "part."},
                         "chimney": {
                             "type": "string",
                             "enum": ["auto", "ridge", "none"],
                             "description": "auto (default): a chimney "
                             "over every fireplace (part home_fireplace) — "
                             "a stack outside an outside wall, a breast "
                             "through the floors above an inside wall; "
                             "ridge: one on the ridge even without a "
                             "fireplace."}}},
            "walls": {
                "type": "object",
                "description": "How the walls are finished.",
                "properties": {
                    "outside": {
                        "type": "string",
                        "description": (
                            "Painted plaster, White render, Cream "
                            "render, Grey render, Red brick, Buff "
                            "brick, Yellow stock brick, Brown brick, "
                            "Blue engineering brick, Painted brick, "
                            "Grey stone, Cotswold stone, Timber "
                            "cladding, Grey cladding, White "
                            "weatherboard, Concrete, Sand render, "
                            "Ochre render, Terracotta render, "
                            "Lime-washed white.")},
                    "inside": {
                        "type": "string",
                        "description": (
                            "Between rooms: Painted plaster, Warm "
                            "white, Soft grey, Sage, Duck egg, Clay "
                            "pink, Mustard, Navy, Exposed brick.")},
                    "joinery": {
                        "type": "string",
                        "description": (
                            "Window and door frames, fascias: White, "
                            "Anthracite grey, Black, Oak, Sage green, "
                            "Cream, Walnut, Turquoise; omit for what "
                            "suits the outside walls.")}}},
            "garden": {"type": "object",
                       "description": "Lawn beside the house; omit for "
                                      "none.",
                       "properties": {"width": {"type": "number"},
                                      "depth": {"type": "number"},
                                      "gap": {"type": "number"}}},
            "dry_run": {"type": "boolean",
                        "description": "Check and resolve placements; "
                                       "build nothing."},
        }),
    },
    {
        "name": "list_molecules",
        "description": (
            "The compound library: about 490 compounds — gases, "
            "inorganic acids, bases and ions, VSEPR shapes (BF3, SF6, "
            "XeF4…), hydrocarbons, alcohols, carbonyls, acids, esters, "
            "nitrogen compounds and solvents, biomolecules, benzene "
            "derivatives, polycyclic aromatics, and the common medicines "
            "by what they treat (pain, antibiotics, heart, brain, "
            "stomach & allergy, hormones & vitamins) — with formula and "
            "SMILES, plus the fullerene cages (C20, C60, C70, C80). Pass "
            "`compound` for one in full (3D atoms in nm, bonds). Anything "
            "else is built from its SMILES."
        ),
        "input_schema": _obj({
            "category": {"type": "string",
                         "description": "Filter to one family."},
            "compound": {"type": "string",
                         "description": "A key, name or formula, e.g. "
                                        "'caffeine', 'Water', 'CO2'."},
        }),
    },
    {
        "name": "build_molecule",
        "description": (
            "Build a molecule in 3D, in nanometres, as one Object — from "
            "the library (`compound`: key, name or formula) or from any "
            "SMILES. Every atom gets its VSEPR shape (lone pairs "
            "included: water bent, XeF4 square), rings are placed whole "
            "and the result relaxed — a faithful sketch of the shape, "
            "not a quantum-chemistry optimum. Never place atoms by hand."
        ),
        "input_schema": _obj({
            "compound": {"type": "string",
                         "description": "Library key, name or formula."},
            "smiles": {"type": "string",
                       "description": "Any SMILES, e.g. 'CCO', "
                                      "'c1ccccc1O', '[NH4+]'."},
            "name": {"type": "string"},
            "style": {"type": "string",
                      "enum": ["ball_and_stick", "space_filling",
                               "sticks", "lattice"]},
            "segments": {"type": "integer",
                         "description": "Round segments (default 16)."},
            "dry_run": {"type": "boolean",
                        "description": "Formula, atoms and triangles "
                                       "only; build nothing."},
        }),
    },
    {
        "name": "list_character_options",
        "description": (
            "Everything build_character accepts: genders, ages, builds, "
            "skin tones, arm gestures and leg stances, hair styles and "
            "colours, beards, glasses, hats, and every top, bottom, coat "
            "and pair of shoes with the BODY PARTS it covers; the named "
            "colours; the body parts and part groups a custom garment "
            "row may name; the materials; and the presets (Doctor, "
            "Chef, Runner, Grandmother, …). Call it before "
            "build_character, and to invent clothes the catalogue lacks."
        ),
        "input_schema": _obj({}),
    },
    {
        "name": "list_shoe_options",
        "description": (
            "Everything build_shoe accepts: the presets (Devil arrow "
            "pump, Classic black pump, Kitten heel pump, Block-heel ankle "
            "boot, Cork wedge sandal, Square-toe loafer, Ballet flat, "
            "Tennis sneaker, Oxford dress shoe, Work boot, Running shoe, "
            "High-top basketball, Retro court shoe, Canvas skate shoe), "
            "genders, toes, uppers, soles, heels, side decorations and "
            "named colours. Call it before build_shoe."
        ),
        "input_schema": _obj({}),
    },
    {
        "name": "build_shoe",
        "description": (
            "Add a SHOE (or a pair) as one Object — the Shoe Builder in "
            "one call. Start from a `preset` or none; every other key "
            "overrides it: gender (Women/Men, men's last 4 % wider), "
            "size (EU, sets the length), toe (Pointed/Round/Square), "
            "upper (Pump, Ballet flat, Loafer, Oxford, Sneaker, "
            "High-top, Ankle boot, Work boot, Sandal), sole (Thin rises "
            "with the heel; Leather, Cupsole, Runner, Vulcanised, Lug "
            "are thick with toe spring), heel (Stiletto, Block, Wedge, "
            "None) + heel_height mm, arrow (a devil-tail arrowhead at "
            "the stiletto's tip), decoration (an ORIGINAL side wave or "
            "stripe — never copy a brand's logo), pair, and colours "
            "upper_colour / lining_colour / sole_colour / heel_colour / "
            "accent_colour / lace_colour (a name from list_shoe_options "
            "or #rrggbb). `replace_id` rebuilds an earlier shoe in place."
        ),
        "input_schema": _obj({
            "preset": {"type": "string"},
            "name": {"type": "string"},
            "gender": {"type": "string"},
            "size": {"type": "number", "description": "EU size 30-50."},
            "toe": {"type": "string"}, "upper": {"type": "string"},
            "sole": {"type": "string"}, "heel": {"type": "string"},
            "heel_height": {"type": "number", "description": "mm"},
            "arrow": {"type": "boolean"},
            "decoration": {"type": "string"},
            "pair": {"type": "boolean"},
            "upper_colour": {"type": "string"},
            "lining_colour": {"type": "string"},
            "sole_colour": {"type": "string"},
            "heel_colour": {"type": "string"},
            "accent_colour": {"type": "string"},
            "lace_colour": {"type": "string"},
            "x": {"type": "number"}, "y": {"type": "number"},
            "rz": {"type": "number"},
            "replace_id": {"type": "number"},
        }),
    },
    {
        "name": "build_character",
        "description": (
            "Add a dressed, posed PERSON as one Object — the Human "
            "Builder in one call. Start from a `preset` or none; every "
            "other key overrides it: body (gender, age, build, stature "
            "in mm), skin, gesture (arms) and stance (legs), hair and "
            "hair_colour, beard, glasses, hat + hat_colour, top / bottom "
            "/ coat / shoes / gloves each + its _colour (a colour name "
            "from list_character_options or #rrggbb). Clothes are "
            "painted by BODY PART, so they stay on in any pose; skirts, "
            "coat tails, hoods, capes, hair, hats and glasses are solids "
            "fitted to the posed body. To make clothes the catalogue "
            "lacks, add `garments`: rows [part, colour, material] "
            "applied last — a part (chest, waist, hips, shoulder, "
            "upper_arm, forearm, hand, upper_thigh, thigh, shin, ankle, "
            "foot, neck, head) or group (torso, arm, leg, body), "
            "optionally '.L' / '.R' for one side: a glove on one hand is "
            "['hand.R', '#1d1e22', 'Rubber'], striped socks are two "
            "rows, a one-shoulder top covers 'chest' + 'shoulder.L'. "
            "Anything that stands off the body (a bag, a tie, a crown) "
            "is ordinary geometry you add beside it with apply_code, "
            "placed with face_landmarks / probe_surface on the figure. "
            "`replace_id` rebuilds an earlier person in place."
        ),
        "input_schema": _obj({
            "preset": {"type": "string",
                       "description": "A preset from "
                                      "list_character_options."},
            "name": {"type": "string"},
            "gender": {"type": "string"}, "age": {"type": "string"},
            "build": {"type": "string"},
            "stature": {"type": "number",
                        "description": "Height in mm (0 = typical)."},
            "skin": {"type": "string",
                     "description": "Skin tone name or #rrggbb."},
            "gesture": {"type": "string"}, "stance": {"type": "string"},
            "hair": {"type": "string"}, "hair_colour": {"type": "string"},
            "beard": {"type": "string"}, "glasses": {"type": "string"},
            "hat": {"type": "string"}, "hat_colour": {"type": "string"},
            "top": {"type": "string"}, "top_colour": {"type": "string"},
            "bottom": {"type": "string"},
            "bottom_colour": {"type": "string"},
            "coat": {"type": "string"}, "coat_colour": {"type": "string"},
            "shoes": {"type": "string"}, "shoes_colour": {"type": "string"},
            "gloves": {"type": "string"},
            "gloves_colour": {"type": "string"},
            "garments": {"type": "array",
                         "items": {"type": "array"},
                         "description": "Custom garment rows [part, "
                                        "colour, material], applied "
                                        "last."},
            "x": {"type": "number"}, "y": {"type": "number"},
            "rz": {"type": "number",
                   "description": "Turn about Z, degrees (0 faces -Y)."},
            "replace_id": {"type": "integer",
                           "description": "A person Object to rebuild "
                                          "in place."},
        }),
    },
    {
        "name": "build_reaction",
        "description": (
            "Write a chemical reaction in 3D: '2 H2 + O2 -> 2 H2O', 'CH4 "
            "+ 2 O2 -> CO2 + 2 H2O', 'N2 + 3 H2 <=> 2 NH3' (arrows -> <=> "
            "→ ⇌ =, spaces round them and round '+'; coefficients may be "
            "fractions; species are library keys, names, formulas with "
            "charges — NH4+, SO4^2- — or smiles:...). Checks the atom "
            "and charge balance and, with balance (default true), finds "
            "the missing coefficients. Lays the molecules out left to "
            "right with coefficients, + and the arrow in 3D, the formula "
            "under each; returns the balanced equation and the "
            "per-element table."
        ),
        "input_schema": _obj({
            "equation": {"type": "string"},
            "balance": {"type": "boolean",
                        "description": "Find missing coefficients "
                                       "(default true)."},
            "labels": {"type": "boolean",
                       "description": "Formula under each molecule "
                                      "(default true)."},
            "style": {"type": "string",
                      "enum": ["ball_and_stick", "space_filling",
                               "sticks", "lattice"]},
            "segments": {"type": "integer"},
            "dry_run": {"type": "boolean",
                        "description": "Balance and count only."},
        }, ["equation"]),
    },
    {
        "name": "chemistry",
        "description": (
            "The Chemistry Builder (Library ▸ Science ▸ Chemistry Builder…) "
            "— build, edit, MEASURE and export molecules, crystals, surfaces "
            "and reactions, then put them in the document. One action a "
            "call: load (source compound: name/formula/SMILES; crystal: "
            "library key + cells [a,b,c] + dope; surface: crystal + miller "
            "+ repeat [u,v] + layers + complete (whole polyhedra at the "
            "cut) + dope; cif: path; reaction: equation) · state (atoms "
            "[index, element, x, y, z Å] and bonds) · measure (atoms: 2 = "
            "distance Å, 3 = angle °, 4 = torsion °; drawn on the "
            "builder's canvas too) · edit (op add {element, position or "
            "bond_to}, delete, bond, unbond, move {position}, element, "
            "find_bonds; atoms = 0-based indices) · dope (rule 'Nb:Mo:0.1', "
            "seed) · adsorb (a compound onto a loaded surface: mode flat / "
            "upright / as drawn, height Å above the top layer, spin °, x, "
            "y; else the first free spot) · move_adsorbate (group, x, y, "
            "height, rx, ry, rz) · remove_adsorbate · properties (formula, "
            "mass, composition at.% / wt.%, bond range, space group, "
            "density) · export (path .xyz .pdb .cif .mol .sdf) · build "
            "(into the document, ball and stick in nm with the cell box; a "
            "reaction becomes a film driven by the rx_t slider — finish "
            "with play_motion)."
        ),
        "input_schema": _obj({
            "action": {"type": "string",
                       "enum": ["load", "state", "measure", "edit", "dope",
                                "adsorb", "move_adsorbate",
                                "remove_adsorbate", "properties", "export",
                                "build"]},
            "source": {"type": "string",
                       "enum": ["compound", "crystal", "surface", "cif",
                                "reaction"]},
            "compound": {"type": "string"},
            "crystal": {"type": "string",
                        "description": "Library key from list_crystals."},
            "cells": {"type": "array", "items": {"type": "integer"}},
            "miller": {"type": "string"},
            "repeat": {"type": "array", "items": {"type": "integer"}},
            "layers": {"type": "integer"},
            "termination": {"type": "number"},
            "complete": {"type": "boolean",
                         "description": "Whole coordination polyhedra at "
                                        "a surface cut."},
            "dope": {"type": "string",
                     "description": "host:dopant:fraction, e.g. Nb:Mo:0.1."},
            "rule": {"type": "string"},
            "seed": {"type": "integer"},
            "equation": {"type": "string"},
            "path": {"type": "string",
                     "description": "A CIF to load, or the file to export."},
            "format": {"type": "string",
                       "enum": ["xyz", "pdb", "cif", "mol", "sdf"]},
            "atoms": {"type": "array", "items": {"type": "integer"}},
            "op": {"type": "string",
                   "enum": ["add", "delete", "bond", "unbond", "move",
                            "element", "find_bonds"]},
            "element": {"type": "string"},
            "position": {"type": "array", "items": {"type": "number"}},
            "bond_to": {"type": "integer"},
            "order": {"type": "integer"},
            "mode": {"type": "string",
                     "enum": ["flat", "upright", "as drawn"]},
            "height": {"type": "number"},
            "spin": {"type": "number"},
            "x": {"type": "number"},
            "y": {"type": "number"},
            "rx": {"type": "number"},
            "ry": {"type": "number"},
            "rz": {"type": "number"},
            "group": {"type": "integer"},
            "name": {"type": "string"},
            "style": {"type": "string",
                      "enum": ["ball_and_stick", "space_filling", "sticks"]},
            "cell_box": {"type": "boolean"},
        }, ["action"]),
    },
    {
        "name": "list_proteins",
        "description": (
            "What the Protein Builder takes: the preset peptides (alpha "
            "and 3-10 helix, beta strand, a Trpzip beta hairpin, "
            "polyproline, collagen, melittin, magainin, the GCN4 zipper, "
            "amyloid beta) with sequence and secondary structure, the "
            "secondary-structure letters, styles and colour schemes."
        ),
        "input_schema": _obj({}),
    },
    {
        "name": "build_protein",
        "description": (
            "Build a protein or peptide in 3D, in nanometres, as one "
            "Object. Either BUILT from a sequence — ideal bond geometry, "
            "each residue's backbone on the (phi, psi) of its secondary-"
            "structure letter, side chains on clash-free rotamers; local "
            "structure only, NOT a fold (the result reports clashes) — "
            "or READ as a real fold: pdb_id downloads from RCSB, uniprot "
            "the AlphaFold model, path a .pdb/.cif file, pdb_text a PDB "
            "you have. Drawn as a cartoon (helix ribbons, strand arrows), "
            "cartoon with side chains, CA trace, or every atom; ligands "
            "ball and stick. Never place a protein's atoms by hand."
        ),
        "input_schema": _obj({
            "preset": {"type": "string",
                       "description": "A list_proteins preset key."},
            "sequence": {"type": "string",
                         "description": "One-letter codes (FASTA ok)."},
            "secondary": {"type": "string",
                          "description": "helix, strand, polyproline, "
                                         "coil — or a letter per residue: "
                                         "H helix, G 3-10, E strand, T "
                                         "turn (TT between strands = "
                                         "hairpin), P PPII, L left-handed,"
                                         " C coil. Default helix."},
            "phi_psi": {"type": "array",
                        "items": {"type": "array"},
                        "description": "Explicit [phi, psi] per residue "
                                       "(degrees), overriding secondary."},
            "pdb_id": {"type": "string",
                       "description": "RCSB entry, e.g. 1CRN, 1UBQ, "
                                      "4HHB."},
            "uniprot": {"type": "string",
                        "description": "UniProt accession for the "
                                       "AlphaFold model, e.g. P69905."},
            "path": {"type": "string",
                     "description": "A .pdb or .cif file (full access)."},
            "pdb_text": {"type": "string",
                         "description": "PDB or mmCIF text."},
            "name": {"type": "string"},
            "style": {"type": "string",
                      "enum": ["cartoon", "cartoon_sticks", "trace",
                               "ball_and_stick", "sticks",
                               "space_filling"]},
            "colour": {"type": "string",
                       "enum": ["structure", "chain", "rainbow", "residue",
                                "hydropathy", "element"],
                       "description": "Default: structure for cartoons, "
                                      "element for atoms."},
            "chains": {"type": "string",
                       "description": "Only these chains, e.g. 'A, B'."},
            "ligands": {"type": "boolean",
                        "description": "Draw ligands (default true)."},
            "water": {"type": "boolean",
                      "description": "Draw waters (default false)."},
            "detail": {"type": "integer",
                       "description": "Cartoon rings a residue (default "
                                      "6)."},
            "segments": {"type": "integer",
                         "description": "Round segments (default 10)."},
            "dry_run": {"type": "boolean",
                        "description": "Summary and triangles only."},
        }),
    },
    {
        "name": "select_nodes",
        "description": (
            "Select nodes in the window, so the user sees what you mean "
            "and the geometry is highlighted in both viewers. Pass no "
            "ids to clear the selection."
        ),
        "input_schema": _obj({"ids": _IDS}),
    },

    # ── Document ───────────────────────────────────────────────────
    {
        "name": "set_reference_image",
        "description": (
            "Put a reference picture — a photo, a sketch, a character "
            "sheet — on one of the axis planes, to model against it "
            "(Blender's reference images). It shows in the 2D view "
            "while that plane is shown and in the 3D view on its plane, "
            "behind the model, and is saved with the document. Pass "
            "clear to remove them all, or remove with an index."
        ),
        "input_schema": _obj({
            "path": {"type": "string",
                     "description": "Absolute path of a PNG/JPEG."},
            "plane": {"type": "string", "enum": ["Top", "Front", "Side"],
                      "description": "Top = XY (default), Front = XZ, "
                                     "Side = YZ."},
            "x": {"type": "number",
                  "description": "The picture's lower-left corner along "
                                 "the plane's horizontal axis, mm "
                                 "(default: centred on the origin)."},
            "y": {"type": "number",
                  "description": "... along the plane's vertical axis."},
            "width": {"type": "number",
                      "description": "Width in mm (default 100); the "
                                     "height follows the picture."},
            "offset": {"type": "number",
                       "description": "The plane's distance along its "
                                      "normal, mm — e.g. a Front picture "
                                      "set behind the model."},
            "opacity": {"type": "number",
                        "description": "0-1 (default 0.5)."},
            "remove": {"type": "integer",
                       "description": "Remove the picture at this index "
                                      "instead."},
            "clear": {"type": "boolean",
                      "description": "Remove every reference picture."},
        }),
    },
    {
        "name": "set_render_options",
        "description": (
            "The document-wide segment count ($fn) for round objects, "
            "the document unit, and the 3D camera. Higher segments are "
            "smoother and slower — raise it for an export, not while "
            "iterating."
        ),
        "input_schema": _obj({
            "time": {"type": "number",
                     "description": "OpenSCAD's animation time $t, 0-1: "
                                    "a model whose expressions read $t "
                                    "is shown at that moment (the "
                                    "document is not changed)."},
            "segments": {"type": "integer",
                         "description": "Global $fn (3-512)."},
            "unit": {"type": "string",
                     "enum": ["nm", "um", "mm", "cm", "m", "in"],
                     "description": "What one model unit means — a "
                                    "LABEL for every readout (status "
                                    "bar, 2D view, Analyse, Blueprint, "
                                    "these tools); the geometry is not "
                                    "rescaled. Set it before building a "
                                    "model at another scale: a 100 nm "
                                    "particle is written 100 in a nm "
                                    "document. Saved with the file; one "
                                    "undo step."},
            "real_scale": {"type": "number", "exclusiveMinimum": 0,
                           "description": "The N of 1 : N — how many "
                                          "times smaller than life the "
                                          "model is (a 60 mm Earth is "
                                          "212600000; 1 = life size, "
                                          "0.04 = enlarged 25 : 1). The "
                                          "3D scale bar then measures "
                                          "the REAL thing (kilometres "
                                          "on a planet) and shows the "
                                          "ratio. A label: nothing is "
                                          "rescaled. Inserting a planet "
                                          "or moon into an empty "
                                          "document sets it by itself."},
            "segments_on": {"type": "boolean",
                            "description": "False lets each object keep "
                                           "its own $fn."},
            "orientation": {"type": "string", "enum": ORIENTATIONS},
            "fit": {"type": "boolean",
                    "description": "Frame the whole model."},
            "projection": {"type": "string", "enum": PROJECTIONS,
                           "description": "The user's 3D projection: "
                                          "perspective or orthographic."},
            "background": {"type": "string",
                           "enum": ["Theme", "Studio", "Light", "White",
                                    "Slate", "Dark", "Blueprint"],
                           "description": "The 3D view's background. "
                                          "'White' is plain white with no "
                                          "horizon — for figures."},
            "stage": {"type": "boolean",
                      "description": "Stand the model on a round "
                                     "platform with a soft shadow from "
                                     "a top-left light, instead of the "
                                     "ground grid (also what "
                                     "render_view shows)."},
            "heatmap": {"type": "string",
                        "enum": ["off", "thickness", "overhang", "draft",
                                 "curvature", "zebra"],
                        "description": "Paint the print check ON the "
                                       "part, in the view and in every "
                                       "render_view: 'thickness' colours "
                                       "each face by the wall behind it "
                                       "(red = thinner than heat_min_wall), "
                                       "'overhang' by how far it looks "
                                       "down (red = needs support), "
                                       "'draft' by its draft against +Z "
                                       "for moulding (red = vertical, "
                                       "heat_draft degrees wanted), "
                                       "'curvature' (red bulges, blue "
                                       "dips), 'zebra' reflected stripes "
                                       "(a kink = a crease). The "
                                       "result carries the legend and "
                                       "stats (thinnest wall, fraction "
                                       "red). Turn it 'off' after."},
            "heat_min_wall": {"type": "number",
                              "description": "Minimum printable wall for "
                                             "the thickness map (document "
                                             "units, default 0.8)."},
            "heat_draft": {"type": "number",
                           "description": "Wanted draft angle in degrees "
                                          "for the draft map (default 2)."},
            "heat_overhang": {"type": "number",
                              "description": "Overhang limit in degrees "
                                             "for the overhang map "
                                             "(default 45)."},
            "cavity": {"type": "boolean",
                       "description": "Cavity shading: valleys darker, "
                                      "ridges lighter (Blender's Solid "
                                      "view look)."},
            "edges": {"type": "boolean",
                      "description": "Draw crease and outline edges as "
                                     "thin lines."},
            "grid": {"type": "boolean",
                     "description": "Draw the square ground grid under "
                                    "the model in the 3D view (off by "
                                    "default; hidden while the platform "
                                    "is shown)."},
            "axes": {"type": "boolean",
                     "description": "Show the X / Y / Z axis lines at the "
                                    "origin of the 3D view (on by "
                                    "default)."},
            "scale_bar": {"type": "boolean",
                          "description": "Show a scale bar in the "
                                         "document's unit in the 3D view, "
                                         "true at the orbit centre "
                                         "(everywhere in orthographic)."},
            "overlay": {"type": "boolean",
                        "description": "Draw the reference images OVER "
                                       "the model too (onion skin), to "
                                       "compare a likeness with its "
                                       "photo."},
            "smooth": {"type": "boolean",
                       "description": "Smooth shading: curved surfaces "
                                      "shade as one skin instead of "
                                      "facets (edges over 40° stay "
                                      "sharp). OpenGL only."},
            "opengl": {"type": "boolean",
                       "description": "Draw the faces with OpenGL (exact "
                                      "occlusion, anti-aliased); off "
                                      "uses the built-in painter."},
            "interface_style": {"type": "string",
                                "enum": ["KherveCAD", "Fusion",
                                         "SolidWorks"],
                                "description": "Make the toolbars look "
                                               "like KherveCAD's own "
                                               "(classic), Fusion's "
                                               "(tabs over icon panels) "
                                               "or SolidWorks' "
                                               "CommandManager. Only on "
                                               "the user's request: it "
                                               "is their workspace."},
            "explode": {"type": "number",
                        "description": "Exploded view: push every part "
                                       "away from the assembly's centre, "
                                       "1 = as far again as it already "
                                       "sits; 0 puts them back. A "
                                       "display only — the model does "
                                       "not move."},
            "explode_mode": {"type": "string",
                             "enum": ["Radial", "X", "Y", "Z"],
                             "description": "Which way the parts move: "
                                            "outwards, or along one "
                                            "axis."},
            "cut": {"type": "string", "enum": ["none", "x", "y", "z"],
                    "description": "Cut Through: slice the 3D view "
                                   "across this axis and cap the cut "
                                   "face, to show the inside (holes, "
                                   "walls, threads) — also what "
                                   "render_view shows. 'none' switches "
                                   "it off. A display only: exports and "
                                   "the model stay whole."},
            "cut_position": {"type": "number",
                             "description": "Where the cut goes, 0 to 1 "
                                            "across the model's extent "
                                            "(0.5 = the middle)."},
            "cut_flip": {"type": "boolean",
                         "description": "Keep the other half."},
        }),
    },
    {
        "name": "load_example",
        "description": (
            "Replace the document with a built-in example. Like "
            "new_document this discards the current model, so it "
            "refuses unsaved work unless discard_unsaved_changes is "
            "set."
        ),
        "input_schema": _obj({
            "name": {"type": "string",
                     "description": "Example name from list_examples."},
            "discard_unsaved_changes": {"type": "boolean"},
        }, ["name"]),
    },
    {
        "name": "new_document",
        "description": (
            "Start an empty document. The user's unsaved work is real: "
            "this refuses unless discard_unsaved_changes is set. Offer "
            "to save instead."
        ),
        "input_schema": _obj({
            "discard_unsaved_changes": {"type": "boolean"},
        }),
    },
    {
        "name": "import_image_stack",
        "description": (
            "Import a TIFF IMAGE STACK — a multi-page TIFF (microscope, "
            "CT / MRI, ImageJ, BigTIFF), a folder of TIFF slices, or a list "
            "of them in order — as a 3D solid: the pages are slices of a "
            "block, every voxel brighter than `threshold` (darker with "
            "invert) is solid, and its closed surface lands as one Object "
            "holding an imported STL written beside the stack. threshold "
            "'auto' (default) is Otsu's; voxel_size [x, y, z] mm defaults "
            "to the file's own (ImageJ spacing / resolution tags) else 1; "
            "step down-samples (default: under ~3 M voxels); smooth "
            "(default true) removes speckle. Returns the triangles, the "
            "size in mm and the node ids; render_view to look at it."
        ),
        "input_schema": _obj({
            "path": {"type": "string",
                     "description": "A TIFF file or a folder of them."},
            "paths": {"type": "array", "items": {"type": "string"},
                      "description": "Single-image TIFFs, one per slice "
                                     "(sorted by name)."},
            "threshold": {"description": "A number, or 'auto'.",
                          "anyOf": [{"type": "number"},
                                    {"type": "string", "enum": ["auto"]}]},
            "invert": {"type": "boolean",
                       "description": "Solid where DARKER than the "
                                      "threshold."},
            "voxel_size": {"description": "mm a voxel: one number or "
                                          "[x, y, z].",
                           "anyOf": [{"type": "number"},
                                     {"type": "array",
                                      "items": {"type": "number"},
                                      "minItems": 3, "maxItems": 3}]},
            "step": {"type": "integer", "minimum": 1,
                     "description": "Down-sampling (average step³ "
                                    "voxels)."},
            "smooth": {"type": "boolean"},
        }),
    },
    {
        "name": "open_document",
        "description": (
            "Open a .kcad document, import a .scad (or OpenSCAD .csg) "
            "program as objects, import a mesh (.stl/.obj/.off/.3mf/.amf/"
            ".glb) as one part (an OBJ or GLB made of named groups, materials "
            "or nodes comes in as one Object with a named, coloured group "
            "per part), a 2D drawing (.svg/.dxf) as an extruded "
            "import_2d part, a height map (.dat) as a surface part, or "
            "a CAD file from another program — STEP (.step/.stp), IGES "
            "(.iges/.igs), Rhino (.3dm) or OpenCascade .brep — as one "
            "Object named after the file holding one named, coloured "
            "group per part (`quality` Draft / Normal / Fine sets how "
            "finely curved surfaces are faceted). Refuses to discard unsaved work unless "
            "discard_unsaved_changes is set."
        ),
        "input_schema": _obj({
            "path": {"type": "string", "description": "Absolute path."},
            "discard_unsaved_changes": {"type": "boolean"},
            "quality": {"type": "string",
                        "enum": ["Draft", "Normal", "Fine"],
                        "description": "CAD files only. Default Normal."},
        }, ["path"]),
    },
    {
        "name": "save_document",
        "description": (
            "Save the document. With no path it saves over the file the "
            "user already has open."
        ),
        "input_schema": _obj({
            "path": {"type": "string",
                     "description": "Absolute path ending in .kcad. "
                                    "Omit to save in place."},
        }),
    },
    {
        "name": "export_movie",
        "description": (
            "A movie for a product page or an advert. By default a "
            "turntable: the "
            "camera circles the model at a fixed height and distance "
            "(fitted so the whole model stays in frame from every side) "
            "and each frame is painted by the 3D view — the user's "
            "colours, materials, lighting, platform and any Cut Through. "
            ".mp4 (H.264, plays everywhere) or .gif (looping). The loop "
            "joins without a stutter. Needs ffmpeg (bundled by the "
            "imageio-ffmpeg package); 8 s at 30 fps is 240 snapshots, "
            "so allow a minute or two. Moving parts can move while it "
            "films (animate), with the camera turning, tumbling or still."
        ),
        "input_schema": _obj({
            "path": {"type": "string",
                     "description": "Absolute path ending in .mp4 or "
                                    ".gif."},
            "seconds": {"type": "number",
                        "description": "Length, 0.5-120. Default 8."},
            "fps": {"type": "integer",
                    "description": "Frames per second, 5-60. Default 30 "
                                   "(use 15 for a GIF)."},
            "turns": {"type": "number",
                      "description": "Full turns over the movie. "
                                     "Default 1."},
            "width": {"type": "integer",
                      "description": "Pixels wide. Default 1280."},
            "height": {"type": "integer",
                       "description": "Pixels high. Default 720."},
            "elevation": {"type": "number",
                          "description": "Camera height in degrees "
                                         "above the ground plane. "
                                         "Default: the user's view."},
            "motion": {"type": "string",
                       "enum": ["turntable", "light", "both",
                                "sequence", "still", "tumble"],
                       "description": "What moves: the camera round the "
                                      "model (default), the light round "
                                      "a still model (reflections sweep "
                                      "across it), both, sequence — "
                                      "light sweep, then a turn, then "
                                      "light again, a third each — "
                                      "still (the camera stays where "
                                      "the user has it: use with "
                                      "animate), or tumble (the camera "
                                      "goes round AND over the top at "
                                      "once, two axes together)."},
            "tumble_turns": {"type": "number",
                             "description": "Tumble only: turns over "
                                            "the top during the movie "
                                            "(while `turns` go round). "
                                            "Default 1."},
            "animate": {"description": "Move the model's MOVING PARTS "
                                       "while filming: true for its "
                                       "motion sliders (Customizer "
                                       "variables in a Motion group, "
                                       "e.g. a robot arm's joints), or a "
                                       "list of slider names, or of "
                                       "{variable, from, to} to limit "
                                       "each one's sweep, or {variable, "
                                       "keys} to script it over time. Every slider "
                                       "goes from -> to -> from together, "
                                       "so the movie loops; the user's "
                                       "values come back after.",
                        "anyOf": [{"type": "boolean"},
                                  {"type": "array", "items": {
                                      "anyOf": [
                                          {"type": "string"},
                                          {"type": "object",
                                           "properties": {
                                               "variable": {
                                                   "type": "string"},
                                               "from": {"type": "number"},
                                               "to": {"type": "number"},
                                               "keys": {
                                                   "type": "array",
                                                   "description":
                                                   "[[time 0-1, value], "
                                                   "...]: the slider "
                                                   "follows these, eased "
                                                   "between them — a "
                                                   "choreography (reach, "
                                                   "grip, lift, release)."
                                                   " Time is one cycle."}},
                                           "required": ["variable"]}]}}]},
            "animate_cycles": {"type": "number",
                               "description": "How many times the parts "
                                              "go there and back over "
                                              "the movie. Default 1."},
            "light_seconds": {"type": "number",
                              "description": "Sequence only: length of "
                                             "EACH light swing; the turn "
                                             "gets the rest. Default a "
                                             "third of the movie each."},
            "direction": {"type": "string",
                          "enum": ["clockwise", "anticlockwise"],
                          "description": "Seen from above. Default "
                                         "clockwise."},
        }, ["path"]),
    },
    {
        "name": "export_drawing",
        "description": (
            "A 2D engineering drawing of the model (or the selection): "
            "third-angle Front / Top / Right views and an isometric, "
            "visible edges solid and hidden edges dashed, overall "
            "dimensions, an optional hatched section through the "
            "middle, on an A4/A3 sheet at a standard scale with a title "
            "block. Written by the path's extension: .pdf, .svg, .dxf "
            "(lines on VISIBLE / HIDDEN / DIM / SECTION layers, sheet "
            "mm) or .png. When the user has made a Blueprint for this "
            "document (File > Blueprint), that sheet is exported "
            "instead — their views, dimensions, notes and title block, "
            "re-projected from the model as it is now — unless "
            "blueprint is false; the sheet options below then do not "
            "apply."
        ),
        "input_schema": _obj({
            "path": {"type": "string",
                     "description": "Absolute path ending in .pdf, "
                                    ".svg, .dxf or .png."},
            "sheet": {"type": "string", "enum": ["A4", "A3", "Letter"],
                      "description": "Sheet size, landscape (A4)."},
            "views": {"type": "array", "items": {"type": "string"},
                      "description": "Any of Front, Top, Right, Left, "
                                     "Back, Bottom, Isometric (default "
                                     "Front, Top, Right, Isometric) — or "
                                     "['Current'] alone for Make2D: a "
                                     "line drawing from the 3D view's "
                                     "own camera, hidden edges off "
                                     "unless hidden_lines."},
            "dimensions": {"type": "boolean",
                           "description": "Overall width/height "
                                          "dimensions on the three "
                                          "orthographic views (true)."},
            "section": {"type": "string", "enum": ["x", "y", "z"],
                        "description": "Add a hatched section through "
                                       "the model's middle on this axis."},
            "hidden_lines": {"type": "boolean",
                             "description": "Dashed edges behind the "
                                            "surface (true); off for "
                                            "threaded parts, whose facets "
                                            "swamp the sheet."},
            "scale": {"type": "number",
                      "description": "Drawing scale as a multiplier "
                                     "(0.5 = 1:2, 2 = 2:1); omit for "
                                     "the largest standard scale that "
                                     "fits."},
            "title": {"type": "string"},
            "blueprint": {"type": "boolean",
                          "description": "Export the document's saved "
                                         "Blueprint sheet when it has one "
                                         "(true). False draws a fresh "
                                         "sheet from the options above."},
        }, ["path"]),
    },
    {
        "name": "make_surface",
        "description": (
            "Make an EXACT surface from 3D curves — Rhino's Loft, Sweep, "
            "Sweep2, Patch, Revolve, Extrude. Draw the curves first "
            "(add_node type curve with points [[x, y, z], …], style "
            "smooth | straight, closed; or kcad_curve(...) in "
            "apply_code), then pass their ids IN ORDER: `loft` skins "
            "through them (closed curves are capped into a solid unless "
            "capped is false); `sweep` — the first is the rail, the rest "
            "profiles; `sweep2` — the first two are rails; `patch` — "
            "the first is a CLOSED boundary, the others curves the "
            "surface passes through; `revolve` turns the first about Z "
            "by `angle`; `extrude` pushes it up by `height`. An open "
            "surface is thickened by `thickness` mm (default 1) into a "
            "solid. The curves move inside the new node, so editing one "
            "reshapes the surface; STEP export keeps the surface exact."
        ),
        "input_schema": _obj({
            "curve_ids": {"type": "array", "items": {"type": "string"},
                          "description": "Curve node ids (or Objects "
                                         "holding curves), in order."},
            "kind": {"type": "string",
                     "enum": ["loft", "sweep", "sweep2", "patch",
                              "revolve", "extrude"]},
            "thickness": {"type": "number"},
            "ruled": {"type": "boolean"},
            "capped": {"type": "boolean"},
            "angle": {"type": "number"},
            "height": {"type": "number"},
            "direction": {"type": "string",
                          "enum": ["+Z", "-Z", "+X", "-X", "+Y", "-Y"],
                          "description": "extrude: the axis it pushes "
                                         "along."},
            "draft": {"type": "number",
                      "description": "extrude: draft angle in degrees "
                                     "(+ widens) — a drafted surface."},
            "sheet": {"type": "boolean",
                      "description": "Keep it a SURFACE (no thickening) "
                                     "so surface_edit can trim, knit, "
                                     "fillet and thicken it."},
        }, ["curve_ids", "kind"]),
    },
    {
        "name": "surface_edit",
        "description": (
            "Edit SURFACE BODIES the SolidWorks Surfaces way (make them "
            "with make_surface sheet=true): wraps node_ids in a surface "
            "node of `op`. trim: the surfaces cut each other where they "
            "cross; `remove` = points ON the pieces to remove (node "
            "frame); mutual false = the first surface is trimmed by the "
            "rest, true = all trim all; keep true keeps the picked pieces "
            "instead. Call with action=pieces first: it lists every "
            "piece with its area and a point on it. knit: sew into one "
            "body (`solid` true = a solid when closed). planar: fill "
            "the whole open edge loop through each of `points`. "
            "boundary: close a round open edge (point on it) by its "
            "chord. thicken: `thickness` mm. fillet: `fillets` rows "
            "[x, y, z, radius] (a point ON each edge) or `points` + "
            "`radius`. mirror: `plane` 'XY (Top)' | 'XZ (Front)' | "
            "'YZ (Right)' + `offset`. Chain them: each wraps the last, "
            "like SolidWorks' feature list."
        ),
        "input_schema": _obj({
            "op": {"type": "string",
                   "enum": ["trim", "knit", "planar", "boundary",
                            "thicken", "fillet", "mirror"]},
            "action": {"type": "string", "enum": ["make", "pieces"]},
            "node_ids": {"type": "array", "items": {"type": "integer"}},
            "mutual": {"type": "boolean"},
            "keep": {"type": "boolean"},
            "remove": {"type": "array",
                       "items": {"type": "array",
                                 "items": {"type": "number"}}},
            "points": {"type": "array",
                       "items": {"type": "array",
                                 "items": {"type": "number"}}},
            "fillets": {"type": "array",
                        "items": {"type": "array",
                                  "items": {"type": "number"}}},
            "solid": {"type": "boolean"},
            "thickness": {"type": "number"},
            "radius": {"type": "number"},
            "plane": {"type": "string"},
            "offset": {"type": "number"},
        }, ["op", "node_ids"]),
    },
    {
        "name": "exact_part",
        "description": (
            "Edit a part imported from STEP / IGES as its EXACT surfaces. "
            "`node_id` an imported part (its Object or the mesh): it is "
            "turned into an exact B-rep part first (same place and "
            "name). `fillets` rows [x, y, z, radius] round the edge "
            "nearest each WORLD point (pick a point on the edge — "
            "probe_surface or list_edges give them), `chamfers` rows "
            "[x, y, z, size] cut edges back. Rows are added to the "
            "part's own; `clear` true removes the old ones first. The "
            "fillets are OpenCascade's rolling-ball fillets, kept exact "
            "in a STEP export."
        ),
        "input_schema": _obj({
            "node_id": {"type": "string"},
            "fillets": {"type": "array", "items": {"type": "array",
                                                   "items": {"type":
                                                             "number"}}},
            "chamfers": {"type": "array", "items": {"type": "array",
                                                    "items": {"type":
                                                              "number"}}},
            "clear": {"type": "boolean"},
        }, ["node_id"]),
    },
    {
        "name": "export_document",
        "description": (
            "Export by the path's extension: .scad writes the program, "
            ".stl writes the mesh (.3mf, .off, .amf and .csg through "
            "OpenSCAD; .svg / .dxf when the document is 2D), .png "
            "writes a picture of the 3D "
            "view. An STL goes through OpenSCAD when it is installed "
            "(exact, booleans really cut) and through the built-in "
            "tessellator otherwise — the result says which, and an "
            "approximated export is not one to send to a printer. A "
            "big model can take a while. A PNG is the model alone (no "
            "grid or badge) in the user's render style, colours and "
            "lighting: `view` 'current' keeps the user's camera, a "
            "preset name frames the whole model from that side, and "
            "'all' writes one numbered file per standard view beside "
            "the path, the front-right isometric first. "
            ".step / .stp / .iges / .igs / .brep write a file other CAD "
            "programs (Fusion, SolidWorks, Onshape, FreeCAD, Rhino) open "
            "with EXACT surfaces where the model has them — cubes, "
            "spheres, cylinders, extrusions, revolves, transforms, "
            "booleans, loops — one named, coloured part per top-level "
            "object, always in real millimetres; anything without an "
            "exact form (a blend, sculpt, gear, imported mesh) is a "
            "faceted solid, and the result lists those parts. .3dm "
            "writes a Rhino file of meshes, one named layer per part; .glb a glTF binary for games and 3D programs (metres, Y up): one named node per part (an Object at the origin is split into its parts), a material per colour."
        ),
        "input_schema": _obj({
            "path": {"type": "string",
                     "description": "Absolute path ending in .scad, "
                                    ".stl, .3mf (3MF needs OpenSCAD), "
                                    ".png, .step, .iges, .brep or "
                                    ".3dm."},
            "view": {"type": "string",
                     "enum": ["current", *STILL_VIEWS, "all"],
                     "description": "PNG only: which camera. Default "
                                    "'current'."},
            "width": {"type": "integer",
                      "description": "PNG only: pixels wide. Default "
                                     "twice the 3D view's width for "
                                     "'current', else %d." %
                                     PNG_DEFAULT_SIZE[0]},
            "height": {"type": "integer",
                       "description": "PNG only: pixels high. Default "
                                      "twice the 3D view's height for "
                                      "'current', else %d." %
                                      PNG_DEFAULT_SIZE[1]},
            "transparent": {"type": "boolean",
                            "description": "PNG only: leave the "
                                           "background transparent."},
            "exploded": {"type": "boolean",
                         "description": "PNG only: picture the assembly "
                                        "exploded — every part pulled "
                                        "away from the centre."},
            "scale_to_mm": {"type": "boolean",
                            "description": "STL/3MF of a document not in "
                                           "mm: multiply every length to "
                                           "real millimetres (a 100 nm "
                                           "part becomes 0.0001 mm). "
                                           "Default false: written 1:1, "
                                           "so a slicer reads 1 unit as "
                                           "1 mm — what printing a "
                                           "scale model wants. The "
                                           "result says which."},
        }, ["path"]),
    },
    {
        "name": "publish_to_printables",
        "description": (
            "Build a complete Printables upload bundle for the open "
            "model in one call: the mesh (STL and 3MF), the "
            "parametric .scad source, the .kcad project, preview "
            "stills painted the way the 3D view shows the model "
            "(colours, materials, lighting, platform and shadow) "
            "from three-quarter angles — every corner, the product "
            "angles and the underside, the front-right isometric "
            "first, as the cover — description.txt "
            "and upload-form.txt (every field of Printables' add-a-"
            "model form, already answered). "
            "Printables has NO upload API, so this does not and "
            "cannot post the model — it prepares everything and the "
            "user drops the folder into printables.com themselves. "
            "Say that plainly rather than claiming the model is "
            "published.\n"
            "WRITE THE DESCRIPTION YOURSELF and pass it in: look at "
            "the model first (get_document_info, list_tree, "
            "render_view) and describe what the thing actually is, "
            "what it is for, its size in mm, which variables are "
            "worth changing, and suggested print settings. PLAIN "
            "TEXT, not Markdown — Printables' description box shows "
            "hashes and backticks back as literal characters. "
            "Leaving `description` out falls back to a generated "
            "skeleton, which is worse. Whatever you write, the "
            "bundle appends a credit naming KherveCAD "
            "(khervetools.com), OpenSCAD and Claude — do not strip "
            "or duplicate that, and do not claim the model is human-"
            "designed if you designed it."
        ),
        "input_schema": _obj({
            "title": {"type": "string",
                      "description": "Listing title, also the file "
                                     "stem."},
            "description": {"type": "string",
                            "description": "The listing body, in "
                                           "plain text. Write this."},
            "summary": {"type": "string",
                        "description": "Printables' required one-line "
                                       "summary, max %d characters. "
                                       "Write this too." %
                                       SUMMARY_LIMIT},
            "category": {"type": "string", "enum": CATEGORIES,
                         "description": "Printables' required main "
                                        "category. Defaults to %s." %
                                        DEFAULT_CATEGORY},
            "exploded": {"type": "boolean",
                         "description": "Add exploded-view stills (every "
                                        "part pulled apart). Default: "
                                        "yes for an assembly of two or "
                                        "more parts."},
            "origin": {"type": "string", "enum": ORIGINS,
                       "description": "Where the model came from. "
                                      "Defaults to %s." %
                                      DEFAULT_ORIGIN},
            "tags": {"type": "array", "items": {"type": "string"},
                     "description": "Printables tags, lowercase."},
            "license": {"type": "string", "enum": LICENSES,
                        "description": "Defaults to %s." %
                                       DEFAULT_LICENSE},
            "folder": {"type": "string",
                       "description": "Absolute path for the bundle "
                                      "folder. Defaults to a folder "
                                      "beside the document."},
            "formats": {"type": "array",
                        "items": {"type": "string", "enum": list(FORMATS)},
                        "description": "Defaults to all four."},
            "views": {"type": "array",
                      "items": {"type": "string", "enum": list(STILL_VIEWS)},
                      "description": "Camera angles to render. "
                                     "Defaults to every one: %s — the "
                                     "front-right Isometric is always "
                                     "first, as the cover." %
                                     ", ".join(DEFAULT_VIEWS)},
            "open_browser": {"type": "boolean",
                             "description": "Open the Printables "
                                            "upload page and reveal "
                                            "the folder. Off by "
                                            "default — turn it on "
                                            "when the user has said "
                                            "they want to upload "
                                            "now."},
        }, ["title"]),
    },

    # ── Fillet ─────────────────────────────────────────────────────
    {
        "name": "list_edges",
        "description": (
            "The edges of a node's solid that a fillet can round — "
            "every crease where two faces meet at more than min_angle, "
            "grouped into tangent-continuous chains (a cylinder's rim "
            "is ONE chain; a box has 12). Each chain gives its `seed` "
            "(6 numbers: a segment's start and end, in the node's own "
            "frame — what fillet_edges takes), its ends, length, "
            "dihedral angle, convex (outside corner) or not, closed, "
            "and centre, longest first. Coordinates are local to the "
            "node, not the assembly."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "min_angle": {"type": "number",
                          "description": "Degrees; default 20. Facets "
                                         "below it are one surface."},
        }, ["node_id"]),
    },
    {
        "name": "fillet_edges",
        "description": (
            "Round (or chamfer) chosen edges of a node — SolidWorks' "
            "Fillet. Wraps the node in a fillet (or adds to the fillet "
            "it already is / sits in) and records the edges as seed "
            "segments from list_edges, by `edges` rows or by `chains` "
            "indices into list_edges(node_id). A convex edge is cut "
            "round, a concave one filled. The result shows in the "
            "exact OpenSCAD render (render_view after a moment); the "
            "built-in preview cannot cut. Radius is in mm (the "
            "chamfer's setback along each face)."
        ),
        "input_schema": _obj({
            "node_id": _ID,
            "edges": {"type": "array",
                      "items": {"type": "array",
                                "items": {"type": "number"}},
                      "description": "Seed rows [x1, y1, z1, x2, y2, "
                                     "z2] from list_edges."},
            "chains": {"type": "array", "items": {"type": "integer"},
                       "description": "Indices into list_edges' list "
                                      "for the same node, instead of "
                                      "or as well as `edges`."},
            "radius": {"type": "number", "description": "mm; default 2."},
            "kind": {"type": "string", "enum": ["round", "chamfer"]},
            "detail": {"type": "integer",
                       "description": "Segments across a round; "
                                      "default 6."},
        }, ["node_id"]),
    },

    # ── Checking ───────────────────────────────────────────────────
    {
        "name": "mass_properties",
        "description": (
            "Volume, surface area, centre of mass and bounding box of "
            "nodes (in the document's unit; volume_mm3 / area_mm2 are "
            "true mm), plus mass at true size for a material, and — "
            "for a mm, cm or inch document only — material cost and a "
            "print-time estimate (rough). Without node_ids: the whole "
            "scope. `approximate` flags a preview mesh with uncut "
            "booleans."
        ),
        "input_schema": _obj({
            "node_ids": _IDS,
            "material": {"type": "string",
                         "description": "Undefined (default: no mass), or "
                                        "e.g. Steel, Stainless steel (304), "
                                        "Aluminium 6061, Copper, Bronze, "
                                        "Iron, Titanium, Brick, Cement, "
                                        "Wood, PLA, ABS. An unknown name "
                                        "is answered with the full list."},
            "price_per_kg": {"type": "number",
                             "description": "Default 20."},
        }),
    },
    {
        "name": "check_printability",
        "description": (
            "Blender's 3D-Print Toolbox in one call: watertight, "
            "overhangs beyond overhang_deg (needs supports), walls "
            "thinner than min_wall, and the footprint on the build "
            "plate — each pass / warn / fail with a plain-language "
            "message. Run it after building anything meant to be "
            "printed and fix what it names. The part is judged at 1:1 "
            "in the document's unit (a nanometre model is flagged)."
        ),
        "input_schema": _obj({
            "node_ids": _IDS,
            "overhang_deg": {"type": "number", "description": "Default 45."},
            "min_wall": {"type": "number",
                         "description": "Real printer mm, whatever the "
                                        "document unit; default 0.8."},
        }),
    },
    {
        "name": "check_interference",
        "description": (
            "Do parts overlap? Every pair of the given nodes (default: "
            "every visible top-level part in the assembly) is reported "
            "as intersect, contains / inside, or clear, with the "
            "overlap box and crossing points. Run it after placing or "
            "mating parts."
        ),
        "input_schema": _obj({"node_ids": _IDS}),
    },
    {
        "name": "check_sharp_edges",
        "description": (
            "Sharp-edge check (Analyse > Check Sharp Edges): crease edges "
            "whose faces meet at under face_angle (default 135°: a 90° "
            "corner is sharp, a 45° chamfer is not) and that no fillet / "
            "bevel / chamfer rounds. Returns status, count, total length, "
            "the chains (centre, ends, length, face angle) and per node "
            "the LOCAL fillet_seeds to hand to fillet_edges. highlight "
            "tints them in the 3D view. Run it after building a part, "
            "before updating the Blueprint."
        ),
        "input_schema": _obj({
            "node_ids": _IDS,
            "face_angle": {"type": "number",
                           "description": "Degrees inside the material; "
                                          "default 135."},
            "concave": {"type": "boolean",
                        "description": "Count inside corners too."},
            "highlight": {"type": "boolean"},
        }),
    },
    {
        "name": "check_fits",
        "description": (
            "Clearance / fit check (Analyse > Check Fits & Tolerances): "
            "for every pair of the parts (default: the scope's visible "
            "parts) that overlap, are mated or lie within `near` mm, the "
            "minimum gap and its two points, pass / warn (under "
            "`clearance`, or touching unmated) / fail (overlap). A pin "
            "standing in a bore gets its diametral clearance and the ISO "
            "286 hole-basis fit it falls in (H11/c11 … H7/s6). Give "
            "nominal + diametral_clearance to classify a fit directly."
        ),
        "input_schema": _obj({
            "node_ids": _IDS,
            "clearance": {"type": "number",
                          "description": "Wanted gap, default 0.1."},
            "near": {"type": "number",
                     "description": "Neighbour distance, default 2."},
            "nominal": {"type": "number"},
            "diametral_clearance": {"type": "number"},
        }),
    },
    {
        "name": "tolerance_stackup",
        "description": (
            "Tolerance stack-up of Blueprint dimensions carrying tol_plus "
            "/ tol_minus: worst case and RSS range of the closing value. "
            "chain = note indices from blueprint state (or {index, sign: "
            "-1} for a dimension that subtracts); default every "
            "toleranced dimension, added. limits [min, max] gives pass "
            "(worst case inside) / warn (only RSS) / fail. drawing = an "
            "Object's own sheet (default the assembly)."
        ),
        "input_schema": _obj({
            "chain": {"type": "array", "items": {}},
            "limits": {"type": "array", "items": {"type": "number"},
                       "minItems": 2, "maxItems": 2},
            "drawing": {"type": "string"},
        }),
    },
    {
        "name": "check_welds",
        "description": (
            "Weld check (Analyse > Check Welds): every pair of the parts "
            "(default: the scope's visible parts) that touch is a weld "
            "candidate. Per joint: type from the geometry (lap, T, "
            "corner, butt, fillet), seam length one side and all round, "
            "thickness, the parts' materials, and advice — process (TIG / "
            "MIG / SAW / brazing…) for the material and thickness, "
            "filler, fillet leg z and throat a, or butt preparation; "
            "impossible pairs (aluminium to steel, plastic, wood) fail. "
            "Welds recorded with set_weld are judged pass / warn / fail "
            "against that advice."
        ),
        "input_schema": _obj({"node_ids": _IDS}),
    },
    {
        "name": "set_weld",
        "description": (
            "Record the weld joining parts a and b (saved on a as "
            "params.welds): process (TIG, MIG, MAG, FCAW, SAW, Stick, "
            "Laser, Spot, Brazing, Plastic welding), joint (fillet, butt, "
            "lap, T, corner, edge, plug), size mm (fillet leg z, or butt "
            "depth), sides ('one side', 'both sides', 'all round'), "
            "filler, note. remove=true deletes it. note=true writes the "
            "weld list (ISO 2553 words) on the Blueprint. Returns the "
            "check of that joint."
        ),
        "input_schema": _obj({
            "a": _ID, "b": _ID,
            "process": {"type": "string"}, "joint": {"type": "string"},
            "size": {"type": "number"}, "sides": {"type": "string"},
            "filler": {"type": "string"}, "note": {"type": "boolean"},
            "remove": {"type": "boolean"},
        }, ["a", "b"]),
    },
    {
        "name": "build_city",
        "description": (
            "The City Builder: villages, towns and cities — optionally ON "
            "a landscape (hills, mountain, valley...: roads follow the "
            "slopes, buildings get levelled pads). Call get_city FIRST: it "
            "lists every valid building style (with default size and "
            "floor range), wall, roof, road kind, tree species, terrain "
            "and library piece id, an example spec, and the city the "
            "document already holds. All mm, Z up, centred on the origin. "
            "Two ways, which combine: `layout` ('village' | 'town' | "
            "'city' + `blocks`, `seed`) generates a whole plan; or give "
            "the pieces — roads [{points: [[x, y], ...], kind}], buildings "
            "[{style, x, y (centre), w, d, rz, floors, wall, roof, "
            "roof_material, color, roof_color, name}] (a building's FRONT "
            "faces -Y; rz 0-360 turns it to face its road), lights "
            "[{x, y, rz}] or {spacing} along every road, trees [{kind, x, "
            "y, height}], street_trees {spacing, kind}, props [{part_id, "
            "x, y, rz, color, dims}] for any library piece (a park, a "
            "football pitch, a traffic light, a landmark, a bridge), "
            "terrain {kind, height, seed}, ground {margin, color}. "
            "`mode`: 'replace' (default) makes this spec THE city — every "
            "earlier City Object is removed — so to CHANGE an existing "
            "city, take get_city's `current`, edit it and send it back "
            "whole; 'add' appends your roads / buildings / trees / lights "
            "/ props to the city already built. The result is up to six "
            "Objects (City ground, City roads, City buildings, Street "
            "lights, City trees, City props); the design is saved in the "
            ".kcad and opens in Library > City > City Builder. dry_run "
            "counts without building. Check with render_view "
            "(orientation Top, or azimuth/elevation/target/distance for a "
            "street view)."
        ),
        "input_schema": _obj({
            "layout": {"type": "string",
                       "enum": ["village", "town", "city"]},
            "blocks": {"type": "integer",
                       "description": "Grid size (town 3, city 5)."},
            "seed": {"type": "integer"},
            "roads": {"type": "array", "items": {"type": "object"}},
            "buildings": {"type": "array", "items": {"type": "object"}},
            "lights": {"description": "[{x, y, rz}, ...] or {spacing}."},
            "trees": {"type": "array", "items": {"type": "object"}},
            "terrain": {"type": "object",
                        "description": "Build the city ON a landscape: "
                                       "{kind: hills|mountain|cliff|valley|"
                                       "mesa|island|canyon|dunes, height "
                                       "(relief, mm), seed, roughness (0 "
                                       "smooth swells .. 0.5 default .. 1 "
                                       "tight bumpy ground), cells}. Roads "
                                       "follow the slopes, buildings stand "
                                       "on levelled pads, trees/lights/"
                                       "props at ground height — a street "
                                       "grid on hills is San Francisco."},
            "props": {"type": "array", "items": {"type": "object"},
                      "description": "Library pieces: {part_id, x, y, rz, "
                                     "color, dims}."},
            "street_trees": {"type": "object"},
            "ground": {"description": "{margin, color}, or null."},
            "mode": {"type": "string", "enum": ["replace", "add"],
                     "description": "replace (default): this spec is the "
                                    "whole city; add: append to the city "
                                    "already built."},
            "dry_run": {"type": "boolean",
                        "description": "Count only; build nothing."},
            "detail": {"type": "string", "enum": ["auto", "low", "full"],
                       "description": "Building detail: full (windows, "
                                      "gutters, chimneys), low (walls and "
                                      "roof, ~1/15 the triangles) or auto "
                                      "(low past 150 buildings)."},
            "path": {"type": "string",
                     "description": "Read the whole spec from this JSON "
                                    "file instead (other keys given here "
                                    "override it) — for large cities, so "
                                    "nothing passes through the chat."},
            "save_to": {"type": "string",
                        "description": "Also write the resolved spec to "
                                       "this JSON file."},
        }),
    },
    {
        "name": "import_map",
        "description": (
            "Import a REAL place as a City Builder design, downloaded by "
            "the app itself (nothing to paste): OpenStreetMap roads, the "
            "real building outlines (footprints) with heights and roof "
            "shapes from the map tags; in England the Environment "
            "Agency's 1 m LiDAR for the measured ground (roads and pads "
            "levelled on it), the height of every untagged building, and "
            "tree tops found in the canopy (species chosen from each "
            "tree's measured height and crown); optionally the aerial "
            "photo laid on the ground as a reference image. Give center "
            "[lat, lon] + radius_m (default 300) or bbox [south, west, "
            "north, east]. Builds it (replacing the city) unless build is "
            "false; `path` saves the spec JSON, which build_city can load "
            "later. Takes a while (downloads): a 300 m radius is ~30-60 s."
        ),
        "input_schema": _obj({
            "center": {"type": "array", "items": {"type": "number"},
                       "description": "[latitude, longitude]"},
            "radius_m": {"type": "number"},
            "bbox": {"type": "array", "items": {"type": "number"},
                     "description": "[south, west, north, east] degrees"},
            "heights": {"type": "string", "enum": ["lidar", "flat"],
                        "description": "Ground and building heights from "
                                       "LiDAR (England; default) or flat."},
            "trees": {"type": "string",
                      "enum": ["auto", "lidar", "osm", "both", "none"],
                      "description": "Where trees come from (auto: lidar "
                                     "when heights are lidar)."},
            "tree_step_m": {"type": "number",
                            "description": "Canopy sampling step, m "
                                           "(default 1.5)."},
            "detail": {"type": "string", "enum": ["auto", "low", "full"]},
            "aerial": {"type": "boolean",
                       "description": "Lay the aerial photo on the ground "
                                      "as a reference image."},
            "name": {"type": "string"},
            "build": {"type": "boolean",
                      "description": "Build it now (default true)."},
            "path": {"type": "string",
                     "description": "Save the spec JSON here."},
        }),
    },
    {
        "name": "send_to_planetcraft",
        "description": (
            "Send the model (or one node) to the PlanetCraft game as a "
            "WALKING CREATURE: writes creatures/<name>.json into the "
            "KhervePlanet folder. A running game picks it up within "
            "seconds and puts it in front of the player; it also joins "
            "the wild herds and the game's Creatures book (menu > "
            "Creatures; the result's book_url). Parts are chosen by NAME "
            "— nodes named Head, Tail, Wing (left/right) or Leg "
            "(front/back, left/right; 'Left leg' is enough for a biped; "
            "'Legs' holding several is split by where each stands) become "
            "joints (legs swing at their top, the head nods at its neck); "
            "unnamed legs under a clear middle are found automatically. "
            "A creature from build_creature is already named and carries "
            "its own nature, speed, health and damage. `nature` says what "
            "the game makes of it: animal, person (walks about, turns to "
            "look at you) or monster (hunts the player); auto reads a "
            "monster's name and a person's two upright legs. Real size "
            "(1 block = 1 m) unless `height` (blocks). Build creatures "
            "with the front facing -Y, Z up, +X the creature's left."
        ),
        "input_schema": _obj({
            "name": {"type": "string"},
            "node_id": {"type": "integer",
                        "description": "Send only this subtree."},
            "height": {"type": "number",
                       "description": "Height in blocks (default: real "
                                      "size)."},
            "speed": {"type": "number"},
            "health": {"type": "integer"},
            "wild": {"type": "boolean",
                     "description": "Roams wild herds (default true)."},
            "nature": {"type": "string",
                       "enum": ["auto", "animal", "person", "monster"],
                       "description": "What the game makes of it: an animal "
                                      "grazes and bolts, a person walks about "
                                      "and turns to look at you, a monster "
                                      "hunts you. auto (default): the game "
                                      "reads a monster's name and a person's "
                                      "two legs."},
            "damage": {"type": "integer",
                       "description": "Hearts a monster's blow takes "
                                      "(default: from its size)."},
            "path": {"type": "string",
                     "description": "The PlanetCraft (KhervePlanet) folder; "
                                    "found automatically when omitted."},
            "dry_run": {"type": "boolean",
                        "description": "Report the parts, write nothing."},
        }, ["name"]),
    },
    {
        "name": "list_creature_options",
        "description": (
            "Everything build_creature accepts: the body plans, the "
            "presets (name, plan, real height, what the game makes of it), "
            "the features (horns, ears, nose, tail, weapon, tusks, fangs, "
            "claws, wings, spikes, eyes), the shape keys and the colours. "
            "Call it before build_creature."
        ),
        "input_schema": _obj({}),
    },
    {
        "name": "build_creature",
        "description": (
            "Build a MONSTER or beast for the PlanetCraft game in one call "
            "— every piece already inside the part the game turns it "
            "about (Head, Tail, Left/Right wing, each leg), so "
            "send_to_planetcraft makes it walk, run and hunt at once. "
            "Start from a `preset` (Troll, Ogre, Goblin, Orc, Minotaur, "
            "Yeti, Cyclops, Gargoyle, Imp, Dragon, Dire wolf, Cave bear, "
            "Boar, Basilisk, Giant spider, Serpent, Slime) or a `plan`; "
            "every other key overrides it: height (mm, real size), colours "
            "(#rrggbb), features and shape. It is an ordinary editable "
            "tree afterwards — render_view it, change pieces, keep "
            "each piece inside its part's group — then "
            "send_to_planetcraft with node_id, or pass send=true to send "
            "it at once. The creature keeps its nature, speed, health and "
            "damage for the send."
        ),
        "input_schema": _obj({
            "preset": {"type": "string",
                       "description": "A preset from list_creature_options."},
            "plan": {"type": "string",
                     "enum": ["biped", "winged", "quadruped", "spider",
                              "serpent", "slime"]},
            "name": {"type": "string",
                     "description": "Its name in the game (default: the "
                                    "preset's)."},
            "height": {"type": "number",
                       "description": "Feet to crown in mm, 200-12000 "
                                      "(1000 mm = 1 block)."},
            "skin": {"type": "string"}, "belly": {"type": "string"},
            "accent": {"type": "string",
                       "description": "Horns, tusks, claws, teeth, spikes."},
            "eyes": {"type": "string",
                     "description": "Eye colour; the eyes glow."},
            "cloth": {"type": "string"}, "wood": {"type": "string"},
            "metal": {"type": "string"}, "wing": {"type": "string"},
            "hair": {"type": "string"},
            "horns": {"type": "string",
                      "enum": ["none", "bull", "ram", "straight", "swept",
                               "nubs"]},
            "ears": {"type": "string",
                     "enum": ["none", "round", "pointy", "long"]},
            "nose": {"type": "string", "enum": ["none", "big", "snout"]},
            "tail": {"type": "string",
                     "enum": ["none", "thin", "tuft", "spade", "bushy",
                              "stub", "curly", "long"]},
            "weapon": {"type": "string",
                       "enum": ["none", "club", "spiked club", "axe",
                                "spear", "dagger"]},
            "tusks": {"type": "boolean"}, "fangs": {"type": "boolean"},
            "claws": {"type": "boolean"}, "wings": {"type": "boolean"},
            "loincloth": {"type": "boolean"}, "face": {"type": "boolean"},
            "ruff": {"type": "boolean"}, "hood": {"type": "boolean"},
            "spade_tip": {"type": "boolean"},
            "spikes": {"type": "integer", "description": "0-14."},
            "eyes_n": {"type": "integer", "description": "1 or 2."},
            "eye_size": {"type": "number"},
            "bulk": {"type": "number"}, "leg": {"type": "number"},
            "head": {"type": "number"}, "arm": {"type": "number"},
            "hunch": {"type": "number"}, "length": {"type": "number"},
            "neck": {"type": "number"}, "wing_span": {"type": "number"},
            "nature": {"type": "string",
                       "enum": ["auto", "animal", "person", "monster"]},
            "speed": {"type": "number"}, "health": {"type": "integer"},
            "damage": {"type": "integer"},
            "x": {"type": "number"}, "y": {"type": "number"},
            "send": {"type": "boolean",
                     "description": "Send it to PlanetCraft as soon as it "
                                    "is built."},
            "path": {"type": "string",
                     "description": "The PlanetCraft folder, for send."},
        }),
    },
    {
        "name": "list_planetcraft_creatures",
        "description": (
            "What the PlanetCraft game already has in its creatures/ "
            "folder: each creature's name, kind, nature, height, joints "
            "and when it was sent — plus whether the game is running "
            "and the URL of its Creatures book."
        ),
        "input_schema": _obj({
            "path": {"type": "string",
                     "description": "The PlanetCraft folder; found "
                                    "automatically when omitted."},
        }),
    },
    {
        "name": "remove_from_planetcraft",
        "description": (
            "Take one creature out of the PlanetCraft game: deletes "
            "creatures/<name>.json and its line in the index. Ask the "
            "user first — the file is the game's only copy."
        ),
        "input_schema": _obj({
            "name": {"type": "string",
                     "description": "Its name, file name or kind "
                                    "(kc_troll)."},
            "path": {"type": "string"},
        }, ["name"]),
    },
    {
        "name": "get_city",
        "description": (
            "Read before build_city. Returns `catalog` — the valid "
            "building styles (floors range, default footprint, default "
            "roof and wall), walls, roofs, roof materials, road kinds "
            "(widths), tree species (natural heights), terrains, layouts, "
            "every library piece usable as a prop (Buildings, Park & "
            "sport, Lighting & signals, Landscape, Trees, Landmarks, "
            "Skyscrapers, Bridges: part ids, sizes, colours) and a worked "
            "example spec — and `current`: the city this document holds "
            "(resolved: every building with its position, size, rz and "
            "name, lights and street trees as positions; pieces the user "
            "moved in the main window read back), or null. Edit `current` "
            "and pass it to build_city to change the city."
        ),
        "input_schema": _obj({
            "catalog": {"type": "boolean",
                        "description": "Include the catalogue (default "
                                       "true)."},
        }),
    },
    # ------------------------------------------------ animated characters
    {
        "name": "import_character",
        "description": (
            "Bring in a rigged, ANIMATED character (.glb — skeleton, skin "
            "and clips) as one Object, standing on z = 0, facing -Y, in "
            "mm: its body as coloured imported meshes, its bones and clips "
            "kept. Then add parts inside it (helmet, armour, pouches...), "
            "attach_to_bone, pose_character to check any clip, and "
            "export_character for a game. Returns the Object id, its "
            "height, bone names with head positions, and the clips."
        ),
        "input_schema": _obj({
            "path": {"type": "string", "description": "Absolute .glb path."},
            "height_mm": {"type": "number", "description": (
                "Real height (default: from the file, metres assumed).")},
            "name": {"type": "string"},
        }, ["path"]),
    },
    {
        "name": "attach_to_bone",
        "description": (
            "Make parts ride on a character's bones: each node is wrapped "
            "in a `bone` node and from then on follows that bone in every "
            "pose and in the exported game model (a helmet on the Head, a "
            "radio on the Spine...). Give `bone`, or leave it out to use "
            "each part's NEAREST bone. Many parts in one call."
        ),
        "input_schema": _obj({
            "node_ids": dict(_IDS, description=(
                "Parts inside an imported character.")),
            "bone": {"type": "string", "description": (
                "Bone name for all of them; omit for the nearest.")},
        }, ["node_ids"]),
    },
    {
        "name": "pose_character",
        "description": (
            "Pose an imported character: a clip at a time (seconds) and/or "
            "extra bone turns {bone: [rx, ry, rz]} degrees. The body is "
            "re-skinned with its own weights and every attached part "
            "follows its bone. No clip and no turns = rest pose. Returns "
            "the clips with their lengths."
        ),
        "input_schema": _obj({
            "node_id": dict(_ID, description="The character's Object."),
            "clip": {"type": "string"},
            "time": {"type": "number", "description": "Seconds."},
            "turns": {"type": "object", "description": (
                "{\"<bone>\": [rx, ry, rz]} degrees, in the bone's frame.")},
        }, ["node_id"]),
    },
    {
        "name": "export_character",
        "description": (
            "Write the character as an animated .glb for a game: the "
            "original skeleton, skin and every clip, plus everything added "
            "in KherveCAD bound to its bone (parts not attached go to the "
            "nearest bone), with their colours."
        ),
        "input_schema": _obj({
            "node_id": dict(_ID, description="The character's Object."),
            "path": {"type": "string", "description": "Absolute .glb path."},
        }, ["node_id", "path"]),
    },
]

#: Name -> definition, for the executor and the access-level checks.
BY_NAME = {t["name"]: t for t in TOOLS}
