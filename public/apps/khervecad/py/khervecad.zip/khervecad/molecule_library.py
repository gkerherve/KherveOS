"""The compound library of the Compound Builder (Qt-free).

Common chemical compounds as name + SMILES, in families. Formulas,
masses and 3D shapes are COMPUTED (molecule.py) rather than typed, so a
library entry is one line that cannot disagree with itself; the tests
build every one and check its formula, its bond lengths and that no
two atoms clash. An assistant reaches the same list through
list_molecules and builds anything else from SMILES.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from .molecule import from_smiles

GASES = "Gases & simple molecules"
INORGANIC = "Inorganic acids, bases & ions"
SHAPES = "Molecular shapes (VSEPR)"
HYDROCARBONS = "Hydrocarbons"
OXYGEN = "Alcohols, ethers & carbonyls"
ACIDS = "Acids & esters"
NITROGEN = "Nitrogen compounds & solvents"
BIO = "Biomolecules & drugs"
SALTS = "Salts, oxides & minerals"
CATEGORIES = (GASES, INORGANIC, SALTS, SHAPES, HYDROCARBONS, OXYGEN,
              ACIDS, NITROGEN, BIO)

#: key -> (name, SMILES, category, formula it must give)
COMPOUNDS = {
    # gases & simple molecules
    "hydrogen": ("Hydrogen", "[H][H]", GASES, "H2"),
    "oxygen": ("Oxygen", "O=O", GASES, "O2"),
    "nitrogen": ("Nitrogen", "N#N", GASES, "N2"),
    "water": ("Water", "O", GASES, "H2O"),
    "carbon_dioxide": ("Carbon dioxide", "O=C=O", GASES, "CO2"),
    "carbon_monoxide": ("Carbon monoxide", "[C-]#[O+]", GASES, "CO"),
    "ozone": ("Ozone", "[O-][O+]=O", GASES, "O3"),
    "ammonia": ("Ammonia", "N", GASES, "H3N"),
    "methane": ("Methane", "C", GASES, "CH4"),
    "hydrogen_chloride": ("Hydrogen chloride", "Cl", GASES, "ClH"),
    "hydrogen_sulfide": ("Hydrogen sulfide", "S", GASES, "H2S"),
    "hydrogen_cyanide": ("Hydrogen cyanide", "C#N", GASES, "CHN"),
    "sulfur_dioxide": ("Sulfur dioxide", "O=S=O", GASES, "O2S"),
    "hydrogen_peroxide": ("Hydrogen peroxide", "OO", GASES, "H2O2"),
    "fluorine": ("Fluorine", "FF", GASES, "F2"),
    "chlorine": ("Chlorine", "ClCl", GASES, "Cl2"),
    "bromine": ("Bromine", "BrBr", GASES, "Br2"),
    "iodine": ("Iodine", "II", GASES, "I2"),
    "hydrogen_fluoride": ("Hydrogen fluoride", "F", GASES, "FH"),
    "hydrogen_bromide": ("Hydrogen bromide", "Br", GASES, "BrH"),
    "hydrogen_iodide": ("Hydrogen iodide", "I", GASES, "HI"),
    "nitrous_oxide": ("Nitrous oxide", "[N-]=[N+]=O", GASES, "N2O"),
    "carbon_disulfide": ("Carbon disulfide", "S=C=S", GASES, "CS2"),
    "carbonyl_sulfide": ("Carbonyl sulfide", "O=C=S", GASES, "COS"),
    "nitrogen_trifluoride": ("Nitrogen trifluoride", "FN(F)F", GASES, "F3N"),
    "sulfur_trioxide": ("Sulfur trioxide", "O=S(=O)=O", GASES, "O3S"),
    "phosphine": ("Phosphine", "P", GASES, "H3P"),
    "arsine": ("Arsine", "[AsH3]", GASES, "AsH3"),
    "phosgene": ("Phosgene", "ClC(=O)Cl", GASES, "CCl2O"),
    # inorganic acids, bases & ions
    "sulfuric_acid": ("Sulfuric acid", "OS(=O)(=O)O", INORGANIC, "H2O4S"),
    "nitric_acid": ("Nitric acid", "O[N+](=O)[O-]", INORGANIC, "HNO3"),
    "phosphoric_acid": ("Phosphoric acid", "OP(=O)(O)O", INORGANIC,
                        "H3O4P"),
    "carbonic_acid": ("Carbonic acid", "OC(=O)O", INORGANIC, "CH2O3"),
    "hydroxide": ("Hydroxide ion", "[OH-]", INORGANIC, "HO-"),
    "hydronium": ("Hydronium ion", "[OH3+]", INORGANIC, "H3O+"),
    "ammonium": ("Ammonium ion", "[NH4+]", INORGANIC, "H4N+"),
    "sulfate": ("Sulfate ion", "[O-]S(=O)(=O)[O-]", INORGANIC, "O4S 2-"),
    "nitrate": ("Nitrate ion", "[O-][N+](=O)[O-]", INORGANIC, "NO3-"),
    "carbonate": ("Carbonate ion", "[O-]C(=O)[O-]", INORGANIC, "CO3 2-"),
    "hypochlorous_acid": ("Hypochlorous acid", "OCl", INORGANIC, "ClHO"),
    "chlorous_acid": ("Chlorous acid", "OCl=O", INORGANIC, "ClHO2"),
    "chloric_acid": ("Chloric acid", "OCl(=O)=O", INORGANIC, "ClHO3"),
    "perchloric_acid": ("Perchloric acid", "OCl(=O)(=O)=O",
                        INORGANIC, "ClHO4"),
    "boric_acid": ("Boric acid", "OB(O)O", INORGANIC, "BH3O3"),
    "silicic_acid": ("Silicic acid", "O[Si](O)(O)O", INORGANIC, "H4O4Si"),
    "bicarbonate": ("Bicarbonate ion", "[O-]C(=O)O", INORGANIC, "CHO3-"),
    "phosphate": ("Phosphate ion", "[O-]P(=O)([O-])[O-]", INORGANIC, "O4P 3-"),
    "hydrogen_phosphate": ("Hydrogen phosphate ion", "[O-]P(=O)(O)[O-]",
                           INORGANIC, "HO4P 2-"),
    "dihydrogen_phosphate": ("Dihydrogen phosphate ion", "OP(=O)(O)[O-]",
                             INORGANIC, "H2O4P-"),
    "sulfite": ("Sulfite ion", "[O-]S(=O)[O-]", INORGANIC, "O3S 2-"),
    "thiosulfate": ("Thiosulfate ion", "[O-]S(=O)(=O)[S-]",
                    INORGANIC, "O3S2 2-"),
    "cyanide": ("Cyanide ion", "[C-]#N", INORGANIC, "CN-"),
    "thiocyanate": ("Thiocyanate ion", "[S-]C#N", INORGANIC, "CNS-"),
    "permanganate": ("Permanganate ion", "[O-][Mn](=O)(=O)=O",
                     INORGANIC, "MnO4-"),
    "chromate": ("Chromate ion", "[O-][Cr](=O)(=O)=O", INORGANIC, "CrO4-"),
    # salts, oxides & minerals
    "sodium_chloride": ("Sodium chloride", "[Na+].[Cl-]", SALTS,
                        "ClNa"),
    "potassium_chloride": ("Potassium chloride", "[K+].[Cl-]", SALTS, "ClK"),
    "lithium_chloride": ("Lithium chloride", "[Li+].[Cl-]", SALTS, "ClLi"),
    "lithium_fluoride": ("Lithium fluoride", "[Li+].[F-]", SALTS, "FLi"),
    "sodium_hydroxide": ("Sodium hydroxide", "[Na+].[OH-]", SALTS, "HNaO"),
    "potassium_hydroxide": ("Potassium hydroxide", "[K+].[OH-]", SALTS, "HKO"),
    "ammonium_chloride": ("Ammonium chloride", "[NH4+].[Cl-]", SALTS, "ClH4N"),
    "calcium_chloride": ("Calcium chloride", "[Ca+2].[Cl-].[Cl-]",
                         SALTS, "CaCl2"),
    "magnesium_chloride": ("Magnesium chloride", "[Mg+2].[Cl-].[Cl-]",
                           SALTS, "Cl2Mg"),
    "calcium_carbonate": ("Calcium carbonate", "[Ca+2].[O-]C(=O)[O-]",
                          SALTS, "CCaO3"),
    "sodium_carbonate": ("Sodium carbonate", "[Na+].[Na+].[O-]C(=O)[O-]",
                         SALTS, "CNa2O3"),
    "sodium_bicarbonate": ("Sodium bicarbonate", "[Na+].[O-]C(=O)O",
                           SALTS, "CHNaO3"),
    "potassium_nitrate": ("Potassium nitrate", "[K+].[O-][N+](=O)[O-]",
                          SALTS, "KNO3"),
    "silver_nitrate": ("Silver nitrate", "[Ag+].[O-][N+](=O)[O-]",
                       SALTS, "AgNO3"),
    "copper_sulfate": ("Copper sulfate", "[Cu+2].[O-]S(=O)(=O)[O-]",
                       SALTS, "CuO4S"),
    "iron_iii_chloride": ("Iron(III) chloride", "[Fe+3].[Cl-].[Cl-].[Cl-]",
                          SALTS, "Cl3Fe"),
    "iron_ii_chloride": ("Iron(II) chloride", "[Fe+2].[Cl-].[Cl-]",
                         SALTS, "Cl2Fe"),
    "zinc_oxide": ("Zinc oxide", "[Zn+2].[O-2]", SALTS, "OZn"),
    "magnesium_oxide": ("Magnesium oxide", "[Mg+2].[O-2]", SALTS, "MgO"),
    "calcium_oxide": ("Calcium oxide", "[Ca+2].[O-2]", SALTS, "CaO"),
    "calcium_sulfate": ("Calcium sulfate", "[Ca+2].[O-]S(=O)(=O)[O-]",
                        SALTS, "CaO4S"),
    "ammonium_nitrate": ("Ammonium nitrate", "[NH4+].[O-][N+](=O)[O-]",
                         SALTS, "H4N2O3"),
    "ammonium_sulfate": ("Ammonium sulfate",
                         "[NH4+].[NH4+].[O-]S(=O)(=O)[O-]", SALTS, "H8N2O4S"),
    "potassium_permanganate": ("Potassium permanganate",
                               "[K+].[O-][Mn](=O)(=O)=O", SALTS, "KMnO4"),
    "sodium_sulfate": ("Sodium sulfate", "[Na+].[Na+].[O-]S(=O)(=O)[O-]",
                       SALTS, "Na2O4S"),
    # molecular shapes
    "boron_trifluoride": ("Boron trifluoride", "FB(F)F", SHAPES, "BF3"),
    "carbon_tetrachloride": ("Carbon tetrachloride", "ClC(Cl)(Cl)Cl",
                             SHAPES, "CCl4"),
    "phosphorus_pentachloride": ("Phosphorus pentachloride",
                                 "ClP(Cl)(Cl)(Cl)Cl", SHAPES, "Cl5P"),
    "sulfur_hexafluoride": ("Sulfur hexafluoride", "FS(F)(F)(F)(F)F",
                            SHAPES, "F6S"),
    "xenon_tetrafluoride": ("Xenon tetrafluoride", "F[Xe](F)(F)F", SHAPES,
                            "F4Xe"),
    "silane": ("Silane", "[SiH4]", SHAPES, "H4Si"),
    "phosphorus_pentafluoride": ("Phosphorus pentafluoride", "FP(F)(F)(F)F",
                                 SHAPES, "F5P"),
    "germanium_tetrachloride": ("Germanium tetrachloride", "Cl[Ge](Cl)(Cl)Cl",
                                SHAPES, "Cl4Ge"),
    "phosphine_oxide": ("Phosphine oxide", "O=P", SHAPES, "HOP"),
    # hydrocarbons
    "ethane": ("Ethane", "CC", HYDROCARBONS, "C2H6"),
    "propane": ("Propane", "CCC", HYDROCARBONS, "C3H8"),
    "butane": ("Butane", "CCCC", HYDROCARBONS, "C4H10"),
    "isobutane": ("Isobutane", "CC(C)C", HYDROCARBONS, "C4H10"),
    "hexane": ("Hexane", "CCCCCC", HYDROCARBONS, "C6H14"),
    "octane": ("Octane", "CCCCCCCC", HYDROCARBONS, "C8H18"),
    "ethylene": ("Ethylene", "C=C", HYDROCARBONS, "C2H4"),
    "propene": ("Propene", "CC=C", HYDROCARBONS, "C3H6"),
    "acetylene": ("Acetylene", "C#C", HYDROCARBONS, "C2H2"),
    "cyclohexane": ("Cyclohexane", "C1CCCCC1", HYDROCARBONS, "C6H12"),
    "benzene": ("Benzene", "c1ccccc1", HYDROCARBONS, "C6H6"),
    "toluene": ("Toluene", "Cc1ccccc1", HYDROCARBONS, "C7H8"),
    "styrene": ("Styrene", "C=Cc1ccccc1", HYDROCARBONS, "C8H8"),
    "naphthalene": ("Naphthalene", "c1ccc2ccccc2c1", HYDROCARBONS,
                    "C10H8"),
    "pentane": ("Pentane", "CCCCC", HYDROCARBONS, "C5H12"),
    "isopentane": ("Isopentane", "CCC(C)C", HYDROCARBONS, "C5H12"),
    "neopentane": ("Neopentane", "CC(C)(C)C", HYDROCARBONS, "C5H12"),
    "cyclobutane": ("Cyclobutane", "C1CCC1", HYDROCARBONS, "C4H8"),
    "cyclopentane": ("Cyclopentane", "C1CCCC1", HYDROCARBONS, "C5H10"),
    "cyclooctane": ("Cyclooctane", "C1CCCCCCC1", HYDROCARBONS, "C8H16"),
    "butadiene": ("1,3-Butadiene", "C=CC=C", HYDROCARBONS, "C4H6"),
    "isoprene": ("Isoprene", "C=C(C)C=C", HYDROCARBONS, "C5H8"),
    "cumene": ("Cumene", "CC(C)c1ccccc1", HYDROCARBONS, "C9H12"),
    "o_xylene": ("o-Xylene", "Cc1ccccc1C", HYDROCARBONS, "C8H10"),
    "m_xylene": ("m-Xylene", "Cc1cccc(C)c1", HYDROCARBONS, "C8H10"),
    "p_xylene": ("p-Xylene", "Cc1ccc(C)cc1", HYDROCARBONS, "C8H10"),
    "ethylbenzene": ("Ethylbenzene", "CCc1ccccc1", HYDROCARBONS, "C8H10"),
    "biphenyl": ("Biphenyl", "c1ccc(cc1)-c1ccccc1", HYDROCARBONS, "C12H10"),
    "indene": ("Indene", "c1ccc2c(c1)CC=C2", HYDROCARBONS, "C9H8"),
    "anthracene": ("Anthracene", "c1ccc2cc3ccccc3cc2c1",
                   HYDROCARBONS, "C14H10"),
    "furan": ("Furan", "c1ccoc1", HYDROCARBONS, "C4H4O"),
    "thiophene": ("Thiophene", "c1ccsc1", HYDROCARBONS, "C4H4S"),
    "limonene": ("Limonene", "CC1=CCC(CC1)C(=C)C", HYDROCARBONS, "C10H16"),
    # alcohols, ethers & carbonyls
    "methanol": ("Methanol", "CO", OXYGEN, "CH4O"),
    "ethanol": ("Ethanol", "CCO", OXYGEN, "C2H6O"),
    "isopropanol": ("Isopropanol", "CC(C)O", OXYGEN, "C3H8O"),
    "ethylene_glycol": ("Ethylene glycol", "OCCO", OXYGEN, "C2H6O2"),
    "glycerol": ("Glycerol", "OCC(O)CO", OXYGEN, "C3H8O3"),
    "diethyl_ether": ("Diethyl ether", "CCOCC", OXYGEN, "C4H10O"),
    "formaldehyde": ("Formaldehyde", "C=O", OXYGEN, "CH2O"),
    "acetaldehyde": ("Acetaldehyde", "CC=O", OXYGEN, "C2H4O"),
    "acetone": ("Acetone", "CC(C)=O", OXYGEN, "C3H6O"),
    "phenol": ("Phenol", "Oc1ccccc1", OXYGEN, "C6H6O"),
    "propanol": ("1-Propanol", "CCCO", OXYGEN, "C3H8O"),
    "butanol": ("1-Butanol", "CCCCO", OXYGEN, "C4H10O"),
    "tert_butanol": ("tert-Butanol", "CC(C)(C)O", OXYGEN, "C4H10O"),
    "propylene_glycol": ("Propylene glycol", "CC(O)CO", OXYGEN, "C3H8O2"),
    "diethylene_glycol": ("Diethylene glycol", "OCCOCCO", OXYGEN, "C4H10O3"),
    "cresol": ("p-Cresol", "Cc1ccc(O)cc1", OXYGEN, "C7H8O"),
    "hydroquinone": ("Hydroquinone", "Oc1ccc(O)cc1", OXYGEN, "C6H6O2"),
    "catechol": ("Catechol", "Oc1ccccc1O", OXYGEN, "C6H6O2"),
    "resorcinol": ("Resorcinol", "Oc1cccc(O)c1", OXYGEN, "C6H6O2"),
    "eugenol": ("Eugenol", "C=CCc1ccc(O)c(OC)c1", OXYGEN, "C10H12O2"),
    "thymol": ("Thymol", "CC(C)c1ccc(C)cc1O", OXYGEN, "C10H14O"),
    "butanone": ("Butanone (MEK)", "CCC(C)=O", OXYGEN, "C4H8O"),
    "cyclohexanone": ("Cyclohexanone", "O=C1CCCCC1", OXYGEN, "C6H10O"),
    "benzaldehyde": ("Benzaldehyde", "O=Cc1ccccc1", OXYGEN, "C7H6O"),
    "cinnamaldehyde": ("Cinnamaldehyde", "O=CC=Cc1ccccc1", OXYGEN, "C9H8O"),
    "furfural": ("Furfural", "O=Cc1ccco1", OXYGEN, "C5H4O2"),
    "menthol": ("Menthol", "CC(C)C1CCC(C)CC1O", OXYGEN, "C10H20O"),
    # acids & esters
    "formic_acid": ("Formic acid", "OC=O", ACIDS, "CH2O2"),
    "acetic_acid": ("Acetic acid", "CC(=O)O", ACIDS, "C2H4O2"),
    "lactic_acid": ("Lactic acid", "CC(O)C(=O)O", ACIDS, "C3H6O3"),
    "citric_acid": ("Citric acid", "OC(=O)CC(O)(CC(=O)O)C(=O)O", ACIDS,
                    "C6H8O7"),
    "benzoic_acid": ("Benzoic acid", "OC(=O)c1ccccc1", ACIDS, "C7H6O2"),
    "ethyl_acetate": ("Ethyl acetate", "CCOC(C)=O", ACIDS, "C4H8O2"),
    "propionic_acid": ("Propionic acid", "CCC(=O)O", ACIDS, "C3H6O2"),
    "butyric_acid": ("Butyric acid", "CCCC(=O)O", ACIDS, "C4H8O2"),
    "oxalic_acid": ("Oxalic acid", "OC(=O)C(=O)O", ACIDS, "C2H2O4"),
    "malic_acid": ("Malic acid", "OC(=O)C(O)CC(=O)O", ACIDS, "C4H6O5"),
    "tartaric_acid": ("Tartaric acid", "OC(=O)C(O)C(O)C(=O)O",
                      ACIDS, "C4H6O6"),
    "salicylic_acid": ("Salicylic acid", "OC(=O)c1ccccc1O", ACIDS, "C7H6O3"),
    "glycolic_acid": ("Glycolic acid", "OCC(=O)O", ACIDS, "C2H4O3"),
    "pyruvic_acid": ("Pyruvic acid", "CC(=O)C(=O)O", ACIDS, "C3H4O3"),
    "succinic_acid": ("Succinic acid", "OC(=O)CCC(=O)O", ACIDS, "C4H6O4"),
    "maleic_acid": ("Maleic acid", "OC(=O)C=CC(=O)O", ACIDS, "C4H4O4"),
    "fumaric_acid": ("Fumaric acid", "OC(=O)/C=C/C(=O)O", ACIDS, "C4H4O4"),
    "adipic_acid": ("Adipic acid", "OC(=O)CCCCC(=O)O", ACIDS, "C6H10O4"),
    "stearic_acid": ("Stearic acid", "CCCCCCCCCCCCCCCCCC(=O)O",
                     ACIDS, "C18H36O2"),
    "palmitic_acid": ("Palmitic acid", "CCCCCCCCCCCCCCCC(=O)O",
                      ACIDS, "C16H32O2"),
    "methyl_acetate": ("Methyl acetate", "COC(C)=O", ACIDS, "C3H6O2"),
    "ethyl_formate": ("Ethyl formate", "CCOC=O", ACIDS, "C3H6O2"),
    "methyl_benzoate": ("Methyl benzoate", "COC(=O)c1ccccc1", ACIDS, "C8H8O2"),
    "ascorbic_acid": ("Ascorbic acid (vitamin C)", "OCC(O)C1OC(=O)C(O)=C1O",
                      ACIDS, "C6H8O6"),
    # nitrogen compounds & solvents
    "methylamine": ("Methylamine", "CN", NITROGEN, "CH5N"),
    "urea": ("Urea", "NC(N)=O", NITROGEN, "CH4N2O"),
    "aniline": ("Aniline", "Nc1ccccc1", NITROGEN, "C6H7N"),
    "pyridine": ("Pyridine", "c1ccncc1", NITROGEN, "C5H5N"),
    "acetonitrile": ("Acetonitrile", "CC#N", NITROGEN, "C2H3N"),
    "nitrobenzene": ("Nitrobenzene", "O=[N+]([O-])c1ccccc1", NITROGEN,
                     "C6H5NO2"),
    "dmso": ("Dimethyl sulfoxide (DMSO)", "CS(C)=O", NITROGEN, "C2H6OS"),
    "dmf": ("Dimethylformamide (DMF)", "CN(C)C=O", NITROGEN, "C3H7NO"),
    "dichloromethane": ("Dichloromethane", "ClCCl", NITROGEN, "CH2Cl2"),
    "chloroform": ("Chloroform", "ClC(Cl)Cl", NITROGEN, "CHCl3"),
    "thf": ("Tetrahydrofuran (THF)", "C1CCOC1", NITROGEN, "C4H8O"),
    "hydrazine": ("Hydrazine", "NN", NITROGEN, "H4N2"),
    "hydroxylamine": ("Hydroxylamine", "NO", NITROGEN, "H3NO"),
    "nitromethane": ("Nitromethane", "C[N+](=O)[O-]", NITROGEN, "CH3NO2"),
    "dimethylamine": ("Dimethylamine", "CNC", NITROGEN, "C2H7N"),
    "trimethylamine": ("Trimethylamine", "CN(C)C", NITROGEN, "C3H9N"),
    "diethylamine": ("Diethylamine", "CCNCC", NITROGEN, "C4H11N"),
    "triethylamine": ("Triethylamine", "CCN(CC)CC", NITROGEN, "C6H15N"),
    "ethylenediamine": ("Ethylenediamine", "NCCN", NITROGEN, "C2H8N2"),
    "pyrrole": ("Pyrrole", "c1cc[nH]c1", NITROGEN, "C4H5N"),
    "pyrrolidine": ("Pyrrolidine", "C1CCNC1", NITROGEN, "C4H9N"),
    "piperidine": ("Piperidine", "C1CCNCC1", NITROGEN, "C5H11N"),
    "imidazole": ("Imidazole", "c1cnc[nH]1", NITROGEN, "C3H4N2"),
    "indole": ("Indole", "c1ccc2[nH]ccc2c1", NITROGEN, "C8H7N"),
    "quinoline": ("Quinoline", "c1ccc2ncccc2c1", NITROGEN, "C9H7N"),
    "morpholine": ("Morpholine", "C1COCCN1", NITROGEN, "C4H9NO"),
    "acetamide": ("Acetamide", "CC(N)=O", NITROGEN, "C2H5NO"),
    "formamide": ("Formamide", "NC=O", NITROGEN, "CH3NO"),
    "acrylonitrile": ("Acrylonitrile", "C=CC#N", NITROGEN, "C3H3N"),
    "melamine": ("Melamine", "Nc1nc(N)nc(N)n1", NITROGEN, "C3H6N6"),
    "nicotine": ("Nicotine", "CN1CCCC1c1cccnc1", NITROGEN, "C10H14N2"),
    "guanidine": ("Guanidine", "NC(N)=N", NITROGEN, "CH5N3"),
    # biomolecules & drugs
    "glycine": ("Glycine", "NCC(=O)O", BIO, "C2H5NO2"),
    "alanine": ("Alanine", "CC(N)C(=O)O", BIO, "C3H7NO2"),
    "glucose": ("Glucose (beta-D-glucopyranose)", "OCC1OC(O)C(O)C(O)C1O",
                BIO, "C6H12O6"),
    "adenine": ("Adenine", "Nc1ncnc2[nH]cnc12", BIO, "C5H5N5"),
    "caffeine": ("Caffeine", "Cn1cnc2c1c(=O)n(C)c(=O)n2C", BIO,
                 "C8H10N4O2"),
    "aspirin": ("Aspirin", "CC(=O)Oc1ccccc1C(=O)O", BIO, "C9H8O4"),
    "paracetamol": ("Paracetamol", "CC(=O)Nc1ccc(O)cc1", BIO, "C8H9NO2"),
    "vanillin": ("Vanillin", "COc1cc(C=O)ccc1O", BIO, "C8H8O3"),
    "serine": ("Serine", "OCC(N)C(=O)O", BIO, "C3H7NO3"),
    "cysteine": ("Cysteine", "SCC(N)C(=O)O", BIO, "C3H7NO2S"),
    "valine": ("Valine", "CC(C)C(N)C(=O)O", BIO, "C5H11NO2"),
    "leucine": ("Leucine", "CC(C)CC(N)C(=O)O", BIO, "C6H13NO2"),
    "isoleucine": ("Isoleucine", "CCC(C)C(N)C(=O)O", BIO, "C6H13NO2"),
    "proline": ("Proline", "OC(=O)C1CCCN1", BIO, "C5H9NO2"),
    "phenylalanine": ("Phenylalanine", "NC(Cc1ccccc1)C(=O)O", BIO, "C9H11NO2"),
    "tyrosine": ("Tyrosine", "NC(Cc1ccc(O)cc1)C(=O)O", BIO, "C9H11NO3"),
    "tryptophan": ("Tryptophan", "NC(Cc1c[nH]c2ccccc12)C(=O)O",
                   BIO, "C11H12N2O2"),
    "aspartic_acid": ("Aspartic acid", "NC(CC(=O)O)C(=O)O", BIO, "C4H7NO4"),
    "glutamic_acid": ("Glutamic acid", "NC(CCC(=O)O)C(=O)O", BIO, "C5H9NO4"),
    "asparagine": ("Asparagine", "NC(=O)CC(N)C(=O)O", BIO, "C4H8N2O3"),
    "glutamine": ("Glutamine", "NC(=O)CCC(N)C(=O)O", BIO, "C5H10N2O3"),
    "lysine": ("Lysine", "NCCCCC(N)C(=O)O", BIO, "C6H14N2O2"),
    "arginine": ("Arginine", "NC(N)=NCCCC(N)C(=O)O", BIO, "C6H14N4O2"),
    "histidine": ("Histidine", "NC(Cc1c[nH]cn1)C(=O)O", BIO, "C6H9N3O2"),
    "methionine": ("Methionine", "CSCCC(N)C(=O)O", BIO, "C5H11NO2S"),
    "threonine": ("Threonine", "CC(O)C(N)C(=O)O", BIO, "C4H9NO3"),
    "guanine": ("Guanine", "Nc1nc2[nH]cnc2c(=O)[nH]1", BIO, "C5H5N5O"),
    "cytosine": ("Cytosine", "Nc1cc[nH]c(=O)n1", BIO, "C4H5N3O"),
    "thymine": ("Thymine", "Cc1c[nH]c(=O)[nH]c1=O", BIO, "C5H6N2O2"),
    "uracil": ("Uracil", "O=c1cc[nH]c(=O)[nH]1", BIO, "C4H4N2O2"),
    "fructose": ("Fructose", "OCC1(O)OCC(O)C(O)C1O", BIO, "C6H12O6"),
    "ribose": ("Ribose", "OCC1OC(O)C(O)C1O", BIO, "C5H10O5"),
    "deoxyribose": ("Deoxyribose", "OCC1OC(O)CC1O", BIO, "C5H10O4"),
    "ibuprofen": ("Ibuprofen", "CC(C)Cc1ccc(cc1)C(C)C(=O)O", BIO, "C13H18O2"),
    "serotonin": ("Serotonin", "NCCc1c[nH]c2ccc(O)cc12", BIO, "C10H12N2O"),
    "dopamine": ("Dopamine", "NCCc1ccc(O)c(O)c1", BIO, "C8H11NO2"),
    "adrenaline": ("Adrenaline (epinephrine)", "CNCC(O)c1ccc(O)c(O)c1",
                   BIO, "C9H13NO3"),
}

# benzene derivatives, fused aromatics and the common medicines
from .molecule_library_more import (CATEGORIES as _MORE_CATEGORIES,  # noqa
                                    MORE as _MORE)
COMPOUNDS.update(_MORE)
CATEGORIES = CATEGORIES + _MORE_CATEGORIES
# elements, more salts and halides, homologous series… (from KherveMol)
from .molecule_library_extra import (CATEGORIES as _EXTRA_CATEGORIES,  # noqa
                                     EXTRA as _EXTRA)
COMPOUNDS.update(_EXTRA)
CATEGORIES = CATEGORIES[:3] + _EXTRA_CATEGORIES[:2] + CATEGORIES[3:] + \
    _EXTRA_CATEGORIES[2:]


def get(key: str):
    """The library molecule *key* (3D, cached); KeyError names the
    choices."""
    k = str(key).strip().lower().replace(" ", "_")
    if k not in COMPOUNDS:
        by_name = {v[0].lower(): kk for kk, v in COMPOUNDS.items()}
        k = by_name.get(str(key).strip().lower(), k)
    if k not in COMPOUNDS:
        from . import carbon_nano      # C60 and the other cages
        try:
            return carbon_nano.get(key)
        except KeyError:
            pass
        raise KeyError(f"No compound '{key}'. Choices: "
                       + ", ".join(COMPOUNDS))
    name, smiles, category, _formula = COMPOUNDS[k]
    return from_smiles(smiles, name=name, key=k, category=category)


def by_formula(formula: str):
    """Library keys whose molecule has this formula (order as listed)."""
    from .molecule import formula_counts, hill_formula
    try:
        want = hill_formula(formula_counts(formula))
    except ValueError:
        return []
    return [k for k, (_n, _s, _c, f) in COMPOUNDS.items()
            if hill_formula(formula_counts(f.split(" ")[0].rstrip("+-")))
            == want]
