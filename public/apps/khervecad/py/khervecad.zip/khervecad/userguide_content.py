"""The chapters of the User Guide (userguide.py shows them).

``chapters()`` returns (anchor, title, html) in reading order. A chapter
whose html is ``"@reference"`` is replaced by the tool reference that
userguide.py builds from tooltips.py. Screenshots come from
``khervecad/help/`` via ``figure()``; regenerate them with
``packaging/make_help_screenshots.py``.

Copyright (C) 2026 Gwilherm Kerherve

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""


def chapters():
    from .userguide import figure, kbd
    K = kbd
    return [
        ("welcome", "Welcome", f"""
<p>KherveCAD is a CAD program for people who want real, printable,
exportable solids without learning a programming language first. You
draw, extrude, combine and arrange; behind the scenes every step is one
line of an <b>OpenSCAD</b> program, and OpenSCAD is the engine that
turns it into exact geometry.</p>
<p>The one idea to hold on to: <b>your model is a tree of objects</b>.
Every tool either adds a row to that tree or changes one. The program in
the <b>Code</b> tab is written from the tree, so the two always agree
&mdash; you can work in whichever you prefer.</p>
{figure("window", "The KherveCAD window with an example model loaded.")}
<table>
<tr><td><b>1</b></td><td><b>Object tree &amp; tabs</b> &mdash; the
model itself. Main (the assembly), Object (the part you are building),
Collections, Variables and Code.</td></tr>
<tr><td><b>2</b></td><td><b>Properties</b> &mdash; every setting of the
selected object: sizes, positions, angles, colour.</td></tr>
<tr><td><b>3</b></td><td><b>2D sketch</b> &mdash; a millimetre grid
where you draw profiles and drag parts into place.</td></tr>
<tr><td><b>4</b></td><td><b>3D preview</b> &mdash; the solid result.
Orbit, pan and zoom with the mouse.</td></tr>
<tr><td><b>5</b></td><td><b>Drawing tools &amp; solids</b> &mdash;
sketch tools, measuring, and one-click 3D shapes.</td></tr>
<tr><td><b>6</b></td><td><b>Main toolbar</b> &mdash; file, undo, the
operations (grouped), snapping, the sketch controls and the 3D
view.</td></tr>
</table>
<p><b>Selection is shared.</b> Click an object anywhere &mdash; tree, 2D
or 3D &mdash; and it is selected in all of them: the Properties panel
shows its settings, the sketch outlines it and the 3D view tints it
red.</p>
<p><b>Hover any icon</b> for a tooltip that says what it does and how to
use it, step by step. Press {K("F1")} to come back to this guide.</p>
"""),

        ("first-part", "Your first part in five minutes", f"""
<p>This walk-through makes a plate with a hole in it &mdash; the four
moves that build most parts: <i>draw, extrude, add, cut</i>.</p>

<h3>Step 1 &mdash; draw a rectangle</h3>
<ol>
<li>Pick the <b>Rectangle</b> tool in the left toolbar (or press
{K("R")}).</li>
<li>In the 2D sketch, press at one corner, drag to the other and let
go. The size reads live in millimetres.</li>
<li>Type exact numbers in <b>Properties</b>: Width 60, Height 40.</li>
</ol>
<p>Because you drew in the <b>Main</b> tab, KherveCAD makes the shape
into a new <b>Object</b> (a part) and opens the <b>Object</b> tab on it:
parts are built in the Object tab and arranged in Main.</p>
{figure("tutorial_1_rectangle", "A rectangle, drawn and sized. The "
        "Object tab has opened on the new part.")}

<h3>Step 2 &mdash; extrude it into a plate</h3>
<ol>
<li>With the rectangle selected, open the <b>Extrude</b> group on the
main toolbar and pick <b>Linear extrude</b>.</li>
<li>In Properties set <b>Height</b> to 8. The rectangle is now a plate:
in the tree, <i>Linear extrude</i> wraps <i>Rectangle</i>.</li>
</ol>
{figure("tutorial_2_extrude", "Linear extrude wraps the rectangle and "
        "gives it height.")}

<h3>Step 3 &mdash; add a cylinder where the hole goes</h3>
<ol>
<li>Click <b>Cylinder</b> in the left toolbar. It appears at the origin,
inside the part you are editing.</li>
<li>In Properties set both radii to 8, Height 20 and Z to &minus;6, so
it passes right through the plate.</li>
</ol>
{figure("tutorial_3_cylinder", "The cylinder pokes through the plate; "
        "it is selected, so it is tinted and its settings are shown.")}

<h3>Step 4 &mdash; cut the hole</h3>
<ol>
<li>In the tree, click <i>Linear extrude</i>, then Ctrl-click
<i>Cylinder</i> (the body first, then the cutter).</li>
<li>Open the <b>Combine</b> group and pick <b>Difference</b>. The
cylinder is subtracted from the plate.</li>
</ol>
{figure("tutorial_4_difference", "Difference: the first object minus "
        "everything after it. The hole is cut by the OpenSCAD engine.")}
<p>That is a finished part. Save it with {K("Ctrl+S")}, export it for
3D printing with <b>File &rsaquo; Export STL</b>, or click <b>To
Main</b> to place it into an assembly. Everything you did is undoable
one step at a time with {K("Ctrl+Z")}.</p>
<p class='tip'><i>Tip:</i> the same four moves with other shapes make
almost anything: a polygon extruded into a bracket, circles cut from a
plate for a flange, text extruded and cut into a nameplate.</p>
"""),

        ("window", "The window, panel by panel", f"""
<h3>The tabs above the tree</h3>
<p><b>Main</b> is the <i>assembly</i>: every part in your document, each
one row, placed where it belongs. The <b>Common segments ($fn)</b> box
at the top sets how smooth every circle, sphere and cylinder is (higher
is smoother and slower); untick it to let each shape use its own
value.</p>
{figure("tab_main", "Main tab: the document's parts and their "
        "placement.", 430)}
<p><b>Object</b> is where one part is <i>built</i>. Choose the part in
the drop-down, or <b>+ New</b> to start one; the pencil button renames
it and <b>To Main</b> places another copy of it into the assembly.
While this tab is open, the 2D and 3D views show only this part, at its
own origin.</p>
{figure("tab_object", "Object tab: the construction of one part, step "
        "by step.", 430)}
<p><b>Variables</b> is a small spreadsheet of named numbers
(<i>w</i>, <i>wall</i>&hellip;) you can use in any field. <b>Code</b>
shows the OpenSCAD program and lets you edit it.</p>
{figure("tab_variables", "Variables tab: named values used by "
        "expressions like <i>w - 2 * wall</i>.", 430)}

<h3>Properties</h3>
<p>Every setting of the selected object, generated from its type: sizes,
position, angles, segments, colour, text. Any number field also accepts
an <b>expression</b> &mdash; <code>wall * 2</code>, <code>i * 10</code>,
<code>cos(a) * r</code> &mdash; which is how a model becomes adjustable.
A polygon shows its corners as an editable table.</p>
{figure("properties", "Properties of a cylinder.", 430)}

<h3>The 2D sketch</h3>
<p>A millimetre grid on one plane of the model &mdash; <b>Top (XY)</b>,
<b>Front (XZ)</b> or <b>Side (YZ)</b>, chosen in the main toolbar. The
two axes are coloured like the 3D gizmo (X red, Y green, Z blue).
Shapes are drawn here; a selected shape shows its size with dimension
arrows and square handles to resize it. 3D parts appear as filled
outlines you can drag. Middle-drag pans, the wheel zooms, and the scale
bar at the bottom left tells you how big a grid square is. The small
bar in the top-right corner does the same without the mouse: the arrows
scroll, the magnifiers zoom (hold a button to repeat), <b>Focus</b>
(&#x25CE;) frames the selected part wherever it is &mdash; handy when a
part is nowhere near the origin &mdash; and <b>Fit all</b> shows
everything.</p>
{figure("sketch", "The 2D sketch: a selected rectangle with its "
        "automatic dimensions, and a circle.")}

<h3>The 3D preview</h3>
<p>The solid result. <b>Left-drag</b> orbits, <b>right- or
middle-drag</b> pans, the <b>wheel</b> zooms and a <b>double-click</b>
frames the whole model. The floating bar at the top left sets
<b>brightness</b> and <b>contrast</b> (&#x27F2; resets them) and has
<b>Redraw</b> (&#x27F3;). The bar at the top right turns the model,
pans, zooms, frames the selected part (<b>Focus</b>) or the whole model
(<b>Fit all</b>). The label at the bottom says what you are
looking at: <i>built-in preview</i> (instant, approximate) or
<i>OpenSCAD</i> (exact), and how many parts are exact already.</p>
{figure("view3d_plate", "The 3D preview with the lighting bar.")}

<h3>The status bar</h3>
<p>From left to right: the cursor position in the sketch, messages,
the current file, the sketch zoom (1&nbsp;mm = n pixels) and the
engine: <i>OpenSCAD (ready)</i>, <i>(rendering&hellip;)</i> or
<i>built-in preview</i> when OpenSCAD is not installed.</p>
"""),

        ("toolbars", "The toolbars", f"""
<p>The <b>left toolbar</b> holds the drawing tools (one is always
active &mdash; Select by default), the two measuring tools, and the 3D
solids that are added with one click. The <b>main toolbar</b> along the
top is split into sections:</p>
{figure("toolbar_main", "The main toolbar and its sections.", 900)}
<ul>
<li><b>File</b> &mdash; New, Open, Save.</li>
<li><b>Undo</b> &mdash; Undo and Redo.</li>
<li><b>Operations</b> &mdash; six drop-down groups (below).</li>
<li><b>Assembly</b> &mdash; Snap objects together (the magnet).</li>
<li><b>Sketch</b> &mdash; grid, snap-to-grid, grid spacing, the sketch
plane and Fit sketch.</li>
<li><b>3D view</b> &mdash; Render with OpenSCAD, Fit 3D.</li>
<li><b>AI</b> &mdash; the assistant chat.</li>
</ul>
<h3>How the operation groups work</h3>
<p>Each group button is a family of tools. <b>Click the icon</b> and it
runs the tool shown &mdash; the one you used last in that family (it is
remembered between sessions). <b>Click the small arrow</b> next to it
to see the whole family and pick another; hovering a tool in the list
shows its full tooltip.</p>
<table><tr>
<td>{figure("group_extrude", "Extrude", 190)}</td>
<td>{figure("group_transform", "Move &amp; transform", 190)}</td>
<td>{figure("group_combine", "Combine", 190)}</td>
</tr><tr>
<td>{figure("group_deform", "Deform &amp; sculpt", 230)}</td>
<td>{figure("group_character", "Character", 260)}</td>
<td>{figure("group_logic", "Repeat &amp; logic", 190)}</td>
</tr></table>
<p>Operations act on the <b>selection</b>: select objects first (in the
tree or the sketch), then pick the operation &mdash; it wraps them, so
the tree shows e.g. <i>Rotate</i> with your objects inside. Group, the
loops and If/else also work with nothing selected: they add an empty
node you can drag objects into.</p>
<p>Every tool is described one by one in the <b>Tool reference</b>
chapter.</p>
"""),

        ("insert_menu", "The Insert and Tools menus", f"""
<p>Every tool on the two toolbars is also in a menu, one submenu per
group &mdash; handy when you know a tool's name but not its icon, and
every entry keeps the icon's how-to tooltip. <b>Insert</b> holds what
<i>adds</i> something; <b>Tools</b> holds what <i>works on</i> what is
already there.</p>
<p><b>Insert</b>:</p>
<ul>
<li><b>2D Shapes</b> &mdash; line, rectangle, circle, polygon, text (the
same drawing tools as the left bar; the tick shows the one in use).</li>
<li><b>3D Solids</b> &mdash; cube, sphere, cylinder, capsule, ellipsoid,
rounded box, loft.</li>
<li><b>Repeat &amp; logic</b> (loops, if/else, patterns), <b>Code &amp;
files</b> (variables, imported meshes, OpenSCAD code, sheet metal),
<b>Mechanical features</b> and <b>Shapes &amp; patterns</b>.</li>
</ul>
<p><b>Tools</b>:</p>
<ul>
<li><b>Extrude</b>, <b>Move &amp; transform</b>, <b>Combine</b>,
<b>Finish</b>, <b>Deform &amp; sculpt</b> and <b>Character</b> &mdash;
the operation families of the main toolbar, applied to the
selection.</li>
<li><b>Edit Vertices</b> {K("Tab")} &mdash; Blender's Edit Mode: drag
the part's vertices, add new ones, extrude, subdivide.</li>
<li><b>Snap objects</b> {K("J")} and <b>Measure &amp; annotate</b>.</li>
</ul>
<p>Both menus are built from the very tables the toolbars are, so a new
tool appears in both at once.</p>
"""),
        ("exploded", "Exploded views", f"""
<p>An <b>exploded view</b> pulls every part of an assembly away from its
centre so you can see how it goes together &mdash; for instructions,
for a Printables listing, or just to check what sits behind what. It
is a way of <i>looking</i>: the model itself does not move.</p>
<ul>
<li><b>View &rsaquo; Exploded View &rsaquo; Explode the Assembly</b>
{K("Ctrl+Shift+X")} switches it on and off; {K("Ctrl+F")} frames the
spread-out parts. The same switch is on the bar in the top-right corner
of the 3D view, with every option under its arrow.</li>
<li><b>What comes apart</b>: with a part selected, the assembly it
belongs to &mdash; select one leaf of a hinge and the whole hinge comes
apart, while everything else stays put and the selection follows its
part. With nothing selected, the parts of the document (or of the
Object you are editing); a single Group or Object holding them all is
looked into. A boolean is one solid and never comes apart. When there
is only one part, the status bar says so.</li>
<li><b>Distance</b> 50&ndash;300&nbsp;%: at 100&nbsp;% each part moves
as far again as it already sits from the centre.</li>
<li><b>Outwards (radial)</b> spreads parts in every direction;
<b>Along X / Y / Z</b> keeps them in line &mdash; a stack of plates
explodes nicely along Z.</li>
<li>A part is each top-level row of Main (an Object, an instance, a
coloured group); in the Object tab, the Object's own sub-parts.</li>
<li><b>File &rsaquo; Export PNG</b> has an <b>Exploded view</b> box,
and <b>Publish to Printables</b> adds exploded pictures (isometric and
front) for any assembly of two or more parts.</li>
</ul>
"""),
        ("cut-through", "Cut through", f"""
<p><b>Cut through</b> slices the 3D view with a plane, takes one half
away and fills the cut face in red &mdash; the way a CAD section looks
&mdash; so you can see how a part is made inside: the holes and bores,
the wall thickness, a thread, how one part sits in another. Like the
exploded view it is a way of <i>looking</i>: the model, its exports and
its drawings stay whole.</p>
<ul>
<li>Click the <b>scissors</b> on the toolbar, or <b>View &rsaquo; Cut
Through</b> {K("Ctrl+Alt+X")}, or the scissors on the bar in the
top-right corner of the 3D view &mdash; its arrow lists every option:
the axis, where the cut goes (a quarter, the middle, three quarters)
and which half stays.</li>
<li>A bar appears along the bottom of the 3D view: pick <b>X</b>,
<b>Y</b> or <b>Z</b>, and drag the slider to move the cut through the
model; the readout gives its position in millimetres.</li>
<li><b>&#x21C4;</b> keeps the other half; <b>&#x2715;</b> (or the
toolbar button again) shows the whole model.</li>
<li>Keep orbiting while it is cut: the red face is the section, what is
behind it the inside of the part.</li>
<li>With OpenSCAD installed the cut goes through the exact geometry, so
bored holes and threads show as they will print.</li>
</ul>
<p>Pictures from <b>File &rsaquo; Export PNG</b> of the current view
show the cut; <b>Publish to Printables</b> and <b>Blueprint</b> always
use the whole model. A 2D engineering section (hatched, with its
cutting line) is on the <b>Blueprint</b>: Insert &rsaquo; Section
view.</p>
"""),
        ("reference", "Tool reference", "@reference"),

        ("sketching", "Drawing in 2D", f"""
<p>2D shapes are the start of most parts: draw the outline, then give
it depth. Pick a tool in the left toolbar, draw in the sketch, then
refine the numbers in Properties.</p>
<ul>
<li><b>Rectangle</b> {K("R")} &mdash; drag corner to corner.</li>
<li><b>Circle</b> {K("C")} &mdash; press at the centre, drag out to the
radius. <i>Angle</i> 180 gives a semicircle, 90 a quarter.</li>
<li><b>Polygon</b> {K("P")} &mdash; click each corner, double-click or
{K("Enter")} to close, {K("Esc")} to abandon.</li>
<li><b>Line</b> {K("L")} &mdash; a bar between two points, with a
<i>Width</i>; it extrudes like any shape.</li>
<li><b>Text</b> {K("T")} &mdash; click to place, type the words in
Properties.</li>
</ul>
<h3>Grid, snap and planes</h3>
<p><b>Grid</b> shows the millimetre grid; <b>Snap</b> makes drawn points
land on it; the <b>Grid</b> box sets the spacing (down to 0.01 mm). The
<b>Plane</b> box picks which plane you draw on: Top (XY) for plates and
footprints, Front (XZ) for profiles you will revolve, Side (YZ).</p>
<h3>Document units</h3>
<p>A model is in millimetres unless you say otherwise: <b>Edit &rsaquo;
Document Units&hellip;</b> picks nanometres, micrometres, centimetres,
metres or inches. It changes what the numbers are <i>called</i>, not the
model &mdash; a 100&nbsp;nm particle is typed 100 in a nanometre
document, and the status bar, the scale bar, measurements, the Analyse
windows and the Blueprint's UNITS box all say nm. Mass is worked out at
true size; print time and cost only for mm, cm and inches. An STL is
read as millimetres by every slicer, so Export STL asks whether to keep
it 1:1 or scale it to real millimetres. The unit is saved with the
document.</p>
<p>A model can also stand for something far bigger or smaller than
itself. <b>Edit &rsaquo; Document Scale (1&nbsp;:&nbsp;N)&hellip;</b>
says how it compares with the real thing &mdash; a 60&nbsp;mm Earth is
1&nbsp;:&nbsp;212&nbsp;600&nbsp;000 &mdash; and the 3D scale bar then
measures the real thing in kilometres and writes the ratio under
itself, the way a map does. Inserting a planet or a moon into an empty
document sets it for you. The scale bar also climbs to metres and
kilometres by itself, so a street at true size reads 200&nbsp;m, not
200000&nbsp;mm.</p>
<h3>Measuring</h3>
<p><b>Measure</b> {K("M")}: click two points &mdash; the distance shows in
the status bar and nothing is added. <b>Add dimension</b> {K("D")}: the
same, but it leaves a dimension line on the sketch (View &rsaquo; Clear
Dimensions removes them). Both snap to corners and edges. Selected
shapes also show their own size automatically (View &rsaquo; Dimensions
on selection).</p>
<h3>Editing shapes</h3>
<p>With <b>Select</b> {K("V")}: click to select, drag to move, drag a
square handle to resize. A polygon's corners are edited exactly in the
points table in Properties. View &rsaquo; Fit Sketch
{K("Ctrl+Shift+F")} and Zoom to Selection reframe the view.</p>
<p class='tip'><i>Tip:</i> 2D shapes combine too &mdash; a Difference of
two circles is a ring, a Union of rectangles an L-shape &mdash; before
you extrude.</p>
"""),

        ("solids", "Making solids", f"""
<h3>From a 2D shape</h3>
<p><b>Linear extrude</b> pushes the selected 2D shapes straight up by a
<i>Height</i>. <i>Twist</i> turns the top as it rises (a twisted vase),
<i>Scale</i> shrinks or grows the top (0 makes a point, a pyramid),
<i>Center</i> extrudes equally up and down.</p>
<p><b>Rotate extrude</b> spins a profile round the vertical axis like a
lathe. Draw <i>half</i> the cross-section, to the right of the Y axis:
its X becomes the radius and its Y the height. A profile that crosses
X&nbsp;=&nbsp;0 turns red. An <i>Angle</i> below 360 makes a slice.</p>
<p><b>Sweep along path</b> drives a profile along a 3D path &mdash; the
tool for pipes, handrails, cable runs, springs and chain links (what
Blender does with a curve and a bevel object). Draw the cross-section
around the origin (a circle for a pipe, a rectangle for a rail), apply
the sweep, then type the <b>Path points</b> in Properties. Corners are
mitred; <b>Smoothing</b> rounds them into a fair curve that still passes
through every point. <b>Wall thickness</b> hollows it into a pipe,
<b>Closed loop</b> joins the end to the start (an O-ring), and
<b>Twist</b> / <b>Scale</b> act over the length. Seen with the path
coming towards you and Z up, the profile's x is right and y is up, just
like Linear extrude. Library &rsaquo; Mechanical examples &rsaquo; <i>Pipe run
&amp; handrail</i> shows all three.</p>
{figure("sweep", "A hollow pipe through smoothed bends, a mitred square "
        "rail and a closed O-ring — three sweeps.")}
<h3>Ready-made solids</h3>
<p>The bottom of the left toolbar adds a solid with one click:
<b>Cube</b>, <b>Sphere</b>, <b>Cylinder</b> (a different top radius makes
a cone), <b>Capsule</b> (a rod with round ends between two points),
<b>Ellipsoid</b>, <b>Rounded box</b> and <b>Loft</b> (a smooth tube
through a list of cross-sections). In the Main tab a new solid becomes
its own part and the Object tab opens on it; in the Object tab it is
added to the part you are building.</p>
<p><b>Segments</b> sets how many facets make a round shape. The document
default is the <b>Common segments ($fn)</b> box in the Main tab.</p>
<h3>Other ways in</h3>
<ul>
<li><b>Insert &rsaquo; Part Library</b> {K("Ctrl+L")} &mdash;
parametric flanges, fasteners with real threads, valves, glassware,
furniture.</li>
<li><b>File &rsaquo; Import Mesh</b> {K("Ctrl+Shift+I")} &mdash; STL, OBJ,
OFF or 3MF files, or drag the file onto the window. The part arrives as
one Object and the status bar gives its size: an STL has no units, so a
part drawn in inches or metres shows up far too small. Right-click it
&rsaquo; <b>Imported mesh</b> to centre it, stand it on the floor, or
say which unit the file was drawn in; its Properties also turn and scale
it. It works like any other part: snap to its faces, colour it, and
subtract it from a block (the OpenSCAD render cuts it exactly) to make a
holder that fits it. Keep the mesh inside the document's folder and the
.kcad stores it by a relative path, so the folder can be moved or shared
as a whole.</li>
<li><b>File &rsaquo; Import CAD File</b> &mdash; a STEP, IGES, Rhino
(.3dm) or .brep file from Fusion, SolidWorks, Onshape, FreeCAD or Rhino,
or simply open or drop one. It arrives as one Object named after the
file, every part a named group in its own colour, at its real size.
Pick <b>Draft</b> for a big assembly and <b>Fine</b> for a render; Open
and dropping use Normal. Move it as you like: exporting it again writes
the file's own exact surfaces, not the triangles on screen.</li>
<li><b>Insert &rsaquo; OpenSCAD code</b> &mdash; a block of raw OpenSCAD
(e.g. a BOSL2 call) that the engine renders.</li>
</ul>
<h3>3D curves</h3>
<p><b>Insert &rsaquo; Draw 3D Curve</b> {K("Ctrl+Alt+C")} draws a smooth
curve by clicking points in the 3D view &mdash; a cable, a handrail, a
bent rod, the path for a sweep. Each point <b>snaps</b>, and the marker
says to what: a <b>Corner</b>, the <b>Middle of edge</b>, <b>On edge</b>,
<b>On surface</b>, or, in empty space, <b>On the ground grid</b>. Hold
<b>Shift</b> to go straight up or down from the last point, hold
<b>Alt</b> to switch snapping off, or just <b>type</b> a point &mdash;
<i>10, 20, 5</i>, or <i>@0, 0, 15</i> for 15 above the last one &mdash;
and press Enter. <b>Enter</b>, a right-click or a double-click finishes;
<b>Backspace</b> takes a point back; <b>C</b>, or clicking the first
point, closes a loop. Dragging still turns the view between clicks.</p>
<p>The curve is drawn as a round wire; its points, smoothness and wire
thickness are in Properties. Right-click it &rsaquo; <b>Make a Sweep
Along This Curve</b> to give it any profile.</p>
"""),

        ("combine", "Moving and combining", f"""
<h3>Moving, turning, resizing</h3>
<p>Most solids have their own <b>X / Y / Z</b> in Properties, and you can
drag any part in the sketch. The <b>Move &amp; transform</b> group wraps
the selection instead: <b>Translate</b> (move by X/Y/Z), <b>Rotate</b>
(degrees about X, then Y, then Z, around the origin), <b>Scale</b>
(factors; 1 = unchanged) and <b>Mirror</b> (reflect; the original is
not kept).</p>
<p class='tip'><i>Tip:</i> Rotate turns around the origin, so rotate a
part <i>before</i> moving it away, or it will swing round in a big
arc.</p>
<h3>Combining</h3>
<ul>
<li><b>Group (union)</b> {K("Ctrl+G")} &mdash; many objects become one.
{K("Ctrl+Shift+G")} ungroups.</li>
<li><b>Difference</b> &mdash; keeps the <b>first</b> child and cuts every
other child out of it. Order matters: select the body first. In the
tree, drag the rows (or {K("Ctrl+&uarr;")}/{K("Ctrl+&darr;")}) to change
which one is the body.</li>
<li><b>Intersection</b> &mdash; keeps only where all children overlap.</li>
</ul>
<p>Right-click &rsaquo; <b>Apply operation</b> in the tree offers the rest:
<b>Hull</b> (shrink-wrap around the children &mdash; two spheres make a
capsule), <b>Minkowski</b> (sweep one shape around another),
<b>Offset</b> (round or inset 2D corners) and <b>Round edges</b> (a
small Minkowski sphere that fillets a finished solid).</p>
<h3>Rounding edges &mdash; Fillet</h3>
<p><b>Fillet edges</b> (the Finish group) is SolidWorks' Fillet: round
only the edges you choose. Select the solid, click Fillet edges, and the
3D view asks for edges &mdash; <b>click an edge</b> to round it; one
click on a cylinder's rim takes the whole rim, and a click on a
<b>face</b> rounds every edge round that face. {K("Esc")} when you are
done, then set the <b>Radius</b> in Properties; <b>Kind</b> Chamfer cuts
a flat instead of a curve. A convex edge is rounded off and an inside
corner is filled in. The edges are remembered as geometry, so the
fillet survives resizing and moving the part; if an edge disappears
(you cut it away), the fillet turns red and says which. Right-click the
fillet ▸ <b>Pick edges</b> to add more.</p>
{figure("fillet", "Fillet edges: rounded top edges, a chamfered "
        "vertical edge, and a boss rim rounded with one click.")}
<p class='tip'><i>Tip:</i> an edge only exists where one shape has it.
Two overlapping boxes have no inside-corner edge until they are one
solid, so for an inside corner draw the L as one profile and extrude
it. And like any cut, the rounding shows in the exact OpenSCAD render
(a moment after each change, or {K("F5")}); <b>Round edges</b>
(right-click ▸ Apply operation) is the older tool that rounds every
edge of a part by the same amount.</p>
<p class='tip'><i>Why is my hole not cut?</i> The instant built-in
preview draws a Difference as its first child only. The OpenSCAD engine
cuts it for real a moment later (the badge reads <i>OpenSCAD</i> or
<i>n/n parts exact</i>); press {K("F5")} to render right away.</p>
"""),

        ("tree", "Working with the object tree", f"""
<p>The tree <i>is</i> the model: one row per step, children indented
under the operation that wraps them.</p>
<table>
<tr><td>Select</td><td>click; Ctrl-click adds; {K("Tab")} /
{K("Shift+Tab")} (or {K("A")} / {K("Q")}) step to the next / previous
object</td></tr>
<tr><td>Hide / show</td><td>{K("Space")} or right-click &rsaquo; Hide. Hidden
rows turn grey and italic, and everything under them is dimmed.</td></tr>
<tr><td>Rename</td><td>right-click &rsaquo; Rename</td></tr>
<tr><td>Reorder / move</td><td>drag and drop; {K("Ctrl+&uarr;")} /
{K("Ctrl+&darr;")} within the parent</td></tr>
<tr><td>Copy &amp; paste</td><td>{K("Ctrl+C")} {K("Ctrl+X")}
{K("Ctrl+V")} &mdash; works between two KherveCAD windows too</td></tr>
<tr><td>Duplicate / delete</td><td>{K("Ctrl+D")} / {K("Delete")}</td></tr>
<tr><td>Colour</td><td>right-click &rsaquo; Colour&hellip;</td></tr>
</table>
<p>The right-click menu also has <b>Apply operation</b>, <b>Group /
Ungroup</b>, <b>Make Object</b>, <b>Make Master</b> and, on a part,
<b>Edit in Object tab</b> (or double-click it), <b>Anchors</b> and
<b>Attach / Detach</b>.</p>
<p>A placed part shows extra grey <b>Position</b>, <b>Rotation</b> and
<b>Color</b> rows under it: they mirror where the part has been placed
(by dragging, snapping or typing) and cannot be edited themselves &mdash;
click them to select the part.</p>
<h3>Names that say what things are</h3>
<p>A tree of ten rows all called <i>Cube</i> is hard to read. Rename
rows as you go, in the form <b>Cube [Body]</b>: the part in brackets is
a label, and it is also written into the program as a comment, so it
survives saving as .scad and importing again. It works the other way
too &mdash; when an assistant (or you) writes OpenSCAD with a comment at
the end of a line, the comment becomes the label:</p>
<pre>color("pink") cube(body, center=true);  // Body
for (px = [-1, 1]) for (py = [-1, 1])  // Legs</pre>
{figure("named_rows", "Rows named from the comments in the code: Cube "
        "[Body], Cube [Head], For px [Legs]&hellip;", 430)}
<h3>Red means broken</h3>
<p>A row that cannot work &mdash; a bad expression, an empty extrude, a 3D
solid inside an extrude, a revolve crossing its axis &mdash; turns
<b>red</b>. Hover it for the reason; its lines are red in the Code tab
too. OpenSCAD's own errors are mapped back to the rows that caused
them.</p>
"""),

        ("logic", "Variables, expressions and logic", f"""
<h3>Variables</h3>
<p>Give important sizes a name in the <b>Variables</b> tab &mdash;
<i>w = 60</i>, <i>wall = 2</i> &mdash; and use the name in any field:
Width <code>w</code>, inner width <code>w - 2 * wall</code>. Change the
variable and everything that uses it follows. The <b>Scope</b> box
switches between document-wide variables and those of the Object being
edited.</p>
<h3>Expressions</h3>
<p>Any number field takes an expression: <code>+ - * / % ^</code>,
comparisons, <code>a ? b : c</code>, and <code>sin cos tan sqrt abs
min max round floor ceil pow</code>&hellip; (angles in degrees).
Vectors work too: <code>size.x</code>, <code>pts[2]</code>.</p>
<h3>Repeating and choosing</h3>
<ul>
<li><b>For loop</b> repeats its contents. The variable runs
<i>From</i> &rarr; <i>To</i> by <i>Step</i>, or through a list of
<i>Values</i>. Use it in the contents: X = <code>i * 20</code> makes a
row, Rotate Z = <code>i * 60</code> a ring. A loop inside a loop makes
a grid.</li>
<li><b>While loop</b> repeats while a condition holds, updating its
variable each time (e.g. start 1, condition <code>x &lt; 100</code>,
update <code>x * 2</code>).</li>
<li><b>If / else</b> shows its contents only when the condition is true,
and its <i>Else</i> row otherwise &mdash; switch features on and off
with a variable, or alternate parts inside a loop with <code>i % 2 ==
0</code>.</li>
<li><b>Pattern</b> repeats its contents as copies without a loop
variable &mdash; Blender's Array modifier, SolidWorks' linear and
circular patterns. <i>Linear</i> places <i>Count</i> copies at
<i>Step X/Y/Z</i> (a row of holes; set Step Z too for a straight
stair). <i>Polar</i> turns them about the <i>Axis</i>: with
<i>Angle</i> 360 the copies are spread evenly round the circle
(<code>360 &middot; i / count</code> &mdash; a bolt circle); below 360
they <b>span</b> the angle, the first at 0&deg; and the last at
<i>Angle</i> (<code>angle &middot; i / (count &minus; 1)</code> &mdash;
five ribs over 90&deg;); <i>Rise per copy</i> lifts each copy along the
axis, so a spring or a spiral stair is one pattern. <i>Grid</i> makes
<i>Count X &times; Y &times; Z</i> copies at the step. Every field takes
an expression. In the program it is one
<code>kcad_pattern(&hellip;) {{ &hellip; }}</code> call.</li>
<li><b>Sheet metal part</b> (Insert menu) is a plate with a bent
<b>flange</b> on any of its four edges: give each edge a length and a
bend angle (negative bends down), plus the sheet's thickness, inside
bend radius and <b>K-factor</b>. Right-click it &rsaquo; <b>Unfold</b>
lays the <b>flat pattern</b> out beside it &mdash; the blank with the
bend allowance <code>(r + K&middot;t)&middot;&theta;</code> in each bend
and the bend lines marked, and the status bar gives the blank size
&mdash; and <b>Export flat pattern DXF</b> writes it (CUT and BEND
layers) for a laser cutter or a press brake. One bend per edge; a box,
a tray, a bracket, a channel or a U comes straight out of it.</li>
</ul>
{figure("pattern", "One pattern each: a polar bolt circle, a spiral "
        "stair (polar with a rise), a straight stair and a peg grid.")}
<p>With objects selected, these wrap them; with nothing selected they
add an empty node to drag objects into. The <b>Library &rsaquo;
Learn</b> menu has a numbered tutorial for each.</p>
"""),

        ("assemblies", "Parts and assemblies", f"""
<p>KherveCAD separates <b>building a part</b> from <b>arranging
parts</b>, like SolidWorks or Onshape:</p>
<ul>
<li>An <b>Object</b> is a part definition, built in the <b>Object
tab</b>. It becomes its own OpenSCAD <code>module</code>.</li>
<li>The <b>Main tab</b> is the assembly: <b>instances</b> of Objects,
each with its own position, rotation and colour. One Object can be
placed many times &mdash; edit it once and every copy changes.</li>
</ul>
<h3>Making and placing parts</h3>
<ul>
<li><b>Insert &rsaquo; New Object</b> {K("Ctrl+Alt+N")}, or the
<b>New</b> icon (a plus in a box) in the Object tab, starts an empty
part.</li>
<li>The Object tab's icons, left to right: <b>New</b>, <b>Rename</b>
(pencil), <b>Delete</b> (bin &mdash; the Object and every instance of
it in Main go together, and {K("Ctrl+Z")} brings them back) and
<b>To Main</b>. Hover over one for its name.</li>
<li>The Object list holds <b>every</b> Object in the document, nested
ones included &mdash; an imported program's <code>module</code>s are
Objects even when a colour wraps them.</li>
<li>Right-click objects &rsaquo; <b>Make Object</b> turns them into a
part.</li>
<li><b>To Main</b> (the package icon) in the Object tab, or
right-click in Main &rsaquo; Insert Object, places another
instance.</li>
<li>Drag a part's outline in the sketch to move it on the chosen plane,
or type its X/Y/Z and angles in Properties.</li>
</ul>
<h3>Snapping parts together</h3>
<p>The <b>Snap objects</b> tool {K("J")} joins two parts face to face,
like a joint in Fusion 360:</p>
<ol>
<li>Press {K("J")} (or the magnet in the main toolbar). A banner across
the 3D view tells you what to click.</li>
<li>Click the face or edge of the part you want to <b>move</b>. The
face under the cursor lights up first, named after the anchor it will
use; the one you click stays orange.</li>
<li>Click the face on the part it should sit against. The part jumps
into place.</li>
<li>A small window opens to fine-tune: <b>Offset</b> (a gap in mm),
<b>Spin</b> (turn about the joint), <b>Flip 180&deg;</b> and
<b>Detach</b>.</li>
</ol>
<p>{K("Esc")} (or a right-click) cancels. A snap is <b>live</b>: move the
base part and everything attached follows. Dragging an attached part, or
typing its position, detaches it (the status bar says so).</p>
<h3>Anchors and the Attach dialog</h3>
<p>Every part has automatic <b>anchors</b> &mdash; its origin, the centres
of its six faces, twelve edge midpoints and eight corners &mdash; drawn as
coloured markers when the part is selected. Right-click a part &rsaquo;
<b>Anchors</b> to add your own by clicking the model, to <b>set the
origin</b> to any anchor, or to remove one. Right-click &rsaquo;
<b>Attach&hellip;</b> opens the Attach dialog, where you choose the two
anchors by name; every change previews live and Cancel puts everything
back. Beyond the plain face-to-face mate it offers the mates other CAD
programs have: <b>Flush</b> (both faces the same way), <b>Concentric</b>
(the part sits on the other's axis and slides along it &mdash; dragging
it in the sketch view moves the slide instead of breaking the mate),
<b>Angle</b> (a hinge: the part turned by an angle about the anchor's
edge), a <b>gear ratio</b> (the part's spin follows the parent's spin
times the ratio, reversed) and an <b>offset range</b> (a limit mate:
the offset or slide never leaves it).</p>
{figure("dialog_attach", "The Attach dialog: which anchor of this part "
        "meets which anchor of the other.", 450)}
<p>Inside the Object tab the same tools snap the <b>groups that make up
one part</b> to each other, so a part can itself be assembled from
pieces.</p>
"""),

        ("masters", "Linked copies", """
<p>To use one piece many times, make it an <b>Object</b> and place
<b>Linked copies</b> of it, each with its own position and colour. Edit
the Object and every copy changes &mdash; the classic example is one
bolt copied round a bolt circle.</p>
<ol>
<li>Right-click an object &rsaquo; <b>Make Object</b>, then in Main
right-click &rsaquo; <b>Insert Object</b> for each copy (or <b>To
Main</b> in the Object tab).</li>
<li>Or right-click anything &rsaquo; <b>Linked copy</b>: a copy that
follows the original. Put one copy in a For loop to place many.</li>
</ol>
<p>Older documents with a <b>Masters</b> tab open with each master
turned into an Object and its copies unchanged. Library &rsaquo; Learn
OpenSCAD &rsaquo; 21 and Mechanical &rsaquo; Bolt circle show both.</p>
"""),

        ("collections", "Collections", """
<p>A <b>collection</b> is a named set of parts you show, hide or lock
together &mdash; <i>Walls</i>, <i>Roof</i>, <i>Furniture</i> in a house,
<i>Moving parts</i> in a mechanism &mdash; whatever the tree looks like.
It works like Blender's collections.</p>
<ol>
<li>In Main, select parts, right-click &rsaquo; <b>Move to Collection</b>
&rsaquo; <b>New collection&hellip;</b> (or an existing one).</li>
<li>Open the <b>Collections</b> tab. Click the <b>eye</b> to hide or show
a collection; <b>Ctrl+click</b> it to show that collection alone (again
to show everything). Click the <b>padlock</b> so its parts cannot be
picked or dragged by accident in the 2D view.</li>
<li>Drag parts from one collection to another, double-click a name to
rename it, right-click for the rest. Deleting a collection keeps its
parts.</li>
</ol>
<p>Hiding a collection only changes what the views show: the parts stay
in the design, in the program and in every export. To leave a part out
of the model itself, hide the part (Space in the tree).</p>
"""),

        ("colour", "Colour and materials", """
<p>Right-click an object &rsaquo; <b>Colour&hellip;</b>, or use the colour
field in Properties. A colour is an ordinary row in the tree (OpenSCAD's
<code>color()</code>) with an <b>opacity</b> and a <b>material</b>:
Plastic, Metal, Matte, Clay, Glass, Rubber, Skin, Gold, Copper or
Emissive (<i>Default</i> follows the 3D render style). Glass is
see-through.</p>
<p>In the Main tab, colour an instance directly: each copy of a part
can have its own colour. Colours and materials are saved with the
document and exported in the .scad program; the exact OpenSCAD render
of each part is tinted with its colour.</p>
"""),

        ("character", "Characters and organic shapes", f"""
<p>For animals, figures, plants and anything soft, KherveCAD has
shapes and operations that go beyond boxes and cylinders.</p>
<h3>Soft solids</h3>
<p><b>Capsule</b> (limbs, fingers), <b>Ellipsoid</b> (heads, bodies,
eggs), <b>Rounded box</b> (soft blocks) and <b>Loft</b> (tails, necks,
horns: a tube through a list of rings).</p>
<h3>The Character group</h3>
<ul>
<li><b>Symmetry</b> &mdash; keeps its contents and their mirror image:
model the left arm and the right one appears, and follows every
edit.</li>
<li><b>Joint</b> &mdash; rotates its contents about a pivot, like an
elbow. Put the pivot on the hinge, then bend. Joints nest, so a tree of
them is a skeleton you can pose.</li>
</ul>
<h3>The Deform &amp; sculpt group</h3>
<ul>
<li><b>Smooth blend</b> &mdash; melts the shapes inside together like
clay, with smooth fillets where they meet. <i>Blend radius</i> is how
far the melting reaches.</li>
<li><b>Bend</b>, <b>Twist</b>, <b>Taper</b> &mdash; curve, wring or
narrow the contents along an axis.</li>
<li><b>Lattice</b> &mdash; move the eight corners of the bounding box and
the shape follows smoothly.</li>
<li><b>Subdivide</b> &mdash; smooths a blocky shape.</li>
<li><b>Shell</b> &mdash; hollows a solid into a shell of even wall
thickness (Blender's Solidify): set the <b>Wall thickness</b>, and
<b>Open side</b> top / bottom / &plusmn;x / &plusmn;y to leave one side
open &mdash; a cylinder with <i>open = top</i> is a cup. A wall too thick
for the part leaves no room and turns the shell red. Library &rsaquo;
Mechanical &rsaquo; <i>Hollow cup</i>.</li>
</ul>
{figure("shell", "Shell: a cylinder hollowed to a 2 mm cup, open at "
        "the top.")}
<table><tr>
<td>{figure("character_tulip", "Flowers &rsaquo; Tulip", 360)}</td>
<td>{figure("character_oak", "Trees &rsaquo; Oak", 360)}</td>
</tr></table>
<p><b>Library &#9656; Nature &amp; garden</b> has a garden of flowers and
trees built this way &mdash; insert one and look at its tree to see how.</p>
"""),

        ("view3d", "The 3D view", f"""
<table>
<tr><td>Orbit</td><td>left-drag</td></tr>
<tr><td>Pan</td><td>right-drag or middle-drag</td></tr>
<tr><td>Zoom</td><td>mouse wheel</td></tr>
<tr><td>Frame everything</td><td>double-click, {K("Ctrl+F")} or the Fit
3D button</td></tr>
<tr><td>Buttons</td><td>the bar in the top-right corner: turn left /
right, pan, zoom in / out (hold to repeat), <b>Focus</b> on the selected
part, <b>Fit all</b></td></tr>
<tr><td>Standard views</td><td>View &rsaquo; 3D Camera: Isometric, Top,
Bottom, Front, Back, Left, Right</td></tr>
</table>
<p><b>View &rsaquo; 3D Render Style</b> changes the look (Shaded, Matte,
Clay, Toon, Brushed metal, Gold, Copper, Wireframe, X-ray);
<b>3D Background</b> and <b>3D Projection</b> (perspective or
orthographic) are next to it. The floating bar sets brightness and
contrast. None of these change the model.</p>
{figure("render_styles", "Four of the render styles.")}
<h3>Platform and shadow</h3>
<p><b>View &rsaquo; 3D Platform &amp; Shadow</b> (or the platform button on
the 3D view's bar) stands the model on a round platform and casts a
soft shadow from a light far away at the top left, the way a product
photo is lit. The light follows the camera, so the shadow always falls
towards the bottom right as you turn the model. It is a look only
&mdash; nothing is added to the model or the exported files &mdash; and
it is remembered between sessions (it is on until you switch it off).
Exported pictures (File &rsaquo; Export PNG) include it.</p>
{figure("stage", "The platform and its shadow.")}
<h3>Cavity shading and edge lines</h3>
<p>Two looks borrowed from Blender's solid view, both under the
<b>View</b> menu: <b>3D Hardware Rendering (OpenGL)</b> (on by default)
draws the model with the graphics card &mdash; exact occlusion however
big the model, anti-aliased, and it orbits smoothly; switch it off to
use the built-in painter, which is also what Wireframe and X-ray use.
<b>3D Cavity Shading</b> darkens valleys and lightens
ridges so the shape reads at a glance, and <b>3D Edge Lines</b> (on by
default) draws the model's real edges and its outline as thin lines
&mdash; a cylinder shows its two rims, not its facets. Both are looks
only and are remembered between sessions; exported pictures include
them.</p>
<p><b>3D Scale Bar</b> (on by default) puts a round length &mdash; 1, 2
or 5 times a power of ten &mdash; in the bottom-left corner of the 3D
view, in the document's unit (Edit &#9656; Document Units), and redraws
it as you zoom. A perspective picture has no single scale, so the bar is
true at the point the camera orbits around; switch to orthographic and
it is true everywhere.</p>
{figure("cavity_edges", "The same part plain (left) and with cavity "
        "shading and edge lines (right).")}
<h3>Preview and exact render</h3>
<p>Every change redraws instantly with the <b>built-in preview</b>. If
OpenSCAD is installed (it is included with the installer), an
<b>exact</b> render follows a moment later, one part at a time &mdash;
the badge counts <i>n/m parts exact</i>. Holes are only really cut in
the exact render. {K("F5")} renders immediately.</p>
<p>The preview draws in an exact back-to-front order that completes a
moment after each change, by itself. If the view ever looks stale,
<b>Redraw</b> (&#x27F3; on the lighting bar) rebuilds it from the tree.</p>
"""),

        ("library", "Part Library and Examples", f"""
<h3>Part Library</h3>
<p><b>Insert &rsaquo; Part Library</b> {K("Ctrl+L")} opens a catalogue of
parametric parts: CF and KF vacuum flanges, fittings, valves, pumps,
gauges, chambers and manipulators, all in stainless steel; bolts, screws
and nuts from M3 to M20 with real threads; laboratory glassware;
furniture; <b>Home furniture</b> for every room of a house (dining table
and chairs, sofa, bed, wardrobe, chest of drawers, a kitchen with sink,
hob and oven, toilet, washbasin, bath and shower) in a choice of woods,
fabrics and colours; Lego bricks and sets; <b>Playing cards</b>, one card
at a time (pick the suit, then the rank as the size); <b>Pots</b> in
several colours; and ready-made models in <b>Brackets</b>, <b>Cars</b>,
<b>Minecraft</b> and <b>Tools</b>. Pick a category, a part and a standard size, adjust
any dimension, then <b>Insert</b>. The window stays open while you work.
Each part arrives as one Object; its construction is in the Object
tab.</p>
{figure("dialog_library", "The Part Library.", 560)}
<p>The <b>Library</b> menu inserts the same parts at their default size
in one click.</p>
<h3>Examples</h3>
<p>Ready-made example models are in the <b>Library</b> menu too, each in
a submenu marked <i>Opens as a document, in place of yours</i>: the
LEARN section at the bottom holds <b>Learn OpenSCAD, step by step</b>
(21 numbered tutorials, from a single cube to masters), <b>Course
projects</b> and <b>Showcase models</b> (among them a fully assembled
Ferrari 288 GTO); Engineering has <b>Mechanical examples</b> (brackets,
gears, bearings, pulleys, a bolted flange) and a vacuum starter under
Vacuum &amp; UHV; House &amp; home ends with a desk setup. Open one and
click through its tree to see how it is made. You are asked before
unsaved work is replaced.</p>
<h3>Mechanisms &amp; motion</h3>
<p><b>Library &#9656; Mechanisms &amp; motion</b> adds working mechanisms
to your design &mdash; a motor and gear pair, crank and piston, rack and
pinion, cam and follower, four-bar linkage, planetary gearset, an XY
moving platform, a scissor lift and a robot arm. Each lands beside what
is already there with its own sliders in the <b>Customizer</b> panel
(View &#9656; Customizer): drag one, or press &#9654; beside it, and the
mechanism moves. Insert several and each keeps its own variables
(<code>crank_angle</code>, <code>crank2_angle</code>&hellip;).</p>
"""),

        ("crystals", "Crystals and nanoparticles", """
<p><b>Library &#9656; Crystal Builder&hellip;</b> builds real crystal
structures from a library of 32 standard ones &mdash; metals (copper,
gold, iron, titanium&hellip;), semiconductors (silicon, GaAs, GaN),
salts, oxides (rutile, anatase, perovskite, &alpha;-quartz) and carbon
(diamond, graphite, h-BN). Each entry holds its lattice and every atom
of its unit cell, checked against its published density and bond
lengths.</p>
<p>A crystal is built in three levels, each its own Object:</p>
<table>
<tr><td><b>Unit cell</b></td><td>the lattice box, every atom at its
covalent radius and, for compounds, the coordination polyhedra
(SiO<sub>4</sub> tetrahedra in quartz, TiO<sub>6</sub> octahedra in
rutile) drawn over the atoms.</td></tr>
<tr><td><b>Supercell</b></td><td>a block of unit cells repeated by
<i>for</i> loops.</td></tr>
<tr><td><b>Particle</b></td><td>a sphere, hemisphere, cube, box,
cylinder, hexagonal prism or octahedron filled with every cell whose
centre lies inside &mdash; or, for big particles, with blocks of
N&times;N&times;N cells. A sphere's columns are stacked by a
<i>while</i> loop.</td></tr>
<tr><td><b>Scatter</b></td><td>several particles spread over an area,
never touching, each resting on the surface (a half sphere flat on it)
and turned at random &mdash; a dispersion on a substrate. The particle
is built once and repeated, so twenty cost little more than one, and
the seed brings the same arrangement back.</td></tr>
</table>
<p>The panel counts the build as you change it &mdash; cells, atoms,
polyhedra and the triangles the 3D view will draw &mdash; and will not
build what would freeze the view: a 10&nbsp;nm particle already holds
tens of thousands of atoms. Draw the cells as <b>polyhedra</b> (about
ten times lighter than atoms) or let <b>Automatic</b> switch to
blocks.</p>
<p>Crystals are built in <b>nanometres</b>: an empty document switches
to nm (Edit &#9656; Document Units). The radius, block size and gap
become variables named after the crystal &mdash; <tt>quartz_r</tt>,
<tt>quartz_N</tt> &mdash; so the <b>Variables</b> tab reshapes the build
afterwards. An assistant connected over MCP uses the same builder
(<tt>list_crystals</tt>, <tt>build_crystal</tt>).</p>
<p>Every crystal is also ready-made in the <b>Library</b> menu and the
Part Library: <b>Crystals (unit cells)</b> and <b>Crystals
(supercells)</b>, 2&times;2&times;2 to 6&times;6&times;6 cells, one
click each.</p>
"""),

        ("molecules", "Molecules and reactions", """
<p><b>Library &#9656; Compound Builder&hellip;</b> builds molecules in 3D
and writes chemical reactions with them.</p>
<p>On the <b>Molecule</b> tab pick a compound from the library &mdash;
about 80, from water and CO<sub>2</sub> through acids, ions, solvents
and hydrocarbons to glucose, caffeine and aspirin &mdash; or type any
molecule as <b>SMILES</b>, the line notation chemists use (ethanol is
<tt>CCO</tt>, phenol <tt>c1ccccc1O</tt>, the ammonium ion
<tt>[NH4+]</tt>). Every atom gets the shape its bonds and lone pairs
give it &mdash; water bent at 104.5&deg;, methane tetrahedral,
XeF<sub>4</sub> square &mdash; and rings come out as rings: benzene
flat, cyclohexane puckered. Draw it <b>ball and stick</b> (each half of
a bond in its atom's colour, double and triple bonds as parallel
sticks), <b>space filling</b> or as <b>sticks</b>.</p>
<p>On the <b>Reaction</b> tab write the equation as you would on paper:
<tt>2 H2 + O2 -&gt; 2 H2O</tt>, <tt>N2 + 3 H2 &lt;=&gt; 2 NH3</tt>. Leave
the numbers out and <b>Balance it</b> finds them; the panel always
shows whether the atoms and charges balance before you build. The
reaction is laid out left to right with its coefficients, plus signs,
arrow and the formula under each molecule. Species are names or
formulas from the library (<tt>ethanol</tt>, <tt>H2O</tt>,
<tt>SO4^2-</tt>) or <tt>smiles:</tt>&hellip; for anything else.</p>
<p>Molecules are built in <b>nanometres</b>, and every library compound
is also ready-made in the <b>Library</b> menu (<b>Molecules: </b>&hellip;
families). An assistant connected over MCP uses the same builder
(<tt>list_molecules</tt>, <tt>build_molecule</tt>,
<tt>build_reaction</tt>).</p>
"""),

        ("code", "OpenSCAD code", f"""
<p>The <b>Code</b> tab shows the OpenSCAD program written from the tree.
Selecting an object highlights its lines; broken objects are tinted
red.</p>
{figure("tab_code", "The Code tab for the plate-with-a-hole part.", 430)}
<ul>
<li><b>Edit and apply</b>: change the text and press <b>Apply code</b>
&mdash; it is read back into real, editable objects.</li>
<li><b>Scope</b>: <i>Whole program</i> or <i>Active object</i> (just the
part open in the Object tab).</li>
<li>The toolbar has undo/redo, cut/copy/paste and indent; {K("Tab")} /
{K("Shift+Tab")} indent and dedent the selected lines.</li>
</ul>
<h3>Import and export</h3>
<ul>
<li><b>File &rsaquo; Export OpenSCAD</b> {K("Ctrl+E")} writes a standalone
.scad file; <b>Import OpenSCAD</b> {K("Ctrl+I")} (or opening a .scad
file) reads one back as objects. Export &rarr; import &rarr; export gives
the same program.</li>
<li>A call KherveCAD cannot turn into objects is kept as an
<b>OpenSCAD code</b> row with exactly what was written: the engine
renders it, and nothing is lost when you export again. A whole file can
also be loaded as a single raw block.</li>
<li>A comment at the end of a line names that object in the tree:
<code>cube(10);  // Lid</code> becomes <b>Cube [Lid]</b>.</li>
<li><b>File &rsaquo; Import 2D Drawing</b> reads SVG and DXF outlines
(<code>import()</code>), <b>Import Height Map</b> a .dat matrix or a
picture (<code>surface()</code>); .csg and .amf files open too.</li>
</ul>
<h3>The OpenSCAD language, as objects</h3>
<p>Every statement of OpenSCAD has a row in the tree and writes back the
same code: <b>resize</b>, <b>multmatrix</b>, <b>render</b>,
<b>intersection_for</b>, <b>let</b>, <b>echo</b> and <b>assert</b> (a
false assert turns red with its message), modules with
<code>children()</code>, vector maths, strings and function literals.
Expressions over variables stay expressions, so an imported program is
still parametric. Right-click &rsaquo; <b>Debug modifier</b> sets
<code>#</code> (highlight), <code>%</code> (background) or <code>!</code>
(show only).</p>
<h3>Libraries</h3>
<p><b>Library &rsaquo; OpenSCAD Libraries</b> installs BOSL2, MCAD,
NopSCADlib, Round-Anything, dotSCAD, threads.scad, Catch'n'Hole and
Gridfinity into your OpenSCAD library folder. A program that starts with
<code>include &lt;BOSL2/std.scad&gt;</code> then opens here: library calls
become objects where they can and stay OpenSCAD code where they
cannot.</p>
<h3>Customizer</h3>
<p>Comments in OpenSCAD's Customizer style turn variables into controls
in the <b>Variables</b> tab:</p>
<pre>/* [Size] */
// Box width in mm
width = 40;   // [10:5:200]
lid = "snap"; // [snap, screw, none]</pre>
<p>gives a slider and a drop-down in the <i>Adjust</i> column, grouped
and described; the comments are written back when you export.</p>
<h3>Animation</h3>
<p><b>View &rsaquo; Animate</b> plays a model that reads <code>$t</code>
(0 to 1) &mdash; <code>rotate([0, 0, 360 * $t])</code> &mdash; and
exports its frames as pictures.</p>
"""),

        ("features", "Gears, threads, holes and printing", f"""
<p>The parts of OpenSCAD's best-known libraries are objects in
KherveCAD, each with its settings in Properties and a real OpenSCAD
module behind it:</p>
<ul>
<li><b>Insert &rsaquo; Mechanical features</b>: involute <b>gears</b>
(spur, helical, herringbone, internal, rack, bevel, worm), <b>threads</b>
(metric, trapezoidal, square, buttress, pipe, bottle &mdash; or the tap
that cuts a nut), <b>holes</b> (counterbore, countersink, nut trap,
heat-set insert, slot, teardrop), knurls and textured surfaces.</li>
<li><b>Insert &rsaquo; Shapes &amp; patterns</b>: regular polyhedra,
stars, polygons with a radius per corner, B&eacute;zier and SVG-path
shapes, honeycomb panels.</li>
<li><b>Library &rsaquo; 3D printing</b>: dovetails, snap-fits,
print-in-place and living hinges, insert bosses, a threaded bottle cap,
cable clips, Gridfinity bins and baseplates, divided trays, an
electronics enclosure. <b>Motion &amp; electronics</b>: NEMA motors,
T-slot extrusions, rails, GT2 pulleys, bearings, fans, Raspberry Pi and
Arduino boards. Also Lego Technic and generative panels.</li>
<li>Right-click a part &rsaquo; <b>Split for printing</b> cuts one too big
for the bed into two, with dowel holes and a pin.</li>
</ul>
<p>Two gears mesh when they share the module and pressure angle and
their centres are m &times; (z<sub>1</sub> + z<sub>2</sub>) / 2 apart.
For a nut, put an <i>internal</i> thread inside a Difference with the
nut's body.</p>
"""),

        ("ai", "Assistants: Claude and the ChatBox", f"""
<h3>Connect to Claude (no API key)</h3>
<p><b>AI &rsaquo; Connect to Claude (Simple)&hellip;</b> lets Claude
Desktop, Claude Code, Cursor, Cline, VS Code or LM Studio build directly
in the open document, using the account you already have.</p>
<ol>
<li>Tick <b>Let assistants connect to this document</b>.</li>
<li>Leave <b>The assistant may</b> on <b>Full</b> (recommended), so it
can also open and export the files you mention. <i>Edit</i> keeps it
inside the open document; <i>Read only</i> lets it only look.</li>
<li>Under <b>Connect an application</b>, pick yours and press
<b>Connect</b>; restart that application.</li>
<li>In its chat, <b>mention KherveCAD</b>: <i>&ldquo;in KherveCAD, build
a 40 mm bracket with two M6 holes&rdquo;</i>.</li>
</ol>
<p>The assistant works with real objects: it reads and edits the tree,
writes OpenSCAD that arrives as editable rows (labelled, e.g. <b>Cube
[Body]</b>), inserts library parts, assembles Objects and looks at the 3D
view to check its work. Each of its steps is one {K("Ctrl+Z")}. The
connection stays on this computer.</p>
<p>The assistant labels every piece it builds (<b>Cube [Front-left
leg]</b>, <b>Sphere [Left eye]</b>), and when it makes a part an
<b>Object</b> or a <b>Master</b> it tells you what it made, why, and in
which tab to find it.</p>
<h3>Vibe Model</h3>
<p>Building by conversation? Click <b>Vibe Model</b> at the right end
of the main toolbar ({K("Ctrl+Shift+M")}, or View &rsaquo; Vibe Model):
the tree, Properties, the 2D sketch and the drawing tools fold away, the
toolbar keeps only New, Open, Save, Undo and Redo, and the 3D model
fills the window, so you can describe the part and watch it build. Click
again to bring everything back and edit by hand. The name
borrows from <i>vibe coding</i> &mdash; building software by describing
it to an AI.</p>
{figure("vibe_model", "Vibe Model: only the 3D view, with its "
        "navigation bar; the toggle is lit at the end of the toolbar.")}
<h3>The ChatBox</h3>
<p><b>AI &rsaquo; ChatBox</b> {K("Ctrl+/")} docks a
chat on the right that works with your own <b>Claude, Mistral or
Ollama</b> API key (the gear button). Describe a part, or paste a
picture of one; the reply is applied to the document &mdash; inside the
part you are editing when the Object tab is open. Type <b>/help</b> for
its commands.</p>
{figure("chat_panel", "The ChatBox.", 270)}
"""),

        ("files", "Files, Git and publishing", f"""
<ul>
<li><b>.kcad</b> is KherveCAD's own format: every object, colour,
variable, part and snap. Save {K("Ctrl+S")}, Save As
{K("Ctrl+Shift+S")}, Open {K("Ctrl+O")}, Open Recent.</li>
<li><b>Open</b> also accepts .scad programs, meshes (.stl, .obj, .off,
.3mf) and CAD files (.step, .iges, .3dm, .brep); so does dragging a file
onto the window.</li>
<li><b>Export STL</b> {K("Ctrl+Shift+E")} for 3D printing (exact when
OpenSCAD is installed); <b>Export OpenSCAD</b> {K("Ctrl+E")}.</li>
<li><b>Export for Other CAD</b> {K("Ctrl+Alt+S")} writes <b>STEP</b>
(Fusion, SolidWorks, Onshape, FreeCAD, Rhino), <b>IGES</b> or a Rhino
<b>.3dm</b>. In STEP and IGES the surfaces are <b>exact</b> wherever the
model has an exact form &mdash; boxes, spheres, cylinders and cones,
extrusions, revolves, booleans, loops, 3D curves and imported STEP parts
&mdash; so a hole opens in the other program as a real cylinder. Each
part keeps its name and colour, and the file is always in real
millimetres. Shapes with no exact form (a blend, a sculpt, a gear) go in
as faceted solids, and the message after saving names them. The .3dm is
meshes, one named layer per part; for editable surfaces in Rhino send
STEP. These formats need <i>cadquery-ocp</i> (and <i>rhino3dm</i> for
.3dm); if one is missing the message says what to install.</li>
<li><b>Export PNG</b> {K("Ctrl+Alt+E")} saves a picture of the 3D view in
its colours, style and lighting: the <b>current view</b> exactly as the
camera shows it, or <b>all standard views</b> (the isometric from all
four corners, three-quarter front, bird's-eye, low angle and underside),
one file each. Pick a
size up to 4K, and tick <b>Transparent background</b> to drop the picture
onto a slide or a web page. Your own camera never moves.</li>
<li><b>Blueprint</b> {K("Ctrl+Shift+D")} (also on the toolbar) opens
the 2D engineering drawing of the model in its own window. The first
time, it lays the sheet out by itself: third-angle <b>Front, Top and
Right</b> views and an isometric at the largest standard scale that
fits, the overall sizes, every hole's diameter (<i>3&times; &Oslash;6</i>)
with its centre mark, and a <b>title block</b> already filled in &mdash;
title, drawing number, material, the <b>mass</b> worked out from the
volume and the material's density, scale, sheet, date and who drew it.
<ul>
<li>Drag views to arrange them (Top and Right stay aligned to Front);
drag a dimension or a note by its label.</li>
<li>The tools down the left: <b>Smart dimension</b> {K("D")} (click a
round edge for &Oslash; or R, a straight edge for its length, or two
points &mdash; then place it), horizontal, vertical, aligned, diameter,
radius and angle dimensions; <b>notes</b> with leaders, text,
<b>balloons</b>, centre marks and lines, <b>surface finish</b>,
<b>datums</b> and <b>geometric tolerances</b>; lines, rectangles and
circles; and <b>detail views</b> (an area enlarged 2:1). Clicks snap to
corners, midpoints, centres and edges.</li>
<li>Across the top: Insert a projected view, a hatched <b>section</b>
(its cutting line drawn on the view it cuts), a shaded picture of the
model or the <b>parts list</b>; sheet size A4&ndash;A0, Letter or
Tabloid; the scale; <b>white paper or blueprint blue</b>; hidden lines;
auto-dimension; auto-arrange.</li>
<li>Select anything to edit it in <b>Properties</b> &mdash; a
dimension's text, prefix and &plusmn; tolerance; double-click the title
block to fill it in.</li>
<li><b>Export PDF</b>, <b>DXF</b> (layered, with real HIDDEN and CENTER
linetypes, in sheet millimetres), <b>SVG</b> or <b>PNG</b>, or
<b>Print</b>.</li>
</ul>
The sheet is saved in the .kcad. After changing the part, <b>Update
from model</b> {K("F5")} re-projects every view and keeps your
annotations. Turn <i>Hidden lines</i> off for threaded or very detailed
parts.</li>
<li><b>File &rsaquo; Show in File Explorer</b> opens the document's
folder; <b>New Window</b> {K("Ctrl+Shift+N")} opens a second document.</li>
<li><b>View &rsaquo; Add Reference Image&hellip;</b> puts a photo or
drawing on the sketch plane to trace over; it shows in both views.</li>
</ul>
<h3>Git</h3>
<p>The <b>Git</b> menu versions the folder holding your document:
<b>Commit</b> {K("Ctrl+K")} saves a snapshot with a message,
<b>Push</b> / <b>Pull</b> sync with GitHub or GitLab, and <b>Connect to
GitHub / GitLab</b> sets up the remote.</p>
<h3>Publishing to Printables</h3>
<p><b>File &rsaquo; Publish to Printables&hellip;</b>
{K("Ctrl+Shift+P")} prepares everything for an upload: STL and 3MF
files &mdash; and, for an assembly, <b>one STL per Object</b>
(<code>name-Object.stl</code>, each at its own origin, ready to print
apart; an Object inside a colour or a group counts, and one placed
several times is written once) &mdash; the .scad and .kcad, a source ZIP, preview pictures
painted exactly like the 3D view (your colours, materials, lighting,
platform and shadow) from eight three-quarter angles (the
front-right isometric first, as the cover), a description and the
upload form's answers. It then opens the Printables
upload page; the final upload is yours to click.</p>
"""),

        ("updates", "Updates", f"""
<p>KherveCAD keeps itself up to date from its GitHub releases.</p>
<ul>
<li>An installed copy checks <b>once a day</b>, a few seconds after it
starts. When a newer version exists, a window lists <b>what
changed</b>: the release notes and every improvement since your
version.</li>
<li><b>Download and install</b> fetches it in the background (with a
progress bar you can cancel), then closes KherveCAD, installs and starts
the new version. You are asked to save unsaved work first.</li>
<li><b>Skip this version</b> stops the reminder for that version only;
<b>Later</b> asks again next time.</li>
<li><b>Help &rsaquo; Check for Updates&hellip;</b> checks now;
<b>Help &rsaquo; Check for Updates Automatically</b> turns the daily
check on or off.</li>
</ul>
{figure("dialog_update", "An update is available: what changed, and "
        "the choice to install it.", 620)}
<p>The version number is <b>0.1.<i>N</i></b>, where <i>N</i> counts the
changes made to KherveCAD so far &mdash; it goes up by one with each
change, and the title bar and Help &rsaquo; About show it.</p>
<p class='tip'>A portable copy, or KherveCAD run from its source code,
is not replaced automatically: the update window offers the download
page instead.</p>
"""),

        ("checking", "Checking a part", f"""
<p>The <b>Analyse</b> menu (and the right-click menu of the tree) checks a
part the way a slicer or a CAD package would, before you print or
send it. Each window stays open while you fix things; <b>Check again</b>
re-runs it.</p>
<h3>Mass properties</h3>
<p>Volume, surface area, size, centre of mass and bounding box of the
selected parts (or the whole document), plus the <b>mass</b> for a
chosen material (PLA, PETG, ABS, resin, aluminium, steel&hellip;), its
<b>cost</b> at your price per kilogram, and a <i>rough</i> print time.
The mass is for a solid part; a print with infill weighs less.</p>
<h3>Check for 3D printing</h3>
<p>Four checks, each <span style='color:#2e8b57'><b>PASS</b></span>,
<span style='color:#d08a00'><b>WARN</b></span> or
<span style='color:#c0392b'><b>FAIL</b></span>:</p>
<ul>
<li><b>Watertight</b> &mdash; the surface is closed and consistently
wound. An open edge means a slicer may fill the wrong side or drop the
part; the report says where the first one is.</li>
<li><b>Overhangs</b> &mdash; faces looking down more than the limit (45°
by default) need supports. Re-orient the part, add a chamfer under the
overhang, or accept supports.</li>
<li><b>Wall thickness</b> &mdash; walls thinner than the minimum (0.8 mm,
two extrusion widths) may not print or will snap. Thicken them, or use
a finer nozzle.</li>
<li><b>Footprint</b> &mdash; a tall part on a small base tips or peels
off the plate: lay it flat or add a brim.</li>
</ul>
<p>Tick <b>Show overhangs and thin walls on the model</b> to see the
offending faces tinted in the 3D view.</p>
{figure("print_check", "Check for 3D printing on a T-shaped part: the "
        "underside of the top is an overhang.")}
<h3>Check interference</h3>
<p>Do any two parts overlap? Select two or more parts (or nothing, for
every part in Main) and each pair is reported as <b>clear</b>,
<b>INTERSECT</b> (with a crossing point) or <b>INSIDE / CONTAINS</b>
(one sits wholly inside the other). Two parts that only touch are
clear. Run it after snapping or moving parts.</p>
<p class='tip'><i>Tip:</i> all three work on the mesh the 3D view
shows. Until the exact render lands, a part with a Difference shows its
holes uncut and the figures say so.</p>
"""),

        ("rhino", "Curves, surfaces and other CAD", f"""
<p>Tools from Rhino and the other surface modellers: work with other CAD
programs' files, draw 3D curves and make surfaces from them, shape
smooth forms with a cage, move parts with handles, check surfaces, and
draw what you see.</p>
<h3>Files from other CAD programs</h3>
<ul>
<li><b>Open</b> a STEP, IGES, Rhino (.3dm) or .brep file, or drop it on
the window. It arrives as one Object named after the file, every part a
group with its own name and colour, at its real size. <b>File &rsaquo;
Import CAD File</b> asks one thing more: how smooth to show curved
surfaces (Draft for big assemblies, Fine for renders).</li>
<li><b>File &rsaquo; Export for Other CAD</b> {K("Ctrl+Alt+S")} writes
<b>STEP</b> (Fusion, SolidWorks, Onshape, FreeCAD, Rhino), <b>IGES</b>
or <b>.3dm</b>. Boxes, cylinders, extrusions, revolves, booleans,
curves, surfaces and imported parts go out with <b>exact</b> surfaces,
each part named and coloured, in real millimetres. Shapes with no exact
form go in as faceted solids, and the message after saving names
them.</li>
<li>Right-click an imported part &rsaquo; <b>Make Exact</b> keeps it as
its true surfaces; then <b>Fillet Edges</b> or <b>Chamfer Edges</b>:
type the size and click the edges on the part, Esc when done.</li>
</ul>
<h3>3D curves</h3>
<p><b>Insert &rsaquo; Draw 3D Curve</b> {K("Ctrl+Alt+C")}: click points
in the 3D view. Each point <b>snaps</b>, and the marker says to what
&mdash; Corner, Middle of edge, On edge, On surface, or the ground grid.
Hold <b>Shift</b> to go straight up or down from the last point,
<b>Alt</b> to switch snapping off, or type a point (<i>10, 20, 5</i>,
or <i>@0, 0, 15</i> for 15 above the last). <b>Enter</b> or a
right-click finishes, <b>Backspace</b> takes a point back, <b>C</b>
closes a loop. A curve is a round wire; its points and thickness are in
Properties.</p>
<h3>Surfaces from curves</h3>
<p>Select curves in the tree, in order, and pick <b>Tools &rsaquo;
Surface from Curves</b> (or right-click): <b>Loft</b> through them,
<b>Sweep</b> profiles along a rail (the first curve), <b>Sweep along two
rails</b>, <b>Patch</b> inside a closed curve, <b>Revolve</b> about Z or
<b>Extrude</b> upwards. The surface is exact; an open one is thickened
by its <b>Wall thickness</b> so it prints. The curves move inside it,
so editing a curve reshapes the surface.</p>
<h3>SubD: smooth shapes from a cage</h3>
<p><b>Insert &rsaquo; SubD Box</b>, or select a solid and <b>Tools
&rsaquo; Convert to SubD</b>. Press <b>Tab</b> over the 3D view and Edit
Mode opens the <b>cage</b>: drag its points, <b>E</b> extrudes a face,
and the smooth surface follows. <b>Smoothness</b>, a crease angle and
creased edges are in Properties.</p>
<h3>The Gumball</h3>
<p><b>View &rsaquo; Gumball</b> {K("Ctrl+Alt+G")} puts arrows and rings
on the selected part. Drag an <b>arrow</b> to slide it along that axis,
a <b>ring</b> to turn it about its centre; hold <b>Ctrl</b> to snap to
the grid or to 15°, and press <b>Esc</b> during a drag to put it back.
A drag anywhere else still turns the view.</p>
<h3>Checking surfaces</h3>
<p><b>Analyse &rsaquo; Heat Map</b> has three surface checks besides the
printing ones: <b>Draft angle</b> (red faces are vertical and would
stick in a mould), <b>Curvature</b> (red bulges out, blue dips in) and
<b>Zebra stripes</b> (stripes that run on unbroken across a seam mean a
smooth join; a kink is a crease &mdash; turn the view and press Redraw
to see them again).</p>
<h3>Make 2D</h3>
<p><b>File &rsaquo; Make 2D Drawing of This View</b> saves the model as
clean lines exactly as the 3D view shows it &mdash; SVG, DXF for a laser
cutter, PDF or PNG &mdash; with a title block and a standard scale. Tick
<b>Show hidden edges dashed</b> to see what is behind.</p>
"""),

        ("shortcuts", "Keyboard shortcuts", f"""
<p>On a Mac, {K("Ctrl")} is the {K("&#8984; Cmd")} key.</p>
<table>
<tr><td colspan='2'><b>Tools</b></td></tr>
<tr><td>{K("V")} {K("L")} {K("R")} {K("C")} {K("P")} {K("T")}</td>
<td>Select, Line, Rectangle, Circle, Polygon, Text</td></tr>
<tr><td>{K("M")} {K("D")}</td><td>Measure, Add dimension</td></tr>
<tr><td>{K("J")}</td><td>Snap objects together</td></tr>
<tr><td>{K("Enter")} / {K("Esc")}</td><td>Finish / abandon a polygon;
{K("Esc")} also cancels a snap</td></tr>
<tr><td colspan='2'><b>File</b></td></tr>
<tr><td>{K("Ctrl+N")} {K("Ctrl+O")} {K("Ctrl+S")}</td><td>New, Open,
Save ({K("Ctrl+Shift+S")} Save As, {K("Ctrl+Shift+N")} New
Window)</td></tr>
<tr><td>{K("Ctrl+I")} {K("Ctrl+Shift+I")}</td><td>Import OpenSCAD, Import
mesh</td></tr>
<tr><td>{K("Ctrl+E")} {K("Ctrl+Shift+E")}</td><td>Export OpenSCAD, Export
STL</td></tr>
<tr><td>{K("Ctrl+Alt+E")}</td><td>Export PNG</td></tr>
<tr><td>{K("Ctrl+Shift+P")}</td><td>Publish to Printables</td></tr>
<tr><td colspan='2'><b>Edit</b></td></tr>
<tr><td>{K("Ctrl+Z")} {K("Ctrl+Y")}</td><td>Undo, Redo (also
{K("Ctrl+Shift+Z")})</td></tr>
<tr><td>{K("Ctrl+X")} {K("Ctrl+C")} {K("Ctrl+V")}</td><td>Cut, Copy,
Paste</td></tr>
<tr><td>{K("Ctrl+D")} {K("Delete")}</td><td>Duplicate, Delete</td></tr>
<tr><td>{K("Ctrl+G")} {K("Ctrl+Shift+G")}</td><td>Group, Ungroup</td></tr>
<tr><td>{K("Ctrl+&uarr;")} {K("Ctrl+&darr;")}</td><td>Move up / down in
the tree</td></tr>
<tr><td>{K("Tab")} {K("Shift+Tab")} ({K("A")} {K("Q")})</td><td>Next /
previous object</td></tr>
<tr><td>{K("Space")}</td><td>Hide / show the selection</td></tr>
<tr><td colspan='2'><b>Insert &amp; view</b></td></tr>
<tr><td>{K("Ctrl+Alt+N")}</td><td>New Object</td></tr>
<tr><td>{K("Ctrl+L")}</td><td>Part Library</td></tr>
<tr><td>{K("Ctrl++")} {K("Ctrl+-")} {K("Ctrl+0")}</td><td>Sketch zoom
in, out, reset</td></tr>
<tr><td>{K("Ctrl+Shift+F")} {K("Ctrl+F")}</td><td>Fit sketch, Fit 3D
view</td></tr>
<tr><td>{K("Ctrl+'")} {K("Ctrl+Shift+'")}</td><td>Grid, Snap to
grid</td></tr>
<tr><td>{K("F5")}</td><td>Render with OpenSCAD</td></tr>
<tr><td colspan='2'><b>Other</b></td></tr>
<tr><td>{K("Ctrl+/")}</td><td>ChatBox</td></tr>
<tr><td>{K("Ctrl+K")}</td><td>Git commit</td></tr>
<tr><td>{K("F1")}</td><td>This guide ({K("Ctrl+F")} inside it
searches)</td></tr>
</table>
"""),

        ("troubleshooting", "Troubleshooting", f"""
<h3>A hole or cut does not show</h3>
<p>The instant preview draws a Difference as its first child. Wait for
the badge to read <i>OpenSCAD</i> or <i>n/n parts exact</i>, or press
{K("F5")}. If the status bar says <i>built-in preview</i>, OpenSCAD was
not found: install it, or point to it with <b>Edit &rsaquo; Locate
OpenSCAD&hellip;</b></p>
<h3>Something turned red</h3>
<p>Hover the red row: the tooltip says what is wrong (a typo in an
expression, a 3D solid inside an extrude, a revolve profile crossing
the axis&hellip;). Undo {K("Ctrl+Z")} if you are not sure.</p>
<h3>An operation did nothing</h3>
<p>Operations act on the selection. Select objects first &mdash; in the
Object tab, select them in <i>that</i> tab's tree.</p>
<h3>The model is slow</h3>
<p>Lower <b>Common segments ($fn)</b> in the Main tab (32&ndash;48 is
plenty while designing), or a big shape's own Segments. Orbiting a large
model shows a lighter draft and snaps back to full detail when you let
go.</p>
<h3>The 3D view looks wrong</h3>
<p>Press <b>Redraw</b> (&#x27F3;) on the lighting bar, or
<b>Fit 3D</b> if the model is out of view.</p>
<h3>An assistant cannot see KherveCAD</h3>
<p>Check that <b>Let assistants connect</b> is ticked in AI &rsaquo;
Connect to Claude, that the application was restarted after
<b>Connect</b>, and mention KherveCAD in the chat.</p>
<h3>KherveCAD crashed</h3>
<p>A report is written to <code>khervecad_crash.log</code> in your
temporary folder (<code>%TEMP%</code> on Windows). Please attach it when
you report the problem.</p>
"""),
    ]
